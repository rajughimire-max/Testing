
import React, { useState, useEffect } from 'react';
import { Player, Team } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Users, Star, Phone, Mail, MapPin, Search, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function LoanPlayers() {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [positionFilter, setPositionFilter] = useState('all');
  const [loanTypeFilter, setLoanTypeFilter] = useState('all');

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [playersData, teamsData] = await Promise.all([
          Player.filter({ is_available_for_loan: true, is_publicly_visible: true }, 'last_name'),
          Team.list()
        ]);
        setPlayers(playersData);
        setTeams(teamsData);
      } catch (error) {
        console.error("Error loading loan players:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const calculateAge = (dateOfBirth) => {
    if (!dateOfBirth) return 'N/A';
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const filteredPlayers = players.filter(player => {
    const searchMatch = !searchTerm || 
      `${player.first_name} ${player.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      player.position?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const positionMatch = positionFilter === 'all' || player.position === positionFilter;
    const loanTypeMatch = loanTypeFilter === 'all' || player.loan_availability === loanTypeFilter;
    
    return searchMatch && positionMatch && loanTypeMatch;
  });

  const PlayerCard = ({ player, delay = 0 }) => {
    const team = teams.find(t => t.id === player.team_id);

    return (
      <div 
        className="animate-in fade-in slide-in-from-bottom-4 duration-500"
        style={{ animationDelay: `${delay}ms` }}
      >
        <Card className="group bg-white shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 rounded-xl overflow-hidden border-0">
          <CardContent className="p-6">
            <div className="text-center mb-4">
              {(player.profile_photo_url || player.photo_url) ? (
                <img
                  src={player.profile_photo_url || player.photo_url}
                  alt={`${player.first_name} ${player.last_name}`}
                  className="w-24 h-24 rounded-full object-cover mx-auto mb-3 border-4 border-red-200 group-hover:border-red-400 transition-colors"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center mx-auto mb-3">
                  <Users className="w-10 h-10 text-red-400" />
                </div>
              )}
              
              <div className="flex items-center justify-center gap-2 mb-2">
                <Badge className="bg-red-600 text-white font-bold">
                  #{player.preferred_number}
                </Badge>
                <Badge className="bg-green-100 text-green-800">
                  AVAILABLE
                </Badge>
              </div>
              
              <h3 className="text-xl font-bold text-slate-900 mb-1">
                {player.first_name} {player.last_name}
              </h3>
              
              {player.position && (
                <p className="text-red-600 font-semibold mb-2">
                  {player.position}
                </p>
              )}

              <p className="text-slate-600 text-sm">
                Age: {calculateAge(player.date_of_birth)}
              </p>
            </div>
            
            <div className="space-y-3 text-sm">
              {team && (
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: team.team_color || '#64748b' }}
                  ></div>
                  <span className="font-medium">{team.name}</span>
                </div>
              )}

              {player.height && player.weight && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Physical:</span>
                  <span>{player.height}cm, {player.weight}kg</span>
                </div>
              )}

              {player.playing_foot && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Playing Foot:</span>
                  <span>{player.playing_foot}</span>
                </div>
              )}

              {player.loan_availability && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Availability:</span>
                  <Badge variant="outline">{player.loan_availability}</Badge>
                </div>
              )}

              {player.loan_fee && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Loan Fee:</span>
                  <span className="font-semibold text-green-600">AUD ${player.loan_fee}</span>
                </div>
              )}

              {player.strengths && player.strengths.length > 0 && (
                <div className="pt-2 border-t border-slate-200">
                  <p className="text-slate-500 text-xs mb-1">Key Strengths:</p>
                  <div className="flex flex-wrap gap-1">
                    {player.strengths.slice(0, 3).map((strength, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">{strength}</Badge>
                    ))}
                    {player.strengths.length > 3 && (
                      <Badge variant="secondary" className="text-xs">+{player.strengths.length - 3} more</Badge>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            <div className="mt-6 pt-4 border-t border-slate-200">
              <Link to={createPageUrl(`PlayerBio?playerId=${player.id}`)}>
                <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                  View Full Profile
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="bg-black text-white min-h-screen">
      <div className="relative py-24 bg-gradient-to-r from-red-900/50 to-black">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black tracking-tight mb-4">LOAN PLAYERS</h1>
          <p className="text-lg text-gray-300">Available talent for your team</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Filters */}
        <div className="bg-white rounded-xl p-6 mb-8 shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by name or position..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-black"
              />
            </div>
            
            <Select value={positionFilter} onValueChange={setPositionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Positions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Positions</SelectItem>
                <SelectItem value="GK">Goalkeeper</SelectItem>
                <SelectItem value="DF">Defender</SelectItem>
                <SelectItem value="MF">Midfielder</SelectItem>
                <SelectItem value="FW">Forward</SelectItem>
              </SelectContent>
            </Select>

            <Select value={loanTypeFilter} onValueChange={setLoanTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Loan Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Loan Types</SelectItem>
                <SelectItem value="Single game">Single Game</SelectItem>
                <SelectItem value="Tournament">Tournament</SelectItem>
                <SelectItem value="Season loan">Season Loan</SelectItem>
                <SelectItem value="Flexible">Flexible</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center text-black">
              <Filter className="w-4 h-4 mr-2" />
              <span className="text-sm">{filteredPlayers.length} player{filteredPlayers.length !== 1 ? 's' : ''} available</span>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="h-12 w-12 animate-spin text-red-600" />
          </div>
        ) : (
          <>
            {filteredPlayers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredPlayers.map((player, index) => (
                  <PlayerCard key={player.id} player={player} delay={index * 50} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <div className="w-24 h-24 bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="w-12 h-12 text-red-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4">No loan players available</h3>
                <p className="text-gray-400">Check back later or adjust your search criteria.</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
