
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { GeneratedContract, SponsorshipApplication, SponsorshipTier } from '@/api/entities';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from "@/components/ui/checkbox";
import { signContract } from '@/api/functions';
import { createPaymentSession } from '@/api/functions';
import { redirectToStripeCheckout } from '../components/stripe/StripeLoader';
import { ShieldCheck, FileText, UserCheck, AlertTriangle, Loader2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function SignSponsorshipContract() {
  const location = useLocation();
  const [contract, setContract] = useState(null);
  const [application, setApplication] = useState(null);
  const [tier, setTier] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSigned, setIsSigned] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [signerName, setSignerName] = useState('');
  const [declarationAgreed, setDeclarationAgreed] = useState(false);

  useEffect(() => {
    const fetchContractData = async () => {
      const params = new URLSearchParams(location.search);
      const contractId = params.get('contractId');
      
      if (!contractId) {
        setError('No contract ID provided.');
        setLoading(false);
        return;
      }
      
      try {
        const contractData = await GeneratedContract.get(contractId);
        if (!contractData) throw new Error("Contract not found.");

        const appData = await SponsorshipApplication.get(contractData.application_id);
        if (!appData) throw new Error("Sponsorship application not found.");

        const tierData = await SponsorshipTier.get(appData.sponsorship_tier_id);
        if (!tierData) throw new Error("Sponsorship tier details not found.");

        // All data is loaded, now set the state
        setContract(contractData);
        setApplication(appData);
        setTier(tierData);

        if (contractData.status === 'signed' || contractData.status === 'completed') {
          setIsSigned(true);
        }
        
        if (appData.contact_person) {
          setSignerName(appData.contact_person);
        }
      } catch (err) {
        console.error("Error fetching contract details:", err);
        setError(err.message || 'Could not load the contract. It might be invalid or expired.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchContractData();
  }, [location]);

  const handleSign = async () => {
    if (!signerName.trim()) {
      toast.error("Please enter your full name to sign the contract.");
      return;
    }

    if (!declarationAgreed) {
      toast.error("You must agree to the declaration before signing.");
      return;
    }

    setProcessing(true);
    try {
      const { data } = await signContract({
        contractId: contract.id,
        sponsorSignature: signerName.trim(),
      });

      toast.success("Contract signed successfully!");
      setContract(data.contract);
      setIsSigned(true);
    } catch (error) {
      console.error("Error signing contract:", error);
      toast.error("Failed to sign contract. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const handlePayment = async () => {
    setProcessing(true);
    try {
      // Robustly determine the payment amount
      const sponsorshipAmount = application?.custom_amount > 0 
        ? application.custom_amount 
        : tier?.minimum_amount;

      if (!sponsorshipAmount || sponsorshipAmount <= 0) {
        toast.error("Sponsorship amount is invalid or missing. Cannot proceed to payment. Please contact the club administrator.");
        setProcessing(false);
        return; // Stop execution to prevent sending a bad request
      }

      const paymentData = {
        type: 'sponsorship',
        applicationId: application.id,
        custom_amount: sponsorshipAmount,
        payment_plan: application.payment_preference,
        installment_count: application.installment_months,
      };

      const { data } = await createPaymentSession(paymentData);

      if (data.url) {
        await redirectToStripeCheckout({ sessionId: data.id, checkoutUrl: data.url });
      } else {
        throw new Error('Failed to retrieve checkout URL.');
      }
    } catch (error) {
      console.error("Error creating payment session:", error);
      toast.error("Failed to create payment session: " + (error.response?.data?.error || error.message));
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-slate-600">Loading contract...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-6">
        <Alert className="max-w-md border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertTitle className="text-red-800">Contract Error</AlertTitle>
          <AlertDescription className="text-red-700">{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-blue-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="text-center mb-8">
          <div className="inline-block bg-white p-4 rounded-full shadow-md mb-4">
            <FileText className="w-10 h-10 text-red-600" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900">Sponsorship Agreement</h1>
          <p className="text-slate-600 mt-2">Please review and sign your sponsorship contract with Nepbourne FC.</p>
        </div>

        <Card className="shadow-xl bg-white border-slate-200 mb-6">
          <CardHeader className="bg-slate-50 border-b border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <ShieldCheck className="w-5 h-5 text-green-600" />
                  Contract Details
                </CardTitle>
                <p className="text-slate-600 mt-1">
                  {application?.company_name} • {tier?.name} Sponsorship
                </p>
              </div>
              <Badge variant={isSigned ? "default" : "secondary"} className="px-4 py-2 text-sm">
                {isSigned ? "Signed" : "Awaiting Signature"}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
             <div 
                className="contract-display-area"
                dangerouslySetInnerHTML={{ __html: contract?.contract_content || '' }}
              />
          </CardContent>
        </Card>

        {/* Signature & Payment Section */}
        {!isSigned ? (
          <Card className="mb-6 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Sign & Complete</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold text-blue-900">Declaration</h4>
                  <div className="flex items-start space-x-3">
                    <Checkbox id="declaration" checked={declarationAgreed} onCheckedChange={setDeclarationAgreed} />
                    <Label htmlFor="declaration" className="text-sm font-normal text-blue-800">
                      I declare that I have read, understood, and agree to the terms of this Sponsorship Agreement and have the authority to sign on behalf of the Sponsor.
                    </Label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signerName">Type Full Name to Sign</Label>
                  <Input 
                    id="signerName"
                    value={signerName}
                    onChange={e => setSignerName(e.target.value)}
                    disabled={!declarationAgreed || processing}
                    placeholder="e.g., Jane Smith"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleSign}
                disabled={!declarationAgreed || !signerName.trim() || processing}
                className="w-full bg-indigo-600 hover:bg-indigo-700 py-3 text-lg"
              >
                {processing ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <UserCheck className="w-5 h-5 mr-2" />}
                {processing ? 'Processing...' : 'Sign Agreement'}
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <Card className="bg-green-50 border-green-200 text-center">
            <CardHeader>
              <CardTitle className="flex items-center justify-center gap-3 text-2xl text-green-900">
                <CheckCircle className="w-8 h-8" />
                Contract Signed! What's next?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-green-800 text-lg">
                Thank you for your sponsorship! The final step is to complete the payment. You will receive a copy of the signed contract via email.
              </p>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handlePayment} 
                disabled={processing || !application || !tier}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-3 text-lg"
              >
                {processing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Proceed to Payment
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>

      <style jsx>{`
        .contract-display-area {
          font-family: ui-monospace, Menlo, Monaco, "Courier New", monospace;
          white-space: pre-wrap;
          word-wrap: break-word;
          font-size: 0.875rem;
          line-height: 1.6;
          color: #334155;
          background-color: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 0.5rem;
          padding: 1.5rem;
          min-height: 500px;
        }
      `}</style>
    </div>
  );
}
