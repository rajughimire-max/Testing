
import React, { useState, useEffect } from 'react';
import { Event, SocialGameSettings } from '@/api/entities';
import { submitSocialGameSignup } from '@/api/functions';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format, parseISO, isAfter, isBefore } from 'date-fns';
import { Calendar, Clock, MapPin, CheckCircle, ArrowLeft, Gamepad2, UserPlus, Info, Users } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function SocialGamesPage() {
  const [settings, setSettings] = useState(null);
  const [allGames, setAllGames] = useState([]);
  const [activeTab, setActiveTab] = useState('upcoming');
  const [showRegistration, setShowRegistration] = useState(false);
  const [selectedGame, setSelectedGame] = useState(null);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    ethnicity: '',
    skills_level: '',
    notes: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadPageData();
  }, []);

  const loadPageData = async () => {
    setLoading(true);
    try {
      const [settingsData, gamesData] = await Promise.all([
        SocialGameSettings.list(),
        Event.filter({ is_social_game: true }, '-event_date')
      ]);

      if (settingsData.length > 0) {
        setSettings(settingsData[0]);
      }
      
      // Sort games by date, newest first
      const sortedGames = gamesData.sort((a, b) => new Date(b.event_date) - new Date(a.event_date));
      setAllGames(sortedGames);
    } catch (error) {
      console.error("Error loading social games data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterClick = (game) => {
    const now = new Date();
    // Combine event_date and end_time to get the exact end moment
    const gameEndDateTime = new Date(`${game.event_date}T${game.end_time}:00`);
    
    // Check if game has already ended (past the end time)
    if (isBefore(gameEndDateTime, now) || gameEndDateTime.getTime() <= now.getTime()) {
      alert("Registration is not available for completed games.");
      return;
    }
    
    setSelectedGame(game);
    setShowRegistration(true);
  };

  const handleFormChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formData.ethnicity !== 'Nepali') {
      alert('Sorry, social games are currently only available for Nepali community members.');
      return;
    }
    
    setSubmitting(true);
    
    try {
      const registrationData = {
        ...formData,
        event_id: selectedGame.id,
        experience_level: formData.skills_level,
        availability: 'Both',
        code_of_conduct_accepted: true,
        marketing_opt_in: false
      };
      
      await submitSocialGameSignup(registrationData);
      setSubmitted(true);
    } catch (error) {
      console.error("Error submitting registration:", error);
      alert("Failed to submit registration. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setShowRegistration(false);
    setSelectedGame(null);
    setSubmitted(false);
    setFormData({
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      ethnicity: '',
      skills_level: '',
      notes: ''
    });
  };

  // Helper function to check if a game is completed (now is after its end time)
  const isGameCompleted = (game) => {
    const now = new Date();
    const gameEndDateTime = new Date(`${game.event_date}T${game.end_time}:00`);
    return isBefore(gameEndDateTime, now) || gameEndDateTime.getTime() <= now.getTime();
  };

  // Helper function to check if a game's end time is still in the future (i.e., not completed yet)
  const isGameUpcoming = (game) => { // Note: This means 'not yet completed', so includes in-progress games
    const now = new Date();
    const gameEndDateTime = new Date(`${game.event_date}T${game.end_time}:00`);
    return isAfter(gameEndDateTime, now);
  };

  // Filter games by tab with proper time checking
  const getFilteredGamesByTab = () => {
    switch (activeTab) {
      case 'upcoming':
        return allGames.filter(g => isGameUpcoming(g)); // Show games that are not yet completed
      case 'completed':
        return allGames.filter(g => isGameCompleted(g));
      case 'all':
      default:
        return allGames;
    }
  };

  // These variables are used for tab counts
  const upcomingGames = allGames.filter(g => isGameUpcoming(g)); // All games not yet completed
  const completedGames = allGames.filter(g => isGameCompleted(g));

  const renderGameCard = (game, index) => {
    const now = new Date();
    const gameStartDateTime = new Date(`${game.event_date}T${game.start_time}:00`);
    const gameEndDateTime = new Date(`${game.event_date}T${game.end_time}:00`);

    const isCurrentlyCompleted = isBefore(gameEndDateTime, now) || gameEndDateTime.getTime() <= now.getTime();
    const isCurrentlyNotStarted = isAfter(gameStartDateTime, now);
    const isCurrentlyInProgress = !isCurrentlyCompleted && !isCurrentlyNotStarted;

    return (
      <div 
        key={game.id} 
        className="animate-in fade-in slide-in-from-bottom-4 duration-500"
        style={{ animationDelay: `${index * 100}ms` }}
      >
        <Card className={`shadow-md hover:shadow-lg transition-shadow duration-300 rounded-xl overflow-hidden h-full flex flex-col ${
          isCurrentlyCompleted ? 'bg-gray-50 text-gray-600' : 'bg-white text-gray-900'
        }`}>
          <CardHeader>
            <div className="flex justify-between items-start gap-4">
              <CardTitle className={`text-2xl font-bold ${isCurrentlyCompleted ? 'text-gray-500' : 'text-red-600'}`}>
                {game.title}
              </CardTitle>
              <div className="flex gap-2">
                <Badge variant="outline" className={isCurrentlyCompleted ? "border-gray-400 text-gray-500" : "border-red-600 text-red-600"}>
                  {format(parseISO(game.event_date), 'EEE, d MMM')}
                </Badge>
                {isCurrentlyCompleted && (
                  <Badge className="bg-gray-500 text-white">Completed</Badge>
                )}
                {isCurrentlyNotStarted && (
                  <Badge className="bg-green-500 text-white">Upcoming</Badge>
                )}
                {isCurrentlyInProgress && (
                  <Badge className="bg-orange-500 text-white">In Progress</Badge>
                )}
              </div>
            </div>
            <div className={`flex flex-wrap items-center gap-x-6 gap-y-2 pt-2 text-sm ${isCurrentlyCompleted ? 'text-gray-500' : 'text-gray-600'}`}>
              <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" /> {game.start_time} - {game.end_time}</span>
              <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /> {game.venue}</span>
            </div>
          </CardHeader>
          {game.description && (
            <CardContent className="flex-grow">
              <p className={`whitespace-pre-wrap ${isCurrentlyCompleted ? 'text-gray-600' : 'text-gray-700'}`}>{game.description}</p>
            </CardContent>
          )}
          <CardFooter className={`p-6 mt-auto ${isCurrentlyCompleted ? 'bg-gray-100' : 'bg-gray-50'}`}>
            {isCurrentlyCompleted ? (
              <div className="w-full text-center">
                <p className="text-gray-500 text-sm">This game has ended. Registration is no longer available.</p>
              </div>
            ) : isCurrentlyNotStarted ? (
              <Button onClick={() => handleRegisterClick(game)} className="bg-red-600 hover:bg-red-700 w-full">
                <UserPlus className="w-4 h-4 mr-2" />Register Now
              </Button>
            ) : ( // Game is in progress
              <div className="w-full text-center">
                <p className="text-orange-600 text-sm font-medium">Game is currently in progress. Registration is closed.</p>
              </div>
            )}
          </CardFooter>
        </Card>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black p-8">
        <div className="max-w-7xl mx-auto">
          <Skeleton className="h-16 w-1/2 mb-4 bg-gray-800" />
          <Skeleton className="h-8 w-3/4 mb-12 bg-gray-800" />
          <div className="space-y-6">
            <Skeleton className="h-48 w-full bg-gray-900" />
            <Skeleton className="h-48 w-full bg-gray-900" />
          </div>
        </div>
      </div>
    );
  }

  if (showRegistration && selectedGame) {
    // Double-check that registration is still allowed before showing the form
    const now = new Date();
    const gameEndDateTime = new Date(`${selectedGame.event_date}T${selectedGame.end_time}:00`);
    
    if (isBefore(gameEndDateTime, now) || gameEndDateTime.getTime() <= now.getTime()) {
      // Game has ended while user was on the page, redirect back
      alert("Sorry, this game has ended and registration is no longer available.");
      resetForm();
      return null;
    }

    if (submitted) {
      return (
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <Card className="bg-gray-900 text-white w-full max-w-2xl text-center shadow-2xl shadow-green-500/20 border-gray-700">
            <CardContent className="p-12">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold mb-4">Registration Successful!</h1>
              <p className="text-xl text-gray-300 mb-8">
                You're all set for the social game on {format(parseISO(selectedGame.event_date), 'EEEE, MMMM d, yyyy')}
              </p>
              
              <div className="bg-red-900/50 border border-red-700 rounded-lg p-6 mb-8 text-left">
                <h3 className="text-lg font-semibold text-red-100 mb-3">Join The Club!</h3>
                <p className="text-red-200 mb-4">
                  Enjoy our social games? Become an official member for access to all club activities, events, and more!
                </p>
                <Link to={createPageUrl('MembershipSignup')} className="w-full">
                  <Button className="w-full bg-red-600 hover:bg-red-500 text-white text-lg py-3">
                    Become a Member
                  </Button>
                </Link>
              </div>

              {settings?.whatsapp_group_invite_url && (
                <div className="mb-6">
                  <a href={settings.whatsapp_group_invite_url} target="_blank" rel="noopener noreferrer">
                    <Button className="bg-green-600 hover:bg-green-500 mb-4">
                      Join WhatsApp Group
                    </Button>
                  </a>
                </div>
              )}
              
              <Button onClick={resetForm} variant="outline" className="bg-gray-700 border-gray-600 hover:bg-gray-600">
                Back to Games
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-black p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <Button onClick={resetForm} variant="outline" className="mb-6 bg-gray-800 border-gray-700 text-white hover:bg-gray-700 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Games
          </Button>
          
          <Card className="bg-white text-black border-gray-200 shadow-2xl">
            <CardHeader>
              <CardTitle className="text-3xl font-bold">Join Social Game</CardTitle>
              <CardDescription className="text-gray-600 pt-2 text-base">
                {selectedGame.title} on {format(parseISO(selectedGame.event_date), 'EEEE, MMMM d, yyyy')}
              </CardDescription>
              <div className="flex flex-wrap gap-x-6 gap-y-2 pt-4 text-gray-700">
                <div className="flex items-center"><Clock className="w-4 h-4 mr-2" />{selectedGame.start_time} - {selectedGame.end_time}</div>
                <div className="flex items-center"><MapPin className="w-4 h-4 mr-2" />{selectedGame.venue}</div>
              </div>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="first_name">First Name</Label>
                    <Input id="first_name" value={formData.first_name} onChange={e => handleFormChange('first_name', e.target.value)} required />
                  </div>
                  <div>
                    <Label htmlFor="last_name">Last Name</Label>
                    <Input id="last_name" value={formData.last_name} onChange={e => handleFormChange('last_name', e.target.value)} required />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" value={formData.email} onChange={e => handleFormChange('email', e.target.value)} required />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" value={formData.phone} onChange={e => handleFormChange('phone', e.target.value)} required />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                   <div>
                    <Label htmlFor="ethnicity">Ethnicity</Label>
                    <Select onValueChange={(value) => handleFormChange('ethnicity', value)} value={formData.ethnicity}>
                      <SelectTrigger><SelectValue placeholder="Select ethnicity..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Nepali">Nepali</SelectItem>
                        <SelectItem value="Australian">Australian</SelectItem>
                        <SelectItem value="Indian">Indian</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="skills_level">Skill Level</Label>
                    <Select onValueChange={(value) => handleFormChange('skills_level', value)} value={formData.skills_level}>
                      <SelectTrigger><SelectValue placeholder="Select skill level..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Beginner">Beginner</SelectItem>
                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                        <SelectItem value="Advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                 <div>
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea id="notes" value={formData.notes} onChange={e => handleFormChange('notes', e.target.value)} placeholder="Anything else we should know?"/>
                </div>

                {formData.ethnicity && formData.ethnicity !== 'Nepali' && (
                  <div className="bg-yellow-100 border border-yellow-300 text-yellow-800 p-4 rounded-lg flex items-center gap-3">
                    <Info className="w-5 h-5 flex-shrink-0" />
                    <span>Please note: Social games are currently prioritized for the Nepali community.</span>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={submitting || formData.ethnicity !== 'Nepali'} className="bg-red-600 hover:bg-red-700 text-white"><UserPlus className="w-4 h-4 mr-2" />{submitting ? 'Submitting...' : 'Confirm Registration'}</Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="relative py-24 bg-gradient-to-r from-red-900/50 to-black">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-red-600 to-red-800 rounded-2xl flex items-center justify-center shadow-lg mx-auto mb-6">
              <Users className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-black tracking-tight text-white">
            SOCIAL GAMES
          </h1>
          <p className="mt-4 text-lg max-w-3xl mx-auto text-gray-300">
            Join our friendly weekly football games. A great way to stay active, meet new people, and enjoy the beautiful game. Open to all skill levels in the Nepali community.
          </p>
        </div>
      </div>

      {/* Games List with Tabs */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 bg-gray-900 border-gray-700">
            <TabsTrigger value="upcoming" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Upcoming ({upcomingGames.length})
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Completed ({completedGames.length})
            </TabsTrigger>
            <TabsTrigger value="all" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              All Games ({allGames.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            <div className="grid gap-8 lg:grid-cols-2">
              {upcomingGames.length > 0 ? getFilteredGamesByTab().map((game, index) => renderGameCard(game, index)) : (
                <div className="lg:col-span-2 text-center py-16">
                  <div className="flex flex-col items-center gap-4">
                    <Info className="w-16 h-16 text-gray-500" />
                    <h3 className="text-2xl font-semibold text-gray-300">No Upcoming Games Scheduled</h3>
                    <p className="max-w-lg text-gray-400">
                      New social game schedules are released weekly. Please check back soon for the next game!
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="completed">
            <div className="grid gap-8 lg:grid-cols-2">
              {completedGames.length > 0 ? getFilteredGamesByTab().map((game, index) => renderGameCard(game, index)) : (
                <div className="lg:col-span-2 text-center py-16">
                  <div className="flex flex-col items-center gap-4">
                    <Info className="w-16 h-16 text-gray-500" />
                    <h3 className="text-2xl font-semibold text-gray-300">No Completed Games</h3>
                    <p className="max-w-lg text-gray-400">
                      Completed games will appear here after they finish.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="all">
            <div className="grid gap-8 lg:grid-cols-2">
              {allGames.length > 0 ? getFilteredGamesByTab().map((game, index) => renderGameCard(game, index)) : (
                <div className="lg:col-span-2 text-center py-16">
                  <div className="flex flex-col items-center gap-4">
                    <Info className="w-16 h-16 text-gray-500" />
                    <h3 className="text-2xl font-semibold text-gray-300">No Games Found</h3>
                    <p className="max-w-lg text-gray-400">
                      No social games have been scheduled yet.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
