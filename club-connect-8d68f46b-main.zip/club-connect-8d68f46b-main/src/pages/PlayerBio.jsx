import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Users, Star, ArrowLeft, Calendar, Trophy, Zap, Award, Activity, Shirt, Footprints, Scale, ShieldCheck, Heart, Shield, BarChart, TrendingUp, DollarSign } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { getPublicPlayerBio } from '@/api/functions';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

export default function PlayerBio() {
  const [player, setPlayer] = useState(null);
  const [team, setTeam] = useState(null);
  const [uniforms, setUniforms] = useState([]);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const urlParams = new URLSearchParams(location.search);
        const playerId = urlParams.get('playerId');
        
        if (!playerId) {
          setLoading(false);
          return;
        }

        const { data } = await getPublicPlayerBio({ playerId });

        if (data.success) {
          setPlayer(data.player);
          setTeam(data.team);
          setUniforms(data.uniforms);
        } else {
          console.error("Failed to load player data:", data.error);
          setPlayer(null);
        }

      } catch (error) {
        console.error("Error loading player bio:", error);
        setPlayer(null);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [location.search]);

  const calculateAge = (dateOfBirth) => {
    if (!dateOfBirth) return 'N/A';
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  if (loading) {
    return (
      <div className="bg-black text-white min-h-screen p-8">
        <Skeleton className="h-[50vh] w-full rounded-lg" />
        <div className="mt-8 grid md:grid-cols-3 gap-8">
          <Skeleton className="h-64 w-full rounded-lg md:col-span-2" />
          <Skeleton className="h-64 w-full rounded-lg" />
        </div>
      </div>
    );
  }

  if (!player) {
    return (
      <div className="bg-black text-white min-h-screen flex flex-col items-center justify-center text-center p-8">
        <Users className="w-24 h-24 text-red-500 mb-6" />
        <h1 className="text-4xl font-bold mb-4">Player Not Found</h1>
        <p className="text-lg text-gray-400">
          This player profile could not be found or is not publicly available.
        </p>
      </div>
    );
  }

  const heroImage = player.hero_photo_1_url || player.profile_photo_url;
  const heroPosition = player.hero_photo_css_position || 'center';

  return (
    <div className="bg-slate-900 text-white min-h-screen">
      <div 
        className="relative h-[60vh] bg-cover bg-no-repeat"
        style={{ 
          backgroundImage: `url(${heroImage})`,
          backgroundPosition: heroPosition 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/70 to-transparent"></div>
        <div className="absolute top-6 left-6 z-20">
          <Link to={createPageUrl('Squad')}>
            <Button variant="secondary" className="bg-black/60 border-white/20 text-white hover:bg-black/80 backdrop-blur-sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Squad
            </Button>
          </Link>
        </div>
      </div>

      <div className="relative -mt-48 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:flex lg:items-end lg:gap-8">
            <div className="flex-shrink-0">
              {(player.profile_photo_url || player.photo_url) && (
                <div className="relative group">
                   <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-full overflow-hidden border-4 border-slate-700 shadow-2xl bg-slate-800">
                    <img
                      src={player.profile_photo_url || player.photo_url}
                      alt={`${player.first_name} ${player.last_name}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -bottom-4 -right-4">
                     <div className="bg-red-600 text-white text-4xl font-bold w-20 h-20 rounded-full flex items-center justify-center border-4 border-slate-900 shadow-lg">
                       {player.preferred_number}
                     </div>
                  </div>
                </div>
              )}
            </div>
            <div className="mt-6 lg:mt-0">
              <h1 className="text-5xl sm:text-6xl font-black tracking-tight text-shadow-lg">
                {player.first_name} {player.last_name}
              </h1>
              <div className="flex flex-wrap items-center gap-4 mt-4">
                {player.position && (
                  <Badge className="bg-red-600/90 text-white text-xl px-6 py-2 font-bold backdrop-blur-sm">
                    {player.position}
                  </Badge>
                )}
                {team && (
                  <Badge 
                    className="text-xl px-6 py-2 font-bold backdrop-blur-sm border-2"
                    style={{ 
                      backgroundColor: `${team.team_color}20`,
                      borderColor: team.team_color,
                      color: team.team_color || '#fff'
                    }}
                  >
                    {team.name}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Main Details */}
            <div className="lg:col-span-2 space-y-8">
              {player.club_experience && (
                <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white">
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold mb-4 text-red-400">About the Player</h3>
                    <p className="text-lg text-slate-300 leading-relaxed whitespace-pre-wrap">{player.club_experience}</p>
                  </CardContent>
                </Card>
              )}
              
              {player.strengths && player.strengths.length > 0 && (
                <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white">
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold mb-4 text-yellow-400 flex items-center gap-2">
                        <Zap className="w-6 h-6" /> Key Strengths
                    </h3>
                    <div className="flex flex-wrap gap-3">
                      {player.strengths.map((strength, index) => (
                        <Badge key={index} className="bg-blue-600/80 text-white px-4 py-2 text-base backdrop-blur-sm">
                          {strength}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {player.achievements && player.achievements.length > 0 && (
                <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white">
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold mb-4 text-green-400 flex items-center gap-2">
                        <Trophy className="w-6 h-6" /> Achievements & Awards
                    </h3>
                    <ul className="space-y-3">
                      {player.achievements.map((achievement, index) => (
                        <li key={index} className="flex items-start gap-3 text-lg">
                          <Star className="w-5 h-5 text-green-400 flex-shrink-0 mt-1" />
                          <span className="text-slate-300">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {player.hero_photo_2_url && (
                 <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white overflow-hidden">
                   <CardContent className="p-0">
                     <img src={player.hero_photo_2_url} alt="Action Shot" className="w-full h-auto object-cover"/>
                   </CardContent>
                 </Card>
              )}

              {uniforms.length > 0 && (
                <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white">
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold mb-4 text-purple-400 flex items-center gap-2">
                      <Shirt className="w-6 h-6" /> Assigned Uniforms
                    </h3>
                    <Carousel
                      opts={{
                        align: "start",
                      }}
                      className="w-full max-w-sm mx-auto sm:max-w-none"
                    >
                      <CarouselContent>
                        {uniforms.map((uniform, index) => (
                          <CarouselItem key={index} className="basis-full sm:basis-1/2 md:basis-1/2 lg:basis-1/3">
                            <div className="p-1">
                              <Card className="bg-slate-700/50 border-slate-600">
                                <CardContent className="flex flex-col items-center justify-center p-6 space-y-3">
                                  {uniform.item_image_url ? (
                                    <img src={uniform.item_image_url} alt={uniform.itemName} className="h-24 w-24 object-contain mb-2" />
                                  ) : (
                                    <Shirt className="h-24 w-24 text-gray-400 mb-2" />
                                  )}
                                  <h4 className="text-lg font-bold text-white text-center">{uniform.itemName}</h4>
                                  <Badge className="bg-gray-600 text-white text-sm">Issued: {new Date(uniform.assigned_date).toLocaleDateString()}</Badge>
                                </CardContent>
                              </Card>
                            </div>
                          </CarouselItem>
                        ))}
                      </CarouselContent>
                      <CarouselPrevious />
                      <CarouselNext />
                    </Carousel>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Right Column - Vitals & Status */}
            <div className="lg:col-span-1 space-y-8">
              <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold mb-6 text-blue-400">Player Vitals</h3>
                  <div className="space-y-5">
                    <div className="flex items-center gap-4"><Calendar className="w-5 h-5 text-slate-400" /><span className="text-slate-300">Age:</span> <span className="font-bold text-lg">{calculateAge(player.date_of_birth)}</span></div>
                    {player.height && <div className="flex items-center gap-4"><Activity className="w-5 h-5 text-slate-400" /><span className="text-slate-300">Height:</span> <span className="font-bold text-lg">{player.height} cm</span></div>}
                    {player.weight && <div className="flex items-center gap-4"><Scale className="w-5 h-5 text-slate-400" /><span className="text-slate-300">Weight:</span> <span className="font-bold text-lg">{player.weight} kg</span></div>}
                    {player.playing_foot && <div className="flex items-center gap-4"><Footprints className="w-5 h-5 text-slate-400" /><span className="text-slate-300">Foot:</span> <span className="font-bold text-lg">{player.playing_foot}</span></div>}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white">
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold mb-6 text-green-400">Status</h3>
                  <div className="space-y-5">
                    <div className="flex items-center gap-4">
                      <ShieldCheck className="w-5 h-5 text-slate-400" />
                      <span className="text-slate-300">Fitness:</span>
                      <Badge className={`font-bold text-lg px-4 py-1 ${
                        player.status === 'fit' ? 'bg-green-600' : 
                        player.status === 'injured' ? 'bg-red-600' : 'bg-yellow-600'
                      }`}>
                        {player.status}
                      </Badge>
                    </div>
                    {player.is_available_for_loan && (
                       <div className="space-y-3 pt-4 border-t border-slate-700">
                          <h4 className="text-lg font-bold text-green-400 flex items-center gap-2"><Award className="w-5 h-5" /> On Loan Market</h4>
                          <div>
                            <label className="text-sm text-slate-400">Availability</label>
                            <p className="font-semibold text-lg">{player.loan_availability}</p>
                          </div>
                          {player.loan_fee && (
                            <div>
                              <label className="text-sm text-slate-400">Loan Fee</label>
                              <p className="text-2xl font-bold text-green-300">AUD ${player.loan_fee}</p>
                            </div>
                          )}
                       </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .text-shadow-lg {
          text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.7);
        }
      `}</style>
    </div>
  );
}