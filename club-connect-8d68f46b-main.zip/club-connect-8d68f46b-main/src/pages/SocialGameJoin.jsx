import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { submitSocialGameSignup } from '@/api/functions';
import { Event } from '@/api/entities';
import { format, parseISO, isAfter } from 'date-fns';
import { ShieldCheck, Loader2 } from 'lucide-react';

export default function SocialGameJoin() {
  const [formData, setFormData] = useState({
    event_id: '',
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    ethnicity: 'Nepali',
    skills_level: '',
    notes: '',
    code_of_conduct_accepted: false,
  });
  const [upcomingGames, setUpcomingGames] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingGames, setLoadingGames] = useState(true);

  useEffect(() => {
    const fetchUpcomingGames = async () => {
      try {
        const allGames = await Event.filter({ is_social_game: true }, 'event_date');
        const futureGames = allGames.filter(game => isAfter(parseISO(game.event_date), new Date()));
        setUpcomingGames(futureGames);
      } catch (error) {
        console.error("Error fetching games:", error);
        toast.error("Could not load available game dates.");
      } finally {
        setLoadingGames(false);
      }
    };
    fetchUpcomingGames();
  }, []);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.code_of_conduct_accepted) {
      toast.error("You must accept the Code of Conduct.");
      return;
    }
    if (!formData.event_id) {
      toast.error("Please select a game date.");
      return;
    }
    setLoading(true);
    try {
      const response = await submitSocialGameSignup(formData);
      if (response.data.success) {
        toast.success("Thanks for signing up! We'll see you at the game.");
        setFormData({
          event_id: '',
          first_name: '',
          last_name: '',
          email: '',
          phone: '',
          ethnicity: 'Nepali',
          skills_level: '',
          notes: '',
          code_of_conduct_accepted: false,
        });
      } else {
        throw new Error(response.data.error || 'An unknown error occurred.');
      }
    } catch (error) {
        toast.error(error.message || "Failed to submit your registration.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <Card className="bg-white/90 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-slate-900">Join a Social Game</CardTitle>
            <CardDescription className="text-slate-600">
              Select a date and fill out your details to join in. Open to the Nepali community.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
               <div className="space-y-2">
                <Label htmlFor="event_id" className="font-semibold">Select Game Date</Label>
                <Select onValueChange={(value) => handleChange('event_id', value)} value={formData.event_id} required>
                  <SelectTrigger disabled={loadingGames || upcomingGames.length === 0}>
                    <SelectValue placeholder={loadingGames ? "Loading dates..." : "Choose an upcoming game..."} />
                  </SelectTrigger>
                  <SelectContent>
                    {upcomingGames.length > 0 ? (
                      upcomingGames.map(game => (
                        <SelectItem key={game.id} value={game.id}>
                          {format(parseISO(game.event_date), 'EEEE, d MMM yyyy')} at {game.start_time}
                        </SelectItem>
                      ))
                    ) : (
                      <div className="p-4 text-center text-sm text-slate-500">No upcoming games scheduled. Please check back later.</div>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="first_name">First Name</Label>
                  <Input id="first_name" value={formData.first_name} onChange={e => handleChange('first_name', e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last_name">Last Name</Label>
                  <Input id="last_name" value={formData.last_name} onChange={e => handleChange('last_name', e.target.value)} required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" value={formData.email} onChange={e => handleChange('email', e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" value={formData.phone} onChange={e => handleChange('phone', e.target.value)} required />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="ethnicity">Ethnicity</Label>
                  <Select value={formData.ethnicity} onValueChange={v => handleChange('ethnicity', v)} required>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Nepali">Nepali</SelectItem>
                      <SelectItem value="Other" disabled>Other (Currently Unavailable)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="skills_level">Skills Level</Label>
                  <Select value={formData.skills_level} onValueChange={v => handleChange('skills_level', v)} required>
                    <SelectTrigger><SelectValue placeholder="Select your skill level" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Beginner">Beginner (Just starting out)</SelectItem>
                      <SelectItem value="Intermediate">Intermediate (Play regularly)</SelectItem>
                      <SelectItem value="Advanced">Advanced (Competitive experience)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Input id="notes" value={formData.notes} onChange={e => handleChange('notes', e.target.value)} placeholder="Anything else we should know?"/>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="terms" checked={formData.code_of_conduct_accepted} onCheckedChange={v => handleChange('code_of_conduct_accepted', v)} />
                <label htmlFor="terms" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  I agree to the Club's Code of Conduct.
                </label>
              </div>

              <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-lg" disabled={loading || loadingGames}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-5 w-5" />}
                Sign Up & Play
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}