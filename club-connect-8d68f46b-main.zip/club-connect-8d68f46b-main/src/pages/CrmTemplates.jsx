import React, { useState, useEffect } from 'react';
import { EmailTemplate, SmsTemplate } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Mail, MessageSquare, Edit, Trash2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import EmailTemplateForm from '../components/crm/EmailTemplateForm';
import SmsTemplateForm from '../components/crm/SmsTemplateForm';

export default function CrmTemplatesPage() {
  const [emailTemplates, setEmailTemplates] = useState([]);
  const [smsTemplates, setSmsTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [editingEmailTemplate, setEditingEmailTemplate] = useState(null);
  
  const [showSmsForm, setShowSmsForm] = useState(false);
  const [editingSmsTemplate, setEditingSmsTemplate] = useState(null);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    setLoading(true);
    try {
      const [emailData, smsData] = await Promise.all([
        EmailTemplate.list('-created_date'),
        SmsTemplate.list('-created_date')
      ]);
      setEmailTemplates(emailData);
      setSmsTemplates(smsData);
    } catch (error) {
      console.error("Error loading templates:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFormClose = () => {
    setShowEmailForm(false);
    setEditingEmailTemplate(null);
    setShowSmsForm(false);
    setEditingSmsTemplate(null);
    loadTemplates();
  };

  const handleDelete = async (id, type) => {
    const entity = type === 'email' ? EmailTemplate : SmsTemplate;
    const name = type === 'email' ? 'email template' : 'SMS template';
    if (window.confirm(`Are you sure you want to delete this ${name}?`)) {
      try {
        await entity.delete(id);
        loadTemplates();
      } catch (error) {
        console.error(`Error deleting ${name}:`, error);
        alert(`Failed to delete ${name}. Please try again.`);
      }
    }
  };

  const renderList = (templates, type) => {
    if (loading) {
      return Array(2).fill(0).map((_, i) => <Skeleton key={i} className="h-20 w-full" />);
    }
    if (templates.length === 0) {
      return (
        <div className="text-center py-12 border-dashed border-2 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900">No {type} templates yet</h3>
          <p className="mt-1 text-sm text-gray-500">Get started by creating one.</p>
        </div>
      );
    }
    return (
      <div className="space-y-3">
        {templates.map(template => (
          <Card key={template.id} className="bg-white/80">
            <CardContent className="p-4 flex justify-between items-center">
              <div>
                <p className="font-semibold text-slate-800">{template.name}</p>
                <p className="text-sm text-slate-500 truncate max-w-md">
                  {type === 'email' ? `Subject: ${template.subject}` : template.body}
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => type === 'email' ? (setEditingEmailTemplate(template), setShowEmailForm(true)) : (setEditingSmsTemplate(template), setShowSmsForm(true))}>
                  <Edit className="w-4 h-4 mr-1" /> Edit
                </Button>
                <Button variant="outline" size="sm" className="text-red-500 hover:bg-red-50 hover:text-red-600" onClick={() => handleDelete(template.id, type)}>
                  <Trash2 className="w-4 h-4 mr-1" /> Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Templates</h1>
          <p className="text-slate-600">Create and manage reusable Email & SMS templates for your campaigns.</p>
        </div>

        <Tabs defaultValue="email">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="email"><Mail className="w-4 h-4 mr-2" />Email Templates</TabsTrigger>
            <TabsTrigger value="sms"><MessageSquare className="w-4 h-4 mr-2" />SMS Templates</TabsTrigger>
          </TabsList>
          
          <TabsContent value="email" className="space-y-6">
            <div className="text-right">
              <Button onClick={() => (setEditingEmailTemplate(null), setShowEmailForm(true))} className="bg-red-600 hover:bg-red-700">
                <Plus className="w-4 h-4 mr-2" />New Email Template
              </Button>
            </div>
            {showEmailForm ? (
              <EmailTemplateForm template={editingEmailTemplate} onSave={handleFormClose} onCancel={handleFormClose} />
            ) : (
              renderList(emailTemplates, 'email')
            )}
          </TabsContent>

          <TabsContent value="sms" className="space-y-6">
            <div className="text-right">
              <Button onClick={() => (setEditingSmsTemplate(null), setShowSmsForm(true))} className="bg-red-600 hover:bg-red-700">
                <Plus className="w-4 h-4 mr-2" />New SMS Template
              </Button>
            </div>
            {showSmsForm ? (
              <SmsTemplateForm template={editingSmsTemplate} onSave={handleFormClose} onCancel={handleFormClose} />
            ) : (
              renderList(smsTemplates, 'sms')
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}