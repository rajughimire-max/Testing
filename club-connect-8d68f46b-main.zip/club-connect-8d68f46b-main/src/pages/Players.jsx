
import React, { useState, useEffect } from 'react';
import { Player, Team, User, InventoryItem, InventoryTransaction, UniformAssignment, Match, PlayerInjury, GeneratedContract } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

import PlayerStats from '../components/players/PlayerStats';
import PlayerList from '../components/players/PlayerList';
import PlayerForm from '../components/players/PlayerForm';
import UniformDistributionModal from '../components/players/UniformDistributionModal';
import PlayerDetailModal from '../components/players/PlayerDetailModal';
import PlayerWalletCardModal from '../components/players/PlayerWalletCardModal';
import { generatePlayerIds } from '@/api/functions';

export default function Players() {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [generatedContracts, setGeneratedContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  
  const [isUniformModalOpen, setIsUniformModalOpen] = useState(false);
  const [selectedPlayerForUniform, setSelectedPlayerForUniform] = useState(null);
  const [selectedPlayerForDetail, setSelectedPlayerForDetail] = useState(null);
  const [showPlayerDetail, setShowPlayerDetail] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [selectedPlayerForWallet, setSelectedPlayerForWallet] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [playersData, teamsData, allMatches, allInjuries, contractsData] = await Promise.all([
        Player.list(),
        Team.list(),
        Match.list(),
        PlayerInjury.list(),
        GeneratedContract.filter({ application_type: 'player' }), // More specific query for player contracts
      ]);

      // Pre-process players to include their match performance stats and injury status
      const playersWithStats = playersData.map(player => {
        // Calculate match performance stats
        const playerMatches = allMatches.filter(match => match.selected_players?.includes(player.id));
        const totalGoals = playerMatches.reduce((sum, match) => {
            const perf = match.player_performance?.find(p => p.player_id === player.id);
            return sum + (perf?.goals_scored || 0);
        }, 0);
        const totalAssists = playerMatches.reduce((sum, match) => {
            const perf = match.player_performance?.find(p => p.player_id === player.id);
            return sum + (perf?.assists || 0);
        }, 0);
        const totalAwards = playerMatches.reduce((sum, match) => {
            const perf = match.player_performance?.find(p => p.player_id === player.id);
            return sum + (perf?.awards?.length || 0);
        }, 0);

        // Determine current injury status
        const playerInjuries = allInjuries.filter(injury => injury.player_id === player.id);
        const mostRecentInjury = playerInjuries.sort((a, b) => new Date(b.injury_date) - new Date(a.injury_date))[0];
        
        let currentStatus = 'fit';
        if (mostRecentInjury) {
          switch (mostRecentInjury.current_status) {
            case 'Active injury':
            case 'Under treatment':
              currentStatus = 'injured';
              break;
            case 'Recovering':
              currentStatus = 'recovering';
              break;
            case 'Cleared to play':
              currentStatus = 'fit';
              break;
            default:
              currentStatus = 'fit';
          }
        }

        return {
          ...player,
          status: currentStatus, // Override with actual injury status
          goals_scored: totalGoals,
          assists: totalAssists,
          awards_won: totalAwards,
          match_history: playerMatches, // Pass full history to detail modal
        };
      });

      setPlayers(playersWithStats);
      setTeams(teamsData);
      setGeneratedContracts(contractsData);
    } catch (error) {
      console.error("Error loading players data:", error);
    } finally {
      setLoading(false);
    }
  };

  const generateMissingPlayerIds = async () => {
    toast.info("Generating IDs for players who are missing them...");
    try {
      const response = await generatePlayerIds();
      toast.success(response.data.message || "Player IDs generated successfully!");
      loadData(); // Reload to show the new IDs
    } catch (error) {
      console.error("Error generating Player IDs:", error);
      toast.error("Failed to generate Player IDs. Please try again.");
    }
  };

  const handleOpenUniformModal = (player) => {
    setSelectedPlayerForUniform(player);
    setIsUniformModalOpen(true);
  };

  const handleOpenWalletModal = (player) => {
    setSelectedPlayerForWallet(player);
    setIsWalletModalOpen(true);
  };

  const handlePlayerDoubleClick = (player) => {
    setSelectedPlayerForDetail(player);
    setShowPlayerDetail(true);
  };

  const handleUniformDistribution = async (distributionDataArray) => {
    if (!selectedPlayerForUniform || !Array.isArray(distributionDataArray)) return;

    try {
      for (const distributionData of distributionDataArray) {
        const { item, variant, quantity } = distributionData;
        
        await UniformAssignment.create({
          player_id: selectedPlayerForUniform.id,
          item_id: item.id,
          variant_name: variant.name,
          quantity: quantity,
          assigned_date: new Date().toISOString().slice(0, 10),
        });

        const updatedVariants = item.variants.map(v => 
          v.name === variant.name ? { ...v, quantity: v.quantity - quantity } : v
        );
        const newTotalQuantity = updatedVariants.reduce((sum, v) => sum + v.quantity, 0);

        await InventoryItem.update(item.id, {
          variants: updatedVariants,
          quantity_on_hand: newTotalQuantity
        });

        await InventoryTransaction.create({
          item_id: item.id,
          transaction_type: "Check-out",
          quantity_change: -quantity,
          assigned_to_person_id: selectedPlayerForUniform.id,
          reason: `Assigned ${quantity}x ${variant.name} ${item.name} to ${selectedPlayerForUniform.first_name} ${selectedPlayerForUniform.last_name}`
        });
      }

      alert(`Successfully distributed ${distributionDataArray.length} uniform item(s)!`);
      setIsUniformModalOpen(false);
      setSelectedPlayerForUniform(null);
      loadData(); // Reload data to reflect updated inventory counts
    } catch (error) {
      console.error("Error distributing uniforms:", error);
      alert("Failed to distribute uniforms. Please try again.");
    }
  };

  const handlePlayerSubmit = async (formData) => {
    const dataToSubmit = {
      ...formData,
      height: formData.height ? Number(formData.height) : null,
      weight: formData.weight ? Number(formData.weight) : null,
      loan_fee: formData.loan_fee ? Number(formData.loan_fee) : null,
      preferred_number: formData.preferred_number ? Number(formData.preferred_number) : null,
    };

    try {
      if (editingPlayer) {
        await Player.update(editingPlayer.id, dataToSubmit);
        toast.success("Player updated successfully!");
      } else {
        const allPlayers = await Player.list();
        const existingUids = allPlayers.map(p => p.player_uid).filter(Boolean);
        const existingNumbers = existingUids
          .map(uid => {
            const parts = uid.split('-');
            return parts.length === 3 && parts[0] === 'NFC' && parts[1] === 'P' ? parseInt(parts[2], 10) : NaN;
          })
          .filter(num => !isNaN(num));

        const maxNumber = existingNumbers.length > 0 ? Math.max(...existingNumbers) : 0;
        const newNumber = maxNumber + 1;
        const newPlayerUid = `NFC-P-${String(newNumber).padStart(3, '0')}`;
        
        const finalData = { ...dataToSubmit, player_uid: newPlayerUid };
        await Player.create(finalData);
        toast.success("New player created with ID: " + newPlayerUid);
      }
      setShowForm(false);
      setEditingPlayer(null);
      loadData();
    } catch (error) {
      console.error("Error saving player:", error);
      toast.error("Failed to save player. Please check the details and try again.");
    }
  };

  const handleEditPlayer = (player) => {
    setEditingPlayer(player);
    setShowForm(true);
  };

  const handleDeletePlayer = async (id) => {
    if (window.confirm("Are you sure you want to delete this player?")) {
      try {
        await Player.delete(id);
        loadData();
      } catch (error) {
        console.error("Error deleting player:", error);
      }
    }
  };

  // Filter players by the active tab
  const getLoanPlayerCount = () => players.filter(p => p.is_available_for_loan).length;
  const getTeamPlayerCount = (teamId) => players.filter(p => p.team_id === teamId).length;

  let currentTabPlayers;
  if (activeTab === 'all') {
    currentTabPlayers = players;
  } else if (activeTab === 'available-loan') {
    currentTabPlayers = players.filter(player => player.is_available_for_loan);
  } else {
    // Handle team-specific tabs
    currentTabPlayers = players.filter(player => player.team_id === activeTab);
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Players</h1>
            <p className="text-slate-600">Manage all registered club players.</p>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={generateMissingPlayerIds}
              variant="outline"
              size="sm"
            >
              Generate Missing IDs
            </Button>
            <Button 
              onClick={() => {
                setEditingPlayer(null);
                setShowForm(true);
              }} 
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Player
            </Button>
          </div>
        </div>

        <PlayerStats players={players} loading={loading} />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="overflow-x-auto pb-2 -mx-6 px-6">
            <TabsList className="inline-grid grid-flow-col auto-cols-max gap-1 sm:gap-2 bg-white/80 backdrop-blur-sm border-slate-200/60 p-1">
              <TabsTrigger value="all">All Players ({players.length})</TabsTrigger>
              <TabsTrigger value="available-loan">
                Available for Loan ({getLoanPlayerCount()})
              </TabsTrigger>
              {teams.map(team => (
                 <TabsTrigger key={team.id} value={team.id}>
                  {team.name} ({getTeamPlayerCount(team.id)})
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value={activeTab}>
            {showForm && (
              <PlayerForm
                player={editingPlayer}
                teams={teams}
                allPlayers={players}
                allContracts={generatedContracts}
                onSubmit={handlePlayerSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setEditingPlayer(null);
                }}
              />
            )}

            <PlayerList
              players={currentTabPlayers}
              teams={teams}
              loading={loading}
              onEdit={handleEditPlayer}
              onDelete={handleDeletePlayer}
              onDistributeUniform={handleOpenUniformModal}
              onPlayerDoubleClick={handlePlayerDoubleClick}
              onIssueCard={handleOpenWalletModal}
            />
          </TabsContent>
        </Tabs>
      </div>

      <UniformDistributionModal
        isOpen={isUniformModalOpen}
        player={selectedPlayerForUniform}
        onClose={() => {
          setIsUniformModalOpen(false);
          setSelectedPlayerForUniform(null);
          loadData(); // Reload data after uniform distribution modal closes to reflect inventory changes
        }}
        onDistribute={handleUniformDistribution}
      />

      <PlayerDetailModal
        isOpen={showPlayerDetail}
        player={selectedPlayerForDetail}
        teams={teams}
        allContracts={generatedContracts}
        onClose={() => {
          setShowPlayerDetail(false);
          setSelectedPlayerForDetail(null);
        }}
        onEdit={(player) => {
          setSelectedPlayerForDetail(null);
          setShowPlayerDetail(false);
          handleEditPlayer(player);
        }}
      />

      <PlayerWalletCardModal
        isOpen={isWalletModalOpen}
        player={selectedPlayerForWallet}
        onClose={() => setIsWalletModalOpen(false)}
      />
    </div>
  );
}
