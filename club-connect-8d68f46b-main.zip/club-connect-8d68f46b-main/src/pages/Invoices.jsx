import React, { useState, useEffect } from 'react';
import { Invoice } from '@/api/entities';
import { getInvoiceDownloadUrl } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, FileText, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function Invoices() {
    const [invoices, setInvoices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [downloadingId, setDownloadingId] = useState(null);

    useEffect(() => {
        loadInvoices();
    }, []);

    const loadInvoices = async () => {
        setLoading(true);
        try {
            const data = await Invoice.list('-created_date');
            setInvoices(data);
        } catch (error) {
            toast.error("Failed to load invoices.");
            console.error("Error loading invoices:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleDownload = async (invoiceId) => {
        setDownloadingId(invoiceId);
        try {
            const response = await getInvoiceDownloadUrl({ invoiceId });
            if (response.data.signed_url) {
                window.open(response.data.signed_url, '_blank');
            } else {
                toast.error(response.data.error || "Could not get download link.");
            }
        } catch (error) {
            toast.error("Failed to download invoice.");
        } finally {
            setDownloadingId(null);
        }
    };

    const handleDelete = async (invoiceId) => {
        if (window.confirm("Are you sure you want to permanently delete this invoice? This action cannot be undone.")) {
            try {
                await Invoice.delete(invoiceId);
                toast.success("Invoice deleted successfully.");
                setInvoices(prev => prev.filter(inv => inv.id !== invoiceId));
            } catch (error) {
                toast.error("Failed to delete invoice.");
                console.error("Error deleting invoice:", error);
            }
        }
    };

    const statusColors = {
        paid: "bg-green-100 text-green-800",
        sent: "bg-blue-100 text-blue-800",
        draft: "bg-slate-100 text-slate-800",
        overdue: "bg-red-100 text-red-800",
        due: "bg-amber-100 text-amber-800", // Added for consistency
        void: "bg-gray-100 text-gray-800"
    };

    return (
        <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">Invoices</h1>
                    <p className="text-slate-600">View and manage all generated invoices for members and sponsors.</p>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>Invoice History</CardTitle>
                        <CardDescription>A complete log of all financial invoices. You can delete incorrect invoices here to regenerate them.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Invoice #</TableHead>
                                    <TableHead>Date</TableHead>
                                    <TableHead>Related To</TableHead>
                                    <TableHead>Amount</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow><TableCell colSpan="6" className="text-center">Loading...</TableCell></TableRow>
                                ) : invoices.length === 0 ? (
                                    <TableRow><TableCell colSpan="6" className="text-center py-12">
                                        <FileText className="mx-auto h-12 w-12 text-gray-400" />
                                        <h3 className="mt-2 text-sm font-medium text-gray-900">No invoices yet</h3>
                                        <p className="mt-1 text-sm text-gray-500">Invoices will appear here once they are generated.</p>
                                    </TableCell></TableRow>
                                ) : (
                                    invoices.map(invoice => (
                                        <TableRow key={invoice.id}>
                                            <TableCell className="font-medium">{invoice.invoice_number}</TableCell>
                                            <TableCell>{new Date(invoice.issue_date).toLocaleDateString()}</TableCell>
                                            <TableCell className="capitalize">
                                                {invoice.related_entity_type?.replace(/_/g, ' ') || 'N/A'}
                                            </TableCell>
                                            <TableCell>${(invoice.amount || 0).toFixed(2)}</TableCell>
                                            <TableCell>
                                                <Badge className={`${statusColors[invoice.status] || 'bg-gray-100 text-gray-800'} capitalize`}>
                                                    {invoice.status}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="flex justify-end items-center gap-2">
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        onClick={() => handleDownload(invoice.id)}
                                                        disabled={downloadingId === invoice.id}
                                                    >
                                                        <Download className="mr-2 h-4 w-4" />
                                                        {downloadingId === invoice.id ? 'Downloading...' : 'Download'}
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="text-red-600 hover:bg-red-100 h-8 w-8"
                                                        onClick={() => handleDelete(invoice.id)}
                                                    >
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}