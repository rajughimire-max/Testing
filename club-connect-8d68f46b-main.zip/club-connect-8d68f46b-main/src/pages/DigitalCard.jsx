import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { getMemberByWalletToken } from '@/api/functions';
import MemberWalletCard from '../components/members/MemberWalletCard';
import { Skeleton } from '@/components/ui/skeleton';
import { ShieldX } from 'lucide-react';
import { Helmet } from 'react-helmet'; // Using react-helmet for dynamic page titles

export default function DigitalCard() {
  const [memberData, setMemberData] = useState(null);
  const [membershipType, setMembershipType] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const fetchMemberData = async () => {
      const params = new URLSearchParams(location.search);
      const token = params.get('token');

      if (!token) {
        setError("No verification token provided.");
        setLoading(false);
        return;
      }

      try {
        const response = await getMemberByWalletToken({ token });
        if (response.data.success) {
          setMemberData(response.data.member);
          setMembershipType(response.data.membershipType);
        } else {
          setError(response.data.error || "Could not retrieve member details.");
        }
      } catch (err) {
        setError("An error occurred while fetching card details.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchMemberData();
  }, [location.search]);
  
  // Set the page title dynamically
  const pageTitle = loading 
    ? "Loading Card..." 
    : error 
    ? "Card Error" 
    : `${memberData?.first_name} ${memberData?.last_name}'s Card | Nepbourne FC`;


  if (loading) {
    return (
      <div className="w-full min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <Helmet><title>Loading Card...</title></Helmet>
        <div className="w-full max-w-sm">
          <Skeleton className="h-[450px] w-full rounded-xl" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <Helmet><title>Card Error</title></Helmet>
        <div className="text-center bg-white p-8 rounded-lg shadow-md w-full max-w-sm">
          <ShieldX className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-slate-800">Card Error</h1>
          <p className="text-slate-600 mt-2">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet><title>{pageTitle}</title></Helmet>
      <div className="w-full min-h-screen bg-slate-100 p-4 pt-8 md:pt-12">
        <div className="w-full max-w-sm mx-auto">
          {memberData && membershipType && (
            <MemberWalletCard member={memberData} membershipType={membershipType} isPublicView={true} />
          )}
        </div>
      </div>
    </>
  );
}