
import React, { useState, useEffect, useCallback } from "react";
import { FinancialTransaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Download, FileText, Calendar } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import TransactionList from "../components/finance/TransactionList";
import TransactionForm from "../components/finance/TransactionForm";
import FinanceSummary from "../components/finance/FinanceSummary";
import FinancialStatementView from "../components/finance/FinancialStatementView";
import { exportFinanceData } from "@/api/functions";
import { toast } from "sonner";
import { 
  startOfWeek, 
  endOfWeek, 
  startOfMonth, 
  endOfMonth, 
  startOfYear, 
  endOfYear,
  format,
  subWeeks,
  subMonths,
  subYears 
} from "date-fns";

export default function Finance() {
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [filterPeriod, setFilterPeriod] = useState("month"); // week, month, year
  const [filterRange, setFilterRange] = useState("current"); // current, last, custom
  const [viewMode, setViewMode] = useState("summary"); // summary, statement, transactions
  const [exporting, setExporting] = useState({ pdf: false, excel: false });

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await FinancialTransaction.list("-date");
      setTransactions(data);
    } catch (error) {
      console.error("Error loading transactions:", error);
      toast.error("Failed to load transactions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    loadData(); 
  }, []); // Empty dependency array means this runs once on mount

  const getDateRange = useCallback(() => {
    const now = new Date();
    let start, end;

    switch (filterPeriod) {
      case "week":
        if (filterRange === "current") {
          start = startOfWeek(now, { weekStartsOn: 1 });
          end = endOfWeek(now, { weekStartsOn: 1 });
        } else if (filterRange === "last") {
          const lastWeek = subWeeks(now, 1);
          start = startOfWeek(lastWeek, { weekStartsOn: 1 });
          end = endOfWeek(lastWeek, { weekStartsOn: 1 });
        }
        break;
      case "month":
        if (filterRange === "current") {
          start = startOfMonth(now);
          end = endOfMonth(now);
        } else if (filterRange === "last") {
          const lastMonth = subMonths(now, 1);
          start = startOfMonth(lastMonth);
          end = endOfMonth(lastMonth);
        }
        break;
      case "year":
        if (filterRange === "current") {
          start = startOfYear(now);
          end = endOfYear(now);
        } else if (filterRange === "last") {
          const lastYear = subYears(now, 1);
          start = startOfYear(lastYear);
          end = endOfYear(lastYear);
        }
        break;
      default:
        return { start: null, end: null };
    }

    return { start, end };
  }, [filterPeriod, filterRange]); // Dependencies for useCallback

  const filterTransactions = useCallback(() => {
    const { start, end } = getDateRange();
    
    if (!start || !end) {
      setFilteredTransactions(transactions);
      return;
    }

    const filtered = transactions.filter(transaction => {
      const transactionDate = new Date(transaction.date);
      return transactionDate >= start && transactionDate <= end;
    });

    setFilteredTransactions(filtered);
  }, [transactions, getDateRange]); // Dependencies for useCallback

  useEffect(() => {
    filterTransactions();
  }, [filterTransactions]); // Now depends on filterTransactions which is memoized

  const handleSubmit = async (formData) => {
    try {
      if (editingTransaction) {
        await FinancialTransaction.update(editingTransaction.id, formData);
        toast.success("Transaction updated successfully!");
      } else {
        await FinancialTransaction.create(formData);
        toast.success("Transaction created successfully!");
      }
      setShowForm(false);
      setEditingTransaction(null);
      loadData(); // Reload data to reflect changes
    } catch (error) {
      console.error("Error saving transaction:", error);
      toast.error("Failed to save transaction");
    }
  };

  const handleEdit = (transaction) => {
    setEditingTransaction(transaction);
    setShowForm(true);
  };
  
  const handleDelete = async(id) => {
    if(window.confirm("Are you sure you want to delete this transaction?")) {
      try {
        await FinancialTransaction.delete(id);
        toast.success("Transaction deleted successfully!");
        loadData(); // Reload data to reflect changes
      } catch (error) {
        console.error("Error deleting transaction:", error);
        toast.error("Failed to delete transaction");
      }
    }
  };

  const handleExport = async (format) => {
    setExporting(prev => ({ ...prev, [format]: true }));
    try {
      const { start, end } = getDateRange();
      const response = await exportFinanceData({
        format,
        startDate: start?.toISOString().split('T')[0],
        endDate: end?.toISOString().split('T')[0],
        filterPeriod,
        filterRange
      });

      // Handle direct response data (not wrapped in data.data)
      const responseData = response.data || response;
      
      if (format === 'excel') {
        // Create download for Excel
        const blob = new Blob([responseData], { 
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `financial-report-${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        
        toast.success("Finance report exported as Excel");
      } else if (format === 'pdf') {
        // Create download for PDF
        const blob = new Blob([responseData], { 
          type: 'application/pdf' 
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `financial-report-${new Date().toISOString().split('T')[0]}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        
        toast.success("Finance report exported as PDF");
      }
      
    } catch (error) {
      console.error("Export error:", error);
      toast.error("Failed to export finance data");
    } finally {
      setExporting(prev => ({ ...prev, [format]: false }));
    }
  };

  const getPeriodDisplayName = useCallback(() => {
    const { start, end } = getDateRange();
    if (!start || !end) return "All Time";
    
    const prefix = filterRange === "current" ? "Current" : "Last";
    const period = filterPeriod.charAt(0).toUpperCase() + filterPeriod.slice(1);
    
    return `${prefix} ${period} (${format(start, 'MMM d')} - ${format(end, 'MMM d, yyyy')})`;
  }, [getDateRange, filterRange, filterPeriod]);

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Finance</h1>
            <p className="text-slate-600">Track all club income and expenses with detailed financial reporting.</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => handleExport('excel')}
              disabled={exporting.excel}
            >
              <FileText className="w-4 h-4 mr-2" />
              {exporting.excel ? "Exporting..." : "Export Excel"}
            </Button>
            <Button
              variant="outline"
              onClick={() => handleExport('pdf')}
              disabled={exporting.pdf}
            >
              <Download className="w-4 h-4 mr-2" />
              {exporting.pdf ? "Exporting..." : "Export PDF"}
            </Button>
            <Button onClick={() => { setEditingTransaction(null); setShowForm(true); }} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Transaction
            </Button>
          </div>
        </div>

        {/* Filters and View Controls */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  <span className="text-sm font-medium text-slate-700">Filter by:</span>
                  <Select value={filterPeriod} onValueChange={setFilterPeriod}>
                    <SelectTrigger className="w-28">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="week">Week</SelectItem>
                      <SelectItem value="month">Month</SelectItem>
                      <SelectItem value="year">Year</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterRange} onValueChange={setFilterRange}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="current">Current</SelectItem>
                      <SelectItem value="last">Last</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="text-sm text-slate-600 font-medium">
                  {getPeriodDisplayName()}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-slate-700">View:</span>
                <Select value={viewMode} onValueChange={setViewMode}>
                  <SelectTrigger className="w-36">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summary">Summary</SelectItem>
                    <SelectItem value="statement">Statement</SelectItem>
                    <SelectItem value="transactions">Transactions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
        </Card>
        
        {viewMode === "summary" && (
          <FinanceSummary transactions={filteredTransactions} loading={loading} period={getPeriodDisplayName()} />
        )}

        {viewMode === "statement" && (
          <FinancialStatementView transactions={filteredTransactions} loading={loading} period={getPeriodDisplayName()} />
        )}

        {showForm && (
          <TransactionForm
            transaction={editingTransaction}
            onSubmit={handleSubmit}
            onCancel={() => { setShowForm(false); setEditingTransaction(null); }}
          />
        )}

        {viewMode === "transactions" && (
          <TransactionList 
            transactions={filteredTransactions} 
            loading={loading} 
            onEdit={handleEdit} 
            onDelete={handleDelete}
            showPeriod={getPeriodDisplayName()}
          />
        )}
      </div>
    </div>
  );
}
