import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Campaign } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Mail, MessageSquare } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';

export default function CrmCampaignCreatorPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [channel, setChannel] = useState(null);
  const [name, setName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const channelParam = searchParams.get('channel');
    if (channelParam && ['email', 'sms'].includes(channelParam)) {
      setChannel(channelParam);
    } else {
      // Redirect back if channel is invalid or missing
      navigate(createPageUrl('CrmCampaigns'));
    }
  }, [searchParams, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter a campaign name.');
      return;
    }
    setSubmitting(true);
    try {
      await Campaign.create({
        name,
        channel,
        status: 'draft',
        stats: { total: 0, sent: 0, delivered: 0, opened: 0, clicked: 0, bounced: 0, unsubscribed: 0, failed: 0, opt_out: 0 }
      });
      navigate(createPageUrl('CrmCampaigns'));
    } catch (error) {
      console.error('Error creating campaign:', error);
      alert('Failed to create campaign. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleBack = () => {
    navigate(createPageUrl('CrmCampaigns'));
  };

  if (!channel) {
    return (
        <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
            <div className="max-w-2xl mx-auto">
                <Skeleton className="h-10 w-48 mb-4" />
                <Skeleton className="h-64 w-full" />
            </div>
        </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-2xl mx-auto">
        <Button variant="ghost" onClick={handleBack} className="mb-4 text-slate-600 hover:text-slate-900">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Campaigns
        </Button>
        
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              {channel === 'email' ? <Mail className="w-6 h-6 text-blue-600" /> : <MessageSquare className="w-6 h-6 text-green-600" />}
              Create New {channel === 'email' ? 'Email' : 'SMS'} Campaign
            </CardTitle>
            <CardDescription>
              Start by giving your new campaign a name. You can configure the audience and content later.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="campaign-name">Campaign Name</Label>
                <Input
                  id="campaign-name"
                  placeholder={`e.g., "October Newsletter" or "Match Day Reminder"`}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  autoFocus
                  className="text-base"
                />
              </div>
              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={submitting} className="bg-red-600 hover:bg-red-700">
                  {submitting ? 'Saving...' : 'Create Draft Campaign'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}