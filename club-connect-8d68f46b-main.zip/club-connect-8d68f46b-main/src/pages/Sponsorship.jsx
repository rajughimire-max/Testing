
import React, { useState, useEffect } from "react";
import { Sponsor, SponsorshipTier, FinancialTransaction, SponsorshipApplication, GeneratedContract, Invoice } from "@/api/entities"; // Added GeneratedContract, Invoice
import { Button } from "@/components/ui/button";
import { Plus, Handshake, CheckCircle, X, Trash2, FileText, Download, Send, User, Building, DollarSign, Globe, Shield } from "lucide-react"; // Combined and cleaned up icons and added new ones
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import SponsorList from "../components/sponsorship/SponsorList";
import SponsorForm from "../components/sponsorship/SponsorForm";
import TierList from "../components/sponsorship/TierList";
import TierForm from "../components/sponsorship/TierForm";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { generateInvoice } from "@/api/functions";
import { getInvoiceDownloadUrl } from "@/api/functions";
import { sendInvoiceEmail } from "@/api/functions";

const SendContractModal = ({ isOpen, onClose, application, onContractSent }) => {
  const possibleSigners = [
    { id: "president", name: "Club President", email: "president@example.com" },
    { id: "secretary", name: "Club Secretary", email: "secretary@example.com" },
    { id: "treasurer", name: "Club Treasurer", email: "treasurer@example.com" },
  ];
  const [selectedSigner, setSelectedSigner] = useState("president");
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSelectedSigner("president");
    }
  }, [isOpen, application]);

  const handleSendContract = async () => {
    if (!application || !selectedSigner) {
      toast.error("Please ensure an application is selected and a signer is chosen.");
      return;
    }
    setIsSending(true);
    try {
      // In a real scenario, this would trigger an external service to generate/send the contract
      // For now, we just update the application status to reflect that a contract was sent.
      await SponsorshipApplication.update(application.id, { status: "contract_sent" });
      toast.success("Contract sent successfully!");
      onContractSent();
      onClose();
    } catch (error) {
      console.error("Error sending contract:", error);
      toast.error("Failed to send contract. Please try again.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Send Sponsorship Contract</DialogTitle>
          <DialogDescription>
            Generate and send the contract for <strong>{application?.company_name}</strong>.
            Please select the club representative who will sign the contract.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="signer-select">Select Club Signer</Label>
            <Select value={selectedSigner} onValueChange={setSelectedSigner}>
              <SelectTrigger id="signer-select"><SelectValue placeholder="Select a signer" /></SelectTrigger>
              <SelectContent>
                {possibleSigners.map(signer => (
                  <SelectItem key={signer.id} value={signer.id}>{signer.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Recipient (Sponsor)</Label>
            <Input value={`${application?.contact_person} (${application?.email})`} readOnly />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSending}>Cancel</Button>
          <Button onClick={handleSendContract} disabled={isSending}>
            {isSending ? "Sending..." : "Send Contract"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const ViewSignedContractModal = ({ isOpen, onClose, contract }) => {
  if (!contract) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Signed Contract Review</DialogTitle>
          <DialogDescription>
            Review the signed contract before activating the sponsorship
          </DialogDescription>
        </DialogHeader>
        <div className="p-4">
          <div 
            className="prose max-w-none"
            dangerouslySetInnerHTML={{ __html: contract.contract_content }}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};


export default function Sponsorship() {
  const [sponsors, setSponsors] = useState([]);
  const [tiers, setTiers] = useState([]);
  const [applications, setApplications] = useState([]);
  const [invoices, setInvoices] = useState([]); // Add invoices state
  const [loading, setLoading] = useState(true);
  const [showSponsorForm, setShowSponsorForm] = useState(false);
  const [showTierForm, setShowTierForm] = useState(false);
  const [editingSponsor, setEditingSponsor] = useState(null);
  const [editingTier, setEditingTier] = useState(null);
  const [showContractModal, setShowContractModal] = useState({ show: false, application: null });
  const [viewContractModal, setViewContractModal] = useState({ show: false, contract: null }); // New state for viewing signed contracts
  const [contracts, setContracts] = useState([]); // New state to store generated contracts
  
  // State for application invoice actions
  const [generatingInvoiceAppId, setGeneratingInvoiceAppId] = useState(null);
  const [sendingInvoiceAppId, setSendingInvoiceAppId] = useState(null);
  const [downloadingInvoiceAppId, setDownloadingInvoiceAppId] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [sponsorData, tierData, appsData, contractsData, invoicesData] = await Promise.all([
        Sponsor.list("-created_date"),
        SponsorshipTier.list("sort_order"),
        SponsorshipApplication.list('-created_date'),
        GeneratedContract.filter({ application_type: 'sponsorship' }, '-created_date'),
        Invoice.list('-created_date') // Load ALL invoices
      ]);
      setSponsors(sponsorData);
      setTiers(tierData);
      setApplications(appsData);
      setContracts(contractsData);
      setInvoices(invoicesData); // Set invoices
    } catch (error) {
      console.error("Error loading sponsorship data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSponsorSubmit = async (formData) => {
    try {
      let savedSponsor;
      if (editingSponsor) {
        savedSponsor = await Sponsor.update(editingSponsor.id, formData);
        toast.success("Sponsor updated successfully!");
      } else {
        savedSponsor = await Sponsor.create(formData);
        toast.success("Sponsor created successfully!");
        
        // Create Financial Transaction on new sponsor
        if (savedSponsor && formData.amount > 0) {
          const tierName = tiers.find(t => t.id === formData.sponsorship_tier_id)?.name || 'Unknown Tier';
          try {
            await FinancialTransaction.create({
              date: formData.start_date || new Date().toISOString().slice(0, 10), // Use start_date or current date
              type: "Income",
              category: "Sponsorship",
              description: `Sponsorship contribution from ${formData.name} (${tierName})`,
              amount: formData.amount,
              related_entity_id: savedSponsor.id,
              related_entity_name: "Sponsor"
            });
            toast.success("Financial transaction recorded for new sponsor.");
          } catch (financeError) {
            console.error("Failed to create financial transaction for sponsor:", financeError);
            toast.error("Sponsor saved, but failed to create financial record.");
          }
        }
      }
      setShowSponsorForm(false);
      setEditingSponsor(null);
      loadData();
    } catch (error) {
      console.error("Error saving sponsor:", error);
      toast.error("Failed to save sponsor. Please try again.");
    }
  };

  const handleTierSubmit = async (formData) => {
    try {
      if (editingTier) {
        await SponsorshipTier.update(editingTier.id, formData);
        toast.success("Sponsorship tier updated successfully!");
      } else {
        await SponsorshipTier.create(formData);
        toast.success("Sponsorship tier created successfully!");
      }
      setShowTierForm(false);
      setEditingTier(null);
      loadData();
    } catch (error) {
      console.error("Error saving tier:", error);
      toast.error("Failed to save tier. Please try again.");
    }
  };

  const handleEditSponsor = (sponsor) => {
    setEditingSponsor(sponsor);
    setShowSponsorForm(true);
  };

  const handleEditTier = (tier) => {
    setEditingTier(tier);
    setShowTierForm(true);
  };

  const handleDeleteSponsor = async (id) => {
    if(window.confirm("Are you sure you want to delete this sponsor?")) {
      try {
        await Sponsor.delete(id);
        toast.success("Sponsor deleted successfully!");
        loadData();
      } catch (error) {
        console.error("Error deleting sponsor:", error);
        toast.error("Failed to delete sponsor. Please try again.");
      }
    }
  };

  const handleDeleteTier = async (id) => {
    if(window.confirm("Are you sure you want to delete this tier? This will affect any sponsors using this tier.")) {
      try {
        await SponsorshipTier.delete(id);
        toast.success("Sponsorship tier deleted successfully!");
        loadData();
      } catch (error) {
        console.error("Error deleting tier:", error);
        toast.error("Failed to delete tier. Please try again.");
      }
    }
  };

  const handleApplicationStatusChange = async (appId, newStatus) => {
    try {
      await SponsorshipApplication.update(appId, { status: newStatus });
      setApplications(prev => prev.map(app => app.id === appId ? { ...app, status: newStatus } : app));
      toast.success(`Sponsorship application status updated to ${newStatus.replace('_', ' ')}.`);
      loadData(); // Reload data to ensure other components (like contracts) are updated if needed
    } catch (error) {
      console.error("Error updating application status:", error);
      toast.error("Failed to update application status.");
    }
  };

  const handleDeleteApplication = async (appId) => {
    if (window.confirm("Are you sure you want to permanently delete this application? This action cannot be undone.")) {
      try {
        await SponsorshipApplication.delete(appId);
        setApplications(prev => prev.filter(app => app.id !== appId));
        toast.success("Sponsorship application deleted successfully.");
      } catch (error) {
        console.error("Error deleting application:", error);
        
        // Handle the specific case where the application doesn't exist anymore
        if (error.response?.status === 404 || error.message?.includes('Object not found') || error.response?.status === 500) {
          // Application was already deleted, just remove it from UI
          setApplications(prev => prev.filter(app => app.id !== appId));
          toast.success("Application removed (it may have been already processed).");
        } else {
          toast.error("Failed to delete application: " + (error.response?.data?.message || error.message));
        }
      }
    }
  };
  
  // This function is now a callback to refresh the invoice list
  const handleInvoiceGenerated = () => {
    loadData(); // Refresh invoices when a new one is generated
  };

  const handleViewSignedContract = (applicationId) => {
    const signedContract = contracts.find(c => 
      c.application_id === applicationId && c.status === 'signed'
    );
    if (signedContract) {
      setViewContractModal({ show: true, contract: signedContract });
    } else {
      toast.error("No signed contract found for this application.");
    }
  };

  const handleActivateSponsorship = async (appId) => {
    if (window.confirm("Are you sure you want to activate this sponsorship? This will create an active sponsor record and a financial transaction.")) {
      try {
        // Update application status to active
        await SponsorshipApplication.update(appId, { status: 'active' });
        
        // Get the application details
        const application = applications.find(app => app.id === appId);
        if (!application) {
          toast.error("Application not found.");
          return;
        }
        const tier = tiers.find(t => t.id === application.sponsorship_tier_id);
        
        // Calculate end date (e.g., 1 year from activation)
        const startDate = new Date().toISOString().split('T')[0];
        const endDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0];
        
        // Determine the sponsorship amount
        const sponsorshipAmount = application.custom_amount || tier?.minimum_amount || 0;

        // Create the sponsor record
        const newSponsor = await Sponsor.create({
          name: application.company_name,
          contact_person: application.contact_person,
          email: application.email,
          phone: application.phone,
          website: application.website,
          sponsorship_tier_id: application.sponsorship_tier_id,
          amount: sponsorshipAmount,
          sponsor_type: application.sponsor_type || 'general',
          start_date: startDate,
          end_date: endDate,
          status: 'Active',
          notes: `Activated from application ID ${application.id} on ${new Date().toLocaleDateString()}`,
          stripe_customer_id: application.stripe_customer_id,
          stripe_subscription_id: application.stripe_subscription_id
        });

        // If an invoice was generated for the application, re-link it to the new sponsor record
        const appInvoice = invoices.find(inv => inv.related_entity_id === appId && inv.related_entity_type === 'sponsorship_application');
        if (appInvoice) {
          await Invoice.update(appInvoice.id, {
            related_entity_id: newSponsor.id,
            related_entity_type: 'sponsorship'
          });
          toast.info("Application invoice has been linked to the new active sponsor.");
        }

        // Create financial transaction
        if (newSponsor) {
          await FinancialTransaction.create({
            date: startDate,
            type: "Income",
            category: "Sponsorship",
            description: `Sponsorship activation - ${application.company_name} (${tier?.name || 'Tier TBD'})`,
            amount: sponsorshipAmount,
            related_entity_id: newSponsor.id,
            related_entity_name: "Sponsor"
          });
        }

        toast.success(`Sponsorship for ${application.company_name} has been activated successfully!`);
        loadData(); // Reload all data to reflect new sponsor and updated application status
      } catch (error) {
        console.error("Error activating sponsorship:", error);
        toast.error("Failed to activate sponsorship. Please try again.");
      }
    }
  };

  const handleGenerateApplicationInvoice = async (application) => {
    setGeneratingInvoiceAppId(application.id);
    try {
      const response = await generateInvoice({
        entityId: application.id,
        entityType: 'sponsorship_application'
      });

      if (response.data.success) {
        toast.success(`Invoice generated for ${application.company_name}`);
        loadData(); // Refresh invoices
      } else {
        toast.info(response.data.message || 'Could not generate invoice.');
      }
    } catch (error) {
      console.error('Error generating application invoice:', error);
      toast.error('Failed to generate invoice.');
    } finally {
      setGeneratingInvoiceAppId(null);
    }
  };

  const handleDownloadApplicationInvoice = async (invoiceId) => {
    setDownloadingInvoiceAppId(invoiceId);
    try {
      const response = await getInvoiceDownloadUrl({ invoiceId });
      if (response.data.signed_url) {
        window.open(response.data.signed_url, '_blank');
      } else {
        toast.error(response.data.error || "Could not get download link.");
      }
    } catch (error) {
      console.error('Error downloading invoice:', error);
      toast.error("Failed to download invoice.");
    } finally {
      setDownloadingInvoiceAppId(null);
    }
  };

  const handleSendApplicationInvoice = async (invoice, application) => {
    setSendingInvoiceAppId(invoice.id);
    try {
      const response = await sendInvoiceEmail({ invoiceId: invoice.id });
      if (response.data.success) {
        toast.success(`Invoice sent successfully to ${application.email}`);
      } else {
        toast.error(response.data.error || "Could not send invoice email.");
      }
    } catch (error) {
      console.error('Error sending invoice email:', error);
      toast.error('Failed to send invoice email.');
    } finally {
      setSendingInvoiceAppId(null);
    }
  };

  const applicationStatusColors = {
    pending: "bg-amber-100 text-amber-800 border-amber-200",
    payment_pending: "bg-blue-100 text-blue-800 border-blue-200",
    contract_sent: "bg-purple-100 text-purple-800 border-purple-200",
    contract_signed: "bg-indigo-100 text-indigo-800 border-indigo-200", // Added color for contract_signed
    approved: "bg-green-100 text-green-800 border-green-200", // This may overlap with active, consider if needed
    active: "bg-green-100 text-green-800 border-green-200",
    rejected: "bg-red-100 text-red-800 border-red-200"
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Sponsorship</h1>
            <p className="text-slate-600">Manage club sponsors, tiers, and partnership benefits.</p>
          </div>
        </div>

        <Tabs defaultValue="sponsors" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="sponsors">Sponsors ({sponsors.length})</TabsTrigger>
            <TabsTrigger value="tiers">Sponsorship Tiers ({tiers.length})</TabsTrigger>
            <TabsTrigger value="applications" className="flex items-center gap-2">
              Applications <Badge className="ml-2 bg-green-600 text-white">{applications.length}</Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sponsors" className="space-y-6">
            <div className="flex justify-end">
              <Button onClick={() => { setEditingSponsor(null); setShowSponsorForm(true); }} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Sponsor
              </Button>
            </div>

            {showSponsorForm && (
              <SponsorForm
                sponsor={editingSponsor}
                tiers={tiers}
                onSubmit={handleSponsorSubmit}
                onCancel={() => { setShowSponsorForm(false); setEditingSponsor(null); }}
              />
            )}

            <SponsorList 
              sponsors={sponsors} 
              tiers={tiers} 
              loading={loading} 
              onEdit={handleEditSponsor} 
              onDelete={handleDeleteSponsor} 
              onGenerateInvoice={handleInvoiceGenerated} // Changed to new callback
              invoices={invoices} // Pass invoices to the component
            />
          </TabsContent>

          <TabsContent value="tiers" className="space-y-6">
            <div className="flex justify-end">
              <Button onClick={() => { setEditingTier(null); setShowTierForm(true); }} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Tier
              </Button>
            </div>

            {showTierForm && (
              <TierForm
                tier={editingTier}
                onSubmit={handleTierSubmit}
                onCancel={() => { setShowTierForm(false); setEditingTier(null); }}
              />
            )}

            <TierList tiers={tiers} loading={loading} onEdit={handleEditTier} onDelete={handleDeleteTier} />
          </TabsContent>

          <TabsContent value="applications">
             <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Handshake className="w-6 h-6 text-green-600" />
                  Sponsorship Applications ({applications.length})
                </CardTitle>
                <CardDescription>Comprehensive view of all partnership inquiries and sponsorship applications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {applications.map(app => {
                    const selectedTier = tiers.find(t => t.id === app.sponsorship_tier_id);
                    const signedContract = contracts.find(c => 
                      c.application_id === app.id && c.status === 'signed'
                    );
                    const appInvoice = invoices.find(inv => inv.related_entity_id === app.id && inv.related_entity_type === 'sponsorship_application');
                    
                    return (
                      <Card key={app.id} className="bg-gradient-to-r from-white to-slate-50 hover:shadow-xl transition-all duration-300 border-l-4 border-l-blue-500">
                        <CardContent className="p-8">
                          {/* Company Header Section */}
                          <div className="flex flex-col lg:flex-row gap-6 mb-6">
                            {/* Company Logo & Basic Info */}
                            <div className="flex items-start gap-4">
                              {app.logo_url ? (
                                <img 
                                  src={app.logo_url} 
                                  alt={`${app.company_name} logo`} 
                                  className="w-20 h-20 object-contain rounded-lg border-2 border-gray-200 bg-white p-2" 
                                />
                              ) : (
                                <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg flex items-center justify-center">
                                  <span className="text-2xl font-bold text-blue-600">{app.company_name.charAt(0)}</span>
                                </div>
                              )}
                              <div className="flex-1">
                                <div className="flex items-center gap-3 mb-2">
                                  <h3 className="font-bold text-2xl text-slate-900">{app.company_name}</h3>
                                  {app.trading_name && app.trading_name !== app.company_name && (
                                    <Badge variant="outline" className="text-sm">Trading as: {app.trading_name}</Badge>
                                  )}
                                </div>
                                
                                <div className="flex items-center gap-3 flex-wrap mb-3">
                                  <Badge className={`px-3 py-1 border ${applicationStatusColors[app.status]}`}>
                                    {app.status?.replace('_', ' ').toUpperCase()}
                                  </Badge>
                                  <Badge variant="outline" className="capitalize bg-blue-50 text-blue-700 border-blue-200">
                                    {app.sponsor_type} sponsor
                                  </Badge>
                                  {selectedTier && (
                                    <Badge 
                                      style={{backgroundColor: selectedTier.color || '#6b7280', color: 'white'}} 
                                      className="border-transparent px-3 py-1"
                                    >
                                      {selectedTier.name} Tier
                                    </Badge>
                                  )}
                                </div>

                                {/* ABN/ACN */}
                                {app.abn_acn && (
                                  <div className="text-sm text-slate-600 font-medium">
                                    ABN/ACN: {app.abn_acn}
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Sponsorship Amount */}
                            <div className="lg:text-right lg:min-w-[200px]">
                              <div className="text-4xl font-bold text-green-600 mb-1">
                                ${app.custom_amount?.toLocaleString() || 'TBD'}
                              </div>
                              <div className="text-sm text-slate-500 capitalize mb-1">{app.payment_preference}</div>
                              {app.installment_months && (
                                <div className="text-xs text-slate-500">
                                  {app.installment_months} installments
                                </div>
                              )}
                              {selectedTier && (
                                <div className="text-xs text-slate-500 mt-2">
                                  Min: ${selectedTier.minimum_amount?.toLocaleString()}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Detailed Information Grid */}
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                            
                            {/* Contact Information */}
                            <div className="bg-slate-50/70 rounded-lg p-4">
                              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                                <User className="w-4 h-4" />
                                Primary Contact
                              </h4>
                              <div className="space-y-2 text-sm">
                                <div><strong>Name:</strong> {app.contact_person}</div>
                                {app.contact_position && <div><strong>Position:</strong> {app.contact_position}</div>}
                                <div><strong>Email:</strong> {app.email}</div>
                                <div><strong>Phone:</strong> {app.phone}</div>
                              </div>
                            </div>

                            {/* Address Information */}
                            <div className="bg-slate-50/70 rounded-lg p-4">
                              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                                <Building className="w-4 h-4" />
                                Business Address
                              </h4>
                              <div className="space-y-2 text-sm">
                                {app.registered_address && (
                                  <div><strong>Registered:</strong><br />{app.registered_address}</div>
                                )}
                                {app.postal_address && app.postal_address !== app.registered_address && (
                                  <div><strong>Postal:</strong><br />{app.postal_address}</div>
                                )}
                                {app.website && (
                                  <div>
                                    <strong>Website:</strong><br />
                                    <a href={app.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline break-all">
                                      {app.website}
                                    </a>
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Sponsorship Details */}
                            <div className="bg-slate-50/70 rounded-lg p-4">
                              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                                <DollarSign className="w-4 h-4" />
                                Sponsorship Details
                              </h4>
                              <div className="space-y-2 text-sm">
                                <div><strong>Type:</strong> {app.sponsor_type === 'general' ? 'General Sponsorship' : 'Event Sponsorship'}</div>
                                <div><strong>Contribution:</strong> {app.contribution_type === 'financial' ? 'Financial' : 'In-Kind'}</div>
                                {app.contribution_type === 'inkind' && app.inkind_description && (
                                  <>
                                    <div><strong>In-Kind Services:</strong> {app.inkind_description}</div>
                                    {app.inkind_value && <div><strong>Estimated Value:</strong> ${app.inkind_value.toLocaleString()}</div>}
                                  </>
                                )}
                                {app.event_details && (
                                  <div><strong>Event Details:</strong> {app.event_details}</div>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Social Media & Marketing */}
                          {(app.social_media_handles || app.marketing_goals) && (
                            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 mb-6">
                              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                                <Globe className="w-4 h-4" />
                                Marketing & Social Media
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {app.social_media_handles && (
                                  <div>
                                    <strong className="text-sm">Social Media:</strong>
                                    <div className="mt-2 flex flex-wrap gap-2">
                                      {Object.entries(app.social_media_handles).map(([platform, handle]) => 
                                        handle && (
                                          <Badge key={platform} variant="outline" className="text-xs">
                                            {platform}: {handle}
                                          </Badge>
                                        )
                                      )}
                                    </div>
                                  </div>
                                )}
                                {app.marketing_goals && (
                                  <div>
                                    <strong className="text-sm">Marketing Goals:</strong>
                                    <p className="text-sm text-slate-600 mt-1">{app.marketing_goals}</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Guarantor Information */}
                          {app.guarantor_name && (
                            <div className="bg-amber-50/70 rounded-lg p-4 mb-6">
                              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                                <Shield className="w-4 h-4" />
                                Guarantor Information
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                <div>
                                  <strong>Name:</strong> {app.guarantor_name}<br />
                                  <strong>Address:</strong> {app.guarantor_address}
                                </div>
                                <div>
                                  {app.guarantor_email && <div><strong>Email:</strong> {app.guarantor_email}</div>}
                                  {app.guarantor_phone && <div><strong>Phone:</strong> {app.guarantor_phone}</div>}
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Brand Assets */}
                          {(app.logo_url || app.brand_guidelines_url) && (
                            <div className="bg-green-50/70 rounded-lg p-4 mb-6">
                              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                                <FileText className="w-4 h-4" />
                                Brand Assets
                              </h4>
                              <div className="flex gap-4">
                                {app.logo_url && (
                                  <div>
                                    <Badge variant="outline" className="mb-2">Logo Available</Badge>
                                    <a href={app.logo_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm block">
                                      View Logo
                                    </a>
                                  </div>
                                )}
                                {app.brand_guidelines_url && (
                                  <div>
                                    <Badge variant="outline" className="mb-2">Brand Guidelines</Badge>
                                    <a href={app.brand_guidelines_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm block">
                                      View Guidelines
                                    </a>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Application Notes */}
                          {app.notes && (
                            <div className="bg-slate-50/70 rounded-lg p-4 mb-6">
                              <h4 className="font-semibold text-slate-800 mb-2">Additional Notes:</h4>
                              <p className="text-sm text-slate-600">{app.notes}</p>
                            </div>
                          )}

                          {/* Action Buttons - Enhanced */}
                          <div className="flex flex-wrap gap-3 pt-4 border-t border-slate-200">
                            <Button 
                              size="sm" 
                              onClick={() => setShowContractModal({ show: true, application: app })} 
                              disabled={['contract_sent', 'contract_signed', 'active'].includes(app.status)} 
                              className="bg-purple-600 hover:bg-purple-700 text-white"
                            >
                              <FileText className="w-3 h-3 mr-1" /> Send Contract
                            </Button>

                            {signedContract && (
                              <Button 
                                size="sm" 
                                onClick={() => handleViewSignedContract(app.id)}
                                className="bg-blue-600 hover:bg-blue-700 text-white"
                              >
                                <FileText className="w-3 h-3 mr-1" /> Review Signed Contract
                              </Button>
                            )}

                            {/* Invoice Actions */}
                            {signedContract && app.status !== 'active' && (
                              <div className="flex gap-2 flex-wrap items-center border-l-2 border-slate-200 pl-3 ml-1">
                                {appInvoice ? (
                                  <>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => handleDownloadApplicationInvoice(appInvoice.id)}
                                      disabled={downloadingInvoiceAppId === appInvoice.id}
                                      className="text-green-600 bg-green-50"
                                    >
                                      <Download className="w-3 h-3 mr-1" />
                                      {downloadingInvoiceAppId === appInvoice.id ? 'Loading...' : 'View Invoice'}
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => handleSendApplicationInvoice(appInvoice, app)}
                                      disabled={sendingInvoiceAppId === appInvoice.id}
                                      className="text-blue-600 bg-blue-50"
                                    >
                                      <Send className="w-3 h-3 mr-1" />
                                      {sendingInvoiceAppId === appInvoice.id ? 'Sending...' : 'Send Invoice'}
                                    </Button>
                                  </>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleGenerateApplicationInvoice(app)}
                                    disabled={generatingInvoiceAppId === app.id}
                                    className="text-purple-600 bg-purple-50"
                                  >
                                    <FileText className="w-3 h-3 mr-1" />
                                    {generatingInvoiceAppId === app.id ? 'Generating...' : 'Generate Invoice'}
                                  </Button>
                                )}
                              </div>
                            )}

                            {signedContract && app.status !== 'active' && (
                              <Button 
                                size="sm" 
                                onClick={() => handleActivateSponsorship(app.id)}
                                className="bg-green-600 hover:bg-green-700 text-white"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" /> Activate Sponsorship
                              </Button>
                            )}
                            
                            <Button 
                              size="sm" 
                              onClick={() => handleApplicationStatusChange(app.id, 'active')} 
                              disabled={app.status === 'active'} 
                              className="bg-green-500 hover:bg-green-600 text-white"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" /> Quick Activate
                            </Button>
                            
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleApplicationStatusChange(app.id, 'rejected')} 
                              disabled={app.status === 'rejected'} 
                              className="text-red-600 hover:bg-red-50 border-red-200"
                            >
                              <X className="w-4 h-4 mr-1" /> Reject
                            </Button>
                            
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleDeleteApplication(app.id)} 
                              className="text-red-600 hover:bg-red-50 border-red-200"
                            >
                              <Trash2 className="w-4 h-4 mr-1" /> Delete
                            </Button>
                          </div>

                          {/* Application Metadata */}
                          <div className="mt-4 pt-4 border-t border-slate-200 text-xs text-slate-500">
                            <div className="flex justify-between items-center">
                              <span>Applied: {new Date(app.created_date).toLocaleDateString()}</span>
                              {app.terms_accepted_at && (
                                <span>Terms accepted: {new Date(app.terms_accepted_at).toLocaleDateString()}</span>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                  
                  {applications.length === 0 && (
                    <div className="text-center py-12">
                      <Handshake className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-slate-700 mb-2">No Applications Yet</h3>
                      <p className="text-slate-500">Sponsorship applications will appear here when submitted.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {showContractModal.show && (
              <SendContractModal
                application={showContractModal.application}
                isOpen={showContractModal.show}
                onClose={() => setShowContractModal({ show: false, application: null })}
                onContractSent={() => { loadData(); }}
              />
            )}

            {viewContractModal.show && (
              <ViewSignedContractModal
                contract={viewContractModal.contract}
                isOpen={viewContractModal.show}
                onClose={() => setViewContractModal({ show: false, contract: null })}
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
