
import React, { useState, useEffect } from "react";
import { Team, Member, Season } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, Users, Trophy } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from 'sonner';

import TeamList from "../components/teams/TeamList";
import TeamForm from "../components/teams/TeamForm";
import TeamStats from "../components/teams/TeamStats";
import SeasonSetupModal from '../components/teams/SeasonSetupModal';

export default function Teams() {
  const [teams, setTeams] = useState([]);
  const [members, setMembers] = useState([]);
  const [seasons, setSeasons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSport, setFilterSport] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingTeam, setEditingTeam] = useState(null);
  const [showSeasonModal, setShowSeasonModal] = useState(false);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [teamsData, membersData, seasonsData] = await Promise.all([
        Team.list("-created_date"),
        Member.list(),
        Season.list("-created_date")
      ]);
      setTeams(teamsData);
      setMembers(membersData);
      setSeasons(seasonsData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load club data.");
    } finally {
      setLoading(false);
    }
  };

  const handleTeamSubmit = async (teamData) => {
    try {
      if (editingTeam) {
        await Team.update(editingTeam.id, teamData);
        toast.success("Team updated successfully!");
      } else {
        await Team.create(teamData);
        toast.success("Team created successfully!");
      }
      setShowForm(false);
      setEditingTeam(null);
      loadAllData();
    } catch (error) {
      console.error("Error saving team:", error);
      toast.error("Failed to save team.");
    }
  };

  const handleCreateCoach = async (coachData) => {
    try {
      const newCoach = await Member.create(coachData);
      // Reload members to update coach dropdown
      await loadAllData();
      return newCoach;
    } catch (error) {
      console.error("Error creating coach:", error);
      throw error;
    }
  };

  const handleEditTeam = (team) => {
    setEditingTeam(team);
    setShowForm(true);
  };

  const handleDeleteTeam = async (teamId) => {
    if (window.confirm("Are you sure you want to delete this team?")) {
      try {
        await Team.delete(teamId);
        toast.success("Team deleted.");
        loadAllData();
      } catch (error) {
        console.error("Error deleting team:", error);
        toast.error("Failed to delete team.");
      }
    }
  };

  // --- Season Management Handlers ---

  const handleSeasonSubmit = async (seasonData) => {
    try {
      if (seasonData.id) {
        await Season.update(seasonData.id, seasonData);
        toast.success("Season updated successfully!");
      } else {
        await Season.create(seasonData);
        toast.success("Season created successfully!");
      }
      loadAllData(); // Reload all data to reflect changes
    } catch (error) {
      console.error("Error saving season:", error);
      toast.error("Failed to save season.");
    }
  };

  const handleSeasonDelete = async (seasonId) => {
    if (window.confirm("Are you sure you want to delete this season?")) {
      try {
        await Season.delete(seasonId);
        toast.success("Season deleted.");
        loadAllData();
      } catch (error) {
        console.error("Error deleting season:", error);
        toast.error("Failed to delete season.");
      }
    }
  };

  const handleBulkUpdate = async (seasonName, teamIds) => {
    toast.info(`Updating ${teamIds.length} teams to season "${seasonName}"...`);
    try {
      const updatePromises = teamIds.map(id => Team.update(id, { season: seasonName }));
      await Promise.all(updatePromises);
      toast.success(`${teamIds.length} teams have been updated successfully!`);
      loadAllData();
    } catch (error) {
      console.error("Error bulk updating teams:", error);
      toast.error("An error occurred during the bulk update.");
    }
  };

  const filteredTeams = teams.filter(team => {
    const matchesSearch = searchTerm === "" || 
      team.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      team.age_group?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSport = filterSport === "all" || team.sport === filterSport;
    const matchesStatus = filterStatus === "all" || team.status === filterStatus;

    return matchesSearch && matchesSport && matchesStatus;
  });

  // Get coaches for team assignment
  const coaches = members.filter(member => 
    member.membership_type === 'coach' && member.membership_status === 'active'
  );

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Teams</h1>
            <p className="text-slate-600">Manage your club teams, coaches, and seasons.</p>
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <Button
              variant="outline"
              className="flex-1 md:flex-none"
              onClick={() => setShowSeasonModal(true)}
            >
              <Trophy className="w-4 h-4 mr-2" />
              Season Setup
            </Button>
            <Button 
              onClick={() => {
                setEditingTeam(null);
                setShowForm(true);
              }}
              className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Team
            </Button>
          </div>
        </div>

        {/* Stats */}
        <TeamStats teams={teams} loading={loading} />

        {/* Search and Filters */}
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search teams by name or age group..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={filterSport}
                onChange={(e) => setFilterSport(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">All Sports</option>
                <option value="soccer">Soccer</option>
                <option value="basketball">Basketball</option>
                <option value="hockey">Hockey</option>
                <option value="netball">Netball</option>
                <option value="rugby">Rugby</option>
              </select>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="disbanded">Disbanded</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Team Form */}
        {showForm && (
          <TeamForm
            team={editingTeam}
            coaches={coaches}
            onSubmit={handleTeamSubmit}
            onCreateCoach={handleCreateCoach}
            onCancel={() => {
              setShowForm(false);
              setEditingTeam(null);
            }}
          />
        )}

        {/* Teams List */}
        <TeamList
          teams={filteredTeams}
          members={members}
          loading={loading}
          onEditTeam={handleEditTeam}
          onDeleteTeam={handleDeleteTeam}
        />

        {/* Season Setup Modal */}
        <SeasonSetupModal
          isOpen={showSeasonModal}
          onClose={() => setShowSeasonModal(false)}
          seasons={seasons}
          teams={teams}
          onSeasonSubmit={handleSeasonSubmit}
          onSeasonDelete={handleSeasonDelete}
          onBulkUpdate={handleBulkUpdate}
        />
      </div>
    </div>
  );
}
