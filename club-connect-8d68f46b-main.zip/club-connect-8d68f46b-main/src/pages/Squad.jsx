
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Users, Trophy, Star, AlertCircle } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { getPublicSquadData } from '@/api/functions';

export default function SquadPage() {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filteredTeam, setFilteredTeam] = useState(null);
  const [totalActivePlayers, setTotalActivePlayers] = useState(0);

  const location = useLocation();

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const urlParams = new URLSearchParams(location.search);
        const teamId = urlParams.get('teamId');

        const { data } = await getPublicSquadData({ teamId: teamId || null });

        if (data.success) {
          setPlayers(data.players);
          setTeams(data.teams);
          setTotalActivePlayers(data.totalActivePlayers);

          if (teamId) {
            const teamData = data.teams.find(t => t.id === teamId);
            setFilteredTeam(teamData || null);
          } else {
            setFilteredTeam(null);
          }
        } else {
          throw new Error(data.error || "Failed to fetch squad data.");
        }
      } catch (error) {
        console.error("Error loading squad data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [location.search]);

  const PlayerCard = ({ player, delay = 0 }) => {
    const team = teams.find(t => t.id === player.team_id);

    return (
      <div 
        className="animate-in fade-in slide-in-from-bottom-4 duration-500"
        style={{ animationDelay: `${delay}ms` }}
      >
        <Link to={createPageUrl(`PlayerBio?playerId=${player.id}`)}>
          <Card className="group bg-white shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 rounded-xl overflow-hidden border-0 text-center cursor-pointer">
            <CardContent className="p-4 flex flex-col items-center">
              <div className="relative mb-3">
                {(player.profile_photo_url || player.photo_url) ? (
                  <img
                    src={player.profile_photo_url || player.photo_url}
                    alt={`${player.first_name} ${player.last_name}`}
                    className="w-24 h-24 rounded-full object-cover border-4 border-slate-100 group-hover:border-red-200 transition-colors"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center border-4 border-slate-100">
                    <Users className="w-10 h-10 text-red-400" />
                  </div>
                )}
                <Badge className="absolute -bottom-1 -right-1 bg-red-600 text-white text-sm font-bold px-2 py-1 rounded-full border-2 border-white">
                  {player.preferred_number}
                </Badge>
              </div>
              
              <h3 className="text-base font-bold text-slate-900 truncate w-full">
                {player.first_name} {player.last_name}
              </h3>
              
              <p className="text-slate-600 font-medium text-sm">
                {player.position}
              </p>

              {team && (
                <p 
                  className="font-semibold text-sm mt-1"
                  style={{ color: team.team_color || '#000000' }}
                >
                  {team.name}
                </p>
              )}

              {player.is_available_for_loan && (
                <Badge className="bg-green-600 text-white text-xs mt-2">
                  Available for Loan
                </Badge>
              )}

              {player.achievements && player.achievements.length > 0 && (
                <div className="pt-2 mt-2 border-t border-slate-200 w-full">
                  <ul className="space-y-1">
                    {player.achievements.slice(0, 1).map((achievement, index) => (
                      <li key={index} className="text-slate-600 text-xs flex items-center justify-center gap-1.5 truncate">
                        <Star className="w-3 h-3 text-yellow-500 flex-shrink-0" />
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </Link>
      </div>
    );
  };

  // Group players by teams
  const groupPlayersByTeam = () => {
    if (filteredTeam) {
      return { [filteredTeam.name]: players };
    }

    const mainTeam = teams.find(t => t.is_main_team);
    const mastersTeam = teams.find(t => t.name?.toLowerCase().includes('veteran') || t.name?.toLowerCase().includes('master'));
    
    const teamGroups = {
      'Main Team': [],
      'Masters': [],
      'Other Teams': []
    };

    players.forEach(player => {
      const team = teams.find(t => t.id === player.team_id);
      
      if (mainTeam && player.team_id === mainTeam.id) {
        teamGroups['Main Team'].push(player);
      } else if (mastersTeam && player.team_id === mastersTeam.id) {
        teamGroups['Masters'].push(player);
      } else if (team) {
        if (!teamGroups[team.name]) {
          teamGroups[team.name] = [];
        }
        teamGroups[team.name].push(player);
      } else {
        teamGroups['Other Teams'].push(player);
      }
    });

    // Remove empty groups
    Object.keys(teamGroups).forEach(key => {
      if (teamGroups[key].length === 0) {
        delete teamGroups[key];
      }
    });

    return teamGroups;
  };

  const teamGroups = groupPlayersByTeam();

  return (
    <div className="bg-black text-white min-h-screen">
      <div className="relative py-24 bg-gradient-to-r from-red-900/50 to-black">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black tracking-tight">{filteredTeam ? filteredTeam.name : 'OUR SQUAD'}</h1>
          <p className="mt-3 text-lg text-gray-300">{filteredTeam ? `Players for the ${filteredTeam.season || '2025-2026'} season` : 'Meet the talented players of Nepbourne FC'}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {loading ? (
          <div className="flex justify-center items-center">
            <Loader2 className="h-12 w-12 animate-spin text-red-600" />
          </div>
        ) : (
          <>
            {players.length > 0 ? (
              <div className="space-y-16">
                {/* Main Team Section */}
                {teamGroups['Main Team'] && teamGroups['Main Team'].length > 0 && (
                  <section>
                    <div className="text-center mb-12">
                      <h2 className="text-4xl font-black text-white mb-4 flex items-center justify-center gap-3">
                        <Trophy className="w-10 h-10 text-red-600" />
                        MAIN TEAM
                        <Trophy className="w-10 h-10 text-red-600" />
                      </h2>
                      <div className="h-1 w-32 bg-red-600 mx-auto"></div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                      {teamGroups['Main Team'].map((player, index) => (
                        <PlayerCard key={player.id} player={player} delay={index * 30} />
                      ))}
                    </div>
                  </section>
                )}

                {/* Masters Section */}
                {teamGroups['Masters'] && teamGroups['Masters'].length > 0 && (
                  <section>
                    <div className="text-center mb-12">
                      <h2 className="text-4xl font-black text-white mb-4 flex items-center justify-center gap-3">
                        <Star className="w-10 h-10 text-amber-500" />
                        MASTERS
                        <Star className="w-10 h-10 text-amber-500" />
                      </h2>
                      <div className="h-1 w-32 bg-amber-500 mx-auto"></div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                      {teamGroups['Masters'].map((player, index) => (
                        <PlayerCard key={player.id} player={player} delay={index * 30} />
                      ))}
                    </div>
                  </section>
                )}

                {/* Other Teams Sections */}
                {Object.entries(teamGroups).map(([teamName, teamPlayers]) => {
                  if (teamName === 'Main Team' || teamName === 'Masters' || teamPlayers.length === 0) {
                    return null;
                  }

                  const team = teams.find(t => t.name === teamName);
                  
                  return (
                    <section key={teamName}>
                      <div className="text-center mb-12">
                        <h2 className="text-3xl font-black text-white mb-4 flex items-center justify-center gap-3">
                          <Users className="w-8 h-8 text-blue-500" />
                          {teamName.toUpperCase()}
                          <Users className="w-8 h-8 text-blue-500" />
                        </h2>
                        <div className="h-1 w-24 bg-blue-500 mx-auto"></div>
                        {team && team.age_group && (
                          <p className="text-gray-400 mt-2">{team.age_group} • {team.season || '2025-2026'}</p>
                        )}
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                        {teamPlayers.map((player, index) => (
                          <PlayerCard key={player.id} player={player} delay={index * 30} />
                        ))}
                      </div>
                    </section>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="flex flex-col items-center gap-4">
                  <AlertCircle className="w-16 h-16 text-gray-500" />
                  <h3 className="text-2xl font-semibold text-gray-300">Squad Information Coming Soon</h3>
                  <div className="max-w-lg text-gray-400 space-y-2">
                    {totalActivePlayers > 0 ? (
                      <>
                        <p>We have {totalActivePlayers} players in our system, but player profiles are currently being prepared for public display.</p>
                        <p className="text-sm">Check back soon to meet our talented squad!</p>
                      </>
                    ) : (
                      <p>Player information is being updated. Please check back soon to see our talented roster.</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
