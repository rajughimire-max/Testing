
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Campaign, EmailTemplate, SmsTemplate, Contact } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Send, Eye, Users, Settings, Mail, MessageSquare } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';

export default function CrmCampaignEditorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [audienceSize, setAudienceSize] = useState(0);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);

  const [formData, setFormData] = useState({
    template_id: '',
    from_name: '',
    from_email: '',
    reply_to: '',
    audience_filter: 'all'
  });

  // calculateAudienceSize is a dependency for loadCampaignData,
  // but it itself depends on 'campaign' state which is set inside loadCampaignData.
  // This creates a circular dependency or stale closure issue if not handled carefully.
  // A safer approach is to ensure calculateAudienceSize takes all necessary
  // data as arguments or that `campaign` is stable (e.g., from an upstream `loadCampaignData`
  // that completes before `calculateAudienceSize` is called, or by ensuring `campaign` is
  // always the most recent from state when `calculateAudienceSize` is called, not from
  // a stale closure). For this specific case, `campaign` is used for `campaign.channel`,
  // which is derived from `campaignData` passed within `loadCampaignData`.
  // So, let's ensure `calculateAudienceSize` always uses the correct `campaign` object,
  // or pass the channel directly if `campaign` state might lag.
  // For now, it implicitly uses the `campaign` from the component scope, which might be stale.
  // Let's refactor calculateAudienceSize to take campaignChannel as an argument for robustness.
  const calculateAudienceSize = useCallback((contactList, filter, campaignChannel) => {
    let filteredContacts = contactList;
    
    // Apply consent filters
    if (campaignChannel === 'email') {
      filteredContacts = filteredContacts.filter(c => c.marketing_opt_in && c.email);
    } else if (campaignChannel === 'sms') {
      filteredContacts = filteredContacts.filter(c => c.sms_opt_in && c.phone);
    }

    // Apply additional filters based on selection
    switch (filter) {
      case 'members':
        filteredContacts = filteredContacts.filter(c => c.roles?.includes('MEMBER'));
        break;
      case 'players':
        filteredContacts = filteredContacts.filter(c => c.roles?.includes('PLAYER'));
        break;
      case 'sponsors':
        filteredContacts = filteredContacts.filter(c => c.roles?.includes('SPONSOR'));
        break;
      case 'leads':
        filteredContacts = filteredContacts.filter(c => c.roles?.includes('LEAD'));
        break;
      // 'all' includes everyone with proper consent
    }

    setAudienceSize(filteredContacts.length);
  }, []); // No external dependencies for calculateAudienceSize itself, it takes params.

  const loadCampaignData = useCallback(async () => {
    setLoading(true);
    try {
      const [campaignData, contactsData] = await Promise.all([
        Campaign.get(id),
        Contact.list()
      ]);
      
      setCampaign(campaignData);
      setContacts(contactsData);
      
      // Load appropriate templates based on campaign channel
      const templatesData = campaignData.channel === 'email' 
        ? await EmailTemplate.list()
        : await SmsTemplate.list();
      setTemplates(templatesData);

      // Set form data from existing campaign
      const initialFormData = {
        template_id: campaignData.template_id || '',
        from_name: campaignData.from_name || 'Nepbourne FC',
        from_email: campaignData.from_email || '',
        reply_to: campaignData.reply_to || '',
        audience_filter: 'all' // Default for now
      };
      setFormData(initialFormData);

      // Pass campaignData.channel to ensure correct filtering based on newly loaded data
      calculateAudienceSize(contactsData, initialFormData.audience_filter, campaignData.channel);
      
    } catch (error) {
      console.error("Error loading campaign:", error);
      navigate(createPageUrl('CrmCampaigns'));
    } finally {
      setLoading(false);
    }
  }, [id, navigate, calculateAudienceSize]); // Add calculateAudienceSize to dependencies

  useEffect(() => {
    loadCampaignData();
  }, [loadCampaignData]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (field === 'audience_filter') {
      // Ensure we use the latest `campaign` object from state if it's available,
      // or preferably pass the campaign.channel directly from the `campaign` state.
      // Since `campaign` state is updated by `loadCampaignData` and might be
      // stale here immediately after initial load, it's safer to ensure
      // `calculateAudienceSize` has a reliable `campaign.channel`.
      // The `campaign` state is generally stable after `loadCampaignData` resolves.
      if (campaign) {
          calculateAudienceSize(contacts, value, campaign.channel);
      }
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await Campaign.update(id, {
        ...formData,
        status: 'draft'
      });
      alert('Campaign saved successfully!');
    } catch (error) {
      console.error("Error saving campaign:", error);
      alert("Failed to save campaign. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleSend = async () => {
    if (!formData.template_id) {
      alert('Please select a template before sending.');
      return;
    }

    if (audienceSize === 0) {
      alert('No eligible contacts found for this campaign. Check your audience settings and consent preferences.');
      return;
    }

    const confirmation = window.confirm(
      `Are you sure you want to send this ${campaign.channel} campaign to ${audienceSize} contacts? This action cannot be undone.`
    );

    if (!confirmation) return;

    setSending(true);
    try {
      // Update campaign with final settings
      await Campaign.update(id, {
        ...formData,
        status: 'sending',
        stats: { ...campaign.stats, total: audienceSize }
      });

      // TODO: Implement actual sending logic with SendGrid/Twilio
      // For now, we'll simulate sending
      alert(`Campaign queued for sending to ${audienceSize} contacts. (Note: Actual sending requires API keys to be configured)`);
      
      navigate(createPageUrl('CrmCampaigns'));
    } catch (error) {
      console.error("Error sending campaign:", error);
      alert("Failed to send campaign. Please try again.");
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-32 w-full mb-8" />
          <div className="grid gap-6">
            {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-48 w-full" />)}
          </div>
        </div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="p-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-2xl font-bold text-slate-900">Campaign not found</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" onClick={() => navigate(createPageUrl('CrmCampaigns'))}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Campaigns
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              {campaign.channel === 'email' ? 
                <Mail className="w-6 h-6 text-blue-600" /> : 
                <MessageSquare className="w-6 h-6 text-green-600" />
              }
              <div>
                <h1 className="text-2xl font-bold text-slate-900">{campaign.name}</h1>
                <p className="text-slate-600 capitalize">{campaign.channel} Campaign</p>
              </div>
            </div>
          </div>
          <Badge className={`${campaign.status === 'draft' ? 'bg-gray-200 text-gray-800' : 'bg-blue-200 text-blue-800'}`}>
            {campaign.status}
          </Badge>
        </div>

        <Tabs defaultValue="setup" className="space-y-6">
          <TabsList>
            <TabsTrigger value="setup"><Settings className="w-4 h-4 mr-2" />Setup</TabsTrigger>
            <TabsTrigger value="audience"><Users className="w-4 h-4 mr-2" />Audience ({audienceSize})</TabsTrigger>
            <TabsTrigger value="preview"><Eye className="w-4 h-4 mr-2" />Preview</TabsTrigger>
          </TabsList>

          <TabsContent value="setup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Settings</CardTitle>
                <CardDescription>Configure your campaign template and sender details.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Template</Label>
                  <Select value={formData.template_id} onValueChange={(value) => handleChange('template_id', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a template" />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map(template => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {campaign.channel === 'email' && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="from_name">From Name</Label>
                        <Input
                          id="from_name"
                          value={formData.from_name}
                          onChange={(e) => handleChange('from_name', e.target.value)}
                          placeholder="Nepbourne FC"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="from_email">From Email</Label>
                        <Input
                          id="from_email"
                          type="email"
                          value={formData.from_email}
                          onChange={(e) => handleChange('from_email', e.target.value)}
                          placeholder="info@nepbournefc.com"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reply_to">Reply-To Email</Label>
                      <Input
                        id="reply_to"
                        type="email"
                        value={formData.reply_to}
                        onChange={(e) => handleChange('reply_to', e.target.value)}
                        placeholder="info@nepbournefc.com"
                      />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audience" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Select Audience</CardTitle>
                <CardDescription>Choose who will receive this campaign.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Audience Filter</Label>
                  <Select value={formData.audience_filter} onValueChange={(value) => handleChange('audience_filter', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Contacts (with consent)</SelectItem>
                      <SelectItem value="members">Members Only</SelectItem>
                      <SelectItem value="players">Players Only</SelectItem>
                      <SelectItem value="sponsors">Sponsors Only</SelectItem>
                      <SelectItem value="leads">Leads Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Estimated Recipients</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-900">{audienceSize}</p>
                  <p className="text-sm text-blue-700">
                    {campaign.channel === 'email' 
                      ? 'Contacts with email marketing consent'
                      : 'Contacts with SMS marketing consent'
                    }
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Preview</CardTitle>
                <CardDescription>Preview how your campaign will look to recipients.</CardDescription>
              </CardHeader>
              <CardContent>
                {formData.template_id ? (
                  <div className="p-4 border border-slate-200 rounded-lg bg-slate-50">
                    <p className="text-slate-600">Template preview will be shown here once template merging is implemented.</p>
                  </div>
                ) : (
                  <p className="text-slate-500">Select a template to see preview</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div className="text-sm text-slate-600">
                Ready to send to {audienceSize} contacts
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={handleSave} disabled={saving}>
                  {saving ? 'Saving...' : 'Save Draft'}
                </Button>
                <Button 
                  onClick={handleSend} 
                  disabled={sending || !formData.template_id || audienceSize === 0}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Send className="w-4 h-4 mr-2" />
                  {sending ? 'Sending...' : 'Send Campaign'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
