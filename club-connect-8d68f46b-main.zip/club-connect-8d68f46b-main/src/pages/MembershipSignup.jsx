
import React, { useState, useEffect } from 'react';
import { MembershipType, MembershipApplication, ContractTemplate } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea }
 from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, CreditCard, ArrowRight, FileText, Upload, X, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { createPaymentSession } from "@/api/functions";
import { UploadFile } from '@/api/integrations';
import { redirectToStripeCheckout } from "../components/stripe/StripeLoader";
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import ReactMarkdown from 'react-markdown';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

export default function MembershipSignup() {
  const [membershipTypes, setMembershipTypes] = useState([]);
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    date_of_birth: "",
    street_address: "",
    suburb: "",
    state: "",
    postcode: "",
    membership_type_id: "",
    photo_url: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    medical_conditions: "",
    payment_method: "stripe"
  });
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [applicationId, setApplicationId] = useState(null);
  const [termsContent, setTermsContent] = useState('');
  const [termsAgreed, setTermsAgreed] = useState(false);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const [types, templates] = await Promise.all([
          MembershipType.list(),
          ContractTemplate.filter({ contract_type: 'membership', is_active: true })
        ]);
        setMembershipTypes(types.filter(t => t.is_visible && t.is_active));
        if (templates.length > 0) {
          setTermsContent(templates[0].content);
        } else {
          setTermsContent("No active membership terms and conditions found. Please contact the club administrator.");
        }
      } catch (error) {
        console.error("Error loading initial data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadInitialData();
  }, []);

  // Check URL parameters for payment status
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('success') === 'true') {
      setCurrentStep(5); // Show success message (new step 5)
    }
    // Optionally handle canceled payments, though the current design doesn't have a specific step for it
    // if (urlParams.get('canceled') === 'true') {
    //   alert("Payment canceled. Please try again.");
    //   // Potentially redirect back to step 4 or log the cancellation
    // }
  }, []);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file (JPG, PNG, GIF).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('File is too large. Please select an image smaller than 5MB.');
      return;
    }

    setUploading(true);
    try {
      const response = await UploadFile({ file });
      handleChange('photo_url', response.file_url);
    } catch (error) {
      console.error("Error uploading photo:", error);
      alert('Failed to upload photo. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const selectedMembershipType = membershipTypes.find(t => t.id === formData.membership_type_id);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      const application = await MembershipApplication.create({
        ...formData,
        status: "pending", // Set to pending, will move to payment_pending after terms agreement
        terms_accepted: true, // Mark as accepted here, even if T&C step is separate
        terms_accepted_at: new Date().toISOString()
      });

      setApplicationId(application.id);
      console.log('Application created with ID:', application.id); // Debug log
      setCurrentStep(3); // Go to T&C step
      
    } catch (error) {
      console.error("Error submitting application:", error);
      alert("Failed to submit application. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAcceptTerms = async () => {
    if (!applicationId) {
      alert("Application ID is missing. Please try submitting the form again.");
      return;
    }
    setSubmitting(true);
    try {
      await MembershipApplication.update(applicationId, { status: "payment_pending" });
      setCurrentStep(4); // Go to payment step
    } catch (error) {
      console.error("Error updating application status:", error);
      alert("Failed to proceed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handlePayment = async () => {
    console.log('Starting payment with applicationId:', applicationId); // Debug log
    
    if (!applicationId) {
      alert("Application ID is missing. Please try submitting the form again.");
      return;
    }
    if (!selectedMembershipType?.stripe_price_id) {
      alert(`The selected membership type (${selectedMembershipType?.name || 'Unknown'}) is missing a Stripe Price ID. Please contact an administrator to configure it.`);
      return;
    }

    setSubmitting(true);

    try {
      const response = await createPaymentSession({
        line_items: [{ price: selectedMembershipType.stripe_price_id, quantity: 1 }],
        type: 'membership',
        applicationId: applicationId
      });

      const { data } = response;
      
      if (!data || !data.id) {
        throw new Error('Invalid response from payment session creation');
      }

      // Use proper Stripe checkout with fallback
      await redirectToStripeCheckout({
        sessionId: data.id,
        checkoutUrl: data.url
      });

    } catch (error) {
      console.error("Payment checkout failed:", error);
      
      let errorMessage = 'Payment checkout failed. ';
      if (error.response?.data?.error) {
        errorMessage += error.response.data.error;
      } else if (error.message) {
        errorMessage += error.message;
      } else {
        errorMessage += 'Please try again or contact support.';
      }
      
      alert(errorMessage);
      setSubmitting(false); // Make sure to reset submitting state on error
    }
  };

  const steps = [
    { number: 1, title: "Choose Membership", description: "Select your membership type" },
    { number: 2, title: "Personal Details", description: "Tell us about yourself" },
    { number: 3, title: "Terms & Conditions", description: "Please read and agree" },
    { number: 4, title: "Complete Payment", description: "Secure payment processing" },
    { number: 5, title: "Success", description: "Welcome to the club!" }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="text-center mb-16">
            <Skeleton className="h-16 w-96 mx-auto mb-6" />
            <Skeleton className="h-6 w-128 mx-auto" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-96 rounded-2xl" />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative py-32 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-blue-600/20"></div>
        <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: "url(https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=2940&auto=format&fit=crop)", opacity: 0.1}}></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-7xl font-black text-white tracking-tight leading-none">
              BECOME A MEMBER
            </h1>
            <div className="h-2 w-32 bg-red-600 mx-auto"></div>
            <p className="text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
              Join the Nepbourne FC family and be part of our journey
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-24">
        {/* Progress Steps */}
        <div className="mb-16">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <React.Fragment key={step.number}>
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg transition-all duration-300 ${
                    currentStep >= step.number 
                      ? 'bg-red-600 text-white shadow-lg' 
                      : 'bg-white text-slate-500 shadow-md'
                  }`}>
                    {currentStep > step.number ? <CheckCircle className="w-6 h-6" /> : step.number}
                  </div>
                  <div className="hidden sm:block">
                    <h3 className="font-semibold text-slate-900">{step.title}</h3>
                    <p className="text-sm text-slate-500">{step.description}</p>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div className={`flex-1 h-1 mx-4 sm:mx-8 transition-all duration-300 ${
                    currentStep > step.number ? 'bg-red-600' : 'bg-slate-200'
                  }`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Step 1: Membership Selection */}
          {currentStep === 1 && (
            <div className="space-y-12">
              <div className="text-center">
                <h2 className="text-4xl font-bold text-slate-900 mb-4">Choose Your Membership</h2>
                <p className="text-slate-600 text-xl">Select the plan that best suits you</p>
              </div>
              
              <RadioGroup
                value={formData.membership_type_id}
                onValueChange={(value) => handleChange('membership_type_id', value)}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              >
                {membershipTypes.map((type, index) => {
                  const isSelected = formData.membership_type_id === type.id;
                  const isFeatured = index === 1; // Assuming second item is most popular

                  return (
                    <div key={type.id} className="relative animate-in fade-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${index * 100}ms` }}>
                      {isFeatured && (
                        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-red-600 text-white font-bold px-4 py-1.5 text-sm z-10">
                          MOST POPULAR
                        </Badge>
                      )}
                      <Label htmlFor={type.id} className={`h-full flex flex-col p-8 border-2 rounded-2xl cursor-pointer transition-all duration-300 ${isSelected ? 'border-red-600 bg-red-50/50 shadow-xl' : 'bg-white hover:border-slate-400'} ${isFeatured && !isSelected ? 'scale-105 shadow-xl' : ''} ${!type.is_active ? 'opacity-60 cursor-not-allowed' : ''}`}>
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-2xl font-bold text-slate-900">{type.name}</h3>
                          <RadioGroupItem value={type.id} id={type.id} className="text-red-600 border-red-600" disabled={!type.is_active} />
                        </div>
                        
                        <p className="text-slate-600 mb-6 flex-grow">{type.description}</p>
                        
                        <div className="text-4xl font-bold text-red-600 mb-8">
                          ${type.price_aud}
                          <span className="text-lg font-normal text-slate-500">
                            /{type.billing_model === 'annually' ? 'year' : 
                              type.billing_model === 'monthly' ? 'month' : 
                              type.billing_model === 'weekly' ? 'week' : 
                              type.billing_model === 'lifetime' ? 'lifetime' : 'once'}
                          </span>
                        </div>

                        {type.features && type.features.length > 0 && (
                          <div className="mb-auto pb-8">
                            <h4 className="font-semibold text-slate-900 mb-4">What's Included:</h4>
                            <ul className="space-y-3">
                              {type.features.map((feature, featureIndex) => (
                                <li key={featureIndex} className="flex items-start gap-3">
                                  <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                                  </div>
                                  <span className="text-slate-700 leading-relaxed">{feature}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {!type.is_active && (
                            <Badge variant="destructive" className="w-full justify-center py-2 mt-4">Currently Unavailable</Badge>
                        )}
                      </Label>
                    </div>
                  );
                })}
              </RadioGroup>
              
              <div className="flex justify-end mt-12">
                <Button 
                  type="button" 
                  onClick={() => setCurrentStep(2)} 
                  className="bg-red-600 hover:bg-red-700 px-8 py-3 text-lg" 
                  disabled={!formData.membership_type_id}
                >
                  Continue to Personal Details <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Personal Details */}
          {currentStep === 2 && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Personal Details</h2>
                <p className="text-slate-600 text-lg">Tell us about yourself</p>
              </div>

              <Card>
                <CardContent className="p-8 space-y-4">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="first_name">First Name *</Label>
                      <Input 
                        id="first_name" 
                        value={formData.first_name} 
                        onChange={(e) => handleChange("first_name", e.target.value)} 
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last_name">Last Name *</Label>
                      <Input 
                        id="last_name" 
                        value={formData.last_name} 
                        onChange={(e) => handleChange("last_name", e.target.value)} 
                        required 
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input 
                        id="email" 
                        type="email" 
                        value={formData.email} 
                        onChange={(e) => handleChange("email", e.target.value)} 
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input 
                        id="phone" 
                        value={formData.phone} 
                        onChange={(e) => handleChange("phone", e.target.value)} 
                        placeholder="0412 345 678"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date_of_birth">Date of Birth</Label>
                    <Input 
                      id="date_of_birth" 
                      type="date" 
                      value={formData.date_of_birth} 
                      onChange={(e) => handleChange("date_of_birth", e.target.value)} 
                    />
                  </div>

                  {/* Photo Upload Section */}
                  <div className="pt-6 border-t">
                    <Label htmlFor="photo_upload" className="text-lg font-semibold text-slate-900">Profile Photo</Label>
                    <p className="text-sm text-slate-500 mb-4">This photo will appear on your digital membership card. (Max 5MB)</p>
                    
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0">
                        {formData.photo_url ? (
                          <div className="relative">
                            <img 
                              src={formData.photo_url} 
                              alt="Member photo" 
                              className="w-24 h-24 rounded-lg object-cover border-2 border-slate-300"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="sm"
                              onClick={() => handleChange('photo_url', '')}
                              className="absolute -top-2 -right-2 w-6 h-6 p-0 rounded-full"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ) : (
                          <div className="w-24 h-24 rounded-lg bg-slate-100 flex items-center justify-center border-2 border-dashed border-slate-300">
                            <User className="w-8 h-8 text-slate-400" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1">
                        <Input
                          id="photo_upload"
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          disabled={uploading}
                          className="mb-2"
                        />
                        {uploading ? (
                          <p className="text-sm text-blue-600 flex items-center gap-2">
                            <Upload className="w-4 h-4 animate-pulse" />
                            Uploading photo...
                          </p>
                        ) : (
                           <p className="text-xs text-slate-500">
                            A clear, portrait-style photo is recommended.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-6 border-t">
                    <h3 className="text-lg font-semibold text-slate-900">Address</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="street_address">Street Address</Label>
                        <Input 
                          id="street_address" 
                          value={formData.street_address} 
                          onChange={(e) => handleChange("street_address", e.target.value)} 
                        />
                      </div>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="suburb">Suburb</Label>
                          <Input 
                            id="suburb" 
                            value={formData.suburb} 
                            onChange={(e) => handleChange("suburb", e.target.value)} 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="state">State</Label>
                          <Select value={formData.state} onValueChange={(value) => handleChange("state", value)}>
                            <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ACT">ACT</SelectItem>
                              <SelectItem value="NSW">NSW</SelectItem>
                              <SelectItem value="NT">NT</SelectItem>
                              <SelectItem value="QLD">QLD</SelectItem>
                              <SelectItem value="SA">SA</SelectItem>
                              <SelectItem value="TAS">TAS</SelectItem>
                              <SelectItem value="VIC">VIC</SelectItem>
                              <SelectItem value="WA">WA</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="postcode">Postcode</Label>
                          <Input 
                            id="postcode" 
                            value={formData.postcode} 
                            onChange={(e) => handleChange("postcode", e.target.value)} 
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-6 border-t">
                    <h3 className="text-lg font-semibold text-slate-900">Emergency Contact</h3>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_name">Emergency Contact Name</Label>
                        <Input 
                          id="emergency_contact_name" 
                          value={formData.emergency_contact_name} 
                          onChange={(e) => handleChange("emergency_contact_name", e.target.value)} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_phone">Emergency Contact Phone</Label>
                        <Input 
                          id="emergency_contact_phone" 
                          value={formData.emergency_contact_phone} 
                          onChange={(e) => handleChange("emergency_contact_phone", e.target.value)} 
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 pt-6 border-t">
                    <Label htmlFor="medical_conditions" className="text-lg font-semibold text-slate-900">Medical Conditions or Allergies</Label>
                    <Textarea 
                      id="medical_conditions" 
                      value={formData.medical_conditions} 
                      onChange={(e) => handleChange("medical_conditions", e.target.value)} 
                      placeholder="Please list any medical conditions, allergies, or relevant health information..."
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setCurrentStep(1)}
                  className="px-8 py-3"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="bg-red-600 hover:bg-red-700 px-8 py-3"
                  disabled={submitting || uploading}
                >
                  {submitting ? "Saving..." : "Agree to Terms"} <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Terms and Conditions */}
          {currentStep === 3 && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Terms & Conditions</h2>
                <p className="text-slate-600 text-lg">Please read and agree to the club's terms to continue.</p>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <FileText className="w-6 h-6 text-slate-700" />
                    Membership Agreement
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-slate max-w-none h-96 overflow-y-auto p-6 bg-slate-50/50 border border-slate-200 rounded-xl shadow-inner">
                    {termsContent ? (
                      <ReactMarkdown>{termsContent}</ReactMarkdown>
                    ) : (
                      <p>Loading terms...</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2 mt-6">
                    <Checkbox id="terms" checked={termsAgreed} onCheckedChange={setTermsAgreed} />
                    <Label htmlFor="terms" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      I have read and agree to the Nepbourne FC Terms and Conditions.
                    </Label>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setCurrentStep(2)}
                  className="px-8 py-3"
                >
                  Back to Details
                </Button>
                <Button 
                  type="button" 
                  onClick={handleAcceptTerms}
                  className="bg-red-600 hover:bg-red-700 px-8 py-3"
                  disabled={!termsAgreed || submitting}
                >
                  {submitting ? "Processing..." : "Continue to Payment"} <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Payment */}
          {currentStep === 4 && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Complete Payment</h2>
                <p className="text-slate-600 text-lg">Secure payment processing via Stripe</p>
              </div>

              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-semibold">{selectedMembershipType?.name}</h3>
                      <p className="text-slate-600 text-sm capitalize">{selectedMembershipType?.billing_model} membership</p>
                    </div>
                    <span className="font-bold text-xl">${selectedMembershipType?.price_aud}</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center font-bold text-lg">
                      <span>Total</span>
                      <span>${selectedMembershipType?.price_aud} AUD</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Button */}
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <CreditCard className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-slate-900 mb-2">Secure Payment with Stripe</h3>
                    <p className="text-slate-600">Your payment information is encrypted and secure</p>
                  </div>
                  
                  <Button 
                    onClick={handlePayment}
                    disabled={submitting}
                    className="bg-red-600 hover:bg-red-700 px-12 py-4 text-lg"
                  >
                    {submitting ? "Processing..." : `Pay $${selectedMembershipType?.price_aud} Now`}
                  </Button>
                  
                  <p className="text-xs text-slate-500 mt-4">
                    You will be redirected to Stripe's secure checkout page
                  </p>
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setCurrentStep(3)}
                  className="px-8 py-3"
                  disabled={submitting}
                >
                  Back to Terms
                </Button>
              </div>
            </div>
          )}

          {/* Step 5: Success */}
          {currentStep === 5 && (
            <div className="space-y-8 text-center">
              <div className="mb-8">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Welcome to Nepbourne FC!</h2>
                <p className="text-slate-600 text-lg">Your payment has been processed successfully</p>
              </div>

              <Card className="bg-green-50 border-green-200 max-w-2xl mx-auto">
                <CardContent className="p-8">
                  <h3 className="font-bold text-green-900 mb-4">What's Next?</h3>
                  <div className="space-y-4 text-left">
                    <div className="flex items-start gap-3">
                      <span className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">1</span>
                      <p className="text-green-800">You'll receive a confirmation email with your membership details</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <span className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">2</span>
                      <p className="text-green-800">Your membership is now active and you can participate in club activities</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <span className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">3</span>
                      <p className="text-green-800">Welcome to the Nepbourne FC family!</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-center gap-4 mt-8">
                <Button 
                  onClick={() => {
                    setCurrentStep(1);
                    setFormData({
                      first_name: "",
                      last_name: "",
                      email: "",
                      phone: "",
                      date_of_birth: "",
                      street_address: "",
                      suburb: "",
                      state: "",
                      postcode: "",
                      membership_type_id: "",
                      photo_url: "",
                      emergency_contact_name: "",
                      emergency_contact_phone: "",
                      medical_conditions: "",
                      payment_method: "stripe"
                    });
                    setApplicationId(null);
                    setTermsAgreed(false); // Reset terms agreement
                  }}
                  variant="outline"
                  className="px-8"
                >
                  Submit Another Application
                </Button>
                <Link to={createPageUrl('Home')}>
                  <Button className="bg-red-600 hover:bg-red-700 px-8">
                    Return to Homepage
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
