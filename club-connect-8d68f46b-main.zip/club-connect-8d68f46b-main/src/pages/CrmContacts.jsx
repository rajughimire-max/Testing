
import React, { useState, useEffect } from 'react';
import { Contact } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Search, RefreshCw, Plus, Mail, Phone, MapPin, Calendar, Edit, CheckCircle, XCircle, Info, FileDown } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { syncContactsFromEntities } from '@/api/functions';

export default function CrmContactsPage() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedConsent, setSelectedConsent] = useState('all');

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = async () => {
    setLoading(true);
    try {
      const contactsData = await Contact.list('-created_date');
      setContacts(contactsData);
    } catch (error) {
      console.error("Error loading contacts:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSyncContacts = async () => {
    setSyncing(true);
    try {
      const response = await syncContactsFromEntities();
      if (response.data.success) {
        alert(`Successfully synced ${response.data.syncedCount} new contacts!`);
        loadContacts(); // Reload the list
      }
    } catch (error) {
      console.error("Error syncing contacts:", error);
      alert("Failed to sync contacts. Please try again.");
    } finally {
      setSyncing(false);
    }
  };

  const getRoleColor = (role) => {
    const colors = {
      'MEMBER': 'bg-blue-100 text-blue-800',
      'PLAYER': 'bg-green-100 text-green-800',
      'SPONSOR': 'bg-purple-100 text-purple-800',
      'LEAD': 'bg-orange-100 text-orange-800'
    };
    return colors[role] || 'bg-gray-100 text-gray-800';
  };

  const getStatusColor = (status) => {
    const colors = {
      'active': 'bg-green-100 text-green-800',
      'inactive': 'bg-gray-100 text-gray-800',
      'archived': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  // Filter contacts
  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = searchTerm === '' ||
      contact.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.phone?.includes(searchTerm);

    const matchesRole = selectedRole === 'all' ||
      (contact.roles && contact.roles.includes(selectedRole));

    const matchesStatus = selectedStatus === 'all' || contact.status === selectedStatus;

    const matchesConsent = selectedConsent === 'all' ||
      (selectedConsent === 'email_opted_in' && contact.marketing_opt_in) ||
      (selectedConsent === 'sms_opted_in' && contact.sms_opt_in) ||
      (selectedConsent === 'no_consent' && !contact.marketing_opt_in && !contact.sms_opt_in);

    return matchesSearch && matchesRole && matchesStatus && matchesConsent;
  });

  const stats = {
    total: contacts.length,
    members: contacts.filter(c => c.roles?.includes('MEMBER')).length,
    players: contacts.filter(c => c.roles?.includes('PLAYER')).length,
    sponsors: contacts.filter(c => c.roles?.includes('SPONSOR')).length,
    leads: contacts.filter(c => c.roles?.includes('LEAD')).length,
    emailOptIn: contacts.filter(c => c.marketing_opt_in).length,
    smsOptIn: contacts.filter(c => c.sms_opt_in).length
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-24" />)}
          </div>
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">CRM Contacts</h1>
            <p className="text-slate-600">Manage all people in your club ecosystem.</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={handleSyncContacts}
              disabled={syncing}
              variant="outline"
              className="bg-white"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
              {syncing ? 'Syncing...' : 'Sync from Entities'}
            </Button>
            <Button className="bg-red-600 hover:bg-red-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Contact
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-slate-900">{stats.total}</div>
              <div className="text-sm text-slate-600">Total Contacts</div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.members}</div>
              <div className="text-sm text-slate-600">Members</div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.players}</div>
              <div className="text-sm text-slate-600">Players</div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.sponsors}</div>
              <div className="text-sm text-slate-600">Sponsors</div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.leads}</div>
              <div className="text-sm text-slate-600">Leads</div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-600">{stats.emailOptIn}</div>
              <div className="text-sm text-slate-600">Email Consent</div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-indigo-600">{stats.smsOptIn}</div>
              <div className="text-sm text-slate-600">SMS Consent</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="relative lg:col-span-2">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search contacts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger><SelectValue placeholder="Filter by role" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="MEMBER">Members</SelectItem>
                  <SelectItem value="PLAYER">Players</SelectItem>
                  <SelectItem value="SPONSOR">Sponsors</SelectItem>
                  <SelectItem value="LEAD">Leads</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger><SelectValue placeholder="Filter by status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedConsent} onValueChange={setSelectedConsent}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by consent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Consent</SelectItem>
                  <SelectItem value="email_opted_in">Email Opt-in</SelectItem>
                  <SelectItem value="sms_opted_in">SMS Opt-in</SelectItem>
                  <SelectItem value="no_consent">No Consent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Contacts List */}
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>All Contacts ({filteredContacts.length})</CardTitle>
            <Button variant="outline" size="sm">
              <FileDown className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredContacts.map(contact => (
                <Card key={contact.id} className="bg-white/90 backdrop-blur-sm transition-all hover:shadow-md">
                  <CardHeader className="flex flex-row items-center justify-between pb-4">
                      <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-gradient-to-br from-slate-500 to-slate-600 rounded-full flex items-center justify-center shrink-0">
                              <span className="text-white font-semibold text-sm">
                                  {contact.first_name?.charAt(0)}{contact.last_name?.charAt(0)}
                              </span>
                          </div>
                          <div>
                              <CardTitle className="text-lg">{contact.first_name} {contact.last_name}</CardTitle>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                  <Badge className={getStatusColor(contact.status)}>{contact.status}</Badge>
                                  {contact.roles?.map(role => (
                                      <Badge key={role} className={getRoleColor(role)}>{role}</Badge>
                                  ))}
                              </div>
                          </div>
                      </div>
                      <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4 mr-2" /> Edit
                      </Button>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 pt-4 border-t">
                      {/* Left Column: Contact Details */}
                      <div className="space-y-3 text-sm">
                          <div className="flex items-center gap-3 text-slate-700">
                              <Mail className="w-4 h-4 text-slate-400 shrink-0"/>
                              {contact.email ? <a href={`mailto:${contact.email}`} className="hover:underline truncate">{contact.email}</a> : <span className="text-slate-500">No email</span>}
                          </div>
                          <div className="flex items-center gap-3 text-slate-700">
                              <Phone className="w-4 h-4 text-slate-400 shrink-0"/>
                              {contact.phone ? <a href={`tel:${contact.phone}`} className="hover:underline">{contact.phone}</a> : <span className="text-slate-500">No phone</span>}
                          </div>
                          <div className="flex items-start gap-3 text-slate-700">
                              <MapPin className="w-4 h-4 text-slate-400 mt-0.5 shrink-0"/>
                              <span>{(contact.suburb || contact.state) ? `${contact.suburb || ''}${contact.suburb && contact.state ? ', ' : ''}${contact.state || ''}` : <span className="text-slate-500">No location</span>}</span>
                          </div>
                      </div>
                      {/* Right Column: Metadata & Consent */}
                      <div className="space-y-3 text-sm">
                          <div className="flex items-center gap-3 text-slate-700">
                              {contact.marketing_opt_in ? <CheckCircle className="w-4 h-4 text-green-500 shrink-0"/> : <XCircle className="w-4 h-4 text-red-500 shrink-0"/>}
                              <span>Email Marketing {contact.marketing_opt_in ? 'Opted-In' : 'Opted-Out'}</span>
                          </div>
                           <div className="flex items-center gap-3 text-slate-700">
                              {contact.sms_opt_in ? <CheckCircle className="w-4 h-4 text-green-500 shrink-0"/> : <XCircle className="w-4 h-4 text-red-500 shrink-0"/>}
                              <span>SMS Marketing {contact.sms_opt_in ? 'Opted-In' : 'Opted-Out'}</span>
                          </div>
                           <div className="flex items-center gap-3 text-slate-700">
                              <Info className="w-4 h-4 text-slate-400 shrink-0"/>
                              <span>Source: <span className="font-medium">{contact.source || 'N/A'}</span>, Added: <span className="font-medium">{format(new Date(contact.created_date), 'MMM d, yyyy')}</span></span>
                          </div>
                      </div>
                  </CardContent>
                  {contact.tags && contact.tags.length > 0 && (
                      <CardFooter className="pt-4 mt-4 border-t">
                          <div className="flex flex-wrap gap-2">
                              {contact.tags.map(tag => (
                                  <Badge key={tag} variant="secondary">{tag}</Badge>
                              ))}
                          </div>
                      </CardFooter>
                  )}
                </Card>
              ))}

              {filteredContacts.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500">No contacts found matching your criteria</p>
                  {contacts.length === 0 && (
                    <Button
                      onClick={handleSyncContacts}
                      disabled={syncing}
                      className="mt-4"
                    >
                      <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
                      {syncing ? 'Syncing...' : 'Sync Contacts from Your Data'}
                    </Button>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
