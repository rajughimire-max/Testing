
import React, { useState, useEffect } from 'react';
import { Shield, LogOut, Upload, User, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Team, Match, Event, TrainingAttendance, UniformAssignment, InventoryItem, Player, User as UserEntity, GameAttendance } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

import { validatePortalId } from '@/api/functions';
import { getPlayerAttendance } from '@/api/functions';
import { updatePlayerRsvp } from '@/api/functions';
import { playerRsvpSocialGame } from '@/api/functions';

import UpcomingSchedule from '../components/player_portal/UpcomingSchedule';
import PerformanceTracker from '../components/player_portal/PerformanceTracker';
import UniformDetails from '../components/player_portal/UniformDetails';
import PlayerProfile from '../components/player_portal/PlayerProfile';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function PlayerPortal() {
  const [player, setPlayer] = useState(null);
  const [team, setTeam] = useState(null);
  const [matches, setMatches] = useState([]);
  const [trainingSessions, setTrainingSessions] = useState([]);
  const [events, setEvents] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [socialGames, setSocialGames] = useState([]);
  const [socialGameAttendances, setSocialGameAttendances] = useState([]);
  const [uniformAssignments, setUniformAssignments] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);

  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    const portalUserStr = sessionStorage.getItem('portalUser');
    if (!portalUserStr) {
      window.location.href = createPageUrl('PortalLogin');
      return;
    }

    let portalUser;
    try {
      portalUser = JSON.parse(portalUserStr);
    } catch (e) {
      console.error("Error parsing portalUser from sessionStorage:", e);
      sessionStorage.removeItem('portalUser');
      window.location.href = createPageUrl('PortalLogin');
      return;
    }

    if (!portalUser || portalUser.type !== 'player' || !portalUser.data || !portalUser.data.id) {
      alert("Access denied. Please log in with a valid Player ID.");
      sessionStorage.removeItem('portalUser');
      window.location.href = createPageUrl('PortalLogin');
      return;
    }

    setPlayer(portalUser.data);
    loadPlayerData(portalUser.data);
  }, []);

  const loadPlayerData = async (playerData) => {
    setLoading(true);
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const [
        teamData,
        allMatches,
        allTrainingSessions,
        allEvents,
        allSocialGames,
        uniformsData,
        inventoryData,
        attendanceDataResponse,
        socialGameAttendanceData,
      ] = await Promise.all([
        playerData.team_id ? Team.get(playerData.team_id) : Promise.resolve(null),
        Match.filter({ team_id: playerData.team_id }),
        Event.filter({ team_ids: { $in: [playerData.team_id] }, event_type: 'training' }),
        Event.filter({ event_type: { $nin: ['training', 'match', 'social'] } }), // Exclude social games here
        Event.filter({ is_social_game: true }),
        UniformAssignment.filter({ player_id: playerData.id }),
        InventoryItem.list(),
        getPlayerAttendance({ player_id: playerData.id }),
        GameAttendance.filter({ player_id: playerData.id }),
      ]);

      setTeam(teamData);

      const futureMatches = allMatches.filter(m => new Date(m.match_date) >= today);
      setMatches(futureMatches);

      const futureTrainingSessions = allTrainingSessions.filter(e => new Date(e.event_date) >= today);
      setTrainingSessions(futureTrainingSessions);

      const futureGeneralEvents = allEvents.filter(e => new Date(e.event_date) >= today);
      setEvents(futureGeneralEvents);

      const futureSocialGames = allSocialGames.filter(e => new Date(e.event_date) >= today);
      setSocialGames(futureSocialGames);
      setSocialGameAttendances(socialGameAttendanceData);

      setUniformAssignments(uniformsData);
      setInventoryItems(inventoryData);

      if (attendanceDataResponse.data?.success) {
        setAttendanceRecords(attendanceDataResponse.data.attendance);
      } else {
        console.error("Failed to load attendance records:", attendanceDataResponse.data?.error);
        toast.error("Could not load your RSVP history.");
        setAttendanceRecords([]);
      }

    } catch (error) {
      console.error("Error loading player data:", error);
      toast.error("Failed to load portal data.");
    } finally {
      setLoading(false);
    }
  };

  const handleRsvp = async (eventId, newStatus) => {
    try {
      const response = await updatePlayerRsvp({
        player_id: player.id,
        event_id: eventId,
        status: newStatus,
      });

      if (response.data?.success) {
        toast.success(`Your RSVP has been updated to "${newStatus}".`);
        
        // Use the attendance records returned by the backend function
        setAttendanceRecords(response.data.all_attendance);
      } else {
        throw new Error(response.data?.error || 'Failed to update RSVP.');
      }

    } catch (error) {
      console.error("Error updating RSVP:", error);
      toast.error(error.message || "Failed to update your RSVP. Please try again.");
    }
  };

  const handleSocialGameRsvp = async (eventId, newStatus) => {
    try {
      const response = await playerRsvpSocialGame({
        player_id: player.id,
        event_id: eventId,
        status: newStatus,
      });

      if (response.data?.success) {
        toast.success(`Your social game RSVP has been updated to "${newStatus}".`);
        setSocialGameAttendances(response.data.all_attendance);
      } else {
        throw new Error(response.data?.error || 'Failed to update RSVP.');
      }
    } catch (error) {
      console.error("Error updating social game RSVP:", error);
      toast.error(error.message || "Failed to update your social game RSVP. Please try again.");
    }
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      const updatedPlayer = await Player.update(player.id, { profile_photo_url: file_url });
      setPlayer(updatedPlayer);

      // Update session storage
      const portalUser = JSON.parse(sessionStorage.getItem('portalUser'));
      portalUser.data = updatedPlayer;
      sessionStorage.setItem('portalUser', JSON.stringify(portalUser));

      toast.success("Profile photo updated!");
    } catch (error) {
      console.error("Error uploading photo:", error);
      toast.error("Failed to upload photo.");
    } finally {
      setUploading(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('portalUser');
    window.location.href = createPageUrl('PortalLogin');
  };

  if (loading || !player) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-100">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-slate-600 font-medium">Loading Player Portal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white">
      <header className="bg-white/10 backdrop-blur-md border-b border-white/20 px-6 py-4">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-white text-lg">Nepbourne FC</h2>
              <p className="text-xs text-slate-300 font-medium">Player Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium text-white text-sm truncate">{player.first_name} {player.last_name}</p>
              <p className="text-xs text-slate-300 truncate capitalize">Welcome</p>
            </div>
             <Button variant="ghost" size="sm" onClick={handleLogout} className="text-white hover:bg-white/20">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="p-6 space-y-6">
        <div className="max-w-7xl mx-auto">
          <Tabs defaultValue="schedule" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-white/10 text-white">
              <TabsTrigger value="schedule" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Schedule</TabsTrigger>
              <TabsTrigger value="performance" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Performance</TabsTrigger>
              <TabsTrigger value="uniforms" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Uniforms</TabsTrigger>
              <TabsTrigger value="profile" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">My Profile</TabsTrigger>
            </TabsList>
            <TabsContent value="schedule">
              <UpcomingSchedule
                matches={matches}
                trainingSessions={trainingSessions}
                events={events}
                socialGames={socialGames}
                attendanceRecords={attendanceRecords}
                socialGameAttendances={socialGameAttendances}
                onRsvp={handleRsvp}
                onSocialGameRsvp={handleSocialGameRsvp}
              />
            </TabsContent>
            <TabsContent value="performance">
              <PerformanceTracker
                attendanceRecords={attendanceRecords}
                trainingSessions={trainingSessions}
                matches={matches}
                playerId={player.id}
              />
            </TabsContent>
            <TabsContent value="uniforms">
              <UniformDetails
                uniformAssignments={uniformAssignments}
                inventoryItems={inventoryItems}
              />
            </TabsContent>
            <TabsContent value="profile">
              <PlayerProfile
                player={player}
                team={team}
                uploading={uploading}
                onPhotoUpload={handlePhotoUpload}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
