import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { getPaymentStatus } from '@/api/functions';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, Clock, Loader2, Home } from 'lucide-react';

export default function PaymentStatus() {
    const location = useLocation();
    const [status, setStatus] = useState('loading'); // loading, success, failed, pending
    const [message, setMessage] = useState('Verifying your payment...');
    const [customerEmail, setCustomerEmail] = useState('');

    useEffect(() => {
        const query = new URLSearchParams(location.search);
        const sessionId = query.get('session_id');

        if (!sessionId) {
            setStatus('failed');
            setMessage('No payment session found. Please contact support if this is an error.');
            return;
        }

        let attempts = 0;
        const maxAttempts = 5;

        const checkStatus = async () => {
            try {
                attempts++;
                const response = await getPaymentStatus({ session_id: sessionId });
                const { status: sessionStatus, payment_status: paymentStatus } = response.data;
                setCustomerEmail(response.data.customer_email || '');

                if (paymentStatus === 'paid') {
                    setStatus('success');
                    setMessage('Payment approved. Thank you for your order.');
                } else if (sessionStatus === 'open') {
                    setStatus('failed');
                    setMessage('Payment failed. Please try again with another card.');
                } else if (attempts >= maxAttempts) {
                    setStatus('pending');
                    setMessage('Your payment is being processed. We’ll update you via email shortly.');
                } else {
                    // It might still be processing, wait and try again
                    setTimeout(checkStatus, 2000);
                }
            } catch (error) {
                console.error("Error fetching payment status:", error);
                setStatus('failed');
                setMessage('Could not retrieve payment status. Please check your email for a confirmation or contact support.');
            }
        };

        checkStatus();
    }, [location]);

    const statusInfo = {
        success: { icon: CheckCircle, color: 'text-green-500', bgColor: 'bg-green-50' },
        failed: { icon: AlertTriangle, color: 'text-red-500', bgColor: 'bg-red-50' },
        pending: { icon: Clock, color: 'text-blue-500', bgColor: 'bg-blue-50' },
        loading: { icon: Loader2, color: 'text-slate-500', bgColor: 'bg-slate-50' }
    };

    const { icon: Icon, color, bgColor } = statusInfo[status];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-6">
            <Card className="w-full max-w-lg shadow-2xl animate-in fade-in zoom-in-95 duration-500">
                <CardHeader>
                    <CardTitle className="text-center text-2xl font-bold text-slate-800">Payment Status</CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-6 py-12">
                    <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto ${bgColor}`}>
                        <Icon className={`w-12 h-12 ${color} ${status === 'loading' ? 'animate-spin' : ''}`} />
                    </div>
                    <div className="space-y-2">
                        <p className={`text-xl font-semibold ${color}`}>
                            {status === 'success' ? 'Payment Successful!' : 
                             status === 'failed' ? 'Payment Failed' : 
                             status === 'pending' ? 'Payment Processing' : 
                             'Verifying...'}
                        </p>
                        <p className="text-slate-600 text-lg">{message}</p>
                    </div>
                    {customerEmail && (
                        <p className="text-sm text-slate-500">
                            A confirmation will be sent to <strong>{customerEmail}</strong>.
                        </p>
                    )}
                </CardContent>
                <div className="p-6 bg-slate-50/50 border-t flex justify-center">
                    <Link to={createPageUrl('Home')}>
                        <Button variant="outline" className="text-base px-8 py-3">
                            <Home className="w-4 h-4 mr-2" />
                            Back to Homepage
                        </Button>
                    </Link>
                </div>
            </Card>
        </div>
    );
}