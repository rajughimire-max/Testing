
import React, { useState, useEffect, useCallback } from 'react';
import { User, ExecutiveMember, Member, Player, Meeting, AgendaItem } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Calendar, Users, FileText, Clock, Edit, Trash2, Send, Upload, Mail } from 'lucide-react';
import { format, isPast, isFuture } from 'date-fns';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

import MeetingForm from '../components/executive/MeetingForm';
import AgendaItemForm from '../components/executive/AgendaItemForm';
import { autoCreateNotifications } from '@/api/functions';
import { sendMeetingCommunication } from '@/api/functions';

export default function ExecutivePortal() {
    const [user, setUser] = useState(null);
    const [currentExecutive, setCurrentExecutive] = useState(null);
    const [upcomingMeetings, setUpcomingMeetings] = useState([]);
    const [pastMeetings, setPastMeetings] = useState([]);
    const [agendaItems, setAgendaItems] = useState([]);
    const [allExecutives, setAllExecutives] = useState([]); // New state for all executives
    const [executivePersons, setExecutivePersons] = useState([]); // New state for executive person details
    const [loading, setLoading] = useState(true);
    const [showMeetingForm, setShowMeetingForm] = useState(false);
    const [showAgendaForm, setShowAgendaForm] = useState(false);
    const [selectedMeetingForAgenda, setSelectedMeetingForAgenda] = useState(null);
    const [showEditAgendaForm, setShowEditAgendaForm] = useState(false);
    const [agendaItemToEdit, setAgendaItemToEdit] = useState(null);
    const [editingMinutes, setEditingMinutes] = useState({ meetingId: null, text: '' });
    const [viewingAgendaFor, setViewingAgendaFor] = useState(null);

    const loadPortalData = useCallback(async () => {
        setLoading(true);
        try {
            // Check if user is logged in via ID-based session
            const portalUserStr = sessionStorage.getItem('portalUser');
            let userData = null;
            let userExecutive = null;

            if (portalUserStr) {
                // ID-based login
                const portalUser = JSON.parse(portalUserStr);
                userData = {
                    full_name: `${portalUser.data.first_name} ${portalUser.data.last_name}`,
                    email: portalUser.data.email,
                    role: portalUser.type // 'member' or 'player'
                };
                
                // Get executive info from the validation response
                if (portalUser.executive_info) {
                    userExecutive = portalUser.executive_info;
                } else {
                    // If they logged in via portalUser but are not an executive, deny access.
                    // This handles cases where a non-executive member/player tries to access.
                    toast.error("Access denied. You are not an active executive member.");
                    window.location.href = '/PortalLogin'; // Redirect back to login
                    return;
                }
            } else {
                // Google-based login (for admins)
                userData = await User.me();
                if (userData.role !== 'admin') {
                    toast.error("Access denied. Please log in with your member or player ID or an admin account.");
                    window.location.href = '/PortalLogin'; // Or to a general login page
                    return;
                }
                // For admins, currentExecutive will remain null as they don't have a specific executive record
            }

            setUser(userData);
            setCurrentExecutive(userExecutive);

            const [allMeetings, allAgendaItems, allExecutiveMembers] = await Promise.all([
                Meeting.list('-meeting_date'),
                AgendaItem.list(),
                ExecutiveMember.list() // Fetch all executive members
            ]);

            // Get all unique member IDs and player IDs from executives
            const memberIds = [...new Set(allExecutiveMembers.map(e => e.member_id).filter(Boolean))];
            const playerIds = [...new Set(allExecutiveMembers.map(e => e.player_id).filter(Boolean))];

            // Fetch person details for all executives
            const [execMembers, execPlayers] = await Promise.all([
                memberIds.length > 0 ? Member.filter({ id: { $in: memberIds } }) : [],
                playerIds.length > 0 ? Player.filter({ id: { $in: playerIds } }) : []
            ]);

            const allPersons = [...execMembers, ...execPlayers];
            
            setAllExecutives(allExecutiveMembers);
            setExecutivePersons(allPersons);

            const now = new Date();
            const upcoming = allMeetings.filter(meeting => isFuture(new Date(meeting.meeting_date)));
            const past = allMeetings.filter(meeting => isPast(new Date(meeting.meeting_date)));

            setUpcomingMeetings(upcoming);
            setPastMeetings(past);
            setAgendaItems(allAgendaItems);

        } catch (error) {
            console.error("Error loading portal data:", error);
            toast.error("Failed to load executive portal data.");
        } finally {
            setLoading(false);
        }
    }, []); // Empty dependency array because all internal functions/state setters are stable, and external data fetches don't depend on component state directly.

    useEffect(() => {
        loadPortalData();
    }, [loadPortalData]);

    const handleCreateMeeting = async (meetingData) => {
        try {
            const newMeeting = await Meeting.create({
                ...meetingData,
                created_by: currentExecutive?.id
            });

            toast.promise(
                autoCreateNotifications({ entityType: 'Meeting', entityId: newMeeting.id, action: 'created' }),
                {
                    loading: 'Scheduling meeting and sending notifications...',
                    success: 'Meeting created and all executive members have been notified!',
                    error: 'Meeting created, but failed to send notifications.',
                }
            );

            setShowMeetingForm(false);
            loadPortalData();
        } catch (error) {
            console.error("Error creating meeting:", error);
            toast.error("Failed to create meeting.");
        }
    };

    const handleCreateAgendaItem = async (agendaData) => {
        try {
            if (agendaData.bulkItems) {
                const createdItems = await Promise.all(
                    agendaData.bulkItems.map(item =>
                        AgendaItem.create({
                            ...item,
                            proposed_by: currentExecutive?.id
                        })
                    )
                );
                toast.success(`${createdItems.length} agenda items added successfully!`);
            } else if (agendaItemToEdit) {
                await AgendaItem.update(agendaItemToEdit.id, agendaData);
                toast.success("Agenda item updated successfully!");
            } else {
                await AgendaItem.create({
                    ...agendaData,
                    proposed_by: currentExecutive?.id
                });
                toast.success("Agenda item added successfully!");
            }
            setShowAgendaForm(false);
            // Keep the main dialog open after adding an item
            // setSelectedMeetingForAgenda(null); 
            setShowEditAgendaForm(false);
            setAgendaItemToEdit(null);
            loadPortalData(); // Reload all data
            // Also reload the specific meeting being viewed
            if (viewingAgendaFor) {
                const updatedMeeting = await Meeting.get(viewingAgendaFor.id);
                setViewingAgendaFor(updatedMeeting);
            }


        } catch (error) {
            console.error("Error saving agenda item:", error);
            toast.error("Failed to save agenda item.");
        }
    };

    const handleDeleteAgendaItem = async (agendaItemId) => {
        if (!window.confirm("Are you sure you want to delete this agenda item? This action cannot be undone.")) {
            return;
        }
        try {
            await AgendaItem.delete(agendaItemId);
            toast.success("Agenda item deleted successfully!");
            loadPortalData();
            // Also reload the specific meeting being viewed
            if (viewingAgendaFor) {
                const updatedMeeting = await Meeting.get(viewingAgendaFor.id);
                setViewingAgendaFor(updatedMeeting);
            }
        } catch (error) {
            console.error("Error deleting agenda item:", error);
            toast.error("Failed to delete agenda item.");
        }
    };

    const handleSaveMinutes = async (meetingId) => {
        try {
            await Meeting.update(meetingId, { meeting_minutes: editingMinutes.text });
            toast.success("Meeting minutes saved successfully!");
            setEditingMinutes({ meetingId: null, text: '' });
            loadPortalData();
        } catch (error) {
            console.error("Error saving minutes:", error);
            toast.error("Failed to save minutes.");
        }
    };

    const handleSendCommunication = async (meetingId, type) => {
        const typeTitle = type.charAt(0).toUpperCase() + type.slice(1);
        const promise = sendMeetingCommunication({ meetingId, type });

        toast.promise(promise, {
            loading: `Sending ${typeTitle}...`,
            success: (response) => {
                const { data } = response; 
                if (data.success) {
                    if (data.failedContacts && data.failedContacts.length > 0) {
                        console.warn('Failed to send to:', data.failedContacts);
                        toast.warning(`Note: ${data.failedContacts.length} contacts couldn't be reached. Some emails may have failed.`);
                    }
                    loadPortalData(); // Refresh data to show sent status
                    return data.message || `${typeTitle} sent successfully!`;
                } else {
                    throw new Error(data.error || `Failed to send ${typeTitle}.`);
                }
            },
            error: (err) => {
                console.error(`Error sending ${typeTitle}:`, err);
                return err.message || `An error occurred while sending the ${typeTitle}.`;
            }
        });
    };

    const getAgendaItemsForMeeting = (meetingId) => {
        return agendaItems.filter(item => item.meeting_id === meetingId);
    };

    const getMeetingStatusColor = (meeting) => {
        switch (meeting.status) {
            case 'Scheduled': return 'bg-blue-100 text-blue-800';
            case 'In Progress': return 'bg-yellow-100 text-yellow-800';
            case 'Completed': return 'bg-green-100 text-green-800';
            case 'Cancelled': return 'bg-red-100 text-red-800';
            case 'Postponed': return 'bg-gray-100 text-gray-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    // New helper function to get proposer information
    const getProposerInfo = (proposedById) => {
        if (!proposedById) return { name: 'Unknown', position: '' };

        // Find the executive record
        const executive = allExecutives.find(exec => exec.id === proposedById);
        if (!executive) return { name: 'Unknown', position: '' };

        // Find the person details (Member or Player)
        const person = executivePersons.find(p => 
            (executive.member_id && p.id === executive.member_id) || 
            (executive.player_id && p.id === executive.player_id)
        );

        if (!person) return { name: 'Unknown', position: executive.position };

        return {
            name: `${person.first_name} ${person.last_name}`,
            position: executive.position === 'Other' ? executive.custom_position_title : executive.position
        };
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
                <div className="text-center">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg mx-auto mb-4">
                        <Users className="w-6 h-6 text-white animate-pulse" />
                    </div>
                    <p className="text-slate-600">Loading Executive Portal...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900 mb-2">Executive Portal</h1>
                            <p className="text-slate-600">
                                Welcome, {currentExecutive ?
                                    `${currentExecutive.position}${currentExecutive.position === 'Other' ? ` - ${currentExecutive.custom_position_title}` : ''}` :
                                    user?.role === 'admin' ? 'Administrator' : 'Executive Member' // Adjusted for admin role if no specific executive record
                                }
                            </p>
                        </div>
                        <div className="flex gap-3">
                            <Button onClick={() => setShowMeetingForm(true)} className="bg-blue-600 hover:bg-blue-700">
                                <Calendar className="w-4 h-4 mr-2" />
                                Schedule Meeting
                            </Button>
                        </div>
                    </div>
                </div>

                {showMeetingForm && (
                    <MeetingForm
                        onSubmit={handleCreateMeeting}
                        onCancel={() => setShowMeetingForm(false)}
                    />
                )}

                {/* This form is now inside the dialog */}

                {showEditAgendaForm && agendaItemToEdit && (
                    <AgendaItemForm
                        initialData={agendaItemToEdit}
                        onSubmit={handleCreateAgendaItem}
                        onCancel={() => {
                            setShowEditAgendaForm(false);
                            setAgendaItemToEdit(null);
                        }}
                    />
                )}

                <Tabs defaultValue="upcoming" className="w-full">
                    <TabsList className="mb-6">
                        <TabsTrigger value="upcoming">
                            <Clock className="w-4 h-4 mr-2" />
                            Upcoming Meetings ({upcomingMeetings.length})
                        </TabsTrigger>
                        <TabsTrigger value="past">
                            <FileText className="w-4 h-4 mr-2" />
                            Past Meetings ({pastMeetings.length})
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="upcoming" className="space-y-6">
                        {upcomingMeetings.map(meeting => {
                            const agendaItemsForMeeting = getAgendaItemsForMeeting(meeting.id);

                            return (
                                <Card
                                    key={meeting.id}
                                    className="bg-white/80 backdrop-blur-sm border-slate-200/60 cursor-pointer hover:shadow-md transition-shadow"
                                    onDoubleClick={() => setViewingAgendaFor(meeting)}
                                >
                                    <CardHeader>
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <CardTitle className="text-xl">{meeting.title}</CardTitle>
                                                <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                                                    <span>{format(new Date(meeting.meeting_date), 'EEEE, MMM d, yyyy')}</span>
                                                    <span>{meeting.meeting_time}</span>
                                                    <span>{meeting.location}</span>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge className={getMeetingStatusColor(meeting)}>
                                                    {meeting.status}
                                                </Badge>
                                                {meeting.agenda_sent_at ? (
                                                     <Badge variant="outline" className="text-green-700 bg-green-50 border-green-200">
                                                        <Mail className="w-3 h-3 mr-1.5" />
                                                        Agenda sent {format(new Date(meeting.agenda_sent_at), 'dd MMM, p')}
                                                    </Badge>
                                                ) : (
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        onClick={(e) => { e.stopPropagation(); handleSendCommunication(meeting.id, 'agenda'); }}
                                                        className="bg-white"
                                                    >
                                                        <Send className="w-3 h-3 mr-1" />
                                                        Send Agenda
                                                    </Button>
                                                )}
                                            </div>
                                        </div>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="flex items-center justify-between text-sm text-slate-500">
                                            <span>{agendaItemsForMeeting.length} agenda items</span>
                                            <span className="italic font-medium">Double-click to view agenda</span>
                                        </div>
                                    </CardContent>
                                </Card>
                            );
                        })}
                        {upcomingMeetings.length === 0 && (
                            <Card>
                                <CardContent className="text-center py-12">
                                    <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                                    <h3 className="text-lg font-semibold text-slate-700 mb-2">No Upcoming Meetings</h3>
                                    <p className="text-slate-500 mb-4">Schedule your first meeting to get started.</p>
                                    <Button onClick={() => setShowMeetingForm(true)} className="bg-blue-600 hover:bg-blue-700"><Calendar className="w-4 h-4 mr-2" />Schedule Meeting</Button>
                                </CardContent>
                            </Card>
                        )}
                    </TabsContent>

                    <TabsContent value="past" className="space-y-6">
                        {pastMeetings.map(meeting => (
                            <Card key={meeting.id} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle className="text-xl">{meeting.title}</CardTitle>
                                            <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                                                <span>{format(new Date(meeting.meeting_date), 'EEEE, MMM d, yyyy')}</span>
                                                <span>{meeting.meeting_time}</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Badge className={getMeetingStatusColor(meeting)}>{meeting.status}</Badge>
                                            {meeting.meeting_minutes && (
                                                meeting.minutes_sent_at ? (
                                                    <Badge variant="outline" className="text-green-700 bg-green-50 border-green-200">
                                                        <Mail className="w-3 h-3 mr-1.5" />
                                                        Minutes sent {format(new Date(meeting.minutes_sent_at), 'dd MMM, p')}
                                                    </Badge>
                                                ) : (
                                                    <Button size="sm" variant="outline" onClick={() => handleSendCommunication(meeting.id, 'minutes')} className="bg-white">
                                                        <Send className="w-3 h-3 mr-1" />Send Minutes
                                                    </Button>
                                                )
                                            )}
                                        </div>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    {meeting.status === 'Completed' ? (
                                        <div className="space-y-4">
                                            <h4 className="font-semibold text-slate-800">Meeting Minutes:</h4>
                                            {editingMinutes.meetingId === meeting.id ? (
                                                <div className="space-y-2">
                                                    <Textarea
                                                        value={editingMinutes.text}
                                                        onChange={(e) => setEditingMinutes({ ...editingMinutes, text: e.target.value })}
                                                        placeholder="Record the minutes of the meeting..."
                                                        className="h-48"
                                                    />
                                                    <div className="flex justify-end gap-2">
                                                        <Button variant="outline" size="sm" onClick={() => setEditingMinutes({ meetingId: null, text: '' })}>Cancel</Button>
                                                        <Button size="sm" onClick={() => handleSaveMinutes(meeting.id)}>Save Minutes</Button>
                                                    </div>
                                                </div>
                                            ) : meeting.meeting_minutes ? (
                                                <div className="p-4 bg-slate-50 rounded-lg space-y-2 group relative">
                                                    <p className="text-slate-700 whitespace-pre-wrap">{meeting.meeting_minutes}</p>
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                                                        onClick={() => setEditingMinutes({ meetingId: meeting.id, text: meeting.meeting_minutes })}
                                                    >
                                                        <Edit className="w-3 h-3 mr-1" /> Edit
                                                    </Button>
                                                </div>
                                            ) : (
                                                <div className="text-center py-6 bg-slate-50 rounded-lg">
                                                    <p className="text-slate-500 mb-3">No minutes recorded for this meeting.</p>
                                                    <Button variant="outline" onClick={() => setEditingMinutes({ meetingId: meeting.id, text: '' })}>
                                                        <Plus className="w-4 h-4 mr-2" /> Add Minutes
                                                    </Button>
                                                </div>
                                            )}

                                            {meeting.resolutions_document_url && (
                                                <div>
                                                    <h5 className="font-medium text-slate-800 mb-2">Resolutions:</h5>
                                                    <Button variant="outline" size="sm" asChild>
                                                        <a href={meeting.resolutions_document_url} target="_blank" rel="noopener noreferrer">
                                                            <FileText className="w-3 h-3 mr-1" />View Resolutions Document
                                                        </a>
                                                    </Button>
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        <p className="text-slate-500 italic">This meeting has not been completed yet. Minutes can be added once the status is 'Completed'.</p>
                                    )}
                                </CardContent>
                            </Card>
                        ))}
                        {pastMeetings.length === 0 && (
                            <Card><CardContent className="text-center py-12"><FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" /><h3 className="text-lg font-semibold text-slate-700 mb-2">No Past Meetings</h3><p className="text-slate-500">Completed meetings and their minutes will appear here.</p></CardContent></Card>
                        )}
                    </TabsContent>
                </Tabs>
            </div>

            {/* Agenda Details Dialog */}
            <Dialog open={!!viewingAgendaFor} onOpenChange={() => { setViewingAgendaFor(null); setShowAgendaForm(false); }}>
                <DialogContent className="max-w-4xl h-[90vh] flex flex-col">
                    {viewingAgendaFor && (
                        <>
                            <DialogHeader>
                                <DialogTitle className="text-2xl">{viewingAgendaFor.title}</DialogTitle>
                                <DialogDescription>
                                    {format(new Date(viewingAgendaFor.meeting_date), 'EEEE, MMM d, yyyy')} at {viewingAgendaFor.meeting_time} &middot; {viewingAgendaFor.location}
                                </DialogDescription>
                            </DialogHeader>
                            <div className="flex-grow overflow-y-auto pr-4 -mr-6 space-y-6">
                                
                                {showAgendaForm ? (
                                     <AgendaItemForm
                                        meeting={viewingAgendaFor}
                                        onSubmit={handleCreateAgendaItem}
                                        onCancel={() => setShowAgendaForm(false)}
                                    />
                                ) : (
                                    <div className="flex justify-end">
                                        <Button
                                            size="sm"
                                            onClick={() => {
                                                setSelectedMeetingForAgenda(viewingAgendaFor);
                                                setAgendaItemToEdit(null);
                                                setShowEditAgendaForm(false);
                                                setShowAgendaForm(true);
                                            }}
                                        >
                                            <Plus className="w-3 h-3 mr-1" />
                                            Add Agenda Item
                                        </Button>
                                    </div>
                                )}
                               
                                <div className="space-y-3">
                                    <h4 className="font-semibold text-slate-800 text-lg">Agenda Items:</h4>
                                    {getAgendaItemsForMeeting(viewingAgendaFor.id).length === 0 ? (
                                        <p className="text-slate-500 text-sm italic text-center py-8">No agenda items yet. Add the first one!</p>
                                    ) : (
                                        <div className="space-y-4">
                                            {Object.entries(getAgendaItemsForMeeting(viewingAgendaFor.id).reduce((acc, item) => {
                                                const category = item.category || 'Other';
                                                if (!acc[category]) acc[category] = [];
                                                acc[category].push(item);
                                                return acc;
                                            }, {})).sort(([a], [b]) => a.localeCompare(b)).map(([category, items]) => (
                                                <div key={category}>
                                                    <h5 className="font-medium text-slate-800 mb-2 border-b pb-1">{category}</h5>
                                                    <div className="space-y-2 pl-2">
                                                        {items.map(item => {
                                                            const proposer = getProposerInfo(item.proposed_by);
                                                            return (
                                                                <div key={item.id} className="flex items-start gap-3 p-3 bg-slate-50/70 rounded-lg">
                                                                    <div className="flex-1">
                                                                        <h6 className="font-semibold text-slate-900">{item.title}</h6>
                                                                        <p className="text-sm text-slate-600 mt-1">{item.description}</p>
                                                                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                                                                            <Badge variant="outline" className="text-xs font-medium">{item.priority} Priority</Badge>
                                                                            {item.estimated_duration && (
                                                                                <Badge variant="outline" className="text-xs font-medium">{item.estimated_duration} mins</Badge>
                                                                            )}
                                                                            <Badge variant="outline" className="text-xs font-medium bg-blue-50 text-blue-700 border-blue-200">
                                                                                Added by: {proposer.name} ({proposer.position})
                                                                            </Badge>
                                                                        </div>
                                                                    </div>
                                                                    <div className="flex-shrink-0 flex gap-1">
                                                                        <Button variant="ghost" size="icon" onClick={() => { setAgendaItemToEdit(item); setShowAgendaForm(false); setShowEditAgendaForm(true); }} className="h-7 w-7 text-blue-600 hover:bg-blue-100" title="Edit Agenda Item"><Edit className="h-4 w-4" /></Button>
                                                                        <Button variant="ghost" size="icon" onClick={() => handleDeleteAgendaItem(item.id)} className="h-7 w-7 text-red-600 hover:bg-red-100" title="Delete Agenda Item"><Trash2 className="h-4 w-4" /></Button>
                                                                    </div>
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </>
                    )}
                </DialogContent>
            </Dialog>

        </div>
    );
}
