
import React, { useState, useEffect } from 'react';
import { SponsorshipTier, SponsorshipApplication, ContractTemplate, Sponsor } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { CheckCircle, ArrowRight, ArrowLeft, Building2, User, Shield, Trophy, Upload, FileText, Calendar, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { UploadFile } from "@/api/integrations";
import { Skeleton } from '@/components/ui/skeleton';
import { generateContract } from "@/api/functions";
import { add, formatISO, addMonths } from "date-fns";

// Validation functions
const validateABN = (abn) => {
  const cleanABN = abn.replace(/\s/g, '');
  if (!/^\d{11}$/.test(cleanABN)) return false;
  
  // ABN checksum validation
  const weights = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19];
  let sum = 0;
  const abnArray = cleanABN.split('').map(Number);
  abnArray[0] -= 1; // Subtract 1 from first digit
  
  for (let i = 0; i < 11; i++) {
    sum += abnArray[i] * weights[i];
  }
  
  return sum % 89 === 0;
};

const validateAustralianPhone = (phone) => {
  const cleanPhone = phone.replace(/\s/g, '');
  return /^(\+61|0)[2-9]\d{8}$/.test(cleanPhone);
};

const validateEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const validateURL = (url) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

export default function SponsorshipInquiry() {
  const [sponsorshipTiers, setSponsorshipTiers] = useState([]);
  const [activeSponsors, setActiveSponsors] = useState([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingGuidelines, setUploadingGuidelines] = useState(false);
  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    // Section A: Company Details
    legal_entity_name: '',
    trading_name: '',
    abn_acn: '',
    registered_street: '',
    registered_suburb: '',
    registered_state: 'VIC',
    registered_postcode: '',
    registered_country: 'Australia',
    postal_street: '',
    postal_suburb: '',
    postal_state: '',
    postal_postcode: '',
    postal_country: 'Australia',
    website_url: '',
    
    // Section B: Primary Contact
    contact_full_name: '',
    contact_position: '',
    contact_email: '',
    contact_phone: '',
    
    // Section C: Guarantor
    guarantor_full_name: '',
    guarantor_street: '',
    guarantor_suburb: '',
    guarantor_state: '',
    guarantor_postcode: '',
    guarantor_email: '',
    guarantor_phone: '',
    
    // Section D: Sponsorship
    sponsorship_tier_id: '',
    contribution_type: 'financial',
    custom_amount: '',
    inkind_description: '',
    inkind_value: '',
    payment_plan: 'one-off',
    installment_count: 3, // Set a default
    
    // Section E: Branding
    logo_url: '',
    brand_guidelines_url: '',
    facebook_handle: '',
    instagram_handle: '',
    linkedin_handle: '',
    twitter_handle: '',
    
    // Section F: Confirmations
    confirm_accuracy: false,
    confirm_authority: false,
    confirm_consent: false
  });

  const steps = [
    { number: 1, title: "Sponsorship Tier", description: "Select your contribution", icon: Trophy },
    { number: 2, title: "Company Details", description: "Legal entity information", icon: Building2 },
    { number: 3, title: "Primary Contact", description: "Company representative", icon: User },
    { number: 4, title: "Guarantor", description: "Personal guarantee details", icon: Shield },
    { number: 5, title: "Branding Assets", description: "Upload your materials", icon: Upload },
    { number: 6, title: "Confirmation", description: "Review and submit", icon: CheckCircle }
  ];

  useEffect(() => {
    const loadData = async () => {
      try {
        const [tiers, sponsorsData] = await Promise.all([
          SponsorshipTier.list('-minimum_amount'), // Sort by value
          Sponsor.list('-amount'), // Sort by sponsorship amount
        ]);

        setSponsorshipTiers(tiers.filter(t => t.is_active));
        setActiveSponsors(sponsorsData.filter(s => s.status === 'Active' && s.logo_url));
        
        const urlParams = new URLSearchParams(window.location.search);
        const tierIdFromUrl = urlParams.get('tier');
        
        if (tierIdFromUrl) {
          const selectedTier = tiers.find(t => t.id === tierIdFromUrl);
          if (selectedTier) {
             setFormData(prev => ({ 
              ...prev, 
              sponsorship_tier_id: tierIdFromUrl,
              custom_amount: selectedTier.minimum_amount.toString() 
            }));
          }
        }
      } catch (error) {
        console.error("Error loading page data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const handleTierChange = (tierId) => {
    const selectedTier = sponsorshipTiers.find(t => t.id === tierId);
    setFormData(prev => {
      const newFormData = { ...prev, sponsorship_tier_id: tierId };
      if (selectedTier) {
        newFormData.custom_amount = selectedTier.minimum_amount.toString();
      }
      return newFormData;
    });
    // Clear error for sponsorship_tier_id when user selects one
    if (errors.sponsorship_tier_id) {
      setErrors(prev => ({ ...prev, sponsorship_tier_id: null }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 1: // Sponsorship Selection (was Step 4)
        if (!formData.sponsorship_tier_id) newErrors.sponsorship_tier_id = 'Please select a sponsorship tier';
        if (formData.contribution_type === 'inkind' && !formData.inkind_description.trim()) {
          newErrors.inkind_description = 'Please describe your in-kind contribution';
        }
        break;

      case 2: // Company Details (was Step 1)
        if (!formData.legal_entity_name.trim()) newErrors.legal_entity_name = 'Legal entity name is required';
        if (!formData.abn_acn.trim()) {
          newErrors.abn_acn = 'ABN/ACN is required';
        } else if (!validateABN(formData.abn_acn)) {
          newErrors.abn_acn = 'Please enter a valid 11-digit ABN';
        }
        if (!formData.registered_street.trim()) newErrors.registered_street = 'Registered address is required';
        if (!formData.registered_suburb.trim()) newErrors.registered_suburb = 'Suburb is required';
        if (!formData.registered_postcode.trim()) newErrors.registered_postcode = 'Postcode is required';
        if (formData.website_url && !validateURL(formData.website_url)) newErrors.website_url = 'Please enter a valid URL';
        break;
        
      case 3: // Primary Contact (was Step 2)
        if (!formData.contact_full_name.trim()) newErrors.contact_full_name = 'Contact name is required';
        if (!formData.contact_position.trim()) newErrors.contact_position = 'Position/role is required';
        if (!formData.contact_email.trim()) {
          newErrors.contact_email = 'Email is required';
        } else if (!validateEmail(formData.contact_email)) {
          newErrors.contact_email = 'Please enter a valid email address';
        }
        if (!formData.contact_phone.trim()) {
          newErrors.contact_phone = 'Phone number is required';
        } else if (!validateAustralianPhone(formData.contact_phone)) {
          newErrors.contact_phone = 'Please enter a valid Australian phone number';
        }
        break;
        
      case 4: // Guarantor (conditional) (was Step 3)
        // Guarantor is only required for 'installments' now that 'recurring' is removed as an option
        if (formData.payment_plan === 'installments') {
          if (!formData.guarantor_full_name.trim()) newErrors.guarantor_full_name = 'Guarantor name is required for installment/recurring payments';
          if (!formData.guarantor_street.trim()) newErrors.guarantor_street = 'Guarantor address is required';
          if (!formData.guarantor_email.trim()) {
            newErrors.guarantor_email = 'Guarantor email is required';
          } else if (!validateEmail(formData.guarantor_email)) {
            newErrors.guarantor_email = 'Please enter a valid email address';
          }
          if (!formData.guarantor_phone.trim()) {
            newErrors.guarantor_phone = 'Guarantor phone is required';
          } else if (!validateAustralianPhone(formData.guarantor_phone)) {
            newErrors.guarantor_phone = 'Please enter a valid Australian phone number';
          }
        }
        break;
        
      case 5: // Branding Assets (was Step 5)
        if (!formData.logo_url) newErrors.logo_url = 'Company logo is required';
        break;
        
      case 6: // Confirmations (was Step 6)
        if (!formData.confirm_accuracy) newErrors.confirm_accuracy = 'Please confirm information accuracy';
        if (!formData.confirm_authority) newErrors.confirm_authority = 'Please confirm you have authority to enter this agreement';
        if (!formData.confirm_consent) newErrors.confirm_consent = 'Please provide consent for data usage';
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 6));
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    
    // Validate file type and size
    if (!['image/png', 'image/svg+xml', 'image/jpeg', 'image/jpg'].includes(file.type)) {
      setErrors(prev => ({ ...prev, logo_url: 'Please upload a PNG, SVG, or JPG file' }));
      return;
    }
    
    if (file.size > 5 * 1024 * 1024) { // 5MB
      setErrors(prev => ({ ...prev, logo_url: 'File size must be less than 5MB' }));
      return;
    }

    setUploadingLogo(true);
    try {
      const { file_url } = await UploadFile({ file });
      handleChange('logo_url', file_url);
    } catch (error) {
      console.error("Logo upload failed:", error);
      setErrors(prev => ({ ...prev, logo_url: 'Upload failed. Please try again.' }));
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleGuidelinesUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    
    if (file.type !== 'application/pdf') {
      setErrors(prev => ({ ...prev, brand_guidelines_url: 'Please upload a PDF file' }));
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) { // 10MB
      setErrors(prev => ({ ...prev, brand_guidelines_url: 'File size must be less than 10MB' }));
      return;
    }

    setUploadingGuidelines(true);
    try {
      const { file_url } = await UploadFile({ file });
      handleChange('brand_guidelines_url', file_url);
    } catch (error) {
      console.error("Guidelines upload failed:", error);
      setErrors(prev => ({ ...prev, brand_guidelines_url: 'Upload failed. Please try again.' }));
    } finally {
      setUploadingGuidelines(false);
    }
  };

  const calculateInstallments = () => {
    const selectedTier = sponsorshipTiers.find(t => t.id === formData.sponsorship_tier_id);
    const totalAmount = formData.custom_amount ? parseFloat(formData.custom_amount) : (selectedTier?.minimum_amount || 0);
    const installmentCount = formData.installment_count;

    if (!totalAmount || !installmentCount) return [];

    const baseInstallmentAmount = totalAmount / installmentCount;
    const intervalMonths = 12 / installmentCount; // Calculate interval based on 12 months for annual sponsorship

    const installments = [];
    let sumOfPreviousInstallments = 0;

    for (let i = 0; i < installmentCount; i++) {
        const dueDate = addMonths(new Date(), i * intervalMonths);
        let currentInstallmentAmount;

        if (i === installmentCount - 1) {
            // Last installment takes the remainder to ensure sum is exact
            currentInstallmentAmount = totalAmount - sumOfPreviousInstallments;
        } else {
            // Round to 2 decimal places for intermediate payments
            currentInstallmentAmount = parseFloat(baseInstallmentAmount.toFixed(2));
            sumOfPreviousInstallments += currentInstallmentAmount;
        }
        
        installments.push({
            number: i + 1,
            amount: currentInstallmentAmount,
            dueDate: i === 0 ? "Now" : formatISO(dueDate, { representation: 'date' }),
        });
    }
    return installments;
  };

  const handleSubmit = async () => {
    if (!validateStep(6)) return;
    
    setSubmitting(true);
    try {
      const selectedTier = sponsorshipTiers.find(t => t.id === formData.sponsorship_tier_id);
      
      const applicationData = {
        company_name: formData.legal_entity_name,
        trading_name: formData.trading_name,
        abn_acn: formData.abn_acn,
        registered_address: `${formData.registered_street}, ${formData.registered_suburb}, ${formData.registered_state} ${formData.registered_postcode}`,
        postal_address: formData.postal_street ? `${formData.postal_street}, ${formData.postal_suburb}, ${formData.postal_state} ${formData.postal_postcode}` : null,
        website: formData.website_url,
        contact_person: formData.contact_full_name,
        contact_position: formData.contact_position,
        email: formData.contact_email,
        phone: formData.contact_phone,
        guarantor_name: formData.guarantor_full_name,
        guarantor_address: formData.guarantor_street ? `${formData.guarantor_street}, ${formData.guarantor_suburb}, ${formData.guarantor_state} ${formData.guarantor_postcode}` : null,
        guarantor_email: formData.guarantor_email,
        guarantor_phone: formData.guarantor_phone,
        sponsorship_tier_id: formData.sponsorship_tier_id,
        stripe_price_id: selectedTier?.stripe_price_id || null, // Add stripe_price_id
        contribution_type: formData.contribution_type,
        custom_amount: formData.custom_amount ? parseFloat(formData.custom_amount) : null,
        inkind_description: formData.inkind_description,
        inkind_value: formData.inkind_value ? parseFloat(formData.inkind_value) : null,
        payment_preference: formData.payment_plan,
        installment_months: formData.payment_plan === 'installments' ? formData.installment_count : null, // This stores the number of installments
        logo_url: formData.logo_url,
        brand_guidelines_url: formData.brand_guidelines_url,
        social_media_handles: {
          facebook: formData.facebook_handle,
          instagram: formData.instagram_handle,
          linkedin: formData.linkedin_handle,
          twitter: formData.twitter_handle
        },
        status: 'pending',
        terms_accepted: true,
        terms_accepted_at: new Date().toISOString()
      };
      
      const application = await SponsorshipApplication.create(applicationData);

      const templates = await ContractTemplate.filter({ contract_type: 'sponsorship', is_active: true });
      if (templates.length === 0) {
        throw new Error("No active sponsorship contract template found. Please contact support.");
      }

      // Assuming there's one primary active template, use the first one
      const { data } = await generateContract({
        applicationId: application.id,
        applicationType: "sponsorship",
        templateId: templates[0].id
      });
      
      window.location.href = createPageUrl(`SignSponsorshipContract?contractId=${data.contractId}`);

    } catch (error) {
      console.error("Error submitting application and generating contract:", error);
      alert(`Failed to submit application: ${error.message || "An unexpected error occurred."}`);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-6xl mx-auto px-6 py-24">
          <div className="text-center mb-16">
            <Skeleton className="h-16 w-96 mx-auto mb-6" />
            <Skeleton className="h-6 w-128 mx-auto" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-96 rounded-2xl" />)}
          </div>
        </div>
      </div>
    );
  }

  const selectedTier = sponsorshipTiers.find(t => t.id === formData.sponsorship_tier_id);
  const requiresGuarantor = formData.payment_plan === 'installments';

  return (
    <>
      <style>
        {`
          @keyframes marquee {
            0% { transform: translateX(0%); }
            100% { transform: translateX(-50%); }
          }
          .animate-marquee {
            animation: marquee 40s linear infinite;
            white-space: nowrap;
          }
          .animate-marquee:hover {
            animation-play-state: paused;
          }
          /* Mask gradient for marquee */
          .mask-gradient-lr {
            mask-image: linear-gradient(to right, transparent, black 10%, black 90%, transparent);
            -webkit-mask-image: linear-gradient(to right, transparent, black 10%, black 90%, transparent);
          }
        `}
      </style>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        {/* Hero Section */}
        <div className="relative pt-32 pb-20 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-blue-600/20"></div>
          <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: "url(https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2940&auto=format&fit=crop)", opacity: 0.1}}></div>
          <div className="relative max-w-7xl mx-auto px-6 text-center">
            <div className="space-y-8">
              <h1 className="text-6xl md:text-7xl font-black text-white tracking-tight leading-none">
                PARTNER WITH US
              </h1>
              <div className="h-2 w-32 bg-red-600 mx-auto"></div>
              <p className="text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
                Join our sponsorship family and grow your business with Nepbourne FC
              </p>
            </div>
          </div>
        </div>

        {/* Partner Logos Section */}
        {activeSponsors.length > 0 && (
          <div className="bg-slate-900 py-12 border-y border-slate-700/50">
            <div className="max-w-7xl mx-auto px-6">
              <h3 className="text-center text-base font-semibold text-slate-400 tracking-wider mb-10">
                PROUDLY SUPPORTED BY INDUSTRY LEADERS
              </h3>
              <div className="relative w-full overflow-hidden mask-gradient-lr">
                <div className="flex animate-marquee">
                  {[...activeSponsors, ...activeSponsors].map((sponsor, index) => (
                    <div key={`${sponsor.id}-${index}`} className="flex-shrink-0 mx-10 flex items-center justify-center h-16" title={sponsor.name}>
                      <img 
                        src={sponsor.logo_url} 
                        alt={sponsor.name}
                        className="max-h-12 max-w-xs object-contain filter grayscale hover:grayscale-0 transition-all duration-300 cursor-pointer"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="max-w-6xl mx-auto px-6 py-24">
          {/* Progress Steps */}
          <div className="mb-16">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <React.Fragment key={step.number}>
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center font-bold text-lg transition-all duration-300 ${
                      currentStep >= step.number 
                        ? 'bg-red-600 text-white shadow-lg' 
                        : 'bg-white text-slate-500 shadow-md border-2 border-slate-200'
                    }`}>
                      {currentStep > step.number ? <CheckCircle className="w-6 h-6" /> : <step.icon className="w-6 h-6" />}
                    </div>
                    <div className="hidden sm:block">
                      <h3 className="font-semibold text-slate-900">{step.title}</h3>
                      <p className="text-sm text-slate-500">{step.description}</p>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`flex-1 h-1 mx-4 sm:mx-8 transition-all duration-300 ${
                      currentStep > step.number ? 'bg-red-600' : 'bg-slate-200'
                    }`}></div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Step Content */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-xl">
            <CardContent className="p-8">
              {/* Step 1: Sponsorship Selection */}
              {currentStep === 1 && (
                <div className="space-y-8">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Sponsorship Tier</h2>
                    <p className="text-slate-600 text-lg">Select the contribution level that best suits your organization.</p>
                  </div>

                  <RadioGroup
                    value={formData.sponsorship_tier_id}
                    onValueChange={(value) => handleTierChange(value)}
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                  >
                    {sponsorshipTiers.map((tier) => {
                      const isSelected = formData.sponsorship_tier_id === tier.id;
                      const isFeatured = tier.name.toLowerCase().includes('gold');
                      return (
                        <div key={tier.id} className="relative">
                          {isFeatured && (
                            <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-slate-900 font-bold px-4 py-1.5 text-sm flex items-center gap-1 z-10">
                              <Star className="w-4 h-4" />
                              Most Popular
                            </Badge>
                          )}
                          <Label htmlFor={tier.id} className={`h-full flex flex-col p-6 border-2 rounded-xl cursor-pointer transition-all duration-300 ${isSelected ? 'border-red-600 bg-red-50/50 shadow-lg' : 'bg-white hover:border-slate-400'} ${isFeatured && !isSelected ? 'scale-105 shadow-xl' : ''}`}>
                            <div className="flex items-center justify-between mb-4">
                              <h4 className="font-bold text-xl">{tier.name}</h4>
                              <RadioGroupItem value={tier.id} id={tier.id} />
                            </div>
                            <p className="text-sm text-slate-600 mb-4 h-12">{tier.description}</p>
                            <div className="mb-6">
                              <span className="text-4xl font-extrabold text-slate-900">${tier.minimum_amount.toLocaleString()}</span>
                              <span className="text-slate-500"> / year</span>
                            </div>
                            <ul className="space-y-2 text-sm text-slate-700 flex-grow">
                              {tier.benefits.slice(0, 4).map((benefit, index) => (
                                <li key={index} className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                  {benefit}
                                </li>
                              ))}
                            </ul>
                          </Label>
                        </div>
                      );
                    })}
                  </RadioGroup>

                  {formData.sponsorship_tier_id && (
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <Label className="text-lg font-semibold">Contribution Type</Label>
                        <RadioGroup 
                          value={formData.contribution_type} 
                          onValueChange={(value) => handleChange('contribution_type', value)}
                          className="space-y-4"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="financial" id="financial" />
                            <Label htmlFor="financial" className="font-normal">Financial Contribution</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="inkind" id="inkind" />
                            <Label htmlFor="inkind" className="font-normal">In-kind Contribution</Label>
                          </div>
                        </RadioGroup>
                      </div>

                      {formData.contribution_type === 'financial' && selectedTier && (
                        <div className="space-y-2">
                          <Label htmlFor="custom_amount">
                            Contribution Amount (minimum ${selectedTier.minimum_amount.toLocaleString()})
                          </Label>
                          <Input 
                            id="custom_amount"
                            type="number"
                            value={formData.custom_amount}
                            onChange={(e) => handleChange('custom_amount', e.target.value)}
                            placeholder={selectedTier.minimum_amount.toString()}
                            min={selectedTier.minimum_amount}
                          />
                        </div>
                      )}

                      {formData.contribution_type === 'inkind' && (
                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="inkind_description">Description of In-kind Contribution *</Label>
                            <Textarea 
                              id="inkind_description"
                              value={formData.inkind_description}
                              onChange={(e) => handleChange('inkind_description', e.target.value)}
                              placeholder="Describe what you're contributing..."
                              rows={3}
                            />
                            {errors.inkind_description && <p className="text-red-600 text-sm">{errors.inkind_description}</p>}
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="inkind_value">Approximate Value ($)</Label>
                            <Input 
                              id="inkind_value"
                              type="number"
                              value={formData.inkind_value}
                              onChange={(e) => handleChange('inkind_value', e.target.value)}
                              placeholder="Estimated value"
                            />
                          </div>
                        </div>
                      )}

                      {formData.contribution_type === 'financial' && (
                        <div className="space-y-4">
                          <Label className="text-lg font-semibold">Payment Plan</Label>
                          <Select 
                            value={formData.payment_plan} 
                            onValueChange={(value) => handleChange('payment_plan', value)}
                          >
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="one-off">One-off Payment</SelectItem>
                              <SelectItem value="installments">Installments</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}

                      {formData.payment_plan === 'installments' && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="installment_count">Number of Installments</Label>
                            <Select 
                              value={formData.installment_count.toString()} 
                              onValueChange={(value) => handleChange('installment_count', parseInt(value))}
                            >
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="2">2 Installments (Every 6 months)</SelectItem>
                                <SelectItem value="3">3 Installments (Every 4 months)</SelectItem>
                                <SelectItem value="4">4 Installments (Every 3 months)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {selectedTier && (
                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                              <h4 className="font-semibold text-slate-900 mb-3">Payment Schedule Preview</h4>
                              <div className="space-y-2">
                                {calculateInstallments().map((installment) => (
                                  <div key={installment.number} className="flex justify-between items-center text-sm">
                                    <span>Payment {installment.number}:</span>
                                    <span className="font-semibold">${installment.amount.toFixed(2).toLocaleString()} (due {installment.dueDate === 'Now' ? 'today' : new Date(installment.dueDate).toLocaleDateString()})</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex justify-end mt-12">
                    <Button 
                      type="button" 
                      onClick={nextStep} 
                      className="bg-red-600 hover:bg-red-700 px-8 py-3" 
                      disabled={!formData.sponsorship_tier_id}
                    >
                      Continue to Company Details <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 2: Company Details */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Company Details</h2>
                    <p className="text-slate-600">Tell us about your business</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="legal_entity_name">Legal Entity Name *</Label>
                      <Input 
                        id="legal_entity_name"
                        value={formData.legal_entity_name}
                        onChange={(e) => handleChange('legal_entity_name', e.target.value)}
                        placeholder="Pty Ltd Company Name"
                      />
                      {errors.legal_entity_name && <p className="text-red-600 text-sm">{errors.legal_entity_name}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="trading_name">Trading Name</Label>
                      <Input 
                        id="trading_name"
                        value={formData.trading_name}
                        onChange={(e) => handleChange('trading_name', e.target.value)}
                        placeholder="Business trading name (optional)"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="abn_acn">ABN/ACN *</Label>
                      <Input 
                        id="abn_acn"
                        value={formData.abn_acn}
                        onChange={(e) => handleChange('abn_acn', e.target.value)}
                        placeholder="11-digit ABN"
                        maxLength={11}
                      />
                      {errors.abn_acn && <p className="text-red-600 text-sm">{errors.abn_acn}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="website_url">Website URL</Label>
                      <Input 
                        id="website_url"
                        value={formData.website_url}
                        onChange={(e) => handleChange('website_url', e.target.value)}
                        placeholder="https://your-website.com.au"
                      />
                      {errors.website_url && <p className="text-red-600 text-sm">{errors.website_url}</p>}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">Registered Business Address *</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="registered_street">Street Address *</Label>
                        <Input 
                          id="registered_street"
                          value={formData.registered_street}
                          onChange={(e) => handleChange('registered_street', e.target.value)}
                        />
                        {errors.registered_street && <p className="text-red-600 text-sm">{errors.registered_street}</p>}
                      </div>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="registered_suburb">Suburb *</Label>
                          <Input 
                            id="registered_suburb"
                            value={formData.registered_suburb}
                            onChange={(e) => handleChange('registered_suburb', e.target.value)}
                          />
                          {errors.registered_suburb && <p className="text-red-600 text-sm">{errors.registered_suburb}</p>}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="registered_state">State *</Label>
                          <Select value={formData.registered_state} onValueChange={(value) => handleChange('registered_state', value)}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ACT">ACT</SelectItem>
                              <SelectItem value="NSW">NSW</SelectItem>
                              <SelectItem value="NT">NT</SelectItem>
                              <SelectItem value="QLD">QLD</SelectItem>
                              <SelectItem value="SA">SA</SelectItem>
                              <SelectItem value="TAS">TAS</SelectItem>
                              <SelectItem value="VIC">VIC</SelectItem>
                              <SelectItem value="WA">WA</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="registered_postcode">Postcode *</Label>
                          <Input 
                            id="registered_postcode"
                            value={formData.registered_postcode}
                            onChange={(e) => handleChange('registered_postcode', e.target.value)}
                            maxLength={4}
                          />
                          {errors.registered_postcode && <p className="text-red-600 text-sm">{errors.registered_postcode}</p>}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">Postal Address (if different)</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="postal_street">Street Address</Label>
                        <Input 
                          id="postal_street"
                          value={formData.postal_street}
                          onChange={(e) => handleChange('postal_street', e.target.value)}
                          placeholder="Leave blank if same as registered address"
                        />
                      </div>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="postal_suburb">Suburb</Label>
                          <Input 
                            id="postal_suburb"
                            value={formData.postal_suburb}
                            onChange={(e) => handleChange('postal_suburb', e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="postal_state">State</Label>
                          <Select value={formData.postal_state} onValueChange={(value) => handleChange('postal_state', value)}>
                            <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ACT">ACT</SelectItem>
                              <SelectItem value="NSW">NSW</SelectItem>
                              <SelectItem value="NT">NT</SelectItem>
                              <SelectItem value="QLD">QLD</SelectItem>
                              <SelectItem value="SA">SA</SelectItem>
                              <SelectItem value="TAS">TAS</SelectItem>
                              <SelectItem value="VIC">VIC</SelectItem>
                              <SelectItem value="WA">WA</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="postal_postcode">Postcode</Label>
                          <Input 
                            id="postal_postcode"
                            value={formData.postal_postcode}
                            onChange={(e) => handleChange('postal_postcode', e.target.value)}
                            maxLength={4}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Primary Contact */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Primary Contact</h2>
                    <p className="text-slate-600">Company representative details</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="contact_full_name">Full Name *</Label>
                      <Input 
                        id="contact_full_name"
                        value={formData.contact_full_name}
                        onChange={(e) => handleChange('contact_full_name', e.target.value)}
                      />
                      {errors.contact_full_name && <p className="text-red-600 text-sm">{errors.contact_full_name}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact_position">Position/Role *</Label>
                      <Input 
                        id="contact_position"
                        value={formData.contact_position}
                        onChange={(e) => handleChange('contact_position', e.target.value)}
                        placeholder="e.g., Director, Manager"
                      />
                      {errors.contact_position && <p className="text-red-600 text-sm">{errors.contact_position}</p>}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="contact_email">Email Address *</Label>
                      <Input 
                        id="contact_email"
                        type="email"
                        value={formData.contact_email}
                        onChange={(e) => handleChange('contact_email', e.target.value)}
                      />
                      {errors.contact_email && <p className="text-red-600 text-sm">{errors.contact_email}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact_phone">Phone Number *</Label>
                      <Input 
                        id="contact_phone"
                        value={formData.contact_phone}
                        onChange={(e) => handleChange('contact_phone', e.target.value)}
                        placeholder="+61 or 04xxxxxxxx"
                      />
                      {errors.contact_phone && <p className="text-red-600 text-sm">{errors.contact_phone}</p>}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 4: Guarantor */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Personal Guarantee</h2>
                    <p className="text-slate-600">
                      {requiresGuarantor ? 'Required for installment payments' : 'This section is optional for one-off payments'}
                    </p>
                  </div>

                  {requiresGuarantor && (
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg mb-6">
                      <p className="text-amber-800 text-sm">
                        <Shield className="w-4 h-4 inline mr-2" />
                        Personal guarantee details are required for your selected payment plan.
                      </p>
                    </div>
                  )}

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="guarantor_full_name">
                        Full Name {requiresGuarantor && '*'}
                      </Label>
                      <Input 
                        id="guarantor_full_name"
                        value={formData.guarantor_full_name}
                        onChange={(e) => handleChange('guarantor_full_name', e.target.value)}
                      />
                      {errors.guarantor_full_name && <p className="text-red-600 text-sm">{errors.guarantor_full_name}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="guarantor_email">
                        Email Address {requiresGuarantor && '*'}
                      </Label>
                      <Input 
                        id="guarantor_email"
                        type="email"
                        value={formData.guarantor_email}
                        onChange={(e) => handleChange('guarantor_email', e.target.value)}
                      />
                      {errors.guarantor_email && <p className="text-red-600 text-sm">{errors.guarantor_email}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="guarantor_phone">
                      Phone Number {requiresGuarantor && '*'}
                    </Label>
                    <Input 
                      id="guarantor_phone"
                      value={formData.guarantor_phone}
                      onChange={(e) => handleChange('guarantor_phone', e.target.value)}
                      placeholder="+61 or 04xxxxxxxx"
                    />
                    {errors.guarantor_phone && <p className="text-red-600 text-sm">{errors.guarantor_phone}</p>}
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">
                      Residential Address {requiresGuarantor && '*'}
                    </h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="guarantor_street">Street Address</Label>
                        <Input 
                          id="guarantor_street"
                          value={formData.guarantor_street}
                          onChange={(e) => handleChange('guarantor_street', e.target.value)}
                        />
                        {errors.guarantor_street && <p className="text-red-600 text-sm">{errors.guarantor_street}</p>}
                      </div>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="guarantor_suburb">Suburb</Label>
                          <Input 
                            id="guarantor_suburb"
                            value={formData.guarantor_suburb}
                            onChange={(e) => handleChange('guarantor_suburb', e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="guarantor_state">State</Label>
                          <Select value={formData.guarantor_state} onValueChange={(value) => handleChange('guarantor_state', value)}>
                            <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ACT">ACT</SelectItem>
                              <SelectItem value="NSW">NSW</SelectItem>
                              <SelectItem value="NT">NT</SelectItem>
                              <SelectItem value="QLD">QLD</SelectItem>
                              <SelectItem value="SA">SA</SelectItem>
                              <SelectItem value="TAS">TAS</SelectItem>
                              <SelectItem value="VIC">VIC</SelectItem>
                              <SelectItem value="WA">WA</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="guarantor_postcode">Postcode</Label>
                          <Input 
                            id="guarantor_postcode"
                            value={formData.guarantor_postcode}
                            onChange={(e) => handleChange('guarantor_postcode', e.target.value)}
                            maxLength={4}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 5: Branding Assets */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Branding Assets</h2>
                    <p className="text-slate-600">Upload your company materials</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="logo-upload">Company Logo * (PNG, SVG, JPG - min 500px, max 5MB)</Label>
                        <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center">
                          {formData.logo_url ? (
                            <div className="space-y-4">
                              <img 
                                src={formData.logo_url} 
                                alt="Company logo" 
                                className="max-h-32 mx-auto object-contain"
                              />
                              <Button 
                                variant="outline" 
                                onClick={() => document.getElementById('logo-upload').click()}
                              >
                                Change Logo
                              </Button>
                            </div>
                          ) : (
                            <div className="space-y-4">
                              <Upload className="w-12 h-12 text-slate-400 mx-auto" />
                              <Button 
                                variant="outline" 
                                onClick={() => document.getElementById('logo-upload').click()}
                                disabled={uploadingLogo}
                              >
                                {uploadingLogo ? "Uploading..." : "Upload Logo"}
                              </Button>
                            </div>
                          )}
                          <input
                            id="logo-upload"
                            type="file"
                            className="hidden"
                            accept="image/png,image/svg+xml,image/jpeg,image/jpg"
                            onChange={handleLogoUpload}
                          />
                        </div>
                        {errors.logo_url && <p className="text-red-600 text-sm">{errors.logo_url}</p>}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="guidelines-upload">Brand Guidelines (PDF - optional, max 10MB)</Label>
                        <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center">
                          {formData.brand_guidelines_url ? (
                            <div className="space-y-4">
                              <FileText className="w-12 h-12 text-green-600 mx-auto" />
                              <p className="text-sm text-slate-600">Brand guidelines uploaded</p>
                              <Button 
                                variant="outline" 
                                onClick={() => document.getElementById('guidelines-upload').click()}
                              >
                                Replace File
                              </Button>
                            </div>
                          ) : (
                            <div className="space-y-4">
                              <FileText className="w-12 h-12 text-slate-400 mx-auto" />
                              <Button 
                                variant="outline" 
                                onClick={() => document.getElementById('guidelines-upload').click()}
                                disabled={uploadingGuidelines}
                              >
                                {uploadingGuidelines ? "Uploading..." : "Upload Guidelines"}
                              </Button>
                            </div>
                          )}
                          <input
                            id="guidelines-upload"
                            type="file"
                            className="hidden"
                            accept="application/pdf"
                            onChange={handleGuidelinesUpload}
                          />
                        </div>
                        {errors.brand_guidelines_url && <p className="text-red-600 text-sm">{errors.brand_guidelines_url}</p>}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900">Social Media Handles</h3>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="facebook_handle">Facebook</Label>
                          <Input 
                            id="facebook_handle"
                            value={formData.facebook_handle}
                            onChange={(e) => handleChange('facebook_handle', e.target.value)}
                            placeholder="@yourbusiness"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="instagram_handle">Instagram</Label>
                          <Input 
                            id="instagram_handle"
                            value={formData.instagram_handle}
                            onChange={(e) => handleChange('instagram_handle', e.target.value)}
                            placeholder="@yourbusiness"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="linkedin_handle">LinkedIn</Label>
                          <Input 
                            id="linkedin_handle"
                            value={formData.linkedin_handle}
                            onChange={(e) => handleChange('linkedin_handle', e.target.value)}
                            placeholder="company/yourbusiness"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="twitter_handle">X/Twitter</Label>
                          <Input 
                            id="twitter_handle"
                            value={formData.twitter_handle}
                            onChange={(e) => handleChange('twitter_handle', e.target.value)}
                            placeholder="@yourbusiness"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 6: Confirmations */}
              {currentStep === 6 && (
                <div className="space-y-6">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Confirmation</h2>
                    <p className="text-slate-600">Review your details and confirm submission</p>
                  </div>

                  {/* Summary */}
                  <div className="grid md:grid-cols-2 gap-8 mb-8">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Company Summary</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 text-sm">
                        <div><strong>Legal Name:</strong> {formData.legal_entity_name}</div>
                        {formData.trading_name && <div><strong>Trading Name:</strong> {formData.trading_name}</div>}
                        <div><strong>ABN:</strong> {formData.abn_acn}</div>
                        <div><strong>Contact:</strong> {formData.contact_full_name} ({formData.contact_position})</div>
                        <div><strong>Email:</strong> {formData.contact_email}</div>
                        <div><strong>Phone:</strong> {formData.contact_phone}</div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Sponsorship Summary</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 text-sm">
                        {selectedTier && (
                          <>
                            <div><strong>Tier:</strong> {selectedTier.name}</div>
                            <div><strong>Type:</strong> {formData.contribution_type === 'financial' ? 'Financial' : 'In-kind'}</div>
                            {formData.contribution_type === 'financial' && (
                              <>
                                <div><strong>Amount:</strong> ${(formData.custom_amount || selectedTier.minimum_amount).toLocaleString()}</div>
                                <div><strong>Payment Plan:</strong> {formData.payment_plan.replace('_', ' ')}</div>
                              </>
                            )}
                            {formData.contribution_type === 'inkind' && (
                              <>
                                <div><strong>Contribution:</strong> {formData.inkind_description}</div>
                                {formData.inkind_value && <div><strong>Est. Value:</strong> ${parseFloat(formData.inkind_value).toLocaleString()}</div>}
                              </>
                            )}
                          </>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  {/* Confirmations */}
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Checkbox 
                        id="confirm_accuracy" 
                        checked={formData.confirm_accuracy}
                        onCheckedChange={(checked) => handleChange('confirm_accuracy', checked)}
                      />
                      <Label htmlFor="confirm_accuracy" className="text-sm leading-relaxed">
                        I confirm the above information is accurate and complete.
                      </Label>
                    </div>
                    {errors.confirm_accuracy && <p className="text-red-600 text-sm ml-6">{errors.confirm_accuracy}</p>}

                    <div className="flex items-start space-x-3">
                      <Checkbox 
                        id="confirm_authority" 
                        checked={formData.confirm_authority}
                        onCheckedChange={(checked) => handleChange('confirm_authority', checked)}
                      />
                      <Label htmlFor="confirm_authority" className="text-sm leading-relaxed">
                        I have authority to enter into this Agreement on behalf of the Sponsor.
                      </Label>
                    </div>
                    {errors.confirm_authority && <p className="text-red-600 text-sm ml-6">{errors.confirm_authority}</p>}

                    <div className="flex items-start space-x-3">
                      <Checkbox 
                        id="confirm_consent" 
                        checked={formData.confirm_consent}
                        onCheckedChange={(checked) => handleChange('confirm_consent', checked)}
                      />
                      <Label htmlFor="confirm_consent" className="text-sm leading-relaxed">
                        I consent to my details being used for contract, invoicing, and promotional purposes.
                      </Label>
                    </div>
                    {errors.confirm_consent && <p className="text-red-600 text-sm ml-6">{errors.confirm_consent}</p>}
                  </div>
                </div>
              )}

              {/* Success Step - This section is effectively replaced by the redirect to the signing page */}
              {currentStep === 7 && (
                <div className="text-center space-y-8">
                  <div className="space-y-4">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle className="w-12 h-12 text-green-600" />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900">Application Submitted!</h2>
                    <p className="text-slate-600 text-lg max-w-2xl mx-auto">
                      Thank you for your interest in sponsoring Nepbourne FC. Your contract is being prepared.
                    </p>
                  </div>

                  <Card className="bg-green-50 border-green-200 max-w-2xl mx-auto">
                    <CardContent className="p-6">
                      <h3 className="font-bold text-green-900 mb-4">What's Next?</h3>
                      <div className="space-y-4 text-left">
                        <div className="flex items-start gap-3">
                          <span className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">1</span>
                          <p className="text-green-800">You will be redirected to our secure e-signature platform to review and sign your contract.</p>
                        </div>
                        <div className="flex items-start gap-3">
                          <span className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">2</span>
                          <p className="text-green-800">Upon signing, you will be prompted to set up your payment method.</p>
                        </div>
                        <div className="flex items-start gap-3">
                          <span className="bg-green-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">3</span>
                          <p className="text-green-800">Once signed and paid, you'll officially be a Nepbourne FC sponsor!</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="flex justify-center gap-4">
                    <Link to={createPageUrl('Home')}>
                      <Button variant="outline" className="px-8">
                        Return to Homepage
                      </Button>
                    </Link>
                    <Button 
                      onClick={() => {
                        setCurrentStep(1);
                        setFormData({
                          legal_entity_name: '', trading_name: '', abn_acn: '', registered_street: '', registered_suburb: '', 
                          registered_state: 'VIC', registered_postcode: '', registered_country: 'Australia', postal_street: '', 
                          postal_suburb: '', postal_state: '', postal_postcode: '', postal_country: 'Australia', website_url: '',
                          contact_full_name: '', contact_position: '', contact_email: '', contact_phone: '',
                          guarantor_full_name: '', guarantor_street: '', guarantor_suburb: '', guarantor_state: '', 
                          guarantor_postcode: '', guarantor_email: '', guarantor_phone: '', sponsorship_tier_id: '', 
                          contribution_type: 'financial', custom_amount: '', inkind_description: '', inkind_value: '', 
                          payment_plan: 'one-off', installment_count: 3, logo_url: '', brand_guidelines_url: '', 
                          facebook_handle: '', instagram_handle: '', linkedin_handle: '', twitter_handle: '',
                          confirm_accuracy: false, confirm_authority: false, confirm_consent: false
                        });
                        setErrors({});
                      }}
                      className="bg-red-600 hover:bg-red-700 px-8"
                    >
                      Start New Application
                    </Button>
                  </div>
                </div>
              )}

              {/* Navigation */}
              {currentStep < 7 && (
                <div className="flex justify-between pt-8 mt-8 border-t border-slate-200">
                  <Button 
                    variant="outline" 
                    onClick={prevStep}
                    disabled={currentStep === 1}
                    className="px-8"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  
                  {currentStep < 6 ? (
                    <Button 
                      onClick={nextStep}
                      className="bg-red-600 hover:bg-red-700 px-8"
                    >
                      Next
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button 
                      onClick={handleSubmit}
                      disabled={submitting}
                      className="bg-red-600 hover:bg-red-700 px-8"
                    >
                      {submitting ? "Generating Contract..." : "Proceed to Contract"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
