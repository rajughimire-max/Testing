import React, { useState, useEffect, useCallback } from "react";
import { Event, Team, Member, Player } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import TrainingForm from "../components/training/TrainingForm";
import TrainingList from "../components/training/TrainingList";
import TrainingDetailsForm from "../components/training/TrainingDetailsForm";
import TrainingEquipmentManager from "../components/training/TrainingEquipmentManager";
import TrainingAttendanceManager from "../components/training/TrainingAttendanceManager";
import { InventoryItem } from '.@/api/entities';
import { User as UserEntity } from "@/api/entities";
import TrainingDetailModal from "../components/training/TrainingDetailModal";
import { autoCreateNotifications } from '@/api/functions';
import { TrainingAttendance } from "@/api/entities";
import { toast } from "react-hot-toast";

export default function Training() {
  const [sessions, setSessions] = useState([]);
  const [teams, setTeams] = useState([]);
  const [members, setMembers] = useState([]);
  const [players, setPlayers] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [allAttendance, setAllAttendance] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingError, setLoadingError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingSession, setEditingSession] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentStep, setCurrentStep] = useState(0);
  const [currentUser, setCurrentUser] = useState(null);

  // State for detail modal
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedSessionForDetail, setSelectedSessionForDetail] = useState(null);

  const loadAllData = useCallback(async () => {
    setLoading(true);
    setLoadingError(null);
    
    try {
      // Load data in smaller batches with error handling for each
      console.log("Loading current user...");
      let currentUserData = null;
      try {
        currentUserData = await UserEntity.me();
        setCurrentUser(currentUserData);
      } catch (error) {
        console.error("Error loading current user:", error);
        // Continue without user data
      }

      console.log("Loading training sessions...");
      let eventsData = [];
      try {
        // Load only recent events first (last 100) to prevent timeout
        eventsData = await Event.list("-event_date", 100);
        const trainingEvents = eventsData.filter(e => e.event_type === 'training');
        setSessions(trainingEvents);
      } catch (error) {
        console.error("Error loading training sessions:", error);
        toast.error("Failed to load training sessions");
        setLoadingError("Failed to load training sessions. Please refresh the page.");
        return;
      }

      console.log("Loading teams...");
      try {
        const teamsData = await Team.list("-created_date", 50);
        setTeams(teamsData);
      } catch (error) {
        console.error("Error loading teams:", error);
        toast.error("Failed to load teams");
      }

      console.log("Loading members...");
      try {
        const membersData = await Member.list("-created_date", 100);
        setMembers(membersData);
      } catch (error) {
        console.error("Error loading members:", error);
        toast.error("Failed to load members");
      }

      console.log("Loading players...");
      try {
        const playersData = await Player.list("-created_date", 100);
        setPlayers(playersData);
      } catch (error) {
        console.error("Error loading players:", error);
        toast.error("Failed to load players");
      }

      console.log("Loading inventory...");
      try {
        const inventoryData = await InventoryItem.list("-created_date", 100);
        setInventoryItems(inventoryData);
      } catch (error) {
        console.error("Error loading inventory:", error);
        toast.error("Failed to load inventory");
      }

      console.log("Loading attendance...");
      try {
        const attendanceData = await TrainingAttendance.list("-created_date", 200);
        setAllAttendance(attendanceData);
      } catch (error) {
        console.error("Error loading attendance:", error);
        toast.error("Failed to load attendance data");
      }

    } catch (error) {
      console.error("Unexpected error loading training data:", error);
      setLoadingError("An unexpected error occurred. Please refresh the page and try again.");
      toast.error("Failed to load training data");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  const handleInventoryUpdate = async () => {
    try {
      const inventoryData = await InventoryItem.list("-created_date", 100);
      setInventoryItems(inventoryData);
    } catch (error) {
      console.error("Error refreshing inventory:", error);
      toast.error("Failed to refresh inventory");
    }
  };

  const handleCreateTeam = async (teamData) => {
    try {
      const newTeam = await Team.create(teamData);
      await loadAllData();
      return newTeam;
    } catch (error) {
      console.error("Error creating team:", error);
      throw error;
    }
  };

  const handleSessionSubmit = async (sessionData) => {
    try {
      let savedSession;
      if (sessionData.id) {
        await Event.update(sessionData.id, sessionData);
        savedSession = await Event.get(sessionData.id);
        // Send notification for updated training
        try {
          await autoCreateNotifications({
            entityType: 'Event',
            entityId: sessionData.id,
            action: 'updated'
          });
        } catch (notificationError) {
          console.error('Failed to send notifications:', notificationError);
        }
      } else {
        savedSession = await Event.create({ ...sessionData, event_type: 'training' });
        // Send notification for new training
        try {
          await autoCreateNotifications({
            entityType: 'Event',
            entityId: savedSession.id,
            action: 'created'
          });
        } catch (notificationError) {
          console.error('Failed to send notifications:', notificationError);
        }
      }
      setShowForm(false);
      setEditingSession(null);
      setCurrentStep(0);
      loadAllData();
      return savedSession;
    } catch (error) {
      console.error("Error saving session:", error);
      throw error;
    }
  };

  const handleCompleteSession = async (sessionId) => {
    if (window.confirm("Are you sure you want to mark this session as completed?")) {
      try {
        await Event.update(sessionId, { status: 'completed' });
        toast.success("Training session marked as completed!");
        loadAllData();
      } catch (error) {
        console.error("Error completing session:", error);
        toast.error("Failed to complete session.");
      }
    }
  };

  const handleEditSession = (session) => {
    setEditingSession(session);
    setCurrentStep(0);
    setShowForm(true);
  };
  
  const handleDeleteSession = async (id) => {
    if (window.confirm("Are you sure you want to delete this training session?")) {
      try {
        await Event.delete(id);
        setSessions(prevSessions => prevSessions.filter(session => session.id !== id));
        toast.success("Training session deleted successfully!");
      } catch (error) {
        console.error("Error deleting training session:", error);
        if (error.message?.includes('Object not found') || error.response?.status === 404) {
          setSessions(prevSessions => prevSessions.filter(session => session.id !== id));
          toast.success("Training session removed.");
        } else {
          toast.error("Failed to delete training session. Please try again.");
        }
        loadAllData();
      }
    }
  };

  const handleSessionDoubleClick = (session) => {
    setSelectedSessionForDetail(session);
    setShowDetailModal(true);
  };
  
  const handleRsvpUpdate = () => {
    loadAllData();
  };

  const nextStep = () => setCurrentStep(prev => prev + 1);
  const prevStep = () => setCurrentStep(prev => prev - 1);
  const goToStep = (step) => setCurrentStep(step);

  const renderFormStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <TrainingDetailsForm
            session={editingSession}
            teams={teams}
            members={members}
            onSubmit={handleSessionSubmit}
            onCreateTeam={handleCreateTeam}
            onCancel={() => { setShowForm(false); setEditingSession(null); setCurrentStep(0); }}
            nextStep={nextStep}
            goToStep={goToStep}
          />
        );
      case 1:
        return (
          <TrainingEquipmentManager
            session={editingSession}
            inventoryItems={inventoryItems}
            onInventoryUpdate={handleInventoryUpdate}
            prevStep={prevStep}
            nextStep={nextStep}
            goToStep={goToStep}
          />
        );
      case 2:
        return (
          <TrainingAttendanceManager
            session={editingSession}
            members={members}
            players={players}
            allAttendance={allAttendance}
            currentUser={currentUser}
            onStatusChange={loadAllData}
            prevStep={prevStep}
            goToStep={goToStep}
            onCompleteSession={handleCompleteSession}
          />
        );
      default:
        return null;
    }
  };

  const filteredSessions = sessions.filter(session => {
    if (!searchTerm) return true;

    const teamNames = (session.team_ids || (session.team_id ? [session.team_id] : []))
        .map(id => teams.find(t => t.id === id)?.name || "")
        .filter(name => name);

    return session.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
           session.venue?.toLowerCase().includes(searchTerm.toLowerCase()) ||
           teamNames.some(name => name.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  const stepTitles = ["Details", "Equipment", "Attendance"];

  // Show error state
  if (loadingError) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Card className="bg-red-50 border-red-200">
            <CardHeader>
              <h1 className="text-xl font-bold text-red-900">Loading Error</h1>
            </CardHeader>
            <CardContent>
              <p className="text-red-700 mb-4">{loadingError}</p>
              <Button onClick={() => window.location.reload()} className="bg-red-600 hover:bg-red-700">
                Refresh Page
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Training Sessions</h1>
            <p className="text-slate-600">Schedule and manage all team training sessions.</p>
          </div>
          <Button onClick={() => { setEditingSession(null); setShowForm(true); setCurrentStep(0); }} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Session
          </Button>
        </div>

        {!showForm && (
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
            <CardContent className="p-6">
              <div className="relative">
                <Input
                  placeholder="Search training sessions by title, venue, or team..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-4"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {showForm ? (
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
            <CardHeader className="pb-0">
              <h2 className="text-2xl font-semibold text-slate-800 mb-4">
                {editingSession ? "Edit Training Session" : "Create New Training Session"}
              </h2>
              <div className="flex justify-between items-center mb-4">
                {stepTitles.map((title, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className={`flex-1 ${index === currentStep ? 'bg-blue-100 text-blue-700' : 'text-slate-600'}`}
                    onClick={() => goToStep(index)}
                  >
                    Step {index + 1}: {title}
                  </Button>
                ))}
              </div>
            </CardHeader>
            <CardContent className="p-6 pt-4">
              {renderFormStep()}
            </CardContent>
          </Card>
        ) : (
          <TrainingList 
            sessions={filteredSessions} 
            teams={teams}
            members={members}
            loading={loading} 
            onEdit={handleEditSession} 
            onDelete={handleDeleteSession}
            onSessionDoubleClick={handleSessionDoubleClick}
          />
        )}
      </div>

      {/* Detail Modal */}
      {selectedSessionForDetail && (
        <TrainingDetailModal
          session={selectedSessionForDetail}
          teams={teams}
          members={members}
          players={players}
          allAttendance={allAttendance}
          currentUser={currentUser}
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(false)}
          onRsvpUpdate={handleRsvpUpdate}
        />
      )}
    </div>
  );
}