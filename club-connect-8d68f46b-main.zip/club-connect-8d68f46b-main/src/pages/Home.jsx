
import React, { useState, useEffect, useCallback, useRef } from "react";
import { Link } from "react-router-dom";
import { WebsiteContent, NewsArticle, Match, Sponsor, Event, MerchandiseItem, Team, Member } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Users, ShoppingCart, Gamepad2, ArrowRight, Video, ChevronLeft, ChevronRight, User, Shield, Trophy } from "lucide-react";
import { format, isAfter } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { createPageUrl } from '@/utils';
import TrainingDetailModal from "../components/training/TrainingDetailModal"; // Import the modal

export default function HomePage() {
  const [content, setContent] = useState(null);
  const [heroSlides, setHeroSlides] = useState([]);
  const [matches, setMatches] = useState([]);
  const [sponsors, setSponsors] = useState([]);
  const [events, setEvents] = useState([]); // This will be set to empty as per outline
  const [trainingEvents, setTrainingEvents] = useState([]);
  const [merchandise, setMerchandise] = useState([]);
  const [teams, setTeams] = useState([]);
  const [members, setMembers] = useState([]); // Add members state for coach info
  const [loading, setLoading] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);

  // State for detail modal
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedSessionForDetail, setSelectedSessionForDetail] = useState(null);

  useEffect(() => {
    const loadPageData = async () => {
      try {
        const [
          contentData,
          heroData,
          matchesData,
          sponsorsData,
          eventsData,
          merchandiseData,
          teamsData,
          membersData // Fetch members
        ] = await Promise.all([
          WebsiteContent.list().then(res => res[0] || {}),
          NewsArticle.filter({ is_hero_slide: true, status: 'published' }),
          Match.list('match_date', 6),
          Sponsor.list('-amount', 8),
          Event.list('-event_date', 20), // Fetch more events to filter training sessions
          MerchandiseItem.list('-sort_order', 8),
          Team.list(),
          Member.list() // Fetch all members
        ]);

        const upcomingMatches = matchesData
          .filter(match => match.match_status === 'scheduled')
          .filter(match => isAfter(new Date(match.match_date), new Date()))
          .slice(0, 3);

        // Filter and get upcoming training sessions
        const upcomingTraining = eventsData
          .filter(event => event.event_type === 'training')
          .filter(event => isAfter(new Date(event.event_date), new Date()))
          .slice(0, 4);

        const sortedHeroData = heroData.sort((a, b) => {
            if (a.content_type === 'video' && b.content_type !== 'video') {
                return -1;
            }
            if (a.content_type !== 'video' && b.content_type === 'video') {
                return 1;
            }
            return 0;
        });

        setContent(contentData);
        setHeroSlides(sortedHeroData);
        setMatches(upcomingMatches);
        setSponsors(sponsorsData.filter(s => s.status === 'Active'));
        setEvents([]); // Events are not displayed anymore on the homepage
        setTrainingEvents(upcomingTraining); // Set training events
        setMerchandise(merchandiseData.filter(m => m.is_active));
        setTeams(teamsData);
        setMembers(membersData); // Set members state
      } catch (error) {
        console.error("Error loading public site data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadPageData();
  }, []);

  // Auto-advance hero slides
  useEffect(() => {
    if (heroSlides.length > 1) {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
      }, 5000);
      return () => clearInterval(timer);
    }
  }, [heroSlides.length]);

  const handleSessionDoubleClick = (session) => {
    setSelectedSessionForDetail(session);
    setShowDetailModal(true);
  };

  const handleRsvpUpdate = () => {
    // Optionally, you could refetch training data here if you wanted the main page to update.
    // For now, simply closing the modal is sufficient.
    setShowDetailModal(false);
  };

  if (loading) {
    return <div className="p-8"><Skeleton className="h-screen w-full" /></div>;
  }

  if (!content) {
    return <div className="p-8 text-center">Website content not configured yet. Please visit the admin dashboard.</div>;
  }

  // Hero Section with AS Roma style
  const HeroSection = () => (
    <section className="relative h-screen overflow-hidden">
      {/* Background Video/Image */}
      <div className="absolute inset-0">
        {heroSlides.length > 0 ? (
          <div className="relative w-full h-full">
            {heroSlides.map((slide, index) => (
              <div
                key={slide.id}
                className={`absolute inset-0 transition-opacity duration-1000 ${
                  index === currentSlide ? 'opacity-100' : 'opacity-0'
                }`}
              >
                {slide.content_type === 'video' && slide.video_url ? (
                  <video
                    autoPlay
                    muted
                    loop
                    playsInline
                    className="w-full h-full object-cover"
                    src={slide.video_url}
                  />
                ) : (
                  <img
                    src={slide.image_url}
                    alt={slide.title}
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-red-900 via-black to-red-800"></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-black/80"></div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 w-full">
          <div className="max-w-4xl">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-6xl md:text-8xl font-black text-white tracking-tighter leading-none">
                  {content.hero_title || 'NEPBOURNE'}
                </h1>
                <h2 className="text-6xl md:text-8xl font-black gradient-text tracking-tighter leading-none">
                  FOOTBALL CLUB
                </h2>
              </div>
              
              <p className="text-xl md:text-2xl text-gray-300 font-light max-w-2xl leading-relaxed">
                {content.hero_subtitle || 'Excellence • Unity • Victory'}
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-8">
                <Link to={createPageUrl('MembershipSignup')}>
                  <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 text-lg font-semibold tracking-wide">
                    JOIN THE CLUB
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to={createPageUrl('Fixtures')}>
                  <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-black px-8 py-4 text-lg font-semibold tracking-wide">
                    VIEW FIXTURES
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Navigation Dots */}
      {heroSlides.length > 1 && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3 z-20">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentSlide ? 'bg-white scale-125' : 'bg-white/50 hover:bg-white/75'
              }`}
            />
          ))}
        </div>
      )}
    </section>
  );

  // Website Settings-controlled sections
  const TeamsSection = () => content?.show_teams && teams.length > 0 && (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">OUR TEAMS</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>
        <div className="text-center">
          <p className="text-xl text-gray-600 mb-8">
            Discover the different teams that make up Nepbourne FC.
          </p>
          <Link to={createPageUrl('Teams')}>
            <Button className="bg-red-600 hover:bg-red-700 text-white px-8 py-4">
              View All Teams
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );

  const MembersSection = () => content?.show_members && (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">CLUB MEMBERS</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>
        <div className="text-center">
          <p className="text-xl text-gray-600 mb-8">Join our growing community of passionate football supporters</p>
          <Link to={createPageUrl('MembershipSignup')}>
            <Button className="bg-red-600 hover:bg-red-700 text-white px-8 py-4">
              Become a Member
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );

  const PlayersSection = () => content?.show_players && (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">OUR PLAYERS</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>
        <div className="text-center">
          <p className="text-xl text-gray-600 mb-8">Meet our talented squad representing Nepbourne FC</p>
          <Link to={createPageUrl('Squad')}>
            <Button className="bg-red-600 hover:bg-red-700 text-white px-8 py-4">
              View Squad
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );

  // Removed EventsSection as per outline

  const SocialGamesSection = () => content?.show_social_games && (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">JOIN OUR SOCIAL GAMES</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>
        <div className="text-center">
          <p className="text-xl text-gray-600 mb-8">Play football with us every week in a friendly, social environment</p>
          <Link to={createPageUrl('SocialGameJoin')}>
            <Button className="bg-red-600 hover:bg-red-700 text-white px-8 py-4">
              Join Social Games
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );

  // Next Match Section - AS Roma Style, renamed to UpcomingMatchesSection
  const UpcomingMatchesSection = () => matches.length > 0 && (
    <section className="py-20 bg-black text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 to-transparent"></div>
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">NEXT MATCH</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>

        <Card className="bg-gradient-to-r from-gray-900 to-black border-red-900/50 max-w-4xl mx-auto">
          <CardContent className="p-12">
            <div className="text-center space-y-8">
              <Badge className="bg-red-600 text-white text-sm px-4 py-2">
                {matches[0].competition || 'LEAGUE MATCH'}
              </Badge>
              
              <div className="flex items-center justify-center space-x-12">
                <div className="text-center">
                  <div className="w-24 h-24 mx-auto bg-white rounded-full flex items-center justify-center mb-4">
                    <span className="text-2xl font-bold text-black">N</span>
                  </div>
                  <div className="text-2xl font-bold">NEPBOURNE FC</div>
                </div>
                
                <div className="text-6xl font-light text-gray-400">VS</div>
                
                <div className="text-center">
                  <div className="w-24 h-24 mx-auto bg-gray-700 rounded-full flex items-center justify-center mb-4">
                    <span className="text-xl font-bold text-white">
                      {matches[0].opponent_name?.charAt(0) || 'O'}
                    </span>
                  </div>
                  <div className="text-2xl font-bold">{matches[0].opponent_name}</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="text-3xl font-bold">
                  {format(new Date(matches[0].match_date), 'EEEE, MMMM d')}
                </div>
                <div className="text-xl text-gray-300">
                  {matches[0].match_time} • {matches[0].is_home_game ? 'Home Ground' : matches[0].venue}
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 px-8">
                  GET TICKETS
                </Button>
                <Link to={createPageUrl('MatchDetail', matches[0].id)}> {/* Link to match detail page */}
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-black px-8">
                    MATCH INFO
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );

  // Club Statistics Section
  const StatsSection = () => {
    const activeTeams = teams.filter(team => team.status === 'active');
    
    return (
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-red-600 mb-2">2025</div>
              <div className="text-gray-600 uppercase tracking-wide">ESTABLISHED</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-red-600 mb-2">{activeTeams.length}</div>
              <div className="text-gray-600 uppercase tracking-wide">TEAMS</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-red-600 mb-2">150+</div>
              <div className="text-gray-600 uppercase tracking-wide">MEMBERS</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-red-600 mb-2">100%</div>
              <div className="text-gray-600 uppercase tracking-wide">PASSION</div>
            </div>
          </div>
        </div>
      </section>
    );
  };

  const TrainingSection = ({ onSessionDoubleClick }) => content?.show_training && trainingEvents.length > 0 && (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">UPCOMING TRAINING</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {trainingEvents.map(session => {
            const coach = members.find(m => m.id === session.coach_id);
            return (
              <Card 
                key={session.id} 
                className="group overflow-hidden hover:shadow-2xl transition-all duration-500 border-0 cursor-pointer"
                onDoubleClick={() => onSessionDoubleClick(session)}
              >
                <div className="relative bg-gradient-to-br from-blue-500 to-blue-600 p-6 text-white">
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-white text-blue-600">Training</Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="text-2xl font-bold">
                      {format(new Date(session.event_date), 'd')}
                    </div>
                    <div className="text-sm opacity-90">
                      {format(new Date(session.event_date), 'MMM yyyy')}
                    </div>
                    <div className="text-sm opacity-90">
                      {format(new Date(session.event_date), 'EEEE')}
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-2 group-hover:text-red-600 transition-colors line-clamp-2">
                    {session.name}
                  </h3>
                  {coach && (
                    <div className="flex items-center text-sm text-gray-700 mb-2">
                      <User className="w-4 h-4 mr-2" />
                      Coach: {coach.first_name} {coach.last_name}
                    </div>
                  )}
                  <div className="space-y-2 text-sm text-gray-600">
                    {session.event_time && (
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-red-600" />
                        {session.event_time}
                        {session.duration_minutes && ` (${session.duration_minutes}m)`}
                      </div>
                    )}
                    {session.venue && (
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2 text-red-600" />
                        {session.venue}
                      </div>
                    )}
                  </div>
                  {session.coach_observations && (
                    <p className="text-gray-600 text-sm mt-3 line-clamp-2">
                      {session.coach_observations}
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600 mb-4">Join us for regular training sessions to improve your skills</p>
          <Link to={createPageUrl('MembershipSignup')}>
            <Button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
              Join Our Club
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );

  // Shop Section
  const ShopSection = () => content.show_merchandise && merchandise.length > 0 && (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-4xl font-bold text-black mb-4">OFFICIAL STORE</h2>
            <div className="h-1 w-16 bg-red-600"></div>
          </div>
          <Link to={createPageUrl('Shop')}>
            <Button variant="outline" className="hidden md:flex border-2 border-black text-black hover:bg-black hover:text-white">
              VIEW ALL PRODUCTS
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {merchandise.slice(0, 4).map(item => (
            <Card key={item.id} className="group overflow-hidden hover:shadow-2xl transition-all duration-500 border-0">
              <div className="relative overflow-hidden">
                {item.image_urls && item.image_urls[0] ? (
                  <img 
                    src={item.image_urls[0]} 
                    alt={item.name} 
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700" 
                  />
                ) : (
                  <div className="h-64 bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center group-hover:scale-110 transition-transform duration-700">
                    <ShoppingCart className="w-16 h-16 text-red-400" /> {/* Changed to ShoppingCart */}
                  </div>
                )}
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg mb-2 group-hover:text-red-600 transition-colors">
                  {item.name}
                </h3>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-xl text-red-600">${item.price_aud}</span>
                  <Link to={createPageUrl('ProductDetail', item.id)}> {/* Added Link to product detail page */}
                    <Button size="sm" className="bg-red-600 hover:bg-red-700">
                      VIEW ITEM
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );

  // Partners Section, renamed to SponsorsSection
  const SponsorsSection = () => content.show_sponsors && (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">OUR PARTNERS</h2>
          <div className="h-1 w-16 bg-red-600 mx-auto"></div>
        </div>

        {sponsors.length > 0 ? (
          <div className="grid grid-cols-3 md:grid-cols-6 gap-8 items-center opacity-60 hover:opacity-100 transition-opacity">
            {sponsors.map(sponsor => (
              <div key={sponsor.id} className="bg-white/5 p-6 rounded-lg hover:bg-white/10 transition-all duration-300 flex items-center justify-center h-20">
                {sponsor.logo_url ? (
                  <img 
                    src={sponsor.logo_url} 
                    alt={sponsor.name} 
                    className="max-h-12 max-w-full object-contain filter brightness-200" 
                  />
                ) : (
                  <span className="text-white font-semibold text-center">{sponsor.name}</span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-400 py-12">
            <p className="text-xl">Partnership opportunities available</p>
          </div>
        )}
        
        <div className="text-center mt-12">
          <Link to={createPageUrl('SponsorshipInquiry')}>
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8">
              BECOME A PARTNER
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen bg-white text-black">
      <HeroSection />
      
      <TrainingSection onSessionDoubleClick={handleSessionDoubleClick} />

      {/* Replaced NextMatchSection with UpcomingMatchesSection */}
      <UpcomingMatchesSection />
      <TeamsSection />
      {/* Replaced PartnersSection with SponsorsSection */}
      <SponsorsSection />
      <ShopSection />
      <SocialGamesSection />

      {/* Detail Modal */}
      {selectedSessionForDetail && (
        <TrainingDetailModal
          session={selectedSessionForDetail}
          teams={teams}
          members={members}
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(false)}
          onRsvpUpdate={handleRsvpUpdate}
        />
      )}
    </div>
  );
}
