
import React, { useState, useEffect } from "react";
import { InventoryItem, InventoryTransaction, FinancialTransaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, Package, AlertTriangle, TrendingDown, TrendingUp, Wrench } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { resetInventory } from "@/api/functions";

import InventoryList from "../components/inventory/InventoryList";
import InventoryForm from "../components/inventory/InventoryForm";
import InventoryStats from "../components/inventory/InventoryStats";
import InventoryTransactions from "../components/inventory/InventoryTransactions";
import InventoryDetailModal from "../components/inventory/InventoryDetailModal"; // Import the new modal

export default function Inventory() {
  const [items, setItems] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isResetting, setIsResetting] = useState(false); // New state for reset
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterCondition, setFilterCondition] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [activeTab, setActiveTab] = useState("items");
  const [showDetailModal, setShowDetailModal] = useState(false); // State for modal
  const [selectedItem, setSelectedItem] = useState(null); // State for modal's item

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [itemsData, transactionsData] = await Promise.all([
        InventoryItem.list("-created_date"),
        InventoryTransaction.list("-created_date", 50)
      ]);
      setItems(itemsData);
      setTransactions(transactionsData);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleItemSubmit = async (itemData) => {
    try {
      if (editingItem) {
        await InventoryItem.update(editingItem.id, itemData);
      } else {
        const newItem = await InventoryItem.create(itemData);
        
        // Create initial stock transaction if quantity > 0
        if (itemData.quantity_on_hand > 0) {
          await InventoryTransaction.create({
            item_id: newItem.id,
            transaction_type: "Initial Stock",
            quantity_change: itemData.quantity_on_hand,
            reason: `Initial stock entry - Invoice: ${itemData.invoice_number || 'N/A'}`
          });
        }
      }
      setShowForm(false);
      setEditingItem(null);
      loadData();
    } catch (error) {
      console.error("Error saving item:", error);
    }
  };

  const handleStockAdjustment = async (itemId, quantityChange, reason) => {
    try {
      const item = items.find(i => i.id === itemId);
      const newQuantity = item.quantity_on_hand + quantityChange;
      
      await InventoryItem.update(itemId, {
        quantity_on_hand: Math.max(0, newQuantity)
      });
      
      await InventoryTransaction.create({
        item_id: itemId,
        transaction_type: "Adjustment",
        quantity_change: quantityChange,
        reason: reason
      });
      
      loadData();
    } catch (error) {
      console.error("Error adjusting stock:", error);
    }
  };

  const handleEditItem = (item) => {
    setEditingItem(item);
    setShowForm(true);
  };

  const handleDeleteItem = async (itemId) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      try {
        await InventoryItem.delete(itemId);
        loadData();
      } catch (error) {
        console.error("Error deleting item:", error);
      }
    }
  };
  
  const handleItemDoubleClick = (item) => {
    setSelectedItem(item);
    setShowDetailModal(true);
  };

  const handleResetInventory = async () => {
    setIsResetting(true);
    try {
      await resetInventory();
      toast.success("All inventory items have been reset to their original quantities.");
      loadData(); // Reload to show the changes
    } catch (error) {
      console.error("Error resetting inventory:", error);
      toast.error("Failed to reset inventory. Please try again.");
    } finally {
      setIsResetting(false);
    }
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = searchTerm === "" || 
      item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.sku?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = filterCategory === "all" || item.category === filterCategory;
    const matchesCondition = filterCondition === "all" || item.condition === filterCondition;

    return matchesSearch && matchesCategory && matchesCondition;
  });

  const lowStockItems = items.filter(item => 
    item.quantity_on_hand <= item.minimum_level && item.minimum_level > 0
  );

  return (
    <div className="p-4 space-y-4 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-3">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 mb-1">Inventory Management</h1>
            <p className="text-slate-600 text-sm">Track and manage all club equipment and supplies.</p>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="flex-1 md:flex-none">
                  <Wrench className="w-4 h-4 mr-2" />
                  Reset to Original
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Reset All Inventory to Original State?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action will reset all inventory items back to their original quantities when they were first added to the system. All current stock levels, allocations, and damage counts will be restored to their initial values. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleResetInventory} disabled={isResetting} className="bg-red-600 hover:bg-red-700">
                    {isResetting ? 'Resetting...' : 'Yes, Reset to Original'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            
            <Button
              variant="outline"
              size="sm"
              className="flex-1 md:flex-none"
              onClick={() => setActiveTab(activeTab === "items" ? "transactions" : "items")}
            >
              <Package className="w-4 h-4 mr-2" />
              {activeTab === "items" ? "View Transactions" : "View Items"}
            </Button>
            <Button 
              onClick={() => {
                setEditingItem(null);
                setShowForm(true);
              }}
              size="sm"
              className="flex-1 md:flex-none bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Item
            </Button>
          </div>
        </div>

        {/* Stats */}
        <InventoryStats items={items} transactions={transactions} loading={loading} />

        {/* Low Stock Alert */}
        {lowStockItems.length > 0 && (
          <Card className="bg-amber-50/80 border-amber-200 mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-amber-800 text-base">
                <AlertTriangle className="w-4 h-4" />
                Low Stock Alert ({lowStockItems.length} items)
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-1">
                {lowStockItems.map(item => (
                  <div key={item.id} className="flex justify-between items-center text-sm">
                    <span className="text-amber-800">{item.name}</span>
                    <span className="text-amber-700">
                      {item.quantity_on_hand} remaining (min: {item.minimum_level})
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Search and Filters */}
        {activeTab === "items" && (
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-4">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search items by name or SKU..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 h-9"
                  />
                </div>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-9 text-sm"
                >
                  <option value="all">All Categories</option>
                  <option value="Ball">Balls</option>
                  <option value="Bibs">Bibs</option>
                  <option value="Cones">Cones</option>
                  <option value="Kits">Kits</option>
                  <option value="Medical">Medical</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Other">Other</option>
                </select>
                <select
                  value={filterCondition}
                  onChange={(e) => setFilterCondition(e.target.value)}
                  className="px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-9 text-sm"
                >
                  <option value="all">All Conditions</option>
                  <option value="New">New</option>
                  <option value="Good">Good</option>
                  <option value="Fair">Fair</option>
                  <option value="Poor">Poor</option>
                  <option value="Damaged">Damaged</option>
                </select>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Item Form */}
        {showForm && (
          <InventoryForm
            item={editingItem}
            onSubmit={handleItemSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingItem(null);
            }}
          />
        )}

        {/* Content */}
        {activeTab === "items" ? (
          <InventoryList
            items={filteredItems}
            loading={loading}
            onEditItem={handleEditItem}
            onDeleteItem={handleDeleteItem}
            onStockAdjustment={handleStockAdjustment}
            onItemDoubleClick={handleItemDoubleClick} // Pass handler
          />
        ) : (
          <InventoryTransactions
            transactions={transactions}
            items={items}
            loading={loading}
          />
        )}
      </div>
      
      {/* Detail Modal */}
      {selectedItem && (
        <InventoryDetailModal
            item={selectedItem}
            isOpen={showDetailModal}
            onClose={() => {
                setShowDetailModal(false);
                setSelectedItem(null);
                loadData(); // Reload data when modal closes to reflect changes
            }}
        />
      )}
    </div>
  );
}
