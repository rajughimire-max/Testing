
import React, { useState, useEffect } from 'react';
import { MerchandiseItem } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, X, Plus, Minus, Star } from 'lucide-react';
import { createPaymentSession } from '@/api/functions';
import { redirectToStripeCheckout } from '../components/stripe/StripeLoader';

export default function ShopPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const loadMerchandise = async () => {
      try {
        const merchItems = await MerchandiseItem.list('sort_order', 100);
        setItems(merchItems.filter(item => item.is_active));
      } catch (error) {
        console.error("Error loading merchandise:", error);
      } finally {
        setLoading(false);
      }
    };
    loadMerchandise();
  }, []);

  const categories = ['all', 'jerseys', 'training_gear', 'accessories', 'supporters_gear', 'equipment'];
  const filteredItems = selectedCategory === 'all' ? items : items.filter(item => item.category === selectedCategory);

  const addToCart = (item) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.id === item.id);
      if (existingItem) {
        return prevCart.map(cartItem =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem
        );
      }
      return [...prevCart, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (itemId) => {
    setCart(prevCart => prevCart.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId, amount) => {
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === itemId ? { ...item, quantity: Math.max(1, item.quantity + amount) } : item
      ).filter(item => item.quantity > 0)
    );
  };
  
  const handleCheckout = async () => {
    if (cart.length === 0) return;
    
    setIsProcessing(true);
    try {
      const line_items = cart.map(item => ({
        price: item.stripe_price_id,
        quantity: item.quantity
      }));

      const { data: session } = await createPaymentSession({ line_items });

      if (session && session.id) {
        await redirectToStripeCheckout({ sessionId: session.id, checkoutUrl: session.url });
      } else {
        alert("Could not create a checkout session. Please try again.");
      }
    } catch (error) {
      console.error("Checkout error:", error);
      alert("An error occurred during checkout. Please ensure all items have valid Stripe price IDs and try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const cartTotal = cart.reduce((total, item) => total + item.price_aud * item.quantity, 0);
  const cartItemCount = cart.reduce((count, item) => count + item.quantity, 0);

  const ProductCard = ({ item }) => (
    <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow group">
      <div className="aspect-square bg-slate-100 overflow-hidden relative">
        {item.image_urls && item.image_urls[0] ? (
          <img 
            src={item.image_urls[0]} 
            alt={item.name} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-slate-200 text-slate-400">
            No Image
          </div>
        )}
        <div className="absolute top-4 right-4">
          <Badge className="bg-red-600 text-white capitalize">
            {item.category.replace('_', ' ')}
          </Badge>
        </div>
        {item.stock_quantity <= 5 && item.stock_quantity > 0 && (
          <div className="absolute bottom-4 left-4">
            <Badge variant="outline" className="bg-white/90">
              Only {item.stock_quantity} left
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="p-6">
        <h3 className="font-bold text-lg text-slate-800 mb-2">{item.name}</h3>
        <p className="text-sm text-slate-500 mb-4 h-12 overflow-hidden">{item.description}</p>
        
        {/* Sizes and Colors */}
        <div className="space-y-2 mb-4">
          {item.sizes_available && item.sizes_available.length > 0 && (
            <div>
              <span className="text-xs text-slate-600">Sizes: </span>
              <span className="text-xs text-slate-800">{item.sizes_available.join(', ')}</span>
            </div>
          )}
          {item.colors_available && item.colors_available.length > 0 && (
            <div>
              <span className="text-xs text-slate-600">Colors: </span>
              <span className="text-xs text-slate-800">{item.colors_available.join(', ')}</span>
            </div>
          )}
        </div>
        
        <div className="flex justify-between items-center">
          <p className="text-xl font-extrabold text-slate-900">${item.price_aud.toFixed(2)}</p>
          <Button 
            onClick={() => addToCart(item)}
            disabled={item.stock_quantity === 0}
            className={item.stock_quantity === 0 ? "bg-slate-400" : "bg-red-600 hover:bg-red-700"}
          >
            {item.stock_quantity === 0 ? 'Out of Stock' : 'Add to Cart'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="text-center mb-16">
            <Skeleton className="h-16 w-96 mx-auto mb-6" />
            <Skeleton className="h-6 w-[32rem] mx-auto" /> {/* Changed w-128 to w-[32rem] for Tailwind JIT */}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {Array(8).fill(0).map((_, i) => <Skeleton key={i} className="h-96 rounded-2xl" />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative py-32 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-blue-600/20"></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-7xl font-black text-white tracking-tight leading-none">
              CLUB STORE
            </h1>
            <div className="h-2 w-32 bg-red-600 mx-auto"></div>
            <p className="text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
              Show your club pride with official Nepbourne FC merchandise
            </p>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-red-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-24">
        {/* Header with Cart */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 gap-6">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">Official Merchandise</h2>
            <p className="text-slate-600 text-lg">Premium quality gear for true supporters</p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => setIsCartOpen(true)} 
            className="relative bg-white/80 backdrop-blur-sm hover:bg-white shadow-lg border-0 px-8 py-4"
          >
            <ShoppingCart className="w-5 h-5 mr-2" />
            Cart ({cartItemCount})
            {cartItemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
                {cartItemCount}
              </span>
            )}
          </Button>
        </div>

        {/* Category Filter */}
        <div className="mb-12">
          <div className="bg-white/80 backdrop-blur-sm p-4 rounded-2xl shadow-lg">
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map(category => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                    selectedCategory === category 
                      ? "bg-red-600 hover:bg-red-700 text-white shadow-lg" 
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  {category === 'all' ? 'All Products' : category.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Products Grid */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredItems.map((item, index) => (
              <div
                key={item.id}
                className="animate-in fade-in slide-in-from-bottom-4 duration-500"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <ProductCard item={item} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <div className="max-w-md mx-auto">
              <div className="w-32 h-32 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-8">
                <ShoppingCart className="w-16 h-16 text-slate-400" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">No Products Found</h3>
              <p className="text-slate-600 text-lg leading-relaxed">
                {selectedCategory === 'all' 
                  ? 'Products will appear here once they are added to the store.'
                  : `No products found in the ${selectedCategory.replace('_', ' ')} category.`
                }
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Shopping Cart Modal */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black/50 z-50" onClick={() => setIsCartOpen(false)}>
          <div 
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-xl font-bold">Your Cart</h2>
              <Button variant="ghost" size="icon" onClick={() => setIsCartOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">Your cart is empty.</p>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="flex gap-4 p-4 bg-slate-50 rounded-lg">
                    {item.image_urls && item.image_urls[0] && (
                      <img 
                        src={item.image_urls[0]} 
                        alt={item.name} 
                        className="h-16 w-16 object-cover rounded-md"
                      />
                    )}
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm">{item.name}</h4>
                      <p className="text-sm text-slate-500">${item.price_aud.toFixed(2)} each</p>
                      <div className="flex items-center mt-2 gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => updateQuantity(item.id, -1)}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="px-3 py-1 bg-white border rounded text-sm font-semibold">
                          {item.quantity}
                        </span>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => updateQuantity(item.id, 1)}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-col justify-between items-end">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeFromCart(item.id)}
                      >
                        <X className="h-4 w-4 text-slate-500 hover:text-red-500" />
                      </Button>
                      <p className="font-semibold">${(item.price_aud * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            
            {cart.length > 0 && (
              <div className="p-6 border-t">
                <div className="flex justify-between items-center font-bold text-lg mb-4">
                  <span>Total</span>
                  <span>${cartTotal.toFixed(2)} AUD</span>
                </div>
                <Button 
                  className="w-full bg-red-600 hover:bg-red-700" 
                  size="lg" 
                  onClick={handleCheckout} 
                  disabled={isProcessing}
                >
                  {isProcessing ? 'Processing...' : 'Proceed to Checkout'}
                </Button>
                <p className="text-xs text-center text-slate-500 mt-2">
                  Secure checkout powered by Stripe
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
