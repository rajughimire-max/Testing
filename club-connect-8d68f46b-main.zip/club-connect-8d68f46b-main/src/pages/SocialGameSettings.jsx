
import React, { useState, useEffect } from 'react';
import { Event, SocialGameSettings, SocialGameSignup, GameAttendance } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Save, Calendar, Clock, MapPin, Edit, Trash2, RefreshCw, Plus, Users } from 'lucide-react';
import { updateSocialGameEvents, linkTodaysSignupsToSundayGame } from '@/api/functions';
import { toast } from 'sonner';
import { format, parseISO, isBefore, isAfter } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EventForm from '../components/events/EventForm';
import GameAttendeesModal from '../components/social_games/GameAttendeesModal';

export default function SocialGameSettingsPage() {
  const [settings, setSettings] = useState(null);
  const [allGames, setAllGames] = useState([]);
  const [socialGameSignups, setSocialGameSignups] = useState([]);
  const [gameAttendances, setGameAttendances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [editingGame, setEditingGame] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [attendeesModalOpen, setAttendeesModalOpen] = useState(false);
  const [selectedGameForAttendees, setSelectedGameForAttendees] = useState(null);
  const [linkingSignups, setLinkingSignups] = useState(false); // New state for linking signups

  useEffect(() => {
    loadAllData();
  }, []);
  
  const loadAllData = async () => {
    setLoading(true);
    try {
      const [settingsData, gamesData, signupsData, attendanceData] = await Promise.all([
        SocialGameSettings.list(),
        Event.filter({ is_social_game: true }, '-event_date'),
        SocialGameSignup.list('-created_date'),
        GameAttendance.list(),
      ]);

      if (settingsData.length > 0) {
        setSettings(settingsData[0]);
      } else {
        // Initialize new settings with default values for new fields
        const newSettings = await SocialGameSettings.create({ 
          is_enabled: true, 
          enable_recurring: false,
          weekday: 'Sunday', // Default weekday
          start_time: '10:00', // Default start time
          end_time: '12:00', // Default end time
          location: 'Main Pitch', // Default location
          recurrence_end_condition: 'occurrences', // Default to occurrences
          number_of_occurrences: 12, // Default number of occurrences
          recurrence_end_date: null // Default end date
        });
        setSettings(newSettings);
      }
      
      // Sort games by date - MOST RECENT FIRST (descending order)
      const sortedGames = gamesData.sort((a, b) => new Date(b.event_date) - new Date(a.event_date));
      setAllGames(sortedGames);
      setSocialGameSignups(signupsData);
      setGameAttendances(attendanceData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load settings and games.");
    } finally {
      setLoading(false);
    }
  }

  const handleChange = (field, value) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      await SocialGameSettings.update(settings.id, settings);
      toast.success("Settings saved successfully!");
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error("Failed to save settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleSyncEvents = async () => {
    setSyncing(true);
    try {
      // First, save the current settings to the database.
      // This ensures the backend function reads the most up-to-date configuration.
      toast.info("Saving latest settings...");
      await SocialGameSettings.update(settings.id, settings);
      toast.success("Settings saved. Now generating games...");

      // Now, call the function to generate events.
      const response = await updateSocialGameEvents();
      if (response.data.success) {
        toast.success(response.data.message);
        await loadAllData();
      } else {
        toast.error(response.data.error || "Syncing failed.");
      }
    } catch (error) {
      console.error("Error syncing events:", error);
      toast.error("An error occurred while syncing events.");
    } finally {
      setSyncing(false);
    }
  };

  const handleEditGame = (game) => {
    setEditingGame(game);
    setShowForm(true);
  };

  const handleDeleteGame = async (gameId) => {
    if (window.confirm("Are you sure you want to delete this social game? This action cannot be undone.")) {
      try {
        await Event.delete(gameId);
        toast.success("Game deleted successfully.");
        loadAllData();
      } catch(error) {
        toast.error("Failed to delete game.");
        console.error("Error deleting game:", error);
      }
    }
  };

  const handleFormSubmit = async (formData) => {
    const dataToSave = { ...formData, is_social_game: true, event_type: 'social' };
    try {
      if (editingGame) {
        await Event.update(editingGame.id, dataToSave);
        toast.success("Social game updated!");
      } else {
        await Event.create(dataToSave);
        toast.success("Social game created!");
      }
      setShowForm(false);
      setEditingGame(null);
      loadAllData();
    } catch (error) {
      console.error("Error saving social game:", error);
      toast.error("Failed to save game.");
    }
  };

  const handleViewAttendees = (game) => {
    setSelectedGameForAttendees(game);
    setAttendeesModalOpen(true);
  };

  // Add function to link today's signups
  const handleLinkTodaysSignups = async () => {
    setLinkingSignups(true);
    try {
      const response = await linkTodaysSignupsToSundayGame();
      if (response.data.success) {
        toast.success(response.data.message);
        loadAllData(); // Refresh data
      } else {
        toast.error(response.data.error || "Failed to link signups");
      }
    } catch (error) {
      console.error("Error linking signups:", error);
      toast.error("Failed to link today's signups.");
    } finally {
      setLinkingSignups(false);
    }
  };
  
  // Helper functions to check game status based on end time
  const isGameCompleted = (game) => {
    const now = new Date();
    // Assuming game.event_date is 'YYYY-MM-DD' and game.end_time is 'HH:MM'
    const gameEndDateTime = new Date(`${game.event_date}T${game.end_time}:00`);
    return gameEndDateTime <= now;
  };

  const isGameUpcoming = (game) => {
    const now = new Date();
    const gameEndDateTime = new Date(`${game.event_date}T${game.end_time}:00`);
    return gameEndDateTime > now;
  };

  const upcomingGames = allGames.filter(g => isGameUpcoming(g));
  const completedGames = allGames.filter(g => isGameCompleted(g));

  // Group signups by skills level
  const signupsBySkill = socialGameSignups.reduce((acc, signup) => {
    const level = signup.skills_level || 'Unknown';
    if (!acc[level]) acc[level] = [];
    acc[level].push(signup);
    return acc;
  }, {});

  const getSkillLevelColor = (level) => {
    const colors = {
      'Beginner': 'bg-green-100 text-green-800',
      'Intermediate': 'bg-yellow-100 text-yellow-800', 
      'Advanced': 'bg-red-100 text-red-800',
      'Unknown': 'bg-gray-100 text-gray-800'
    };
    return colors[level] || colors['Unknown'];
  };

  if (loading) return <div>Loading settings...</div>;

  const renderGameCard = (game) => {
    const attendeesCount = gameAttendances.filter(a => a.event_id === game.id).length;
    const isCompleted = isGameCompleted(game);
    const isUpcoming = isGameUpcoming(game);
    
    return (
        <Card key={game.id} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
        <CardContent className="p-4">
            <div className="flex justify-between items-start">
            <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h4 className={`font-semibold ${isCompleted ? 'text-slate-500' : 'text-slate-900'}`}>{game.title}</h4>
                  {isCompleted && <Badge className="bg-gray-500 text-white text-xs">Completed</Badge>}
                  {isUpcoming && <Badge className="bg-green-500 text-white text-xs">Upcoming</Badge>}
                  {!isCompleted && !isUpcoming && <Badge className="bg-orange-500 text-white text-xs">In Progress</Badge>}
                </div>
                <div className={`flex items-center text-sm gap-4 flex-wrap ${isCompleted ? 'text-slate-400' : 'text-slate-600'}`}>
                  <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> {format(parseISO(game.event_date), 'EEE, d MMM yyyy')}</span>
                  <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" /> {game.start_time} - {game.end_time}</span>
                  <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /> {game.venue}</span>
                </div>
                {game.description && <p className={`text-sm pt-1 ${isCompleted ? 'text-slate-400' : 'text-slate-500'}`}>{game.description}</p>}
            </div>
            <div className="flex flex-col space-y-2 items-end">
                <Button size="sm" variant="outline" onClick={() => handleViewAttendees(game)}>
                    <Users className="w-3 h-3 mr-2" /> View Participants ({attendeesCount})
                </Button>
                <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEditGame(game)}><Edit className="w-3 h-3 mr-1" /> Edit</Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteGame(game.id)}><Trash2 className="w-3 h-3 mr-1" /> Delete</Button>
                </div>
            </div>
            </div>
        </CardContent>
        </Card>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Social Games Management</h1>
          <p className="text-slate-600">Manage settings and events for the weekly social games.</p>
        </div>

        {/* Add button to link today's signups */}
        <Card className="bg-white/80 backdrop-blur-sm mb-6">
          <CardHeader>
            <CardTitle>Link Today's Social Game Signups</CardTitle>
            <CardDescription>Connect today's social game signups to the Sunday Fun Day event</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={handleLinkTodaysSignups} disabled={linkingSignups} className="bg-green-600 hover:bg-green-700">
              {linkingSignups ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Linking...
                </>
              ) : (
                <>
                  <Users className="w-4 h-4 mr-2" />
                  Link Today's Signups to Sunday Fun Day
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {showForm && (
          <div className="mb-6">
            <EventForm
              event={editingGame}
              onSubmit={handleFormSubmit}
              onCancel={() => { setShowForm(false); setEditingGame(null); }}
              eventType="social"
            />
          </div>
        )}

        <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                <div className="flex justify-between items-center">
                    <div>
                    <CardTitle>Scheduled Social Games</CardTitle>
                    <CardDescription>Manually add, view, edit, or delete scheduled games.</CardDescription>
                    </div>
                    <Button onClick={() => { setEditingGame(null); setShowForm(true); }}>
                    <Plus className="w-4 h-4 mr-2" /> Add Single Game
                    </Button>
                </div>
                </CardHeader>
                <CardContent>
                <Tabs defaultValue="upcoming">
                    <TabsList>
                    <TabsTrigger value="upcoming">Upcoming ({upcomingGames.length})</TabsTrigger>
                    <TabsTrigger value="completed">Completed ({completedGames.length})</TabsTrigger>
                    <TabsTrigger value="all">All ({allGames.length})</TabsTrigger>
                    </TabsList>
                    <TabsContent value="upcoming" className="pt-4 space-y-4">
                    {upcomingGames.length > 0 ? upcomingGames.map(renderGameCard) : <p className="text-slate-500 text-center py-8">No upcoming games scheduled.</p>}
                    </TabsContent>
                    <TabsContent value="completed" className="pt-4 space-y-4">
                    {completedGames.length > 0 ? completedGames.map(renderGameCard) : <p className="text-slate-500 text-center py-8">No completed games.</p>}
                    </TabsContent>
                    <TabsContent value="all" className="pt-4 space-y-4">
                    {allGames.length > 0 ? allGames.map(renderGameCard) : <p className="text-slate-500 text-center py-8">No games scheduled.</p>}
                    </TabsContent>
                </Tabs>
                </CardContent>
            </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Recurrence Settings</CardTitle>
              <CardDescription>Optionally, generate games automatically based on a schedule.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <Label htmlFor="enableRecurring" className="flex-grow">Enable Recurring Game Generation</Label>
                <Switch
                  id="enableRecurring"
                  checked={settings?.enable_recurring || false}
                  onCheckedChange={(checked) => handleChange('enable_recurring', checked)}
                />
              </div>

              {settings?.enable_recurring && (
                <div className="space-y-4 pt-4 border-t">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Day of the Week</Label>
                      <select
                        value={settings.weekday || 'Sunday'} // Default to Sunday if not set
                        onChange={e => handleChange('weekday', e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                      </select>
                    </div>
                    <div>
                      <Label>Location</Label>
                      <Input 
                        value={settings.location || ''} 
                        onChange={e => handleChange('location', e.target.value)} 
                        placeholder="Club Main Pitch"
                      />
                    </div>
                    <div>
                      <Label>Start Time</Label>
                      <Input 
                        type="time" 
                        value={settings.start_time || ''} 
                        onChange={e => handleChange('start_time', e.target.value)} 
                      />
                    </div>
                    <div>
                      <Label>End Time</Label>
                      <Input 
                        type="time" 
                        value={settings.end_time || ''} 
                        onChange={e => handleChange('end_time', e.target.value)} 
                      />
                    </div>
                  </div>

                  {/* New Recurrence End Condition Section */}
                  <div className="pt-4 border-t">
                    <Label className="text-base font-semibold mb-3 block">Generation End Condition</Label>
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* End by Date Option */}
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <input
                            type="radio"
                            id="end_by_date"
                            name="end_condition"
                            value="end_date"
                            checked={settings.recurrence_end_condition === 'end_date'}
                            onChange={() => handleChange('recurrence_end_condition', 'end_date')}
                            className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                          />
                          <Label htmlFor="end_by_date" className="font-medium">End by Date</Label>
                        </div>
                        <div className="ml-6">
                          <Input
                            type="date"
                            value={settings.recurrence_end_date || ''}
                            onChange={e => handleChange('recurrence_end_date', e.target.value)}
                            disabled={settings.recurrence_end_condition !== 'end_date'}
                            className={settings.recurrence_end_condition !== 'end_date' ? 'bg-slate-100' : ''}
                          />
                          <p className="text-xs text-slate-500 mt-1">Generate games until this date</p>
                        </div>
                      </div>

                      {/* End by Number of Occurrences Option */}
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <input
                            type="radio"
                            id="end_by_count"
                            name="end_condition"
                            value="occurrences"
                            checked={settings.recurrence_end_condition === 'occurrences' || !settings.recurrence_end_condition} // Default to occurrences
                            onChange={() => handleChange('recurrence_end_condition', 'occurrences')}
                            className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                          />
                          <Label htmlFor="end_by_count" className="font-medium">Generate Fixed Number</Label>
                        </div>
                        <div className="ml-6">
                          <Input
                            type="number"
                            min="1"
                            max="52"
                            value={settings.number_of_occurrences || 12}
                            onChange={e => handleChange('number_of_occurrences', parseInt(e.target.value))}
                            disabled={settings.recurrence_end_condition === 'end_date'}
                            className={settings.recurrence_end_condition === 'end_date' ? 'bg-slate-100' : ''}
                          />
                          <p className="text-xs text-slate-500 mt-1">Number of games to create (1-52)</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <Button onClick={handleSyncEvents} disabled={syncing}>
                      <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
                      {syncing ? 'Generating...' : 'Generate Games'}
                    </Button>
                    <Button onClick={handleSaveSettings} disabled={saving} variant="outline">
                      <Save className="w-4 h-4 mr-2" />
                      {saving ? 'Saving...' : 'Save Settings'}
                    </Button>
                  </div>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-xs text-blue-700">
                      <strong>Note:</strong> Clicking "Generate Games" will create new game entries based on your settings. 
                      {settings.recurrence_end_condition === 'end_date' 
                        ? ` Games will be created until ${settings.recurrence_end_date ? format(new Date(settings.recurrence_end_date), 'd MMM yyyy') : 'the specified end date'}.`
                        : ` ${settings.number_of_occurrences || 12} games will be created.`
                      }
                      These can be edited or deleted individually after creation.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {selectedGameForAttendees && (
        <GameAttendeesModal
            isOpen={attendeesModalOpen}
            onClose={() => setAttendeesModalOpen(false)}
            game={selectedGameForAttendees}
            allSignups={socialGameSignups}
            allAttendances={gameAttendances}
        />
      )}
    </div>
  );
}
