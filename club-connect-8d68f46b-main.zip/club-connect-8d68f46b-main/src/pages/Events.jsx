
import React, { useState, useEffect } from "react";
import { Event } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Download, Calendar as CalendarIcon, Ticket, UserPlus } from "lucide-react";
import EventList from "../components/events/EventList";
import EventForm from "../components/events/EventForm";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, parseISO, isAfter } from "date-fns";
import { createPageUrl } from '@/utils';
import { Link } from "react-router-dom";
import { autoCreateNotifications } from '@/api/functions';

export default function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Fetch all events
      const allEvents = await Event.list("-event_date");
      // Filter out training and match events, showing only general/social etc.
      const generalEvents = allEvents.filter(e => e.event_type !== 'training' && e.event_type !== 'match');
      setEvents(generalEvents);
    } catch (error) {
      console.error("Error loading events:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEventSubmit = async (eventData) => {
    try {
      let savedEvent;
      if (editingEvent) {
        savedEvent = await Event.update(editingEvent.id, eventData);
        // Send notification for updated event
        try {
          await autoCreateNotifications({
            entityType: 'Event',
            entityId: editingEvent.id,
            action: 'updated'
          });
        } catch (notificationError) {
          console.error('Failed to send notifications for updated event:', notificationError);
        }
      } else {
        savedEvent = await Event.create(eventData);
        // Send notification for new event
        try {
          await autoCreateNotifications({
            entityType: 'Event',
            entityId: savedEvent.id,
            action: 'created'
          });
        } catch (notificationError) {
          console.error('Failed to send notifications for new event:', notificationError);
        }
      }
      setShowForm(false);
      setEditingEvent(null);
      loadData();
    } catch (error) {
      console.error("Error saving event:", error);
    }
  };

  const handleEditEvent = (event) => {
    setEditingEvent(event);
    setShowForm(true);
  };
  
  const handleDeleteEvent = async (id) => {
    if (window.confirm("Are you sure you want to delete this event?")) {
      try {
        await Event.delete(id);
        // Remove from local state immediately
        setEvents(prevEvents => prevEvents.filter(event => event.id !== id));
      } catch (error) {
        console.error("Error deleting event:", error);
        
        // Handle "not found" errors gracefully
        if (error.message?.includes('Object not found') || error.response?.status === 404) {
          setEvents(prevEvents => prevEvents.filter(event => event.id !== id));
          alert("This event has already been deleted. Refreshing the list...");
        } else {
          alert("Failed to delete event. Please try again or refresh the page.");
        }
        
        // Reload data to sync with database
        loadData();
      }
    }
  };

  const generateICS = (event) => {
    const formatICSDate = (date, time) => {
      const d = new Date(`${date}T${time}`);
      return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    }
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//NepbourneFC//NONSGML v1.0//EN',
      'BEGIN:VEVENT',
      `UID:${event.id}@nepbournefc.com`,
      `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'}`,
      `DTSTART:${formatICSDate(event.event_date, event.start_time)}`,
      `DTEND:${formatICSDate(event.event_date, event.end_time)}`,
      `SUMMARY:${event.title}`,
      `DESCRIPTION:${event.description || ''}`,
      `LOCATION:${event.venue || ''}`,
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\n');
    
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${event.title.replace(/ /g, '_')}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Events</h1>
            <p className="text-slate-600">Manage club gatherings, meetings, and social events.</p>
          </div>
          <Button onClick={() => { setEditingEvent(null); setShowForm(true); }} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Event
          </Button>
        </div>

        {showForm && (
          <EventForm
            event={editingEvent}
            onSubmit={handleEventSubmit}
            onCancel={() => { setShowForm(false); setEditingEvent(null); }}
            eventType="general"
          />
        )}

        <EventList events={events} loading={loading} onEdit={handleEditEvent} onDelete={handleDeleteEvent} onDownloadICS={generateICS}/>
      </div>
    </div>
  );
}
