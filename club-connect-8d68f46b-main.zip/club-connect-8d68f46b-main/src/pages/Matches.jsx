
import React, { useState, useEffect } from "react";
import { Match, Team, TournamentType, Player } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import MatchList from "../components/matches/MatchList";
import MatchForm from "../components/matches/MatchForm";
import MatchStats from "../components/matches/MatchStats";
import { autoCreateNotifications } from '@/api/functions';

export default function Matches() {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState([]);
  const [tournamentTypes, setTournamentTypes] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingMatch, setEditingMatch] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterTeam, setFilterTeam] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [matchesData, teamsData, tournamentTypesData, playersData] = await Promise.all([
        Match.list("-match_date"),
        Team.list(),
        TournamentType.list(),
        Player.list()
      ]);
      setMatches(matchesData);
      setTeams(teamsData);
      setTournamentTypes(tournamentTypesData);
      setPlayers(playersData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleMatchSubmit = async (matchData) => {
    try {
      let savedMatch;
      if (editingMatch) {
        savedMatch = await Match.update(editingMatch.id, matchData);
        // Send notification for updated match
        try {
          await autoCreateNotifications({
            entityType: 'Match',
            entityId: editingMatch.id,
            action: 'updated'
          });
        } catch (notificationError) {
          console.error('Failed to send notifications:', notificationError);
        }
      } else {
        savedMatch = await Match.create(matchData);
        // Send notification for new match
        try {
          await autoCreateNotifications({
            entityType: 'Match',
            entityId: savedMatch.id,
            action: 'created'
          });
        } catch (notificationError) {
          console.error('Failed to send notifications:', notificationError);
        }
      }
      setShowForm(false);
      setEditingMatch(null);
      loadData();
    } catch (error) {
      console.error("Error saving match:", error);
    }
  };

  const handleUpdateResults = async (matchId, resultsData) => {
    try {
      await Match.update(matchId, resultsData);
      loadData();
    } catch (error) {
      console.error("Error updating match results:", error);
    }
  };

  const handleEditMatch = (match) => {
    setEditingMatch(match);
    setShowForm(true);
  };
  
  const handleDeleteMatch = async (id) => {
    if (window.confirm("Are you sure you want to delete this match?")) {
      try {
        await Match.delete(id);
        // Remove the match from local state immediately to prevent UI issues
        setMatches(prevMatches => prevMatches.filter(match => match.id !== id));
      } catch (error) {
        console.error("Error deleting match:", error);
        
        // If the match doesn't exist, just remove it from the UI
        if (error.message?.includes('Object not found') || error.response?.status === 404) {
          setMatches(prevMatches => prevMatches.filter(match => match.id !== id));
          alert("This match has already been deleted. Refreshing the list...");
        } else {
          // For other errors, show a proper error message
          alert("Failed to delete match. Please try again or refresh the page.");
        }
        
        // Reload data to sync with database
        loadData();
      }
    }
  };

  const filteredMatches = matches.filter(match => {
    const matchesSearch = searchTerm === "" || 
      match.opponent_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teams.find(t => t.id === match.team_id)?.name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || match.match_status === filterStatus;
    const matchesTeam = filterTeam === "all" || match.team_id === filterTeam;

    return matchesSearch && matchesStatus && matchesTeam;
  });

  const upcomingMatches = filteredMatches.filter(m => new Date(m.match_date) >= new Date() && m.match_status === 'scheduled');
  const completedMatches = filteredMatches.filter(m => m.match_status === 'completed');

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Matches</h1>
            <p className="text-slate-600">Track upcoming and past game results.</p>
          </div>
          <Button onClick={() => { setEditingMatch(null); setShowForm(true); }} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Match
          </Button>
        </div>

        <MatchStats matches={matches} loading={loading} />

        {/* Search and Filters */}
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search matches by opponent or team..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-md"
              >
                <option value="all">All Status</option>
                <option value="scheduled">Scheduled</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
              <select
                value={filterTeam}
                onChange={(e) => setFilterTeam(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-md"
              >
                <option value="all">All Teams</option>
                {teams.map(team => (
                  <option key={team.id} value={team.id}>{team.name}</option>
                ))}
              </select>
            </div>
          </CardContent>
        </Card>

        {showForm && (
          <MatchForm
            match={editingMatch}
            teams={teams}
            tournamentTypes={tournamentTypes}
            players={players}
            onSubmit={handleMatchSubmit}
            onCancel={() => { setShowForm(false); setEditingMatch(null); }}
          />
        )}

        <MatchList 
          matches={filteredMatches}
          upcomingMatches={upcomingMatches}
          completedMatches={completedMatches}
          teams={teams}
          tournamentTypes={tournamentTypes}
          players={players}
          loading={loading} 
          onEdit={handleEditMatch} 
          onDelete={handleDeleteMatch}
          onUpdateResults={handleUpdateResults}
        />
      </div>
    </div>
  );
}
