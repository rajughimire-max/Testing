import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Members from "./Members";

import Teams from "./Teams";

import Inventory from "./Inventory";

import Matches from "./Matches";

import Events from "./Events";

import Training from "./Training";

import Sponsorship from "./Sponsorship";

import Finance from "./Finance";

import Home from "./Home";

import WebsiteSettings from "./WebsiteSettings";

import UserManagement from "./UserManagement";

import MembershipSignup from "./MembershipSignup";

import SponsorshipInquiry from "./SponsorshipInquiry";

import Contracts from "./Contracts";

import HomePage from "./HomePage";

import Fixtures from "./Fixtures";

import Shop from "./Shop";

import PublicTeams from "./PublicTeams";

import SignSponsorshipContract from "./SignSponsorshipContract";

import Players from "./Players";

import SocialGameSettings from "./SocialGameSettings";

import SponsorshipTiers from "./SponsorshipTiers";

import Squad from "./Squad";

import SocialGames from "./SocialGames";

import News from "./News";

import NewsDetail from "./NewsDetail";

import CrmContacts from "./CrmContacts";

import CrmCampaigns from "./CrmCampaigns";

import CrmTemplates from "./CrmTemplates";

import CrmCampaignCreator from "./CrmCampaignCreator";

import CrmCampaignEditor from "./CrmCampaignEditor";

import DigitalCard from "./DigitalCard";

import Communications from "./Communications";

import Invoices from "./Invoices";

import LoanPlayers from "./LoanPlayers";

import PlayerBio from "./PlayerBio";

import SocialGameJoin from "./SocialGameJoin";

import TelegramSettings from "./TelegramSettings";

import PlayerPortal from "./PlayerPortal";

import SignPlayerContract from "./SignPlayerContract";

import SignMembershipContract from "./SignMembershipContract";

import PortalLogin from "./PortalLogin";

import SponsorshipPayment from "./SponsorshipPayment";

import PaymentStatus from "./PaymentStatus";

import ExecutiveTeam from "./ExecutiveTeam";

import ExecutivePortal from "./ExecutivePortal";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Members: Members,
    
    Teams: Teams,
    
    Inventory: Inventory,
    
    Matches: Matches,
    
    Events: Events,
    
    Training: Training,
    
    Sponsorship: Sponsorship,
    
    Finance: Finance,
    
    Home: Home,
    
    WebsiteSettings: WebsiteSettings,
    
    UserManagement: UserManagement,
    
    MembershipSignup: MembershipSignup,
    
    SponsorshipInquiry: SponsorshipInquiry,
    
    Contracts: Contracts,
    
    HomePage: HomePage,
    
    Fixtures: Fixtures,
    
    Shop: Shop,
    
    PublicTeams: PublicTeams,
    
    SignSponsorshipContract: SignSponsorshipContract,
    
    Players: Players,
    
    SocialGameSettings: SocialGameSettings,
    
    SponsorshipTiers: SponsorshipTiers,
    
    Squad: Squad,
    
    SocialGames: SocialGames,
    
    News: News,
    
    NewsDetail: NewsDetail,
    
    CrmContacts: CrmContacts,
    
    CrmCampaigns: CrmCampaigns,
    
    CrmTemplates: CrmTemplates,
    
    CrmCampaignCreator: CrmCampaignCreator,
    
    CrmCampaignEditor: CrmCampaignEditor,
    
    DigitalCard: DigitalCard,
    
    Communications: Communications,
    
    Invoices: Invoices,
    
    LoanPlayers: LoanPlayers,
    
    PlayerBio: PlayerBio,
    
    SocialGameJoin: SocialGameJoin,
    
    TelegramSettings: TelegramSettings,
    
    PlayerPortal: PlayerPortal,
    
    SignPlayerContract: SignPlayerContract,
    
    SignMembershipContract: SignMembershipContract,
    
    PortalLogin: PortalLogin,
    
    SponsorshipPayment: SponsorshipPayment,
    
    PaymentStatus: PaymentStatus,
    
    ExecutiveTeam: ExecutiveTeam,
    
    ExecutivePortal: ExecutivePortal,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Members" element={<Members />} />
                
                <Route path="/Teams" element={<Teams />} />
                
                <Route path="/Inventory" element={<Inventory />} />
                
                <Route path="/Matches" element={<Matches />} />
                
                <Route path="/Events" element={<Events />} />
                
                <Route path="/Training" element={<Training />} />
                
                <Route path="/Sponsorship" element={<Sponsorship />} />
                
                <Route path="/Finance" element={<Finance />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/WebsiteSettings" element={<WebsiteSettings />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/MembershipSignup" element={<MembershipSignup />} />
                
                <Route path="/SponsorshipInquiry" element={<SponsorshipInquiry />} />
                
                <Route path="/Contracts" element={<Contracts />} />
                
                <Route path="/HomePage" element={<HomePage />} />
                
                <Route path="/Fixtures" element={<Fixtures />} />
                
                <Route path="/Shop" element={<Shop />} />
                
                <Route path="/PublicTeams" element={<PublicTeams />} />
                
                <Route path="/SignSponsorshipContract" element={<SignSponsorshipContract />} />
                
                <Route path="/Players" element={<Players />} />
                
                <Route path="/SocialGameSettings" element={<SocialGameSettings />} />
                
                <Route path="/SponsorshipTiers" element={<SponsorshipTiers />} />
                
                <Route path="/Squad" element={<Squad />} />
                
                <Route path="/SocialGames" element={<SocialGames />} />
                
                <Route path="/News" element={<News />} />
                
                <Route path="/NewsDetail" element={<NewsDetail />} />
                
                <Route path="/CrmContacts" element={<CrmContacts />} />
                
                <Route path="/CrmCampaigns" element={<CrmCampaigns />} />
                
                <Route path="/CrmTemplates" element={<CrmTemplates />} />
                
                <Route path="/CrmCampaignCreator" element={<CrmCampaignCreator />} />
                
                <Route path="/CrmCampaignEditor" element={<CrmCampaignEditor />} />
                
                <Route path="/DigitalCard" element={<DigitalCard />} />
                
                <Route path="/Communications" element={<Communications />} />
                
                <Route path="/Invoices" element={<Invoices />} />
                
                <Route path="/LoanPlayers" element={<LoanPlayers />} />
                
                <Route path="/PlayerBio" element={<PlayerBio />} />
                
                <Route path="/SocialGameJoin" element={<SocialGameJoin />} />
                
                <Route path="/TelegramSettings" element={<TelegramSettings />} />
                
                <Route path="/PlayerPortal" element={<PlayerPortal />} />
                
                <Route path="/SignPlayerContract" element={<SignPlayerContract />} />
                
                <Route path="/SignMembershipContract" element={<SignMembershipContract />} />
                
                <Route path="/PortalLogin" element={<PortalLogin />} />
                
                <Route path="/SponsorshipPayment" element={<SponsorshipPayment />} />
                
                <Route path="/PaymentStatus" element={<PaymentStatus />} />
                
                <Route path="/ExecutiveTeam" element={<ExecutiveTeam />} />
                
                <Route path="/ExecutivePortal" element={<ExecutivePortal />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}