
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { NewsPost } from '@/api/entities';
import { format, parseISO } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Calendar, User, ExternalLink, Tag, ChevronRight, Play } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function NewsDetailPage() {
  const [post, setPost] = useState(null);
  const [relatedPosts, setRelatedPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [debugInfo, setDebugInfo] = useState(null);
  const location = useLocation();
  const timeoutRef = useRef(null);

  const isPostVisible = (post) => {
    if (post.publish_status !== 'published') return false;
    if (!post.publish_at) return true;
    
    const now = new Date();
    const publishTime = parseISO(post.publish_at);
    return publishTime <= now;
  };

  const loadPost = useCallback(async () => {
    const params = new URLSearchParams(location.search);
    const slug = params.get('slug');

    if (!slug) {
      setNotFound(true);
      setLoading(false);
      return;
    }

    setLoading(true);
    setNotFound(false);
    
    try {
      const posts = await NewsPost.list('-created_date');
      
      // Enhanced debug information
      setDebugInfo({
        totalPosts: posts.length,
        searchingSlug: slug,
        postsWithSlugs: posts.map(p => ({
          id: p.id,
          title: p.title,
          slug: p.slug,
          status: p.publish_status
        }))
      });
      
      let foundPost = posts.find(p => p.slug === slug);
      
      // Fallback: try to find by title-based slug if no direct match
      if (!foundPost) {
        const titleBasedSlug = slug.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
        foundPost = posts.find(p => {
          if (!p.slug && p.title) {
            const generatedSlug = p.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
            return generatedSlug === titleBasedSlug;
          }
          return false;
        });
      }
      
      if (!foundPost) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      // Auto-generate slug if missing
      if (!foundPost.slug && foundPost.title) {
        const generatedSlug = foundPost.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
        try {
          await NewsPost.update(foundPost.id, { slug: generatedSlug });
          foundPost.slug = generatedSlug; // Update the local object for immediate use
        } catch (error) {
          console.error("Error updating slug:", error);
        }
      }

      if (!isPostVisible(foundPost)) {
        if (foundPost.publish_at) {
          const publishTime = parseISO(foundPost.publish_at);
          const now = new Date();
          const timeUntilPublish = publishTime.getTime() - now.getTime();
          
          if (timeUntilPublish > 0 && timeUntilPublish <= 24 * 60 * 60 * 1000) {
            timeoutRef.current = setTimeout(() => {
              loadPost();
            }, timeUntilPublish + 1000);
          }
        }
        
        setNotFound(true);
        setLoading(false);
        return;
      }

      setPost(foundPost);

      const otherPosts = posts.filter(p => 
        p.id !== foundPost.id && isPostVisible(p)
      );

      let related = [];
      if (foundPost.tags && foundPost.tags.length > 0) {
        related = otherPosts.filter(p => 
          p.tags && p.tags.some(tag => foundPost.tags.includes(tag))
        ).slice(0, 3);
      }
      
      if (related.length < 3) {
        const latest = otherPosts
          .filter(p => !related.find(r => r.id === p.id))
          .slice(0, 3 - related.length);
        related = [...related, ...latest];
      }

      setRelatedPosts(related);
    } catch (error) {
      console.error("Error loading news post:", error);
      setDebugInfo({ error: error.message });
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, [location.search]);

  useEffect(() => {
    loadPost();
    
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [loadPost]);

  const renderVideo = (videoUrl) => {
    if (!videoUrl) return null;

    if (videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be')) {
      let embedId = '';
      if (videoUrl.includes('youtube.com')) {
        embedId = videoUrl.split('v=')[1]?.split('&')[0];
      } else if (videoUrl.includes('youtu.be')) {
        embedId = videoUrl.split('/').pop()?.split('?')[0];
      }
      
      if (embedId) {
        return (
          <iframe
            src={`https://www.youtube.com/embed/${embedId}`}
            className="w-full h-[400px] rounded-lg"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="YouTube video player"
            frameBorder="0"
          />
        );
      }
    }

    if (videoUrl.includes('vimeo.com')) {
      const videoId = videoUrl.split('/').pop()?.split('?')[0];
      if (videoId) {
        return (
          <iframe
            src={`https://player.vimeo.com/video/${videoId}`}
            className="w-full h-[400px] rounded-lg"
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
            title="Vimeo video player"
            frameBorder="0"
          />
        );
      }
    }

    if (videoUrl.endsWith('.mp4') || videoUrl.endsWith('.webm') || videoUrl.endsWith('.ogg')) {
      return (
        <video
          src={videoUrl}
          className="w-full h-auto rounded-lg"
          controls
          preload="metadata"
        />
      );
    }

    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-6 py-24">
          <Skeleton className="h-8 w-32 mb-8" />
          <Skeleton className="h-64 w-full rounded-lg mb-8" />
          <Skeleton className="h-12 w-3/4 mb-4" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        </div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-6 py-24 text-center">
          <div className="bg-white/80 backdrop-blur-sm border-slate-200/60 rounded-xl p-12">
            <h1 className="text-3xl font-bold text-slate-900 mb-4">Article Not Found</h1>
            <p className="text-slate-600 mb-8">
              The news article you're looking for doesn't exist or isn't published yet.
            </p>
            
            {/* Debug Information */}
            {debugInfo && typeof window !== 'undefined' && window.location.hostname === 'localhost' && (
              <div className="bg-yellow-50 p-4 rounded-lg mb-8 text-left">
                <h3 className="font-bold mb-2">Debug Information:</h3>
                <pre className="text-xs text-slate-700 whitespace-pre-wrap">
                  {JSON.stringify(debugInfo, null, 2)}
                </pre>
              </div>
            )}
            
            <Link to={createPageUrl('News')}>
              <Button className="bg-red-600 hover:bg-red-700">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to News
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-6 py-24">
        <div className="mb-8">
          <Link to={createPageUrl('News')}>
            <Button variant="outline" className="text-slate-600 hover:text-slate-900">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to All News
            </Button>
          </Link>
        </div>

        {/* Enhanced Debug Info */}
        {debugInfo && typeof window !== 'undefined' && window.location.hostname === 'localhost' && post && (
          <div className="mb-4 p-4 bg-green-100 rounded-lg text-sm">
            <strong>Debug: Post Found!</strong><br/>
            Title: {post.title}<br/>
            Slug: {post.slug}<br/>
            Status: {post.publish_status}<br/>
            Publish At: {post.publish_at || 'none'}<br/>
            Total Posts in DB: {debugInfo.totalPosts}
          </div>
        )}

        <article className="bg-white/80 backdrop-blur-sm border-slate-200/60 rounded-xl overflow-hidden">
          {post.hero_media_type === 'video' && post.hero_video_url ? (
            <div className="p-6 pb-0">
              {renderVideo(post.hero_video_url)}
            </div>
          ) : post.hero_image_url ? (
            <img
              src={post.hero_image_url}
              alt={post.title}
              className="w-full h-[400px] object-cover"
            />
          ) : null}

          <div className="p-8">
            <div className="flex flex-wrap gap-2 mb-4">
              {post.tags && post.tags.length > 0 && (
                <>
                  {post.tags.map((tag) => (
                    <Link key={tag} to={createPageUrl(`News?tag=${encodeURIComponent(tag)}`)}>
                      <Badge variant="outline" className="hover:bg-red-50 cursor-pointer">
                        {tag}
                      </Badge>
                    </Link>
                  ))}
                </>
              )}
            </div>

            <h1 className="text-4xl font-extrabold text-slate-900 mb-4">{post.title}</h1>
            
            <div className="flex items-center text-slate-500 text-sm mb-8 gap-6">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{post.author || 'Club Admin'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{format(parseISO(post.publish_at || post.created_date), 'MMMM d, yyyy')}</span>
              </div>
            </div>

            <div
              className="prose prose-slate max-w-none prose-lg mb-8"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            {post.action_button_label && post.action_button_url && (
              <div className="mb-8">
                <Button asChild className="bg-red-600 hover:bg-red-700">
                  <a 
                    href={post.action_button_url}
                    target={post.action_button_target || '_self'}
                    rel={post.action_button_target === '_blank' ? 'noopener noreferrer' : undefined}
                  >
                    {post.action_button_label}
                    {post.action_button_target === '_blank' && (
                      <ExternalLink className="w-4 h-4 ml-2" />
                    )}
                  </a>
                </Button>
              </div>
            )}

            {post.gallery && post.gallery.length > 0 && (
              <div className="mb-8">
                <h3 className="text-xl font-bold text-slate-900 mb-4">Gallery</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {post.gallery.map((item, index) => (
                    <div key={index} className="space-y-2">
                      {item.type === 'video' ? (
                        renderVideo(item.url)
                      ) : (
                        <img
                          src={item.url}
                          alt={item.caption || `Gallery image ${index + 1}`}
                          className="w-full h-48 object-cover rounded-lg"
                        />
                      )}
                      {item.caption && (
                        <p className="text-sm text-slate-600 italic">{item.caption}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </article>

        {relatedPosts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-8">Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedPosts.map((relatedPost) => (
                <Card key={relatedPost.id} className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-xl transition-all duration-300">
                  <Link to={createPageUrl(`NewsDetail?slug=${relatedPost.slug}`)}>
                    {relatedPost.hero_image_url ? (
                      <img
                        src={relatedPost.hero_image_url}
                        alt={relatedPost.title}
                        className="w-full h-32 object-cover rounded-t-lg"
                      />
                    ) : (
                      <div className="w-full h-32 bg-gradient-to-br from-slate-200 to-slate-300 rounded-t-lg"></div>
                    )}
                    <CardContent className="p-4">
                      <h3 className="font-bold text-slate-900 mb-2 line-clamp-2">
                        {relatedPost.title}
                      </h3>
                      <p className="text-sm text-slate-600 line-clamp-2">
                        {relatedPost.summary}
                      </p>
                      <div className="text-xs text-slate-500 mt-2">
                        {format(parseISO(relatedPost.publish_at || relatedPost.created_date), 'MMM d, yyyy')}
                      </div>
                    </CardContent>
                  </Link>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
