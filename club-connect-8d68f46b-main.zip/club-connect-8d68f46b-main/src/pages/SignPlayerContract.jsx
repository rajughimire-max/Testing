import React, { useState, useEffect } from 'react';
import { GeneratedContract } from '@/api/entities';
import { signContract } from '@/api/functions';
import { downloadSignedContract } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { FileText, Download, CheckCircle, Clock, Eye } from 'lucide-react';
import { toast } from 'sonner';

export default function SignPlayerContract() {
  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(true);
  const [signing, setSigning] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [signature, setSignature] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const contractId = urlParams.get('contractId');
    
    if (!contractId) {
      setError('Contract ID is required');
      setLoading(false);
      return;
    }

    loadContract(contractId);
  }, []);

  const loadContract = async (contractId) => {
    try {
      const contractData = await GeneratedContract.get(contractId);
      if (!contractData) {
        setError('Contract not found');
        return;
      }

      // Update view status if not already viewed
      if (contractData.status === 'sent') {
        await GeneratedContract.update(contractId, {
          status: 'viewed',
          viewed_at: new Date().toISOString()
        });
        contractData.status = 'viewed';
        contractData.viewed_at = new Date().toISOString();
      }

      setContract(contractData);
    } catch (error) {
      console.error('Error loading contract:', error);
      setError('Failed to load contract');
    } finally {
      setLoading(false);
    }
  };

  const handleSign = async () => {
    if (!signature.trim()) {
      toast.error('Please enter your full name as your signature');
      return;
    }

    setSigning(true);
    try {
      const response = await signContract({
        contractId: contract.id,
        sponsorSignature: signature
      });

      if (response.data.success) {
        toast.success('Contract signed successfully!');
        setContract(response.data.contract);
      } else {
        toast.error('Failed to sign contract');
      }
    } catch (error) {
      console.error('Error signing contract:', error);
      toast.error('Failed to sign contract. Please try again.');
    } finally {
      setSigning(false);
    }
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await downloadSignedContract({ contractId: contract.id });
      
      // Create blob and download
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `player_contract_${contract.id}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success('Contract downloaded successfully');
    } catch (error) {
      console.error('Error downloading contract:', error);
      toast.error('Failed to download contract');
    } finally {
      setDownloading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      sent: <Badge className="bg-blue-100 text-blue-800"><Clock className="w-3 h-3 mr-1" />Sent</Badge>,
      viewed: <Badge className="bg-yellow-100 text-yellow-800"><Eye className="w-3 h-3 mr-1" />Viewed</Badge>,
      signed: <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Signed</Badge>
    };
    return badges[status] || <Badge variant="secondary">{status}</Badge>;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="text-center">
          <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg mx-auto mb-4">
            <FileText className="w-6 h-6 text-white animate-pulse" />
          </div>
          <p className="text-slate-600">Loading contract...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <FileText className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-900 mb-2">Contract Not Found</h2>
            <p className="text-slate-600 mb-4">{error}</p>
            <Button onClick={() => window.close()} variant="outline">Close Window</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-8">
      <div className="max-w-4xl mx-auto px-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl text-slate-900">Player Contract</CardTitle>
                <p className="text-slate-600 mt-2">
                  Contract for: <span className="font-semibold">{contract.sent_to_name}</span>
                </p>
                <p className="text-sm text-slate-500">
                  Season: {contract.season_name} • 
                  Sent: {new Date(contract.created_date).toLocaleDateString()}
                </p>
              </div>
              <div className="text-right">
                {getStatusBadge(contract.status)}
                {contract.signed_at && (
                  <p className="text-sm text-green-600 mt-2">
                    Signed: {new Date(contract.signed_at).toLocaleDateString()}
                  </p>
                )}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Contract Content */}
            <div className="prose max-w-none">
              <div 
                className="bg-white p-8 border rounded-lg shadow-sm"
                dangerouslySetInnerHTML={{ __html: contract.contract_content }}
              />
            </div>

            <Separator />

            {/* Signature Section */}
            {contract.status !== 'signed' ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-900">Electronic Signature</h3>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="signature">Full Name (This will serve as your electronic signature)</Label>
                    <Input
                      id="signature"
                      value={signature}
                      onChange={(e) => setSignature(e.target.value)}
                      placeholder="Enter your full name"
                      className="mt-1"
                    />
                  </div>
                  <p className="text-sm text-slate-600">
                    By entering your name and clicking "Sign Contract", you agree to the terms and conditions outlined in this contract.
                    This constitutes a legally binding electronic signature.
                  </p>
                  <Button 
                    onClick={handleSign} 
                    disabled={signing || !signature.trim()}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {signing ? 'Signing...' : 'Sign Contract'}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-green-800">Contract Successfully Signed</h3>
                  <Button
                    onClick={handleDownload}
                    disabled={downloading}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    {downloading ? 'Downloading...' : 'Download Signed Contract'}
                  </Button>
                </div>
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <p className="text-green-800">
                    This contract was signed on {new Date(contract.signed_at).toLocaleDateString()} and is now fully executed.
                    You can download a copy of the signed contract using the button above.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}