import React, { useState, useEffect } from 'react';
import { Match, Team } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format, isAfter } from 'date-fns';
import { Calendar, Clock, MapPin, Shield, Trophy, Target, Users, ArrowRight } from 'lucide-react';

export default function FixturesPage() {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('upcoming');

  useEffect(() => {
    const loadData = async () => {
      try {
        const [matchesData, teamsData] = await Promise.all([
          Match.list('-match_date'),
          Team.list()
        ]);
        
        const teamsMap = teamsData.reduce((acc, team) => {
          acc[team.id] = team;
          return acc;
        }, {});

        setMatches(matchesData);
        setTeams(teamsMap);
      } catch (error) {
        console.error("Error loading fixtures data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const upcomingMatches = matches.filter(m => {
    if (m.match_status !== 'scheduled') return false;
    return isAfter(new Date(m.match_date), new Date());
  });
  
  const results = matches.filter(m => m.match_status === 'completed').slice(0, 10);

  const MatchCard = ({ match, isResult = false, delay = 0 }) => {
    const homeTeam = teams[match.team_id] || { name: 'Our Team', logo_url: null };

    return (
      <div 
        className="animate-in fade-in slide-in-from-bottom-4 duration-500"
        style={{ animationDelay: `${delay}ms` }}
      >
        <Card className="group shadow-lg hover:shadow-2xl transition-all duration-500 bg-white/90 backdrop-blur-sm rounded-2xl overflow-hidden border-0 hover:scale-105 transform">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <Badge 
                variant={isResult ? "default" : "secondary"} 
                className={`${isResult ? 'bg-green-600 text-white' : 'bg-blue-100 text-blue-800'} px-4 py-2 text-sm font-semibold rounded-full`}
              >
                {match.competition || 'League Match'}
              </Badge>
              {isResult && match.match_status === 'completed' && (
                <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 rounded-full">
                  Final Result
                </Badge>
              )}
            </div>
            
            <div className="space-y-6">
              {/* Teams */}
              <div className="flex items-center justify-between bg-gradient-to-r from-slate-50 to-white p-6 rounded-xl">
                <div className="flex items-center gap-4 flex-1">
                  {homeTeam.logo_url ? (
                    <img src={homeTeam.logo_url} alt={homeTeam.name} className="h-12 w-12 rounded-full shadow-md" />
                  ) : (
                    <div className="h-12 w-12 rounded-full bg-red-600 flex items-center justify-center shadow-md">
                      <Shield className="h-6 w-6 text-white" />
                    </div>
                  )}
                  <span className="font-bold text-xl text-slate-800">{homeTeam.name}</span>
                </div>
                
                {isResult && match.home_score !== null && (
                  <div className="text-3xl font-black text-slate-900 mx-8">
                    {match.home_score}
                  </div>
                )}
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-slate-500 bg-slate-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  VS
                </div>
              </div>
              
              <div className="flex items-center justify-between bg-gradient-to-r from-slate-50 to-white p-6 rounded-xl">
                <div className="flex items-center gap-4 flex-1">
                  <div className="h-12 w-12 rounded-full bg-slate-300 flex items-center justify-center shadow-md">
                    <Shield className="h-6 w-6 text-slate-500" />
                  </div>
                  <span className="font-bold text-xl text-slate-800">{match.opponent_name}</span>
                </div>
                
                {isResult && match.away_score !== null && (
                  <div className="text-3xl font-black text-slate-900 mx-8">
                    {match.away_score}
                  </div>
                )}
              </div>
            </div>

            {/* Match Details */}
            <div className="border-t mt-8 pt-6 space-y-4 bg-gradient-to-r from-slate-50 to-white p-6 rounded-xl">
              <div className="flex items-center gap-3 text-slate-700">
                <Calendar className="w-5 h-5 text-red-600" />
                <span className="font-semibold">{format(new Date(match.match_date), 'EEEE, d MMMM yyyy')}</span>
              </div>
              {match.match_time && (
                <div className="flex items-center gap-3 text-slate-700">
                  <Clock className="w-5 h-5 text-red-600" />
                  <span className="font-semibold">{match.match_time}</span>
                </div>
              )}
              <div className="flex items-center gap-3 text-slate-700">
                <MapPin className="w-5 h-5 text-red-600" />
                <span className="font-semibold">{match.venue}</span>
                <Badge 
                  variant="outline" 
                  className={`ml-2 ${match.is_home_game ? 'bg-green-100 text-green-800 border-green-300' : 'bg-blue-100 text-blue-800 border-blue-300'}`}
                >
                  {match.is_home_game ? 'Home' : 'Away'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="text-center mb-16">
            <Skeleton className="h-16 w-96 mx-auto mb-6" />
            <Skeleton className="h-6 w-128 mx-auto" />
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-96 rounded-2xl" />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative py-32 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-blue-600/20"></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-7xl font-black text-white tracking-tight leading-none">
              FIXTURES & RESULTS
            </h1>
            <div className="h-2 w-32 bg-red-600 mx-auto"></div>
            <p className="text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
              Follow our journey through the season with upcoming matches and recent results
            </p>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-red-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      {/* Tab Navigation */}
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-8">
        <div className="flex justify-center mb-12">
          <div className="bg-white/80 backdrop-blur-sm p-2 rounded-2xl shadow-lg">
            <Button
              onClick={() => setActiveTab('upcoming')}
              className={`px-8 py-4 rounded-xl font-semibold transition-all duration-300 ${
                activeTab === 'upcoming'
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'bg-transparent text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Calendar className="w-5 h-5 mr-2" />
              Upcoming Fixtures
            </Button>
            <Button
              onClick={() => setActiveTab('results')}
              className={`px-8 py-4 rounded-xl font-semibold transition-all duration-300 ${
                activeTab === 'results'
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'bg-transparent text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Trophy className="w-5 h-5 mr-2" />
              Recent Results
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 pb-24">
        {activeTab === 'upcoming' && (
          <div>
            {upcomingMatches.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-8">
                {upcomingMatches.map((match, index) => (
                  <MatchCard key={match.id} match={match} delay={index * 100} />
                ))}
              </div>
            ) : (
              <div className="text-center py-24">
                <div className="max-w-md mx-auto">
                  <div className="w-32 h-32 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-8">
                    <Calendar className="w-16 h-16 text-slate-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">No Upcoming Fixtures</h3>
                  <p className="text-slate-600 text-lg leading-relaxed">
                    Check back soon for new match announcements and fixture updates.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'results' && (
          <div>
            {results.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-8">
                {results.map((match, index) => (
                  <MatchCard key={match.id} match={match} isResult={true} delay={index * 100} />
                ))}
              </div>
            ) : (
              <div className="text-center py-24">
                <div className="max-w-md mx-auto">
                  <div className="w-32 h-32 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-8">
                    <Trophy className="w-16 h-16 text-slate-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">No Results Yet</h3>
                  <p className="text-slate-600 text-lg leading-relaxed">
                    Match results will appear here after games are completed.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}