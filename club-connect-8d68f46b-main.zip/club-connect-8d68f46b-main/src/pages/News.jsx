
import React, { useState, useEffect, useCallback } from 'react';
import { NewsPost } from '@/api/entities';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { format, parseISO } from 'date-fns';
import { Link, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ChevronRight, Image as ImageIcon, Video } from 'lucide-react';

const POSTS_PER_PAGE = 12;

export default function NewsPage() {
  const [posts, setPosts] = useState([]);
  const [allPosts, setAllPosts] = useState([]); // Stores all *published* posts before tag filtering and pagination
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchParams] = useSearchParams();
  const selectedTag = searchParams.get('tag');

  const loadPosts = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch all posts from the backend.
      const allNewsData = await NewsPost.list('-created_date');
      
      // Filter for publicly visible posts on the client-side.
      const visiblePosts = allNewsData.filter(post => {
        if (post.publish_status !== 'published') {
          return false;
        }
        if (post.publish_at) {
          // If there's a scheduled date, it must be in the past.
          return parseISO(post.publish_at) <= new Date();
        }
        // If status is published and no scheduled date, it's visible.
        return true;
      });
      
      setAllPosts(visiblePosts); // Set all published posts for tag filtering and debug info

      // Apply tag filter if selected.
      const filteredPostsByTag = selectedTag 
        ? visiblePosts.filter(post => post.tags && post.tags.includes(selectedTag))
        : visiblePosts;

      // Apply pagination.
      const startIndex = (currentPage - 1) * POSTS_PER_PAGE;
      const endIndex = startIndex + POSTS_PER_PAGE;
      const paginatedPosts = filteredPostsByTag.slice(startIndex, endIndex);

      setPosts(paginatedPosts); // Set posts for the current page
      setTotalPages(Math.ceil(filteredPostsByTag.length / POSTS_PER_PAGE));

    } catch (error) {
      console.error("Error loading news posts:", error);
    } finally {
      setLoading(false);
    }
  }, [currentPage, selectedTag]);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  const getUniqueTagsFromPosts = () => {
    const allTags = allPosts.flatMap(post => post.tags || []);
    return [...new Set(allTags)];
  };

  const renderMediaPreview = (post) => {
    if (post.hero_media_type === 'video' && post.hero_video_url) {
      return (
        <div className="w-full h-48 bg-gradient-to-br from-slate-200 to-slate-300 rounded-t-lg flex items-center justify-center">
          <Video className="w-12 h-12 text-slate-500" />
        </div>
      );
    }
    
    if (post.hero_image_url) {
      return (
        <img
          src={post.hero_image_url}
          alt={post.title}
          className="w-full h-48 object-cover rounded-t-lg"
          loading="lazy"
        />
      );
    }

    return (
      <div className="w-full h-48 bg-gradient-to-br from-slate-200 to-slate-300 rounded-t-lg flex items-center justify-center">
        <ImageIcon className="w-12 h-12 text-slate-500" />
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-6xl mx-auto px-6 py-24">
          <div className="text-center mb-16">
            <Skeleton className="h-12 w-48 mx-auto mb-4" />
            <Skeleton className="h-6 w-96 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(6).fill(0).map((_, i) => (
              <Card key={i} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <Skeleton className="h-48 w-full rounded-t-lg" />
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-20" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-6xl mx-auto px-6 py-24">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-black text-slate-900 mb-4">
            Latest News
          </h1>
          <p className="text-xl text-slate-600">
            Stay up to date with everything happening at our club
          </p>
        </div>

        {/* Debug info for localhost */}
        {typeof window !== 'undefined' && window.location.hostname === 'localhost' && (
          <div className="mb-6 p-4 bg-blue-100 rounded-lg text-sm text-blue-800">
            <strong>Debug Info:</strong> Total published posts (before current tag filter & pagination): {allPosts.length}. Posts currently displayed: {posts.length}
          </div>
        )}

        {/* Tag Filter */}
        {getUniqueTagsFromPosts().length > 0 && (
          <div className="flex flex-wrap gap-2 mb-12 justify-center">
            <Link to={createPageUrl('News')}>
              <Badge 
                variant={!selectedTag ? "default" : "outline"}
                className="cursor-pointer hover:bg-red-100"
              >
                All Posts
              </Badge>
            </Link>
            {getUniqueTagsFromPosts().map(tag => (
              <Link key={tag} to={createPageUrl(`News?tag=${encodeURIComponent(tag)}`)}>
                <Badge 
                  variant={selectedTag === tag ? "default" : "outline"}
                  className="cursor-pointer hover:bg-red-100"
                >
                  {tag}
                </Badge>
              </Link>
            ))}
          </div>
        )}

        {/* News Grid and No Posts Message */}
        {posts.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-24 h-24 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-6">
              <ImageIcon className="w-12 h-12 text-slate-400" />
            </div>
            <h3 className="text-2xl font-bold text-slate-700 mb-4">No News Posts Yet</h3>
            <p className="text-slate-500 text-lg">
              Check back soon for the latest updates and announcements from our club.
            </p>
            {selectedTag && (
              <Link to={createPageUrl('News')} className="mt-4 inline-block">
                <Button variant="outline">
                  View All Posts
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {posts.map((post) => {
                // Auto-generate slug if missing, or use existing one.
                const postSlug = post.slug || post.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
                
                return (
                  <Card key={post.id} className="bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-xl transition-all duration-300 group overflow-hidden">
                    <Link to={createPageUrl(`NewsDetail?slug=${postSlug}`)}>
                      {renderMediaPreview(post)}
                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-red-600 transition-colors">
                          {post.title}
                        </h3>
                        <p className="text-slate-600 mb-4 line-clamp-3">
                          {post.summary}
                        </p>
                        
                        {/* Tags */}
                        {post.tags && post.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2 mb-4">
                            {post.tags.slice(0, 3).map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}

                        {/* Meta */}
                        <div className="flex items-center justify-between text-sm text-slate-500">
                          <span>{post.author || 'Club Admin'}</span>
                          <span>{format(parseISO(post.created_date), 'MMM d, yyyy')}</span>
                        </div>
                        
                        <div className="mt-4 flex items-center text-red-600 group-hover:text-red-700 transition-colors">
                          <span className="font-medium">Read More</span>
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </div>
                      </CardContent>
                    </Link>
                  </Card>
                );
              })}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-4">
                <Button 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))} 
                  disabled={currentPage === 1}
                  variant="outline"
                >
                  Previous
                </Button>
                <span className="text-sm text-slate-600">
                  Page {currentPage} of {totalPages}
                </span>
                <Button 
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} 
                  disabled={currentPage === totalPages}
                  variant="outline"
                >
                  Next
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
