

import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import PublicLayout from './components/public_site/PublicLayout';
import { User } from '@/api/entities';
import { Member, Player, Sponsor, SocialGameSignup, ExecutiveMember } from '@/api/entities';
import {
  LayoutDashboard,
  Users,
  Shield,
  Calendar,
  Trophy,
  Package,
  MessageSquare,
  Settings,
  Menu,
  X,
  Warehouse,
  ClipboardCheck,
  Handshake,
  DollarSign,
  Globe,
  ExternalLink,
  FileText,
  UserCheck,
  Gamepad2, // Added for Social Game
  Contact, // Added for CRM
  Send, // Added for CRM and now Communication Hub
  LogOut, // Import LogOut icon
  Receipt, // Import Receipt icon for Invoices
  Crown // Import Crown icon for Executive Team
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import PortalSwitcher from './components/portals/PortalSwitcher'; // Import the new component
import { toast } from 'sonner';

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
    section: "overview"
  },
  {
    title: "Members",
    url: createPageUrl("Members"),
    icon: Users,
    section: "management"
  },
  {
    title: "Executive Team",
    url: createPageUrl("ExecutiveTeam"),
    icon: Crown,
    section: "management"
  },
  {
    title: "Executive Portal", // Added this item as per outline
    url: createPageUrl("ExecutivePortal"),
    icon: Crown,
    section: "management"
  },
  {
    title: "Teams",
    url: createPageUrl("Teams"),
    icon: Shield,
    section: "management"
  },
  {
    title: "Players",
    url: createPageUrl("Players"),
    icon: UserCheck,
    section: "management"
  },
  {
    title: "Matches",
    url: createPageUrl("Matches"),
    icon: Trophy,
    section: "activities"
  },
  {
    title: "Events",
    url: createPageUrl("Events"),
    icon: Calendar,
    section: "activities"
  },
  {
    title: "Training",
    url: createPageUrl("Training"),
    icon: ClipboardCheck,
    section: "activities"
  },
  {
    title: "Inventory",
    url: createPageUrl("Inventory"),
    icon: Package,
    section: "resources"
  },
  {
    title: "Communications",
    url: createPageUrl("Communications"),
    icon: MessageSquare,
    section: "resources"
  },
  // Communication Hub item removed as per refactoring
  {
    title: "Sponsorship",
    url: createPageUrl("Sponsorship"),
    icon: Handshake,
    section: "financials"
  },
  {
    title: "Invoices",
    url: createPageUrl("Invoices"),
    icon: Receipt,
    section: "financials"
  },
  {
    title: "Contracts",
    url: createPageUrl("Contracts"),
    icon: FileText,
    section: "financials"
  },
  {
    title: "Finance",
    url: createPageUrl("Finance"),
    icon: DollarSign,
    section: "financials"
  },
  // New CRM Section
  {
    title: "Contacts",
    url: createPageUrl("CrmContacts"),
    icon: Contact,
    section: "crm"
  },
  {
    title: "Campaigns",
    url: createPageUrl("CrmCampaigns"),
    icon: Send,
    section: "crm"
  },
  {
    title: "Templates",
    url: createPageUrl("CrmTemplates"),
    icon: FileText,
    section: "crm"
  }
];

const sectionGroups = {
  overview: "Overview",
  management: "Club Management",
  activities: "Activities",
  resources: "Resources",
  crm: "CRM & Marketing", // New CRM section label
  financials: "Financials",
  settings: "Settings"
};

// PlayerPortal and Communications are intentionally NOT in publicPages as they are protected portals.
// Adding them here would make them public and bypass authentication, which breaks existing functionality.
const publicPages = ['Home', 'MembershipSignup', 'SponsorshipInquiry', 'SponsorshipTiers', 'PublicTeams', 'Squad', 'Fixtures', 'Shop', 'SignSponsorshipContract', 'SignPlayerContract', 'SignMembershipContract', 'SocialGameJoin', 'SocialGames', 'News', 'NewsDetail', 'LoanPlayers', 'PlayerBio', 'SponsorshipPayment'];

// Define pages that handle their own authentication (like public pages, login, digital card)
// OR are specific portals that render children directly (like PlayerPortal, Communications, ExecutivePortal).
// Note: This array is primarily used for rendering decisions for the layout itself.
// The useEffect's initial bypass check is more precise about which pages truly skip role verification.
const pagesWithCustomAuth = [...publicPages, 'PortalLogin', 'PlayerPortal', 'Communications', 'DigitalCard', 'ExecutivePortal'];


export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [availablePortals, setAvailablePortals] = useState([]);

  // Check authentication and user roles
  React.useEffect(() => {
    // If the current page is a public page, PortalLogin, or DigitalCard, it handles its own auth or requires no auth.
    // The main role-based check in this effect is bypassed for these specific pages.
    const bypassEffectCheckPages = [...publicPages, 'PortalLogin', 'DigitalCard'];
    if (bypassEffectCheckPages.includes(currentPageName)) {
        setLoading(false);
        return;
    }

    const checkAuth = async () => {
      try {
        const userData = await User.me();
        setUser(userData);

        // Admin always gets full access to dashboard
        if (userData.role === 'admin') {
          setAvailablePortals([{ name: 'Admin Dashboard', page: 'Dashboard' }]);
          setLoading(false);
          
          // Build the full navigation items list for admins
          const fullNavigationItems = [
            ...navigationItems,
            {
              title: "View Website",
              url: createPageUrl("Home"),
              icon: ExternalLink,
              section: "settings"
            },
            {
              title: "Website Settings",
              url: createPageUrl("WebsiteSettings"),
              icon: Globe,
              section: "settings"
            },
            {
              title: "User Management",
              url: createPageUrl("UserManagement"),
              icon: Users,
              section: "settings"
            },
            {
              title: "Social Game Settings",
              url: createPageUrl("SocialGameSettings"),
              icon: Gamepad2,
              section: "settings"
            },
            {
              title: "Telegram Settings",
              url: createPageUrl("TelegramSettings"),
              icon: Settings,
              section: "settings"
            }
          ];
          
          // If admin is on a page not in fullNavigationItems or not Dashboard, redirect to Dashboard
          const isValidAdminPage = currentPageName === 'Dashboard' || 
                                  fullNavigationItems.some(item => item.url === createPageUrl(currentPageName));
          
          if (!isValidAdminPage) {
             window.location.href = createPageUrl('Dashboard');
          }
          return;
        }

        // For non-admin users, check their active roles and determine available portals
        const [memberCheck, playerCheck, sponsorCheck, socialCheck, executiveCheck] = await Promise.all([
          Member.filter({ email: userData.email }),
          Player.filter({ email: userData.email }),
          Sponsor.filter({ email: userData.email }),
          SocialGameSignup.filter({ email: userData.email }),
          ExecutiveMember.list(),
        ]);

        const memberRecord = memberCheck[0];
        const playerRecord = playerCheck[0];
        const sponsorRecord = sponsorCheck[0];
        const socialRecord = socialCheck[0];

        let portals = [];
        let primaryPortal = 'Home'; // Default to Home if no active portal role is found

        // Check for Executive role
        const isExecutive = (memberRecord && executiveCheck.some(e => e.member_id === memberRecord.id && e.status === 'Active')) ||
                            (playerRecord && executiveCheck.some(e => e.player_id === playerRecord.id && e.status === 'Active'));
        
        if (isExecutive) {
          portals.push({ name: 'Executive Portal', page: 'ExecutivePortal' });
          if (primaryPortal === 'Home') primaryPortal = 'ExecutivePortal'; // Executive is highest priority among non-admin
        }

        // Check for Player role
        if (playerRecord) {
          if (playerRecord.is_active) {
            portals.push({ name: 'Player Portal', page: 'PlayerPortal' });
            if (primaryPortal === 'Home' || primaryPortal === 'SocialGames') primaryPortal = 'PlayerPortal'; // Player is next priority after Executive
          } else {
            // Player is inactive, alert and logout if no other active role
            if (!isExecutive) { // Only check player inactivity if not already an executive
                alert("Your player account is currently inactive. Please contact an administrator for assistance.");
                await User.logout();
                window.location.href = createPageUrl('Home');
                return;
            }
          }
        }

        // Check for Member or Sponsor role
        const isActiveMemberOrSponsor = (memberRecord && memberRecord.membership_status === 'active') || (sponsorRecord && sponsorRecord.status === 'Active');
        if (isActiveMemberOrSponsor) {
            portals.push({ name: 'Member Portal', page: 'Communications' });
            if (primaryPortal === 'Home' || primaryPortal === 'SocialGames') primaryPortal = 'Communications'; // Member/Sponsor is next priority after Player/Executive
        } else if ((memberRecord && memberRecord.membership_status !== 'active') || (sponsorRecord && sponsorRecord.status !== 'Active')) {
            // Member or Sponsor record exists but is inactive, alert and logout if no higher active role
            if (!isExecutive && !(playerRecord && playerRecord.is_active)) {
                alert("Your membership or sponsorship is currently inactive. Please contact an administrator for assistance.");
                await User.logout();
                window.location.href = createPageUrl('Home');
                return;
            }
        }

        // Check for Social Game Lead
        if (socialRecord) {
            portals.push({ name: 'Social Games', page: 'SocialGames' });
            if (primaryPortal === 'Home') primaryPortal = 'SocialGames'; // Social Game Lead is lowest priority among active roles
        }
        
        setAvailablePortals(portals);

        // If user's email is not in ANY of our systems AND they don't have any active portals, deny access.
        // This handles cases where a user might be in the system but all their roles are inactive, or they are not in the system at all.
        if (!memberRecord && !playerRecord && !sponsorRecord && !socialRecord) {
             if (portals.length === 0) { // If they aren't even recognized or have no active roles, deny.
                alert("Access denied. Your email is not registered with the club or you have no active roles. Please contact an administrator if you believe this is an error.");
                await User.logout();
                window.location.href = createPageUrl('Home');
                return;
            }
        }
        
        // If, after all checks, no active portals were found (e.g., user exists but all roles are inactive)
        if (portals.length === 0) {
            alert("Your account does not have an active role. Please contact an administrator if you believe this is an error.");
            await User.logout();
            window.location.href = createPageUrl('Home');
            return;
        }
        
        // Redirect to primary portal only if not already on an authorized page for this user
        const isAuthorizedPage = portals.some(p => p.page === currentPageName);
        if (!isAuthorizedPage) {
            window.location.href = createPageUrl(primaryPortal);
        }

      } catch (error) {
        // User not logged in or API error - check if it's a protected page
        console.error("Authentication check failed:", error);
        
        // Define which portals require a Google account login
        const googleAuthPortals = ['Dashboard', 'Members', 'ExecutiveTeam', 'Teams', 'Players', 'Matches', 'Events', 'Training', 'Inventory', 'Communications', 'Sponsorship', 'Invoices', 'Contracts', 'Finance', 'CrmContacts', 'CrmCampaigns', 'CrmTemplates', 'WebsiteSettings', 'UserManagement', 'SocialGameSettings', 'TelegramSettings'];

        // For ID-based portals, redirect to PortalLogin
        const idBasedPortals = ['ExecutivePortal', 'PlayerPortal', 'Communications'];

        if (googleAuthPortals.includes(currentPageName)) {
            // This is a protected page that requires Google login. Redirect to login, then come back.
            toast.info("Please log in to access this page.");
            const callbackUrl = window.location.href; // The full current URL
            User.loginWithRedirect(callbackUrl);
        } else if (idBasedPortals.includes(currentPageName)) {
            // This is an ID-based portal, redirect to PortalLogin
            toast.info("Please log in with your ID to access this portal.");
            window.location.href = createPageUrl('PortalLogin');
        } else {
            // For any other page, default to redirecting to Home.
            window.location.href = createPageUrl('Home');
        }
      } finally {
        setLoading(false);
      }
    };

    // Check for ID-based portal session
    const portalUserStr = sessionStorage.getItem('portalUser');
    if (portalUserStr && ['ExecutivePortal', 'PlayerPortal', 'Communications'].includes(currentPageName)) {
      try {
        const portalUser = JSON.parse(portalUserStr);
        if (portalUser && portalUser.data) {
          const pseudoUser = {
            full_name: `${portalUser.data.first_name || ''} ${portalUser.data.last_name || ''}`.trim(),
            email: portalUser.data.email,
            role: portalUser.type,
          };
          setUser(pseudoUser);

          // Set up available portals based on the validation response
          let portals = [];
          
          if (portalUser.available_portals) {
            if (portalUser.available_portals.includes('executive')) {
              portals.push({ name: 'Executive Portal', page: 'ExecutivePortal' });
            }
            if (portalUser.available_portals.includes('player')) {
              portals.push({ name: 'Player Portal', page: 'PlayerPortal' });
            }
            if (portalUser.available_portals.includes('member')) {
              portals.push({ name: 'Member Portal', page: 'Communications' });
            }
          }
          
          setAvailablePortals(portals);
          
          // Check if current page is authorized for this user
          const isAuthorizedPage = portals.some(p => p.page === currentPageName);
          if (!isAuthorizedPage) {
            // Redirect to their primary portal
            if (portals.length > 0) {
              window.location.href = createPageUrl(portals[0].page);
            } else {
              sessionStorage.removeItem('portalUser');
              window.location.href = createPageUrl('PortalLogin');
            }
          }
        } else {
          sessionStorage.removeItem('portalUser');
          window.location.href = createPageUrl('PortalLogin');
        }
      } catch (e) {
        console.error("Error parsing portalUser from session storage:", e);
        sessionStorage.removeItem('portalUser');
        window.location.href = createPageUrl('PortalLogin');
      }
      setLoading(false);
    } else {
      // Standard Google auth check
      checkAuth();
    }
  }, [currentPageName]);

  // Show public layout for public pages if no user is logged in
  if (publicPages.includes(currentPageName) && !user) {
    return <PublicLayout>{children}</PublicLayout>;
  }

  // DigitalCard and PortalLogin are standalone pages and always render children directly.
  // Other portal pages (PlayerPortal, Communications, ExecutivePortal, SocialGames)
  // also render children directly when a non-admin user is successfully authenticated and directed to them.
  if (['DigitalCard', 'PortalLogin'].includes(currentPageName) || 
      (['PlayerPortal', 'Communications', 'ExecutivePortal', 'SocialGames'].includes(currentPageName) && user?.role !== 'admin')) {
      return <>{children}</>;
  }
  
  // Show loading for protected pages while authentication is being checked
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="text-center">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg mx-auto mb-4">
          <Shield className="w-6 h-6 text-white animate-pulse" />
        </div>
        <p className="text-slate-600">Loading...</p>
      </div>
    </div>;
  }

  const handleLogout = async () => {
    try {
      // Clear portal session
      sessionStorage.removeItem('portalUser');
      // Attempt Google logout
      try {
        await User.logout();
      } catch (e) {
        // Ignore Google logout errors for ID-based sessions
      }
      window.location.href = createPageUrl('Home');
    } catch (error) {
      console.error("Logout error:", error);
    }
  };
  
  // Render Admin Layout for admin users
  if (user?.role === 'admin') {
      // Add new settings navigation items
      const fullNavigationItems = [
        ...navigationItems,
        {
          title: "View Website",
          url: createPageUrl("Home"),
          icon: ExternalLink,
          section: "settings"
        },
        {
          title: "Website Settings",
          url: createPageUrl("WebsiteSettings"),
          icon: Globe,
          section: "settings"
        },
        ...(user?.role === 'admin' ? [{
          title: "User Management",
          url: createPageUrl("UserManagement"),
          icon: Users,
          section: "settings"
        }, {
          title: "Social Game Settings",
          url: createPageUrl("SocialGameSettings"),
          icon: Gamepad2,
          section: "settings"
        }, { // Added Telegram Settings as part of "Move Telegram Settings"
          title: "Telegram Settings",
          url: createPageUrl("TelegramSettings"),
          icon: Settings,
          section: "settings"
        }] : [])
      ];

      const groupedItems = Object.entries(sectionGroups).map(([key, label]) => ({
        label,
        items: fullNavigationItems.filter(item => item.section === key)
      }));

    return (
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 to-blue-50">
          <Sidebar className="border-r border-slate-200/60 bg-white/80 backdrop-blur-sm">
            <SidebarHeader className="border-b border-slate-200/60 p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 text-lg">Nepbourne FC</h2>
                  <p className="text-xs text-slate-500 font-medium">Sports Club Platform</p>
                </div>
              </div>
            </SidebarHeader>

            <SidebarContent className="p-3">
              {groupedItems.map((group) => (
                <SidebarGroup key={group.label} className="mb-2">
                  <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2 mb-1">
                    {group.label}
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      {group.items.map((item) => (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton
                            asChild
                            className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-xl mb-1 ${
                              location.pathname === item.url
                                ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md hover:from-blue-600 hover:to-blue-700 hover:text-white'
                                : 'text-slate-600'
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                              <item.icon className="w-4 h-4" />
                              <span className="font-medium">{item.title}</span>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              ))}
            </SidebarContent>

            <SidebarFooter className="border-t border-slate-200/60 p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-sm">{user?.full_name?.charAt(0) || 'U'}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-900 text-sm truncate">{user?.full_name || 'User'}</p>
                  <p className="text-xs text-slate-500 truncate capitalize">{user?.role || 'User'}</p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="w-full text-slate-600 hover:text-slate-900"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col">
            <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200/60 px-6 py-4 md:hidden">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
                <h1 className="text-xl font-semibold text-slate-900">Nepbourne FC</h1>
              </div>
            </header>

            <div className="flex-1 overflow-auto">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    );
  }

  // Render Member/Player/Lead/Executive Portal Layout for non-admin users
  if (user && user.role !== 'admin') {
    const portalDetails = {
        'ExecutivePortal': 'Executive Portal',
        'PlayerPortal': 'Player Portal',
        'Communications': 'Member Portal',
        'SocialGames': 'Social Games'
    };
    const portalTitle = portalDetails[currentPageName] || "Portal";
    
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
        <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200/60 px-6 py-4">
          <div className="flex justify-between items-center max-w-7xl mx-auto">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 text-lg">Nepbourne FC</h2>
                <p className="text-xs text-slate-500 font-medium">{portalTitle}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {availablePortals.length > 1 && (
                  <PortalSwitcher portals={availablePortals} currentPage={currentPageName} />
              )}
              <div className="text-right">
                <p className="font-medium text-slate-900 text-sm truncate">{user?.full_name || 'User'}</p>
                <p className="text-xs text-slate-500 truncate capitalize">Welcome</p>
              </div>
               <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="text-slate-600 hover:text-slate-900"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    );
  }

  // Fallback for any other case (should not be reached if logic is correct and loading is handled)
  return null;
}

