
import React, { useState, useEffect } from "react";
import { ContractTemplate, GeneratedContract, SponsorshipApplication, Season, Player, MembershipApplication } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Handshake, UserCheck, FileText, Send, Plus, ClipboardList } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from 'sonner';
import { format } from 'date-fns';

import ContractTemplateForm from "../components/contracts/ContractTemplateForm";
import SendContractModal from "../components/contracts/SendContractModal";

export default function ContractsPage() {
  const [templates, setTemplates] = useState([]);
  const [generatedContracts, setGeneratedContracts] = useState([]);
  const [applications, setApplications] = useState([]);
  const [membershipApplications, setMembershipApplications] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showTemplateForm, setShowTemplateForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [selectedTemplateForSending, setSelectedTemplateForSending] = useState(null);
  const [activeSeason, setActiveSeason] = useState(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [templatesData, contractsData, appsData, playersData, memAppsData, seasonsData] = await Promise.all([
        ContractTemplate.list('-created_date'),
        GeneratedContract.list('-created_date'), // Load ALL contracts
        SponsorshipApplication.list('-created_date'),
        Player.list('-created_date'),
        MembershipApplication.list('-created_date'),
        Season.filter({ status: 'Active' })
      ]);
      
      console.log('Loaded contracts:', contractsData); // Debug log
      
      setTemplates(templatesData);
      setGeneratedContracts(contractsData);
      setApplications(appsData);
      setPlayers(playersData);
      setMembershipApplications(memAppsData);
      
      if (seasonsData.length > 0) {
        setActiveSeason(seasonsData[0]);
      } else {
        toast.error("No active season found. Please set an active season in Teams > Season Setup.");
      }
    } catch (error) {
      console.error("Error loading contracts data:", error);
      toast.error("Failed to load contracts data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleFormSubmit = async (formData) => {
    try {
      if (editingTemplate) {
        await ContractTemplate.update(editingTemplate.id, formData);
        toast.success("Contract template updated successfully!");
      } else {
        await ContractTemplate.create(formData);
        toast.success("Contract template created successfully!");
      }
      setShowTemplateForm(false);
      setEditingTemplate(null);
      loadData();
    } catch (error) {
      console.error("Error saving contract template:", error);
      toast.error("Failed to save contract template.");
    }
  };

  const handleEdit = (template) => {
    setEditingTemplate(template);
    setShowTemplateForm(true);
  };

  const handleSendContract = (template) => {
    setSelectedTemplateForSending(template);
    setIsSendModalOpen(true);
  };

  const sponsorshipTemplates = templates.filter(t => t.contract_type === 'sponsorship');
  const playerTemplates = templates.filter(t => t.contract_type === 'player');
  const membershipTemplates = templates.filter(t => t.contract_type === 'membership');

  // Filter contracts by type - only show contracts that have been sent (not drafts)
  const sponsorshipContracts = generatedContracts.filter(c => 
    c.application_type === 'sponsorship' && c.status !== 'draft'
  );
  const playerContracts = generatedContracts.filter(c => 
    c.application_type === 'player' && c.status !== 'draft'
  );
  const membershipContracts = generatedContracts.filter(c => 
    c.application_type === 'membership' && c.status !== 'draft'
  );

  const renderTemplateList = (templateList, title) => (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {templateList.length > 0 ? (
          <ul className="space-y-3">
            {templateList.map(template => (
              <li key={template.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                <div className="flex-1">
                  <p className="font-semibold">{template.name}</p>
                  <p className="text-sm text-slate-500">{template.description}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(template)}>
                    Edit
                  </Button>
                  <Button size="sm" onClick={() => handleSendContract(template)}>
                    <Send className="w-4 h-4 mr-2" />
                    Send
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        ) : <p className="text-slate-500 text-center py-4">No templates of this type.</p>}
      </CardContent>
    </Card>
  );

  const getContractIdentifier = (contract) => {
    // For sponsorship contracts
    if (contract.application_type === 'sponsorship') {
      const app = applications.find(a => a.id === contract.application_id);
      return app?.company_name || contract.sent_to_name || 'Unknown Sponsor';
    }
    
    // For player contracts
    if (contract.application_type === 'player') {
      const player = players.find(p => p.id === contract.application_id);
      return player ? `${player.first_name} ${player.last_name}` : contract.sent_to_name || 'Unknown Player';
    }
    
    // For membership contracts
    if (contract.application_type === 'membership') {
      const memApp = membershipApplications.find(a => a.id === contract.application_id);
      return memApp ? `${memApp.first_name} ${memApp.last_name}` : contract.sent_to_name || 'Unknown Member';
    }
    
    return contract.sent_to_name || 'Unknown Recipient';
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      sent: { color: 'bg-blue-100 text-blue-800', label: 'Sent' },
      viewed: { color: 'bg-yellow-100 text-yellow-800', label: 'Viewed' },
      signed: { color: 'bg-green-100 text-green-800', label: 'Signed' },
      completed: { color: 'bg-green-100 text-green-800', label: 'Completed' },
      draft: { color: 'bg-gray-100 text-gray-800', label: 'Draft' }
    };
    
    const config = statusConfig[status] || { color: 'bg-gray-100 text-gray-800', label: status };
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  const getContractViewUrl = (contract) => {
    if (contract.application_type === 'sponsorship') {
      return `/SignSponsorshipContract?contractId=${contract.id}`;
    }
    if (contract.application_type === 'player') {
      return `/SignPlayerContract?contractId=${contract.id}`;
    }
    if (contract.application_type === 'membership') {
      return `/SignMembershipContract?contractId=${contract.id}`;
    }
    return '#';
  };
    
  const renderContractList = (contractList, type) => {
    console.log(`Rendering ${type} contracts:`, contractList); // Debug log
    
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Sent Contracts ({contractList.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {contractList.length > 0 ? (
            <div className="space-y-2">
              {contractList.map(contract => (
                <div key={contract.id} className="flex justify-between items-center p-2 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-sm truncate">{getContractIdentifier(contract)}</p>
                      {getStatusBadge(contract.status)}
                    </div>
                    <div className="text-xs text-slate-500 space-y-0.5">
                      <p>Sent: {format(new Date(contract.created_date), 'd MMM yyyy')} • {contract.sent_to_email}</p>
                      {contract.season_name && <p>Season: {contract.season_name}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-2">
                    <Button variant="outline" size="sm" asChild className="h-8 px-3 text-xs">
                      <a href={getContractViewUrl(contract)} target="_blank" rel="noopener noreferrer">
                        View
                      </a>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-500 text-sm">No contracts have been sent yet.</p>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  if (loading) return <div className="p-6 text-center">Loading...</div>;

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Contract Management</h1>
            <p className="text-slate-600">Create and manage contract templates, and track sent contracts.</p>
          </div>
          <Button 
            onClick={() => {
              setEditingTemplate(null);
              setShowTemplateForm(true);
            }}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Contract Template
          </Button>
        </div>

        {showTemplateForm && (
          <ContractTemplateForm
            template={editingTemplate}
            onSubmit={handleFormSubmit}
            onCancel={() => { setShowTemplateForm(false); setEditingTemplate(null); }}
          />
        )}
        
        <Tabs defaultValue="sponsorship" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="sponsorship">
              <Handshake className="w-4 h-4 mr-2"/>
              Sponsorship Contracts ({sponsorshipContracts.length})
            </TabsTrigger>
            <TabsTrigger value="player">
              <UserCheck className="w-4 h-4 mr-2"/>
              Player Contracts ({playerContracts.length})
            </TabsTrigger>
            <TabsTrigger value="membership">
              <ClipboardList className="w-4 h-4 mr-2"/>
              Membership Contracts ({membershipContracts.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="sponsorship" className="pt-6">
             <div className="grid md:grid-cols-2 gap-6">
               {renderTemplateList(sponsorshipTemplates, "Sponsorship Templates")}
               {renderContractList(sponsorshipContracts, 'sponsorship')}
             </div>
          </TabsContent>
          
          <TabsContent value="player" className="pt-6">
             <div className="grid md:grid-cols-2 gap-6">
              {renderTemplateList(playerTemplates, "Player Templates")}
              {renderContractList(playerContracts, 'player')}
             </div>
          </TabsContent>
          
          <TabsContent value="membership" className="pt-6">
             <div className="grid md:grid-cols-2 gap-6">
              {renderTemplateList(membershipTemplates, "Membership Templates")}
              {renderContractList(membershipContracts, 'membership')}
             </div>
          </TabsContent>
        </Tabs>

        {isSendModalOpen && (
          <SendContractModal
            isOpen={isSendModalOpen}
            onClose={() => setIsSendModalOpen(false)}
            template={selectedTemplateForSending}
            sponsorshipApplications={applications}
            membershipApplications={membershipApplications}
            players={players}
            allContracts={generatedContracts}
            activeSeason={activeSeason}
            onContractSent={loadData}
          />
        )}
      </div>
    </div>
  );
}
