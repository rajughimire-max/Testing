import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { ExecutiveMember, Member, Player } from '@/api/entities';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Plus, Crown, Users, History } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import ExecutiveMemberForm from '../components/executive/ExecutiveMemberForm';
import ExecutiveMemberList from '../components/executive/ExecutiveMemberList';

export default function ExecutiveTeam() {
    const [leadership, setLeadership] = useState([]);
    const [members, setMembers] = useState([]);
    const [players, setPlayers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingExecutive, setEditingExecutive] = useState(null);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [execData, memberData, playerData] = await Promise.all([
                ExecutiveMember.list('-appointment_date'),
                Member.list(),
                Player.list()
            ]);

            const populatedExecutives = execData.map(exec => {
                let person = null;
                if (exec.member_id) {
                    person = memberData.find(m => m.id === exec.member_id);
                } else if (exec.player_id) {
                    person = playerData.find(p => p.id === exec.player_id);
                }

                return {
                    ...exec,
                    person_name: person ? `${person.first_name} ${person.last_name}` : 'Unknown Person',
                    person_email: person?.email,
                    person_photo: person?.profile_photo_url || person?.photo_url,
                    person_type: exec.player_id ? 'Player' : 'Member',
                    is_core_only: false, // This is a formal executive role
                };
            });

            // Get IDs of people who are already formal executives
            const executivePersonIds = new Set([
                ...execData.map(e => e.member_id),
                ...execData.map(e => e.player_id)
            ].filter(Boolean));

            // Find Core Members (from Members) who are not already executives
            const coreMembers = memberData
                .filter(m => m.is_core_member && !executivePersonIds.has(m.id))
                .map(m => ({
                    id: m.id, // Use the member's ID as the key
                    person_name: `${m.first_name} ${m.last_name}`,
                    person_email: m.email,
                    person_photo: m.photo_url,
                    person_type: 'Member',
                    position: 'Core Member',
                    status: 'Active',
                    is_core_only: true, // Flag to identify them in the UI
                }));

            // Find Core Members (from Players) who are not already executives
            const corePlayers = playerData
                .filter(p => p.is_core_member && !executivePersonIds.has(p.id))
                .map(p => ({
                    id: p.id, // Use the player's ID as the key
                    person_name: `${p.first_name} ${p.last_name}`,
                    person_email: p.email,
                    person_photo: p.profile_photo_url,
                    person_type: 'Player',
                    position: 'Core Member',
                    status: 'Active',
                    is_core_only: true,
                }));
            
            const combinedLeadership = [...populatedExecutives, ...coreMembers, ...corePlayers];

            setLeadership(combinedLeadership);
            setMembers(memberData);
            setPlayers(playerData);
        } catch (error) {
            toast.error('Failed to load leadership team data.');
            console.error(error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadData();
    }, [loadData]);

    // Expose reloadData globally so other components can call it
    useEffect(() => {
        window.reloadExecutiveTeamData = loadData;
        return () => {
            delete window.reloadExecutiveTeamData;
        };
    }, [loadData]);

    const handleFormSubmit = async (formData) => {
        try {
            if (editingExecutive) {
                await ExecutiveMember.update(editingExecutive.id, formData);
                toast.success('Executive member updated successfully.');
            } else {
                await ExecutiveMember.create(formData);
                toast.success('New executive member added successfully.');
            }
            setIsFormOpen(false);
            setEditingExecutive(null);
            loadData();
        } catch (error) {
            toast.error(`Failed to ${editingExecutive ? 'update' : 'add'} executive member.`);
            console.error(error);
        }
    };

    const handleEdit = (executive) => {
        setEditingExecutive(executive);
        setIsFormOpen(true);
        window.scrollTo(0, 0);
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to remove this executive member from their position? This cannot be undone.')) {
            try {
                await ExecutiveMember.delete(id);
                toast.success('Executive member removed.');
                loadData();
            } catch (error) {
                toast.error('Failed to remove executive member.');
                console.error(error);
            }
        }
    };

    const handleCancel = () => {
        setIsFormOpen(false);
        setEditingExecutive(null);
    };

    const activeLeadership = useMemo(() => leadership.filter(e => e.status === 'Active'), [leadership]);
    const pastLeadership = useMemo(() => leadership.filter(e => e.status !== 'Active' && !e.is_core_only), [leadership]);

    return (
        <div className="p-6 md:p-10">
            <header className="flex flex-col md:flex-row justify-between md:items-center mb-8 gap-4">
                <div className="space-y-1">
                    <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3"><Crown className="w-8 h-8 text-blue-600" />Leadership Team</h1>
                    <p className="text-slate-500">Manage your club's leadership, including executives and core decision-making members.</p>
                </div>
                {!isFormOpen && (
                    <Button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2">
                        <Plus className="w-5 h-5" /> Add Executive Role
                    </Button>
                )}
            </header>

            {isFormOpen && (
                <ExecutiveMemberForm
                    executive={editingExecutive}
                    members={members}
                    players={players}
                    onSubmit={handleFormSubmit}
                    onCancel={handleCancel}
                />
            )}

            <Tabs defaultValue="active" className="w-full">
                <TabsList className="mb-6">
                    <TabsTrigger value="active"><Users className="w-4 h-4 mr-2" />Active Members ({activeLeadership.length})</TabsTrigger>
                    <TabsTrigger value="past"><History className="w-4 h-4 mr-2" />Past Executives ({pastLeadership.length})</TabsTrigger>
                </TabsList>
                <TabsContent value="active">
                    <ExecutiveMemberList
                        executives={activeLeadership}
                        loading={loading}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                    />
                </TabsContent>
                <TabsContent value="past">
                    <ExecutiveMemberList
                        executives={pastLeadership}
                        loading={loading}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                        isPast={true}
                    />
                </TabsContent>
            </Tabs>
        </div>
    );
}