
import React, { useState, useEffect } from 'react';
import { WebsiteContent, NewsArticle } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Save, Upload, Eye, Palette, Settings, Image as ImageIcon, Plus, Edit, Trash2 } from 'lucide-react';
import { UploadFile } from "@/api/integrations";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

import { toast } from 'sonner';
import NewsPostList from '../components/news/NewsPostList';

export default function WebsiteSettings() {
  const [content, setContent] = useState(null);
  const [heroSlides, setHeroSlides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingHero, setUploadingHero] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [showSlideForm, setShowSlideForm] = useState(false);
  const [editingSlide, setEditingSlide] = useState(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [contentData, slidesData] = await Promise.all([
        WebsiteContent.list().then(res => res[0] || {}),
        // Assuming NewsArticle is used for hero slides, as per current implementation
        NewsArticle.list('-created_date') 
      ]);
      setContent(contentData);
      setHeroSlides(slidesData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleChange = (field, value) => {
    setContent(prev => ({ ...prev, [field]: value }));
  };

  const handleHeroUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploadingHero(true);
    try {
      const { file_url } = await UploadFile({ file });
      handleChange('hero_image_url', file_url);
    } catch (error) {
      console.error("File upload failed:", error);
    } finally {
      setUploadingHero(false);
    }
  };
  
  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploadingLogo(true);
    try {
      const { file_url } = await UploadFile({ file });
      handleChange('club_logo_url', file_url);
    } catch (error) {
      console.error("Logo upload failed:", error);
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (content.id) {
        await WebsiteContent.update(content.id, content);
      } else {
        await WebsiteContent.create(content);
      }
      toast.success("Website settings saved successfully!");
    } catch (error) {
      console.error("Error saving content:", error);
      toast.error("Failed to save website settings.");
    } finally {
      setSaving(false);
    }
  };

  const handleSlideSubmit = async (slideData) => {
    try {
      if (editingSlide) {
        await NewsArticle.update(editingSlide.id, slideData);
        toast.success("Hero slide updated successfully!");
      } else {
        await NewsArticle.create(slideData);
        toast.success("Hero slide created successfully!");
      }
      setShowSlideForm(false);
      setEditingSlide(null);
      loadData();
    } catch (error) {
      console.error("Error saving slide:", error);
      toast.error("Failed to save hero slide.");
    }
  };

  const handleDeleteSlide = async (slideId) => {
    if (window.confirm("Are you sure you want to delete this hero slide?")) {
      try {
        await NewsArticle.delete(slideId);
        loadData();
        toast.success("Hero slide deleted successfully!");
      } catch (error) {
        console.error("Error deleting slide:", error);
        toast.error("Failed to delete hero slide.");
      }
    }
  };

  if (loading) {
    return (
      <div className="p-8 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-slate-200 rounded w-1/3"></div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="h-32 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
            <div className="h-12 bg-slate-200 rounded-xl w-full"></div>
            <div className="h-96 bg-slate-200 rounded-xl w-full"></div>
          </div>
        </div>
      </div>
    );
  }

  const tabTriggerClass = "flex-grow sm:flex-grow-0 text-center px-4 py-2.5 text-sm font-semibold rounded-md data-[state=active]:bg-white data-[state=active]:text-red-600 data-[state=active]:shadow-md transition-all duration-200";

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Enhanced Header */}
        <div className="mb-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h1 className="text-4xl font-bold text-slate-900 mb-2">Website Management</h1>
              <p className="text-slate-600 text-lg">Control your club's online presence</p>
            </div>
            <div className="flex gap-3">
              <Link to={createPageUrl('Home')} target="_blank">
                <Button variant="outline" size="lg" className="border-2">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview Website
                </Button>
              </Link>
              <Button onClick={handleSave} disabled={saving} size="lg" className="bg-red-600 hover:bg-red-700">
                <Save className="w-4 h-4 mr-2" />
                {saving ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>

          {/* Quick Stats Dashboard */}
          <div className="grid grid-cols-2 md:grid-cols-2 gap-4 mb-6">
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-4 text-center">
                <ImageIcon className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-900">{heroSlides.length}</div>
                <div className="text-sm text-purple-700">Hero Slides</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
              <CardContent className="p-4 text-center">
                <Settings className="w-8 h-8 text-red-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-red-900">
                  {content?.is_published ? 'Live' : 'Draft'}
                </div>
                <div className="text-sm text-red-700">Website Status</div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="content" className="space-y-6">
          <TabsList className="h-auto flex flex-wrap justify-start items-center gap-1 p-1 bg-slate-200/60 rounded-lg">
            <TabsTrigger value="content" className={tabTriggerClass}>Website Content</TabsTrigger>
            <TabsTrigger value="hero" className={tabTriggerClass}>Hero Slides</TabsTrigger>
            <TabsTrigger value="sections" className={tabTriggerClass}>Page Sections</TabsTrigger>
            <TabsTrigger value="news" className={tabTriggerClass}>News</TabsTrigger>
            <TabsTrigger value="theme" className={tabTriggerClass}>Branding</TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Website Publication
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="is_published" className="text-base font-semibold">Website Status</Label>
                    <p className="text-sm text-slate-600">Control whether your website is publicly visible</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Switch 
                      id="is_published" 
                      checked={content.is_published} 
                      onCheckedChange={checked => handleChange('is_published', checked)} 
                    />
                    <Badge className={content.is_published ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                      {content.is_published ? 'Published' : 'Draft'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Brand Logo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="w-5 h-5" />
                  Brand & Logo
                </CardTitle>
                <CardDescription>Manage your club's logo, which appears in the website header.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="club_logo_url">Club Logo</Label>
                  <div className="flex items-center gap-4">
                    <Input
                      id="club_logo_url"
                      value={content.club_logo_url || ''}
                      readOnly
                      placeholder="Upload a logo image"
                      className="flex-1"
                    />
                    <Button asChild variant="outline" disabled={uploadingLogo}>
                      <label htmlFor="logo-upload" className="cursor-pointer">
                        <Upload className="w-4 h-4 mr-2" />
                        {uploadingLogo ? "Uploading..." : "Upload Logo"}
                      </label>
                    </Button>
                    <input
                      id="logo-upload"
                      type="file"
                      className="hidden"
                      onChange={handleLogoUpload}
                      accept="image/*"
                    />
                  </div>
                  {content.club_logo_url && (
                    <div className="mt-4 p-4 bg-slate-100 rounded-lg inline-block">
                      <img
                        src={content.club_logo_url}
                        alt="Logo preview"
                        className="object-contain h-24"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>


            {/* Hero Section */}
            <Card>
              <CardHeader>
                <CardTitle>Hero Section</CardTitle>
                <CardDescription>The main banner that visitors see first</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="hero_title">Main Title</Label>
                    <Input 
                      id="hero_title" 
                      value={content.hero_title || ''} 
                      onChange={e => handleChange('hero_title', e.target.value)} 
                      placeholder="NEPBOURNE FC"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hero_subtitle">Subtitle</Label>
                    <Input 
                      id="hero_subtitle" 
                      value={content.hero_subtitle || ''} 
                      onChange={e => handleChange('hero_subtitle', e.target.value)} 
                      placeholder="Excellence • Unity • Victory"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hero_image_url">Background Image</Label>
                  <div className="flex items-center gap-4">
                    <Input 
                      id="hero_image_url" 
                      value={content.hero_image_url || ''} 
                      readOnly 
                      placeholder="Upload an image" 
                      className="flex-1"
                    />
                    <Button asChild variant="outline" disabled={uploadingHero}>
                      <label htmlFor="hero-image-upload" className="cursor-pointer">
                        <Upload className="w-4 h-4 mr-2" />
                        {uploadingHero ? "Uploading..." : "Upload"}
                      </label>
                    </Button>
                    <input 
                      id="hero-image-upload" 
                      type="file" 
                      className="hidden" 
                      onChange={handleHeroUpload} 
                      accept="image/*" 
                    />
                  </div>
                  {content.hero_image_url && (
                    <img 
                      src={content.hero_image_url} 
                      alt="Hero preview" 
                      className="mt-4 rounded-lg object-cover h-48 w-full" 
                    />
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Welcome Section */}
            <Card>
              <CardHeader>
                <CardTitle>Welcome Section</CardTitle>
                <CardDescription>About your club message</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="welcome_title">Welcome Title</Label>
                  <Input 
                    id="welcome_title" 
                    value={content.welcome_title || ''} 
                    onChange={e => handleChange('welcome_title', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="welcome_text">Welcome Message</Label>
                  <Textarea 
                    id="welcome_text" 
                    value={content.welcome_text || ''} 
                    onChange={e => handleChange('welcome_text', e.target.value)} 
                    rows={5} 
                  />
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>Displayed in the website footer</CardDescription>
              </CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="contact_email">Contact Email</Label>
                  <Input 
                    id="contact_email" 
                    value={content.contact_email || ''} 
                    onChange={e => handleChange('contact_email', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact_phone">Contact Phone</Label>
                  <Input 
                    id="contact_phone" 
                    value={content.contact_phone || ''} 
                    onChange={e => handleChange('contact_phone', e.target.value)} 
                  />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="contact_address">Address</Label>
                  <Input 
                    id="contact_address" 
                    value={content.contact_address || ''} 
                    onChange={e => handleChange('contact_address', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="facebook_url">Facebook URL</Label>
                  <Input 
                    id="facebook_url" 
                    value={content.facebook_url || ''} 
                    onChange={e => handleChange('facebook_url', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="instagram_url">Instagram URL</Label>
                  <Input 
                    id="instagram_url" 
                    value={content.instagram_url || ''} 
                    onChange={e => handleChange('instagram_url', e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="twitter_url">Twitter/X URL</Label>
                  <Input 
                    id="twitter_url" 
                    value={content.twitter_url || ''} 
                    onChange={e => handleChange('twitter_url', e.target.value)} 
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="hero" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-semibold">Hero Carousel Slides</h3>
                <p className="text-sm text-slate-600">Manage the sliding images on your homepage</p>
              </div>
              <Button onClick={() => { setEditingSlide(null); setShowSlideForm(true); }} className="bg-red-600 hover:bg-red-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Slide
              </Button>
            </div>

            {showSlideForm && (
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>{editingSlide ? 'Edit' : 'Add'} Hero Slide</CardTitle>
                </CardHeader>
                <CardContent>
                  <HeroSlideForm 
                    slide={editingSlide}
                    onSubmit={handleSlideSubmit}
                    onCancel={() => { setShowSlideForm(false); setEditingSlide(null); }}
                  />
                </CardContent>
              </Card>
            )}

            <div className="grid md:grid-cols-2 gap-6">
              {heroSlides.map(slide => (
                <Card key={slide.id} className="bg-white/80 backdrop-blur-sm border-slate-200/60 overflow-hidden">
                  <div className="relative h-48">
                    {slide.content_type === 'video' && slide.video_url ? (
                       <div className="w-full h-full bg-black flex items-center justify-center">
                         <p className="text-white text-sm">Video content not directly previewable here</p>
                       </div>
                    ) : (
                      <img src={slide.image_url} alt={slide.title} className="w-full h-full object-cover" />
                    )}
                    
                    <div className="absolute top-2 right-2 flex gap-2">
                      <Button size="sm" variant="secondary" onClick={() => { setEditingSlide(slide); setShowSlideForm(true); }}>
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button size="sm" variant="secondary" onClick={() => handleDeleteSlide(slide.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                    {slide.is_hero_slide && (
                      <Badge className="absolute bottom-2 left-2 bg-green-600">Active Slide</Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h4 className="font-semibold">{slide.title}</h4>
                    <p className="text-sm text-slate-600 truncate">{slide.subtitle}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className={slide.status === 'published' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {slide.status}
                      </Badge>
                      {slide.content_type && (
                         <Badge variant="outline" className="capitalize">
                           {slide.content_type}
                         </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="sections" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Homepage Sections</CardTitle>
                <CardDescription>Choose which sections to display on your homepage</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_teams">Show Our Teams</Label>
                    <Switch 
                      id="show_teams" 
                      checked={content.show_teams} 
                      onCheckedChange={checked => handleChange('show_teams', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_players">Show Star Players</Label>
                    <Switch 
                      id="show_players" 
                      checked={content.show_players} 
                      onCheckedChange={checked => handleChange('show_players', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_upcoming_matches">Show Upcoming Matches</Label>
                    <Switch 
                      id="show_upcoming_matches" 
                      checked={content.show_upcoming_matches} 
                      onCheckedChange={checked => handleChange('show_upcoming_matches', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_events">Show Club Events</Label>
                    <Switch 
                      id="show_events" 
                      checked={content.show_events} 
                      onCheckedChange={checked => handleChange('show_events', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_training">Show Training Schedule</Label>
                    <Switch 
                      id="show_training" 
                      checked={content.show_training} 
                      onCheckedChange={checked => handleChange('show_training', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_merchandise">Show Club Store</Label>
                    <Switch 
                      id="show_merchandise" 
                      checked={content.show_merchandise} 
                      onCheckedChange={checked => handleChange('show_merchandise', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_sponsors">Show Sponsors</Label>
                    <Switch 
                      id="show_sponsors" 
                      checked={content.show_sponsors} 
                      onCheckedChange={checked => handleChange('show_sponsors', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_news">Show Latest News</Label>
                    <Switch 
                      id="show_news" 
                      checked={content.show_news} 
                      onCheckedChange={checked => handleChange('show_news', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_members">Show Club Members</Label>
                    <Switch 
                      id="show_members" 
                      checked={content.show_members} 
                      onCheckedChange={checked => handleChange('show_members', checked)} 
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show_social_games">Show Social Games</Label>
                    <Switch 
                      id="show_social_games" 
                      checked={content.show_social_games} 
                      onCheckedChange={checked => handleChange('show_social_games', checked)} 
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="news">
            <NewsPostList />
          </TabsContent>

          <TabsContent value="theme" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="w-5 h-5" />
                  Brand Colors
                </CardTitle>
                <CardDescription>Customize your website's color scheme</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="theme_primary_color">Primary Color</Label>
                    <div className="flex gap-3">
                      <Input 
                        id="theme_primary_color" 
                        type="color" 
                        value={content.theme_primary_color || '#dc2626'} 
                        onChange={e => handleChange('theme_primary_color', e.target.value)}
                        className="w-16 h-12"
                      />
                      <Input 
                        value={content.theme_primary_color || '#dc2626'} 
                        onChange={e => handleChange('theme_primary_color', e.target.value)}
                        placeholder="#dc2626"
                        className="flex-1"
                      />
                    </div>
                    <p className="text-sm text-slate-500">Used for buttons, links, and accents</p>
                  </div>
                  <div className="space-y-3">
                    <Label htmlFor="theme_secondary_color">Secondary Color</Label>
                    <div className="flex gap-3">
                      <Input 
                        id="theme_secondary_color" 
                        type="color" 
                        value={content.theme_secondary_color || '#1e293b'} 
                        onChange={e => handleChange('theme_secondary_color', e.target.value)}
                        className="w-16 h-12"
                      />
                      <Input 
                        value={content.theme_secondary_color || '#1e293b'} 
                        onChange={e => handleChange('theme_secondary_color', e.target.value)}
                        placeholder="#1e293b"
                        className="flex-1"
                      />
                    </div>
                    <p className="text-sm text-slate-500">Used for headers and dark sections</p>
                  </div>
                </div>
                
                {/* Color Preview */}
                <div className="p-6 rounded-lg border-2 border-slate-200" style={{
                  background: `linear-gradient(135deg, ${content.theme_primary_color || '#dc2626'}15, ${content.theme_secondary_color || '#1e293b'}15)`
                }}>
                  <h3 className="font-bold text-lg mb-2" style={{color: content.theme_secondary_color || '#1e293b'}}>
                    Color Preview
                  </h3>
                  <p className="text-slate-600 mb-4">This is how your colors will look on the website</p>
                  <Button style={{
                    backgroundColor: content.theme_primary_color || '#dc2626',
                    borderColor: content.theme_primary_color || '#dc2626'
                  }}>
                    Sample Button
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Hero Slide Form Component
const HeroSlideForm = ({ slide, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState(slide || {
    title: '',
    subtitle: '',
    content_type: 'video', // Default to video first
    image_url: '',
    video_url: '',
    link_url: '',
    link_text: 'Learn More',
    is_hero_slide: true,
    status: 'published'
  });
  const [uploading, setUploading] = useState(false);

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({ ...prev, image_url: file_url, video_url: '' })); // Clear video URL when image is uploaded
      toast.success("Image uploaded successfully!");
    } catch (error) {
      console.error("File upload failed:", error);
      toast.error("Failed to upload image.");
    } finally {
      setUploading(false);
    }
  };

  const handleVideoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({ ...prev, video_url: file_url, image_url: '' })); // Clear image URL when video is uploaded
      toast.success("Video uploaded successfully!");
    } catch (error) {
      console.error("Video upload failed:", error);
      toast.error("Failed to upload video.");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input 
            id="title"
            value={formData.title} 
            onChange={e => setFormData(prev => ({...prev, title: e.target.value}))} 
            placeholder="Enter slide title"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="subtitle">Subtitle</Label>
          <Input 
            id="subtitle"
            value={formData.subtitle} 
            onChange={e => setFormData(prev => ({...prev, subtitle: e.target.value}))} 
            placeholder="Enter slide subtitle"
          />
        </div>
      </div>

      {/* Content Type Selection - Video First */}
      <div className="space-y-2">
        <Label>Content Type</Label>
        <div className="flex gap-4">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="content_type"
              value="video"
              checked={formData.content_type === 'video'}
              onChange={e => setFormData(prev => ({...prev, content_type: e.target.value, image_url: ''}))}
              className="w-4 h-4 text-red-600 border-gray-300 focus:ring-red-500"
            />
            Video
          </label>
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="content_type"
              value="image"
              checked={formData.content_type === 'image'}
              onChange={e => setFormData(prev => ({...prev, content_type: e.target.value, video_url: ''}))}
              className="w-4 h-4 text-red-600 border-gray-300 focus:ring-red-500"
            />
            Image
          </label>
        </div>
      </div>

      {/* Video Upload Section - Now First */}
      {formData.content_type === 'video' && (
        <div className="space-y-2">
          <Label htmlFor="video_url">Hero Video</Label>
          <div className="flex items-center gap-4">
            <Input 
              id="video_url"
              value={formData.video_url} 
              onChange={e => setFormData(prev => ({...prev, video_url: e.target.value}))} 
              placeholder="Upload a video or paste YouTube/Vimeo URL"
              className="flex-1"
            />
            <Button asChild variant="outline" disabled={uploading} type="button">
              <label htmlFor="video-upload" className="cursor-pointer">
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? "Uploading..." : "Upload Video"}
              </label>
            </Button>
            <input 
              id="video-upload" 
              type="file" 
              className="hidden" 
              onChange={handleVideoUpload} 
              accept="video/mp4,video/webm,video/ogg" 
            />
          </div>
          <p className="text-xs text-slate-500">
            Upload MP4/WebM files or paste YouTube/Vimeo URLs.
          </p>
          {formData.video_url && (
            <div className="mt-4 bg-slate-100 p-3 rounded">
              <p className="text-sm text-slate-700 break-words">Video source: {formData.video_url}</p>
            </div>
          )}
        </div>
      )}

      {/* Image Upload Section */}
      {formData.content_type === 'image' && (
        <div className="space-y-2">
          <Label htmlFor="image_url">Hero Image</Label>
          <div className="flex items-center gap-4">
            <Input 
              id="image_url"
              value={formData.image_url} 
              readOnly // Made readOnly as it's populated by upload or cleared
              placeholder="Upload an image" 
              className="flex-1"
            />
            <Button asChild variant="outline" disabled={uploading} type="button">
              <label htmlFor="image-upload" className="cursor-pointer">
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? "Uploading..." : "Upload Image"}
              </label>
            </Button>
            <input 
              id="image-upload" 
              type="file" 
              className="hidden" 
              onChange={handleImageUpload} 
              accept="image/*" 
            />
          </div>
          {formData.image_url && (
            <img 
              src={formData.image_url} 
              alt="Preview" 
              className="mt-4 rounded-lg object-cover h-32 w-full" 
            />
          )}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="link_url">Link URL (optional)</Label>
          <Input 
            id="link_url"
            value={formData.link_url} 
            onChange={e => setFormData(prev => ({...prev, link_url: e.target.value}))} 
            placeholder="e.g., /Squad or /MembershipSignup"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="link_text">Button Text</Label>
          <Input 
            id="link_text"
            value={formData.link_text} 
            onChange={e => setFormData(prev => ({...prev, link_text: e.target.value}))} 
            placeholder="e.g., Learn More, Join Now"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="is_hero_slide"
            checked={formData.is_hero_slide}
            onChange={e => setFormData(prev => ({...prev, is_hero_slide: e.target.checked}))}
            className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
          />
          <Label htmlFor="is_hero_slide">Show in Hero Carousel</Label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="is_published"
            checked={formData.status === 'published'}
            onChange={e => setFormData(prev => ({...prev, status: e.target.checked ? 'published' : 'draft'}))}
            className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
          />
          <Label htmlFor="is_published">Published</Label>
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-red-600 hover:bg-red-700">
          {slide ? 'Update Slide' : 'Create Slide'}
        </Button>
      </div>
    </form>
  );
};
