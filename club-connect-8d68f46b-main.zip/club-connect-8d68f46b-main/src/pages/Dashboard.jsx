
import React, { useState, useEffect } from "react";
import { Member, Team, Match, Event, InventoryItem, Player, FinancialTransaction, WebsiteContent } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Shield, Trophy, Calendar, Package, TrendingUp, Activity, UserCheck, DollarSign, TrendingDown, Award, Star, Target, Zap } from "lucide-react";
import { format, isThisMonth } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import StatsCard from "../components/dashboard/StatsCard";
import RecentActivity from "../components/dashboard/RecentActivity";
import UpcomingMatches from "../components/dashboard/UpcomingMatches";
import EquipmentAuditLog from "../components/dashboard/EquipmentAuditLog";

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalMembers: 0,
    totalPlayers: 0,
    activeTeams: 0,
    upcomingMatches: 0,
    thisMonthEvents: 0,
    totalInventory: 0,
    totalIncome: 0,
    totalExpenses: 0,
    netBalance: 0
  });
  const [recentData, setRecentData] = useState({
    members: [],
    matches: [],
    events: []
  });
  const [loading, setLoading] = useState(true);
  const [clubInfo, setClubInfo] = useState({ logoUrl: null });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [members, players, teams, matches, events, inventory, transactions, websiteContentData] = await Promise.all([
        Member.list("-created_date", 50),
        Player.list("-created_date", 50),
        Team.list("-created_date", 20),
        Match.list("-match_date", 20),
        Event.list("-event_date", 20),
        InventoryItem.list("-created_date", 50),
        FinancialTransaction.list("-date", 200),
        WebsiteContent.list().then(res => res[0] || {})
      ]);

      setClubInfo({ logoUrl: websiteContentData.club_logo_url });

      // Filter to only count ACTIVE, PAID members (not social game leads or incomplete records)
      const activePaidMembers = members.filter(member => {
        return member.membership_type_id && 
               member.payment_verified && 
               member.membership_status === 'active' &&
               member.membership_number; // Proper members should have membership numbers
      });

      // Calculate financial stats
      const income = transactions
        .filter(t => t.type === 'Income')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const expenses = transactions
        .filter(t => t.type === 'Expense')
        .reduce((sum, t) => sum + t.amount, 0);

      // Calculate other stats
      const upcomingMatchesCount = matches.filter(match => 
        new Date(match.match_date) > new Date() && match.match_status === 'scheduled'
      ).length;
      
      const thisMonthEvents = events.filter(event => 
        isThisMonth(new Date(event.event_date))
      ).length;

      const totalInventoryCount = inventory.reduce((sum, item) => sum + (item.quantity_on_hand || 0), 0);

      setStats({
        totalMembers: activePaidMembers.length, // Now shows only active paid memberships
        totalPlayers: players.length,
        activeTeams: teams.filter(team => team.status === 'active').length,
        upcomingMatches: upcomingMatchesCount,
        thisMonthEvents,
        totalInventory: totalInventoryCount,
        totalIncome: income,
        totalExpenses: expenses,
        netBalance: income - expenses
      });

      setRecentData({
        members: activePaidMembers.slice(0, 5), // Show only active members in recent activity
        matches: matches.slice(0, 5),
        events: events.slice(0, 5)
      });

    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      title: "Total Members",
      value: stats.totalMembers,
      icon: Users,
      trend: "Active memberships",
      gradient: "from-blue-500 to-blue-600",
      link: createPageUrl("Members")
    },
    {
      title: "Total Players",
      value: stats.totalPlayers,
      icon: UserCheck,
      trend: "Registered players",
      gradient: "from-emerald-500 to-emerald-600",
      link: createPageUrl("Players")
    },
    {
      title: "Total Income", 
      value: `$${stats.totalIncome.toLocaleString()}`,
      icon: TrendingUp,
      trend: "All time revenue",
      gradient: "from-green-500 to-green-600",
      link: createPageUrl("Finance")
    },
    {
      title: "Total Expenses",
      value: `$${stats.totalExpenses.toLocaleString()}`,
      icon: TrendingDown,
      trend: "All time spending",
      gradient: "from-red-500 to-red-600",
      link: createPageUrl("Finance")
    },
    {
      title: "Net Balance",
      value: `$${stats.netBalance.toLocaleString()}`,
      icon: DollarSign,
      trend: stats.netBalance >= 0 ? "Positive balance" : "Negative balance",
      gradient: stats.netBalance >= 0 ? "from-green-500 to-green-600" : "from-red-500 to-red-600",
      link: createPageUrl("Finance")
    },
    {
      title: "Active Teams", 
      value: stats.activeTeams,
      icon: Shield,
      trend: "Competition ready",
      gradient: "from-purple-500 to-purple-600",
      link: createPageUrl("Teams")
    },
    {
      title: "Upcoming Matches",
      value: stats.upcomingMatches,
      icon: Trophy,
      trend: "This month",
      gradient: "from-orange-500 to-orange-600",
      link: createPageUrl("Matches")
    },
    {
      title: "Total Inventory",
      value: stats.totalInventory,
      icon: Package,
      trend: "Equipment items",
      gradient: "from-indigo-500 to-indigo-600",
      link: createPageUrl("Inventory")
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/3 w-64 h-64 bg-red-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10 p-6 space-y-8">
        <div className="max-w-7xl mx-auto">
          {/* Enhanced Header */}
          <div className="mb-12 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-white/10 rounded-2xl shadow-lg border border-white/20">
                {clubInfo.logoUrl ? (
                  <img src={clubInfo.logoUrl} alt="Club Logo" className="w-12 h-12 object-contain" />
                ) : (
                  <div className="w-12 h-12 flex items-center justify-center">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                )}
              </div>
              <div className="text-left">
                <h1 className="text-4xl font-black text-white tracking-tight leading-none">
                  DASHBOARD
                </h1>
                <p className="text-lg text-blue-200 font-light">
                  Command Center for Nepbourne FC
                </p>
              </div>
            </div>
            
            {/* Time and Date Banner */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl px-4 py-3 flex items-center gap-4 border border-white/20 shrink-0">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-300" />
                <span className="text-white font-semibold text-sm">
                  {format(new Date(), 'EEEE, MMM d')}
                </span>
              </div>
              <div className="h-5 w-px bg-white/30"></div>
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-green-300 animate-pulse" />
                <span className="text-green-300 font-semibold text-sm">System Active</span>
              </div>
            </div>
          </div>

          {/* Enhanced Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-12">
            {statCards.map((stat, index) => (
              <Link to={stat.link || '#'} key={stat.title} className="block h-full">
                <div
                  className="group animate-in fade-in slide-in-from-bottom-4 duration-700 h-full"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <Card className="relative overflow-hidden bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-500 hover:scale-[1.03] hover:shadow-2xl hover:shadow-blue-500/25 h-full">
                    {/* Gradient Background */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-10 group-hover:opacity-20 transition-opacity duration-500`}></div>
                    
                    <CardHeader className="pb-3 relative z-10">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-medium text-blue-200 mb-2">{stat.title}</p>
                          <CardTitle className="text-3xl font-black text-white group-hover:scale-110 transition-transform duration-300">
                            {stat.value}
                          </CardTitle>
                        </div>
                        <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.gradient} shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:rotate-12`}>
                          <stat.icon className="w-6 h-6 text-white" />
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="relative z-10">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-blue-200">{stat.trend}</span>
                      </div>
                    </CardContent>

                    {/* Animated Border */}
                    <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  </Card>
                </div>
              </Link>
            ))}
          </div>

          {/* Enhanced Content Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {/* Achievement Section - Enhanced */}
            <div className="lg:col-span-2">
              <Card className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden relative">
                {/* Background Pattern */}
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/5 via-transparent to-orange-500/5"></div>
                
                <CardHeader className="relative z-10">
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl">
                      <Award className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-white text-xl font-bold">Club Achievements</span>
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="relative z-10">
                  <div className="text-center py-16">
                    <div className="mb-6">
                      <div className="w-24 h-24 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
                        <Trophy className="w-12 h-12 text-yellow-300" />
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">Ready for Greatness</h3>
                    <p className="text-blue-200 leading-relaxed max-w-md mx-auto">
                      Club achievements and milestones will be showcased here as we build our legacy together.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Side Cards - Enhanced */}
            <div className="space-y-8">
              {/* Financial Summary */}
              <Card className="bg-white/10 backdrop-blur-md border-white/20 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5"></div>
                
                <CardHeader className="relative z-10">
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl">
                      <DollarSign className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-white font-bold">Financial Health</span>
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="relative z-10 space-y-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-4 bg-white/5 rounded-xl border border-white/10">
                      <span className="text-sm font-medium text-blue-200">Revenue</span>
                      <span className="font-bold text-green-400 text-lg">${stats.totalIncome.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex justify-between items-center p-4 bg-white/5 rounded-xl border border-white/10">
                      <span className="text-sm font-medium text-blue-200">Expenses</span>
                      <span className="font-bold text-red-400 text-lg">${stats.totalExpenses.toLocaleString()}</span>
                    </div>
                    
                    <div className="border-t border-white/20 pt-4">
                      <div className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl border border-white/20">
                        <span className="text-sm font-semibold text-white">Net Balance</span>
                        <span className={`font-bold text-xl ${stats.netBalance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          ${stats.netBalance.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-3 rounded-full transition-all duration-1000 ${stats.netBalance >= 0 ? 'bg-gradient-to-r from-green-400 to-emerald-500' : 'bg-gradient-to-r from-red-400 to-red-500'}`}
                        style={{width: Math.min(100, Math.abs((stats.netBalance / Math.max(stats.totalIncome, 1)) * 100)) + '%'}}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="bg-white/10 backdrop-blur-md border-white/20 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-indigo-500/5"></div>
                
                <CardHeader className="relative z-10">
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-xl">
                      <Target className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-white font-bold">Quick Stats</span>
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="relative z-10 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-white/5 rounded-xl">
                      <div className="text-2xl font-bold text-white">{stats.activeTeams}</div>
                      <div className="text-xs text-blue-200">Active Teams</div>
                    </div>
                    <div className="text-center p-4 bg-white/5 rounded-xl">
                      <div className="text-2xl font-bold text-white">{stats.upcomingMatches}</div>
                      <div className="text-xs text-blue-200">Upcoming</div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-xl border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <Package className="w-4 h-4 text-indigo-300" />
                      <span className="text-sm text-indigo-200">Equipment Status</span>
                    </div>
                    <div className="flex justify-between items-end">
                      <span className="text-xl font-bold text-white">{stats.totalInventory}</span>
                      <span className="text-xs text-green-300 bg-green-500/20 px-2 py-1 rounded-full">Good</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Enhanced Main Content Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white/10 backdrop-blur-md border-white/20 rounded-2xl overflow-hidden">
                <UpcomingMatches matches={recentData.matches} loading={loading} />
              </div>
              <div className="bg-white/10 backdrop-blur-md border-white/20 rounded-2xl overflow-hidden">
                <EquipmentAuditLog />
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-white/10 backdrop-blur-md border-white/20 rounded-2xl overflow-hidden">
                <RecentActivity
                  members={recentData.members}
                  events={recentData.events}
                  loading={loading}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
