
import React, { useState, useEffect, useCallback } from 'react';
import { Conversation, Message, PushSubscription } from '@/api/entities';
import { User } from '@/api/entities'; // Specific import for User
import { Member, Sponsor } from '@/api/entities'; // Specific imports for Member and Sponsor
import ConversationList from '../components/communications/ConversationList';
import NotificationCenter from '../components/communications/NotificationCenter';
import PushNotificationSetup from '../components/communications/PushNotificationSetup';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LogOut, Shield } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function Communications() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [portalType, setPortalType] = useState('Member'); // default

  useEffect(() => {
    const portalUserStr = sessionStorage.getItem('portalUser');
    if (portalUserStr) {
      try {
        const portalUser = JSON.parse(portalUserStr);
        if (portalUser && (portalUser.type === 'member' || portalUser.type === 'sponsor') && portalUser.data) {
          const pseudoUser = {
            full_name: `${portalUser.data.first_name || ''} ${portalUser.data.last_name || ''}`.trim() || portalUser.data.name,
            email: portalUser.data.email,
            role: portalUser.type,
          };
          setUser(pseudoUser);
          setPortalType(portalUser.type === 'member' ? 'Member' : 'Sponsor');
        } else {
           // Invalid session data
           sessionStorage.removeItem('portalUser');
           window.location.href = createPageUrl('PortalLogin');
        }
      } catch (e) {
        // JSON parsing error
        console.error("Error parsing portalUser from session storage:", e);
        sessionStorage.removeItem('portalUser');
        window.location.href = createPageUrl('PortalLogin');
      }
      setLoading(false);
    } else {
      // Fallback to Google login for admins or direct access
      const checkAdminAuth = async () => {
        try {
          const adminUser = await User.me();
          if (adminUser.role === 'admin') {
            toast.info("This portal is for members and sponsors. Admins should use the main Communications Hub from the dashboard.");
            window.location.href = createPageUrl('Dashboard');
          } else {
            // Non-admin Google user, check if they are a member/sponsor
            const [memberCheck, sponsorCheck] = await Promise.all([
              Member.filter({ email: adminUser.email }),
              Sponsor.filter({ email: adminUser.email })
            ]);
            if (memberCheck.length > 0) {
              setUser(adminUser);
              setPortalType('Member');
            } else if (sponsorCheck.length > 0) {
              setUser(adminUser);
              setPortalType('Sponsor');
            } else {
               throw new Error("User not found as member or sponsor");
            }
          }
        } catch (error) {
          console.error("Authentication check failed:", error);
          window.location.href = createPageUrl('Home'); // Redirect to home if not authorized
        } finally {
          setLoading(false);
        }
      };
      checkAdminAuth();
    }
  }, []);

  const handleLogout = async () => {
    // Clear both possible session types
    sessionStorage.removeItem('portalUser');
    try {
      await User.logout();
    } catch (e) {
      // Ignore error if not logged in via Google, or if session is already gone
      console.warn("Error during user logout (might be already logged out):", e);
    } finally {
      window.location.href = createPageUrl('PortalLogin');
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading Communications...</div>;
  }
  
  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-purple-50 min-h-screen">
      <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200/60 -mx-6 -mt-6 mb-6 px-6 py-4 sticky top-0 z-20">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 text-lg">Nepbourne FC</h2>
              <p className="text-xs text-slate-500 font-medium">{portalType} Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium text-slate-900 text-sm truncate">{user?.full_name}</p>
              <p className="text-xs text-slate-500 truncate capitalize">Welcome</p>
            </div>
             <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="text-slate-600 hover:text-slate-900"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-800">Communication Hub</h1>
        <p className="text-slate-600 mt-2 mb-8">Stay connected with club announcements and messages.</p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <ConversationList />
          </div>
          <div>
            <PushNotificationSetup />
            <div className="mt-8">
              <NotificationCenter />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
