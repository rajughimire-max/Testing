import React, { useState, useEffect } from 'react';
import { WebsiteContent, NewsArticle, Match, Sponsor } from '@/api/entities';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import HeroCarousel from '../components/public_site/HeroCarousel';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Trophy } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function HomePage() {
  const [heroSlides, setHeroSlides] = useState([]);
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [sponsors, setSponsors] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [slidesData, matchesData, sponsorsData] = await Promise.all([
          NewsArticle.filter({ is_hero_slide: true, status: 'published' }),
          Match.list('match_date', 4, { match_status: 'scheduled' }),
          Sponsor.list('-created_date', 12, { status: 'Active' })
        ]);
        setHeroSlides(slidesData);
        setUpcomingMatches(matchesData);
        setSponsors(sponsorsData);
      } catch (error) {
        console.error("Error loading homepage data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const MatchCard = ({ match }) => (
    <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardContent className="p-6">
        <p className="text-sm text-slate-500 mb-2">{format(new Date(match.match_date), 'EEE, MMM d, yyyy')} - {match.match_time}</p>
        <h3 className="text-xl font-bold text-slate-800">{match.opponent_name}</h3>
        <p className="text-slate-600">{match.competition || 'League Match'}</p>
        <p className="text-sm font-semibold mt-2">{match.is_home_game ? 'Home' : 'Away'}</p>
      </CardContent>
    </Card>
  );

  return (
    <div className="bg-slate-50">
      <HeroCarousel slides={heroSlides} />

      <section className="py-16 sm:py-24">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-extrabold text-slate-900">Upcoming Matches</h2>
            <Button asChild variant="ghost">
              <Link to={createPageUrl('Fixtures')}>
                View All <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Skeleton className="h-48 w-full" />
              <Skeleton className="h-48 w-full" />
              <Skeleton className="h-48 w-full" />
              <Skeleton className="h-48 w-full" />
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {upcomingMatches.map(match => <MatchCard key={match.id} match={match} />)}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-slate-900">Our Valued Sponsors</h2>
            <p className="mt-4 text-lg text-slate-600">Powering our passion on and off the field.</p>
          </div>
          {loading ? (
             <div className="flex flex-wrap justify-center items-center gap-8">
                <Skeleton className="h-16 w-32" />
                <Skeleton className="h-16 w-32" />
                <Skeleton className="h-16 w-32" />
                <Skeleton className="h-16 w-32" />
                <Skeleton className="h-16 w-32" />
             </div>
          ) : (
            <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8">
              {sponsors.map(sponsor => (
                <div key={sponsor.id} className="grayscale hover:grayscale-0 transition-all duration-300">
                  <img src={sponsor.logo_url} alt={sponsor.name} className="h-12 md:h-16 object-contain" />
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}