
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { GeneratedContract, MembershipApplication, MembershipType } from '@/api/entities';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from "@/components/ui/checkbox";
import { signContract } from '@/api/functions';
import { ShieldCheck, FileText, UserCheck, AlertTriangle, Loader2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function SignMembershipContract() {
  const location = useLocation();
  const [contract, setContract] = useState(null);
  const [application, setApplication] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSigned, setIsSigned] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [signerName, setSignerName] = useState('');
  const [declarationAgreed, setDeclarationAgreed] = useState(false);

  useEffect(() => {
    const fetchContractData = async () => {
      const params = new URLSearchParams(location.search);
      const contractId = params.get('contractId');
      
      if (!contractId) {
        setError('No contract ID provided.');
        setLoading(false);
        return;
      }
      
      try {
        const contractData = await GeneratedContract.get(contractId);
        if (!contractData) throw new Error("Contract not found.");

        const appData = await MembershipApplication.get(contractData.application_id);
        if (!appData) throw new Error("Membership application not found.");

        setContract(contractData);
        setApplication(appData);

        if (contractData.status === 'signed') {
          setIsSigned(true);
        }
        
        if (appData.first_name && appData.last_name) {
          setSignerName(`${appData.first_name} ${appData.last_name}`);
        }
      } catch (err) {
        console.error("Error fetching contract details:", err);
        setError(err.message || 'Could not load the contract. It might be invalid or expired.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchContractData();
  }, [location]);

  const handleSign = async () => {
    if (!signerName.trim()) {
      toast.error("Please enter your full name to sign the contract.");
      return;
    }
    if (!declarationAgreed) {
      toast.error("You must agree to the declaration before signing.");
      return;
    }
    setProcessing(true);
    try {
      const { data } = await signContract({
        contractId: contract.id,
        sponsorSignature: signerName.trim(), // API uses a generic name for signature
      });
      toast.success("Contract signed successfully!");
      setContract(data.contract);
      setIsSigned(true);
    } catch (error) {
      toast.error("Failed to sign contract. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6">
        <Alert variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertTitle>Error</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-purple-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="text-center mb-8">
            <div className="inline-block bg-white p-4 rounded-full shadow-md mb-4">
                <FileText className="w-10 h-10 text-purple-600" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900">Membership Agreement</h1>
            <p className="text-slate-600 mt-2">Please review and sign your membership contract with Nepbourne FC.</p>
        </div>

        <Card className="shadow-xl bg-white border-slate-200 mb-6">
            <CardHeader className="bg-slate-50 border-b border-slate-200">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2 text-xl"><ShieldCheck className="w-5 h-5 text-green-600" />Contract Details</CardTitle>
                        <p className="text-slate-600 mt-1">{application?.first_name} {application?.last_name} • Membership</p>
                    </div>
                    <Badge variant={isSigned ? "default" : "secondary"} className="px-4 py-2 text-sm">{isSigned ? "Signed" : "Awaiting Signature"}</Badge>
                </div>
            </CardHeader>
            <CardContent className="p-6">
                 <div 
                    className="contract-display-area"
                    dangerouslySetInnerHTML={{ __html: contract?.contract_content || '' }}
                  />
            </CardContent>
        </Card>

        {/* Signature Section */}
        {!isSigned ? (
          <Card className="mb-6 bg-white/80 backdrop-blur-sm">
            <CardHeader><CardTitle>Sign & Complete</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                  <h4 className="font-semibold text-purple-900">Declaration</h4>
                  <div className="flex items-start space-x-3">
                    <Checkbox id="declaration" checked={declarationAgreed} onCheckedChange={setDeclarationAgreed} />
                    <Label htmlFor="declaration" className="text-sm font-normal text-purple-800">I declare that I have read, understood, and agree to the terms of this Membership Agreement.</Label>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signerName">Type Full Name to Sign</Label>
                  <Input id="signerName" value={signerName} onChange={e => setSignerName(e.target.value)} disabled={!declarationAgreed || processing} />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSign} disabled={!declarationAgreed || !signerName.trim() || processing} className="w-full bg-purple-600 hover:bg-purple-700 py-3 text-lg">
                {processing ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <UserCheck className="w-5 h-5 mr-2" />}
                Sign Agreement
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <Card className="bg-green-50 border-green-200 text-center">
            <CardHeader><CardTitle className="flex items-center justify-center gap-3 text-2xl text-green-900"><CheckCircle className="w-8 h-8" />Contract Signed!</CardTitle></CardHeader>
            <CardContent><p className="text-green-800 text-lg">Thank you for signing. Your membership contract is finalized.</p></CardContent>
          </Card>
        )}
      </div>

      <style jsx>{`
        .contract-display-area {
          font-family: ui-monospace, Menlo, Monaco, "Courier New", monospace;
          white-space: pre-wrap;
          word-wrap: break-word;
          font-size: 0.875rem;
          line-height: 1.6;
          color: #334155;
          background-color: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 0.5rem;
          padding: 1.5rem;
          min-height: 500px;
        }
      `}</style>
    </div>
  );
}
