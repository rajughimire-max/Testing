
import React, { useState, useEffect } from 'react';
import { Member, MembershipType, User, AuditLog, MembershipApplication, Invoice } from '@/api/entities';
import { sendDigitalCardEmail } from '@/api/functions';
import { addMissingMemberPayments } from '@/api/functions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Search, SlidersHorizontal, UserPlus, FilePlus, Edit, Trash2, CheckCircle, X, Clock, Users, CreditCard } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from 'sonner';
import { addYears } from 'date-fns';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

import MemberList from '../components/members/MemberList';
import MemberForm from '../components/members/MemberForm';
import MembershipTypeForm from '../components/members/MembershipTypeForm';
import MemberStats from '../components/members/MemberStats';
import MemberWalletCard from '../components/members/MemberWalletCard';

export default function Members() {
  const [user, setUser] = useState(null);
  const [members, setMembers] = useState([]);
  const [membershipTypes, setMembershipTypes] = useState([]);
  const [membershipApplications, setMembershipApplications] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showMemberForm, setShowMemberForm] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [showMembershipTypeForm, setShowMembershipTypeForm] = useState(false);
  const [editingMembershipType, setEditingMembershipType] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState('all');
  const [showWalletCard, setShowWalletCard] = useState(false);
  const [selectedMember, setSelectedMember] = useState(null);
  const [sendingCardId, setSendingCardId] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [backfilling, setBackfilling] = useState(false);

  useEffect(() => {
    loadInitialData();
  }, []);

  const generateMembershipNumber = async () => {
    const currentYear = new Date().getFullYear();
    const existingMembers = await Member.list();
    const currentYearMembers = existingMembers.filter(member => 
      member.membership_number && member.membership_number.startsWith(`NFC${currentYear}`)
    );
    
    let highestNumber = 0;
    currentYearMembers.forEach(member => {
      const numberMatch = member.membership_number.match(/NFC\d{4}(\d{3})$/);
      if (numberMatch) {
        const num = parseInt(numberMatch[1]);
        if (num > highestNumber) {
          highestNumber = num;
        }
      }
    });
    
    const nextNumber = (highestNumber + 1).toString().padStart(3, '0');
    return `NFC${currentYear}${nextNumber}`;
  };

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const [userData, allMembers, typeData, appData, invoiceData] = await Promise.all([
        User.me(),
        Member.list('-created_date'),
        MembershipType.list(),
        MembershipApplication.list('-created_date'),
        Invoice.list()
      ]);
      setUser(userData);

      // IMPORTANT: Only show actual paid members, NOT social game leads
      // Members must have proper membership types and payment verification
      // Social game signups are handled separately in the CRM and Social Game Settings
      const paidMembers = allMembers.filter(member => {
        // Only include members with membership types and proper verification
        // Exclude anyone who might have been incorrectly added through social games
        return member.membership_type_id && 
               member.payment_verified && 
               member.membership_status === 'active' &&
               member.membership_number; // Proper members should have membership numbers
      });

      const enhancedMembers = paidMembers.map(member => {
        const type = typeData.find(t => t.id === member.membership_type_id);
        return {
          ...member,
          membership_type_name: type?.name || 'N/A',
          billing_model: type?.billing_model
        };
      });

      const enhancedApplications = appData.map(app => {
        const type = typeData.find(t => t.id === app.membership_type_id);
        return {
          ...app,
          membership_type_name: type?.name || 'Unknown Type'
        };
      });

      setMembers(enhancedMembers);
      setMembershipTypes(typeData);
      setMembershipApplications(enhancedApplications);
      setInvoices(invoiceData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load initial data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const createMemberFromApplication = async (appDetails) => {
    const membershipType = membershipTypes.find(t => t.id === appDetails.membership_type_id);
    let expiryDate = null;
    let validTo = null;
  
    if (membershipType) {
      // Only set expiry dates for non-lifetime memberships
      if (membershipType.billing_model === 'annually' || membershipType.billing_model === 'one-off') {
        expiryDate = addYears(new Date(), 1).toISOString().split('T')[0];
        validTo = addYears(new Date(), 1).toISOString().split('T')[0];
      }
      // For lifetime memberships, both stay null
    }

    const membershipNumber = await generateMembershipNumber();
    
    return Member.create({
      first_name: appDetails.first_name,
      last_name: appDetails.last_name,
      email: appDetails.email,
      phone: appDetails.phone,
      date_of_birth: appDetails.date_of_birth,
      street_address: appDetails.street_address,
      suburb: appDetails.suburb,
      state: appDetails.state,
      postcode: appDetails.postcode,
      membership_type_id: appDetails.membership_type_id,
      membership_status: 'active',
      membership_number: membershipNumber,
      membership_expiry_date: expiryDate, // null for lifetime
      membership_valid_from: new Date().toISOString().split('T')[0],
      membership_valid_to: validTo, // null for lifetime
      payment_verified: true,
      emergency_contact_name: appDetails.emergency_contact_name,
      emergency_contact_phone: appDetails.emergency_contact_phone,
      notes: appDetails.medical_conditions ? `Medical: ${appDetails.medical_conditions}` : null,
      is_verified: true,
    });
  };

  const handleApplicationStatusChange = async (appId, newStatus) => {
    try {
      if (newStatus === 'approved') {
        const appDetails = membershipApplications.find(app => app.id === appId);
        if (!appDetails) {
          toast.error("Application details not found.");
          return;
        }

        const existingMembers = await Member.filter({ email: appDetails.email });
        if (existingMembers.length > 0) {
          toast.warn(`A member with email ${appDetails.email} already exists. Application will be marked as approved.`);
          await MembershipApplication.update(appId, { status: newStatus });
        } else {
          const newMember = await createMemberFromApplication(appDetails);
          await MembershipApplication.update(appId, { status: newStatus });
          
          toast.promise(
            sendDigitalCardEmail({ memberId: newMember.id }),
            {
              loading: 'Creating member and sending digital card...',
              success: `Application approved! Digital card sent to ${newMember.email}.`,
              error: 'Member created, but failed to send card email.',
            }
          );
        }
        loadInitialData();
      } else {
        await MembershipApplication.update(appId, { status: newStatus });
        setMembershipApplications(prev => prev.map(app => app.id === appId ? { ...app, status: newStatus } : app));
        toast.success(`Membership application status updated to ${newStatus.replace('_', ' ')}.`);
      }
    } catch (error) {
      console.error("Error updating application status:", error);
      toast.error("Failed to update application status.");
    }
  };

  const handleSendCardEmail = async (memberId) => {
    setSendingCardId(memberId);
    try {
      const member = members.find(m => m.id === memberId);
      if (!member) {
        toast.error("Could not find member details.");
        return;
      }
      
      const result = await sendDigitalCardEmail({ memberId });
      
      if (result.data.success) {
        if (result.data.email_sent !== false) {
          // Email was sent successfully
          toast.success(`Digital card sent to ${member.email}.`);
        } else {
          // Email couldn't be sent, but we have a shareable link
          toast.info(`Email restrictions apply. Share this link with ${member.first_name}:`, {
            duration: 10000,
            action: {
              label: "Copy Link",
              onClick: () => {
                navigator.clipboard.writeText(result.data.cardUrl);
                toast.success("Link copied to clipboard!");
              }
            }
          });
          
          // Also show the link in an alert for easy copying
          setTimeout(() => {
            const shouldCopy = window.confirm(
              `Due to email restrictions, please share this link with ${member.first_name} ${member.last_name} via SMS, WhatsApp, or other method:\n\n${result.data.cardUrl}\n\nClick OK to copy the link to your clipboard.`
            );
            if (shouldCopy) {
              navigator.clipboard.writeText(result.data.cardUrl);
            }
          }, 1000);
        }
      } else {
        toast.error(result.data.error || 'Failed to send card.');
      }
    } catch (error) {
      console.error("Error sending card:", error);
      toast.error('Failed to send card. Please try again.');
    } finally {
      setSendingCardId(null);
    }
  };

  const handleRetryMemberCreation = async (appId) => {
    try {
      const appDetails = membershipApplications.find(app => app.id === appId);
      if (!appDetails || appDetails.status !== 'approved') {
        toast.error("Application not found or not approved.");
        return;
      }

      const existingMembers = await Member.filter({ email: appDetails.email });
      if (existingMembers.length > 0) {
        toast.info(`Member with email ${appDetails.email} already exists.`);
        return;
      }

      const newMember = await createMemberFromApplication(appDetails);
      toast.success(`Member created successfully with membership number: ${newMember.membership_number}`);
      loadInitialData();
    } catch (error) {
      console.error("Error creating member:", error);
      toast.error("Failed to create member from approved application.");
    }
  };

  const handleDeleteApplication = async (appId) => {
    if (window.confirm("Are you sure you want to permanently delete this application? This action cannot be undone.")) {
      try {
        await MembershipApplication.delete(appId);
        setMembershipApplications(prev => prev.filter(app => app.id !== appId));
        toast.success("Membership application deleted successfully.");
      } catch (error) {
        console.error("Error deleting application:", error);
        toast.error("Failed to delete application.");
      }
    }
  };

  const handleEditMember = (member) => {
    setEditingMember(member);
    setShowMemberForm(true);
  };

  const handleMemberFormSubmit = async (formData, manualCreationReason, evidenceFile) => {
    try {
      if (editingMember) {
        await Member.update(editingMember.id, formData);
        await AuditLog.create({
          user_email: user.email,
          action: 'UPDATE',
          entity_name: 'Member',
          entity_id: editingMember.id,
          details: { changes: Object.keys(formData) }
        });
        toast.success("Member updated successfully!");
      } else {
        const newMember = await Member.create(formData);
        await AuditLog.create({
          user_email: user.email,
          action: 'CREATE',
          entity_name: 'Member',
          entity_id: newMember.id,
          details: { reason: manualCreationReason }
        });
        toast.success("Member created successfully!");
      }
      setShowMemberForm(false);
      setEditingMember(null);
      loadInitialData();
    } catch (error) {
      console.error("Error submitting member form:", error);
      toast.error("Failed to save member.");
    }
  };

  const handleDeleteMember = async (memberId) => {
    if (window.confirm("Are you sure you want to permanently delete this member? This action cannot be undone.")) {
      try {
        await Member.delete(memberId);
        await AuditLog.create({
          user_email: user.email,
          action: 'DELETE',
          entity_name: 'Member',
          entity_id: memberId,
          details: {
            reason: "Member deleted from Members page."
          }
        });
        toast.success("Member deleted successfully.");
        loadInitialData();
      } catch (error) {
        console.error("Error deleting member:", error);
        if (error.message?.includes('Object not found') || error.response?.status === 404 || error.response?.status === 500) {
           toast.info("This member has already been deleted. Refreshing the list...");
           loadInitialData();
        } else {
           toast.error("Failed to delete member. Please try again.");
        }
      }
    }
  };

  const handleEditMembershipType = (type) => {
    setEditingMembershipType(type);
    setShowMembershipTypeForm(true);
  };

  const handleMembershipTypeFormSubmit = async () => {
    setShowMembershipTypeForm(false);
    setEditingMembershipType(null);
    loadInitialData();
    toast.success("Membership type saved successfully!");
  };
  
  const handleDeleteMembershipType = async (typeId) => {
    if (window.confirm("Are you sure you want to delete this membership type? This cannot be undone.")) {
      try {
        const membersWithThisType = members.filter(m => m.membership_type_id === typeId);
        if (membersWithThisType.length > 0) {
          toast.error(`Cannot delete. This type is assigned to ${membersWithThisType.length} member(s).`);
          return;
        }
        await MembershipType.delete(typeId);
        toast.success("Membership type deleted successfully.");
        loadInitialData();
      } catch (error) {
        console.error("Error deleting membership type:", error);
        
        if (error.message?.includes('Object not found') || error.response?.status === 404 || error.response?.status === 500) {
          setMembershipTypes(prevTypes => prevTypes.filter(type => type.id !== typeId));
          toast.info("This membership type has already been deleted. Refreshing the list...");
          loadInitialData();
        } else {
          toast.error("Failed to delete membership type. Please try again or refresh the page.");
        }
      }
    }
  };

  const handleViewWalletCard = (member) => {
    setSelectedMember(member);
    setShowWalletCard(true);
  };

  const handleBackfillPayments = async () => {
    if (!window.confirm("This will scan all active members and create missing financial income records. This process cannot be undone. Are you sure you want to continue?")) {
        return;
    }

    setBackfilling(true);
    toast.info("Starting backfill process for missing member payments...");

    try {
        const response = await addMissingMemberPayments();
        if (response.data.success) {
            toast.success(response.data.message, {
                description: `Review the created transactions in the Finance module.`
            });
        } else {
            toast.error(response.data.error || "An unknown error occurred during backfill.");
        }
    } catch (error) {
        console.error("Error backfilling payments:", error);
        toast.error("Failed to backfill payments. Please check the console for details.");
    } finally {
        setBackfilling(false);
    }
  };


  const applicationStatusColors = {
    pending: "bg-amber-100 text-amber-800 border-amber-200",
    payment_pending: "bg-blue-100 text-blue-800 border-blue-200",
    approved: "bg-green-100 text-green-800 border-green-200",
    rejected: "bg-red-100 text-red-800 border-red-200"
  };

  const pendingApplications = membershipApplications.filter(app => app.status !== 'approved');
  const allApplicationsForDebugging = membershipApplications;

  const filteredMembers = members.filter(member => {
    const matchesSearch = searchTerm.trim() === '' ||
      `${member.first_name} ${member.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.membership_number?.includes(searchTerm);

    const matchesType = filterType === 'all' || member.membership_type_id === filterType;

    return matchesSearch && matchesType;
  });

  // Filter members by tab
  const getFilteredMembersByTab = (tab) => {
    switch (tab) {
      case 'lifetime':
        return filteredMembers.filter(member => {
          const membershipType = membershipTypes.find(t => t.id === member.membership_type_id);
          return membershipType?.billing_model === 'lifetime' || 
                 member.membership_type_name?.toLowerCase().includes('lifetime') ||
                 member.membership_type_name?.toLowerCase().includes('life time');
        });
      case 'general':
        return filteredMembers.filter(member => {
          const membershipType = membershipTypes.find(t => t.id === member.membership_type_id);
          return membershipType?.billing_model !== 'lifetime' && 
                 !member.membership_type_name?.toLowerCase().includes('lifetime') &&
                 !member.membership_type_name?.toLowerCase().includes('life time');
        });
      case 'all':
      default:
        return filteredMembers;
    }
  };

  const currentTabMembers = getFilteredMembersByTab(activeTab);

  return (
    <div className="p-4 space-y-4 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Members</h1>
            <p className="text-slate-600 text-sm">Manage club members and membership types</p>
          </div>
          <div className="text-xs text-slate-500">
            Members: {members.length} | All Apps: {membershipApplications.length} | Pending: {pendingApplications.length}
          </div>
        </div>

        <Tabs defaultValue="members" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="members">Members ({members.length})</TabsTrigger>
            <TabsTrigger value="types">Membership Types ({membershipTypes.length})</TabsTrigger>
            <TabsTrigger value="applications" className="flex items-center gap-2">
              Applications <Badge className="ml-2 bg-blue-600 text-white">{pendingApplications.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="all-applications" className="flex items-center gap-2">
              All Applications <Badge className="ml-2 bg-gray-600 text-white">{allApplicationsForDebugging.length}</Badge>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="members" className="space-y-4">
            <MemberStats members={members} loading={loading} />
            
            {/* Member Sub-Tabs */}
            <div className="bg-white/80 backdrop-blur-sm border-slate-200/60 rounded-lg">
              <div className="flex border-b border-slate-200">
                <button
                  className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'all'
                      ? 'border-blue-500 text-blue-600 bg-blue-50'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                  onClick={() => setActiveTab('all')}
                >
                  All Members ({filteredMembers.length})
                </button>
                <button
                  className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'lifetime'
                      ? 'border-yellow-500 text-yellow-600 bg-yellow-50'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                  onClick={() => setActiveTab('lifetime')}
                >
                  Life Time Members ({getFilteredMembersByTab('lifetime').length})
                </button>
                <button
                  className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'general'
                      ? 'border-green-500 text-green-600 bg-green-50'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                  onClick={() => setActiveTab('general')}
                >
                  General Members ({getFilteredMembersByTab('general').length})
                </button>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="flex gap-2">
                <Input 
                  placeholder="Search members..." 
                  className="w-64 bg-white h-9" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-56 bg-white h-9">
                    <SelectValue placeholder="Filter by membership type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Membership Types</SelectItem>
                    {membershipTypes.map(type => (
                      <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleBackfillPayments}
                    disabled={backfilling}
                    className="h-9"
                >
                    <CreditCard className="w-4 h-4 mr-2" />
                    {backfilling ? 'Backfilling...' : 'Backfill Payments'}
                </Button>
                <Button onClick={() => { setEditingMember(null); setShowMemberForm(true); }} className="bg-red-600 hover:bg-red-700 h-9" size="sm">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add Member
                </Button>
              </div>
            </div>

            {showMemberForm ? (
              <MemberForm
                member={editingMember}
                membershipTypes={membershipTypes}
                user={user}
                onSubmit={handleMemberFormSubmit}
                onCancel={() => { setShowMemberForm(false); setEditingMember(null); }}
                onCreateMembershipType={async (typeData) => {
                  const newType = await MembershipType.create(typeData);
                  loadInitialData();
                  return newType;
                }}
              />
            ) : (
              <MemberList 
                members={currentTabMembers} 
                loading={loading} 
                onEditMember={handleEditMember} 
                onDeleteMember={handleDeleteMember}
                onViewWalletCard={handleViewWalletCard}
                onSendCardEmail={handleSendCardEmail}
                sendingCardId={sendingCardId}
                membershipTypes={membershipTypes}
                invoices={invoices}
                onInvoiceGenerated={loadInitialData}
              />
            )}
          </TabsContent>

          <TabsContent value="types" className="space-y-4">
            <div className="flex justify-end">
               <Button onClick={() => { setEditingMembershipType(null); setShowMembershipTypeForm(true); }} className="bg-red-600 hover:bg-red-700 h-9" size="sm">
                <FilePlus className="w-4 h-4 mr-2" />
                Add Membership Type
              </Button>
            </div>
            
            {showMembershipTypeForm ? (
              <MembershipTypeForm 
                membershipType={editingMembershipType}
                onSubmit={handleMembershipTypeFormSubmit}
                onCancel={() => { setShowMembershipTypeForm(false); setEditingMembershipType(null); }}
              />
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardHeader>
                  <CardTitle>All Membership Types</CardTitle>
                  <CardDescription>Configure the different types of memberships your club offers.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {membershipTypes.map(type => (
                      <div key={type.id} className="p-4 border rounded-lg flex flex-col items-start">
                        <div className="w-full flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold text-lg">{type.name}</h4>
                            <p className="text-sm text-slate-600">{type.description}</p>
                            <div className="flex items-center gap-4 mt-2">
                               <Badge>${type.price_aud} {type.billing_model}</Badge>
                               <Badge variant={type.is_active ? "default" : "secondary"}>
                                 {type.is_active ? "Active" : "Inactive"}
                               </Badge>
                               <Badge variant={type.is_visible ? "default" : "secondary"}>
                                 {type.is_visible ? "Visible" : "Hidden"}
                               </Badge>
                            </div>
                          </div>
                          <div className="flex gap-2 flex-shrink-0">
                            <Button variant="outline" size="sm" onClick={() => handleEditMembershipType(type)}>
                              <Edit className="w-3 h-3 mr-1" /> Edit
                            </Button>
                             <Button variant="outline" size="sm" className="text-red-600" onClick={() => handleDeleteMembershipType(type.id)}>
                              <Trash2 className="w-3 h-3 mr-1" /> Delete
                            </Button>
                          </div>
                        </div>

                        {type.features && type.features.length > 0 && (
                           <div className="mt-4 pt-3 border-t w-full">
                            <h5 className="font-medium text-slate-800 mb-2">Features:</h5>
                            <ul className="list-disc list-inside space-y-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                              {type.features.map((feature, index) => (
                                <li key={index} className="text-sm text-slate-600">{feature}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="applications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Users className="w-6 h-6 text-blue-600" />
                  Pending Membership Applications ({pendingApplications.length})
                </CardTitle>
                <CardDescription>Review and manage pending membership applications from your website</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingApplications.map(app => (
                    <Card key={app.id} className="bg-gradient-to-r from-white to-slate-50 hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div className="space-y-2">
                            <div className="flex items-center gap-3 flex-wrap">
                              <h3 className="font-bold text-xl text-slate-900">{app.first_name} {app.last_name}</h3>
                              <Badge className={`px-3 py-1 border ${applicationStatusColors[app.status]}`}>
                                {app.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                                {app.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                                {app.status === 'rejected' && <X className="w-3 h-3 mr-1" />}
                                {app.status?.replace('_', ' ').toUpperCase()}
                              </Badge>
                              <Badge className="bg-indigo-100 text-indigo-800 border-indigo-200">
                                {app.membership_type_name}
                              </Badge>
                            </div>
                            <p className="text-slate-600 font-medium">{app.email}</p>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm text-slate-600 mt-3">
                              <div><strong>Phone:</strong> {app.phone || 'Not provided'}</div>
                              <div><strong>State:</strong> {app.state || 'Not provided'}</div>
                              <div><strong>Emergency Contact:</strong> {app.emergency_contact_name || 'Not provided'}</div>
                            </div>
                          </div>
                          <div className="flex gap-2 flex-shrink-0">
                            <Button 
                              size="sm" 
                              onClick={() => handleApplicationStatusChange(app.id, 'approved')} 
                              disabled={app.status === 'approved' || app.status === 'rejected'} 
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" /> Approve
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleApplicationStatusChange(app.id, 'rejected')} 
                              disabled={app.status === 'rejected' || app.status === 'approved'} 
                              className="text-red-600 hover:bg-red-50 border-red-200"
                            >
                              <X className="w-4 h-4 mr-1" /> Reject
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleDeleteApplication(app.id)} 
                              disabled={app.status === 'approved'}
                              className="text-red-600 hover:bg-red-50 border-red-200"
                            >
                              <Trash2 className="w-4 h-4 mr-1" /> Delete
                            </Button>
                          </div>
                        </div>
                        {app.medical_conditions && (
                          <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                            <strong className="text-amber-800">Medical Conditions:</strong>
                            <p className="text-amber-700 text-sm mt-1">{app.medical_conditions}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                  {pendingApplications.length === 0 && (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-slate-700 mb-2">No Pending Applications</h3>
                      <p className="text-slate-500">All applications have been processed. Check the database for full history.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="all-applications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Users className="w-6 h-6 text-purple-600" />
                  All Membership Applications ({allApplicationsForDebugging.length})
                </CardTitle>
                <CardDescription>Debug view: All applications including approved and rejected</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allApplicationsForDebugging.map(app => {
                    const memberExists = members.some(m => m.email === app.email);

                    return (
                      <Card key={app.id} className="bg-gradient-to-r from-white to-slate-50 hover:shadow-lg transition-all duration-300">
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start mb-4">
                            <div className="space-y-2">
                              <div className="flex items-center gap-3 flex-wrap">
                                <h3 className="font-bold text-xl text-slate-900">{app.first_name} {app.last_name}</h3>
                                <Badge className={`px-3 py-1 border ${applicationStatusColors[app.status]}`}>
                                  {app.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                                  {app.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                                  {app.status === 'rejected' && <X className="w-3 h-3 mr-1" />}
                                  {app.status?.replace('_', ' ').toUpperCase()}
                                </Badge>
                                <Badge className="bg-indigo-100 text-indigo-800 border-indigo-200">
                                  {app.membership_type_name}
                                </Badge>
                              </div>
                              <p className="text-slate-600 font-medium">{app.email}</p>
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm text-slate-600 mt-3">
                                <div><strong>Phone:</strong> {app.phone || 'Not provided'}</div>
                                <div><strong>State:</strong> {app.state || 'Not provided'}</div>
                                <div><strong>Status:</strong> {app.status}</div>
                              </div>
                            </div>
                            <div className="flex gap-2 flex-shrink-0">
                              {app.status === 'approved' ? (
                                <>
                                  {memberExists ? (
                                    <Badge className="bg-green-100 text-green-800">
                                      ✅ Member Record Exists
                                    </Badge>
                                  ) : (
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => handleRetryMemberCreation(app.id)}
                                      className="bg-blue-50 text-blue-600 hover:bg-blue-100"
                                    >
                                      Create Member Record
                                    </Button>
                                  )}
                                </>
                              ) : (
                                <>
                                  <Button 
                                    size="sm" 
                                    onClick={() => handleApplicationStatusChange(app.id, 'approved')} 
                                    disabled={app.status === 'rejected'} 
                                    className="bg-green-600 hover:bg-green-700 text-white"
                                  >
                                    <CheckCircle className="w-4 h-4 mr-1" /> Approve
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    onClick={() => handleApplicationStatusChange(app.id, 'rejected')} 
                                    disabled={app.status === 'rejected'} 
                                    className="text-red-600 hover:bg-red-50 border-red-200"
                                  >
                                    <X className="w-4 h-4 mr-1" /> Reject
                                  </Button>
                                </>
                              )}
                            </div>
                          </div>
                          {app.medical_conditions && (
                            <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                              <strong className="text-amber-800">Medical Conditions:</strong>
                              <p className="text-amber-700 text-sm mt-1">{app.medical_conditions || 'N/A'}</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                  {allApplicationsForDebugging.length === 0 && (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-slate-700 mb-2">No Applications Found</h3>
                      <p className="text-slate-500">No membership applications have been submitted yet.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={showWalletCard} onOpenChange={setShowWalletCard}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Digital Membership Card
              </DialogTitle>
            </DialogHeader>
            {selectedMember && (
              <MemberWalletCard 
                member={selectedMember}
                membershipType={membershipTypes.find(t => t.id === selectedMember.membership_type_id)}
              />
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
