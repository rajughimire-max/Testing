import React, { useState } from 'react';
import { Shield, ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { validatePortalId } from '@/api/functions';
import { toast } from 'sonner';

export default function PortalLogin() {
  const [portalId, setPortalId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!portalId) {
      setError('Please enter your ID number.');
      return;
    }
    setLoading(true);
    setError('');

    try {
      const response = await validatePortalId({ id: portalId });
      const { data } = response;

      if (data.success) {
        // Store user info in session storage to maintain login state
        sessionStorage.setItem('portalUser', JSON.stringify(data));
        
        toast.success(`Welcome, ${data.data.first_name}!`);

        // Determine which portal to redirect to based on available portals
        if (data.available_portals.includes('executive')) {
          // If they have executive access, prioritize ExecutivePortal
          window.location.href = '/ExecutivePortal';
        } else if (data.type === 'player') {
          window.location.href = '/PlayerPortal';
        } else if (data.type === 'member') {
          window.location.href = '/Communications';
        }
      } else {
        setError(data.error || 'Invalid ID number. Please try again.');
        toast.error(data.error || 'Invalid ID number.');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('An unexpected error occurred. Please try again later.');
      toast.error('An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-100 flex items-center justify-center p-4">
      <div className="text-center max-w-md w-full">
        <div className="inline-block bg-white p-4 rounded-2xl shadow-lg mb-6">
          <Shield className="w-12 h-12 text-blue-600" />
        </div>
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-slate-900">Member & Team Portal Access</CardTitle>
            <CardDescription className="text-slate-600">Enter your official ID number to access your portals.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="text"
                placeholder="e.g., NFC-P-001 or NFC2025001"
                value={portalId}
                onChange={(e) => setPortalId(e.target.value)}
                className="text-center h-12 text-lg tracking-wider"
                aria-label="Player or Member ID"
              />
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button type="submit" className="w-full h-12 text-lg" disabled={loading}>
                {loading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <>
                    Access Portal <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
        <p className="text-xs text-slate-500 mt-6">
          Admins and Staff: Please use the standard club management login.
        </p>
      </div>
    </div>
  );
}