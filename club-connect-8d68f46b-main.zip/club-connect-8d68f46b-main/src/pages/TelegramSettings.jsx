import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageCircle } from 'lucide-react';
import TelegramSettings from '../components/communications/TelegramSettings';

export default function TelegramSettingsPage() {
  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <MessageCircle className="w-8 h-8 text-blue-600" />
            Telegram Settings
          </h1>
          <p className="text-slate-600 mt-2">Configure your Telegram bot for instant communication with members</p>
        </div>

        <Card>
          <CardContent className="p-0">
            <TelegramSettings />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}