
import React, { useState, useEffect } from 'react';
import { Team, Member } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Shield, Trophy, MapPin, Calendar, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function PublicTeamsPage() {
  const [teams, setTeams] = useState([]);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [teamsData, membersData] = await Promise.all([
          Team.list(),
          Member.list()
        ]);
        
        // Filter for active teams only
        const activeTeams = teamsData.filter(team => team.status === 'active');
        
        setTeams(activeTeams);
        setMembers(membersData);
      } catch (error) {
        console.error("Error loading teams data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [setLoading]);

  const getCoachName = (coachId) => {
    if (!coachId) return null;
    const coach = members.find(member => member.id === coachId);
    return coach ? `${coach.first_name} ${coach.last_name}` : null;
  };

  const getSportColor = (sport) => {
    const colors = {
      soccer: "bg-green-100 text-green-800 border-green-300",
      basketball: "bg-orange-100 text-orange-800 border-orange-300",
      hockey: "bg-blue-100 text-blue-800 border-blue-300",
      netball: "bg-purple-100 text-purple-800 border-purple-300",
      rugby: "bg-red-100 text-red-800 border-red-300"
    };
    return colors[sport] || "bg-gray-100 text-gray-800 border-gray-300";
  };

  const TeamCard = ({ team, delay = 0 }) => {
    const coachName = getCoachName(team.coach_id);
    
    return (
      <div 
        className="animate-in fade-in slide-in-from-bottom-4 duration-500"
        style={{ animationDelay: `${delay}ms` }}
      >
        <Card className="group shadow-lg hover:shadow-2xl transition-all duration-500 bg-white/90 backdrop-blur-sm rounded-2xl overflow-hidden border-0 hover:scale-105 transform h-full flex flex-col">
          {team.team_photo_url && (
            <div className="w-full h-48 bg-slate-200">
                <img src={team.team_photo_url} alt={team.name} className="w-full h-full object-cover"/>
            </div>
          )}
          <CardContent className="p-8 h-full flex flex-col flex-grow">
            {/* Team Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                {team.logo_url ? (
                  <img 
                    src={team.logo_url} 
                    alt={team.name} 
                    className="h-16 w-16 rounded-full shadow-md object-cover" 
                  />
                ) : (
                  <div 
                    className="h-16 w-16 rounded-full flex items-center justify-center shadow-md text-white font-bold text-xl"
                    style={{ backgroundColor: team.team_color || '#dc2626' }}
                  >
                    {team.name?.charAt(0) || 'T'}
                  </div>
                )}
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 group-hover:text-red-600 transition-colors">
                    {team.name}
                  </h3>
                  <Badge className={`${getSportColor(team.sport)} mt-2`}>
                    {team.sport?.charAt(0).toUpperCase() + team.sport?.slice(1)}
                  </Badge>
                </div>
              </div>
              {team.is_main_team && (
                <Badge className="bg-red-600 text-white">
                  Featured Team
                </Badge>
              )}
            </div>

            {/* Team Details */}
            <div className="space-y-4 flex-grow">
              {team.age_group && (
                <div className="flex items-center gap-3 text-slate-700">
                  <Users className="w-5 h-5 text-red-600" />
                  <span className="font-medium">Age Group: {team.age_group}</span>
                </div>
              )}
              
              {team.season && (
                <div className="flex items-center gap-3 text-slate-700">
                  <Calendar className="w-5 h-5 text-red-600" />
                  <span className="font-medium">Season: {team.season}</span>
                </div>
              )}
              
              {coachName && (
                <div className="flex items-center gap-3 text-slate-700">
                  <User className="w-5 h-5 text-red-600" />
                  <span className="font-medium">Coach: {coachName}</span>
                </div>
              )}

              {team.notes && (
                <div className="mt-8 p-6 bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl border border-slate-200">
                  <div className="text-slate-700 leading-relaxed space-y-3">
                    <ReactMarkdown 
                      components={{
                        p: ({node, ...props}) => <p className="mb-4 last:mb-0 text-base leading-relaxed" {...props} />,
                        strong: ({node, ...props}) => <strong className="font-semibold text-slate-900" {...props} />,
                        em: ({node, ...props}) => <em className="italic text-slate-600" {...props} />
                      }}
                    >
                      {team.notes}
                    </ReactMarkdown>
                  </div>
                </div>
              )}
            </div>

            {/* Team Status */}
            <div className="mt-6 pt-4 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm font-medium text-slate-600">Active Team</span>
                </div>
                <Trophy className="w-5 h-5 text-slate-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="text-center mb-16">
            <Skeleton className="h-16 w-96 mx-auto mb-6" />
            <Skeleton className="h-6 w-128 mx-auto" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(6).fill(0).map((_, i) => (
              <Card key={i} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <Skeleton className="h-16 w-16 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-6 w-32" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const activeMembers = members.filter(member => member.membership_status === 'active');
  const totalSports = [...new Set(teams.map(t => t.sport))].length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative py-32 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-blue-600/20"></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-7xl font-black text-white tracking-tight leading-none">
              OUR TEAMS
            </h1>
            <div className="h-2 w-32 bg-red-600 mx-auto"></div>
            <p className="text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
              Meet the teams that represent our club with pride, passion, and excellence
            </p>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-red-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      {/* Teams Content */}
      <div className="max-w-7xl mx-auto px-6 py-24">
        {teams.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-32 h-32 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-8">
              <Shield className="w-16 h-16 text-slate-400" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-4">No Teams Available</h3>
            <p className="text-slate-600 text-lg leading-relaxed max-w-md mx-auto">
              We're currently building our teams. Check back soon to see our squads in action!
            </p>
          </div>
        ) : (
          <>
            {/* Real Stats Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
              <div className="text-center">
                <div className="text-4xl font-bold text-red-600 mb-2">
                  2025
                </div>
                <div className="text-slate-600 uppercase tracking-wide text-sm">
                  Established
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-red-600 mb-2">
                  {activeMembers.length}
                </div>
                <div className="text-slate-600 uppercase tracking-wide text-sm">
                  Active Members
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-red-600 mb-2">
                  {teams.length}
                </div>
                <div className="text-slate-600 uppercase tracking-wide text-sm">
                  Active Teams
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-red-600 mb-2">
                  {totalSports}
                </div>
                <div className="text-slate-600 uppercase tracking-wide text-sm">
                  Sports Covered
                </div>
              </div>
            </div>

            {/* Teams Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {teams.map((team, index) => (
                <TeamCard key={team.id} team={team} delay={index * 100} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
