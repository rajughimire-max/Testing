import React, { useState, useEffect } from 'react';
import { Campaign } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Mail, MessageSquare, Send, BarChart, Eye, Edit, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CrmCampaignsPage() {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadCampaigns();
  }, []);

  const loadCampaigns = async () => {
    setLoading(true);
    try {
      const data = await Campaign.list('-created_date');
      setCampaigns(data);
    } catch (error) {
      console.error("Error loading campaigns:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCampaign = async (campaignId) => {
    if (window.confirm('Are you sure you want to delete this campaign? This action cannot be undone.')) {
      try {
        await Campaign.delete(campaignId);
        loadCampaigns(); // Refresh the list
      } catch (error) {
        console.error("Error deleting campaign:", error);
        alert("Failed to delete campaign. Please try again.");
      }
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: 'bg-gray-200 text-gray-800',
      scheduled: 'bg-blue-200 text-blue-800',
      sending: 'bg-yellow-200 text-yellow-800 animate-pulse',
      completed: 'bg-green-200 text-green-800',
      failed: 'bg-red-200 text-red-800',
      paused: 'bg-orange-200 text-orange-800'
    };
    return colors[status] || 'bg-gray-200 text-gray-800';
  };

  const renderCampaignList = (channel) => {
    const filteredCampaigns = campaigns.filter(c => c.channel === channel);

    if (loading) {
      return (
        <div className="space-y-4">
          {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      );
    }

    if (filteredCampaigns.length === 0) {
      return (
        <div className="text-center py-16 border-dashed border-2 rounded-lg">
          {channel === 'email' ? <Mail className="mx-auto h-12 w-12 text-gray-400" /> : <MessageSquare className="mx-auto h-12 w-12 text-gray-400" />}
          <h3 className="mt-2 text-lg font-medium text-gray-900">No {channel} campaigns yet</h3>
          <p className="mt-1 text-sm text-gray-500">Get started by creating your first campaign.</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {filteredCampaigns.map(campaign => (
          <Card key={campaign.id} className="bg-white/80 backdrop-blur-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6 grid grid-cols-1 md:grid-cols-12 items-center gap-4">
              <div className="md:col-span-4">
                <p className="font-semibold text-lg text-slate-900">{campaign.name}</p>
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <Badge className={`capitalize ${getStatusColor(campaign.status)}`}>{campaign.status}</Badge>
                  <span>•</span>
                  <span>Created {format(new Date(campaign.created_date), 'MMM d, yyyy')}</span>
                </div>
              </div>

              <div className="md:col-span-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="font-bold text-xl text-slate-800">{(campaign.stats?.sent || 0).toLocaleString()}</p>
                  <p className="text-xs text-slate-500 uppercase">Sent</p>
                </div>
                <div>
                  <p className="font-bold text-xl text-slate-800">{(campaign.stats?.delivered || 0).toLocaleString()}</p>
                  <p className="text-xs text-slate-500 uppercase">Delivered</p>
                </div>
                {channel === 'email' && (
                  <>
                    <div>
                      <p className="font-bold text-xl text-slate-800">{(campaign.stats?.opened || 0).toLocaleString()}</p>
                      <p className="text-xs text-slate-500 uppercase">Opens</p>
                    </div>
                    <div>
                      <p className="font-bold text-xl text-slate-800">{(campaign.stats?.clicked || 0).toLocaleString()}</p>
                      <p className="text-xs text-slate-500 uppercase">Clicks</p>
                    </div>
                  </>
                )}
              </div>

              <div className="md:col-span-2 flex justify-end gap-2">
                 <Button asChild variant="outline" size="sm">
                    <Link to={createPageUrl(`CrmCampaignEditor/${campaign.id}`)}>
                        <Edit className="w-4 h-4 mr-1" /> Edit & Send
                    </Link>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={() => handleDeleteCampaign(campaign.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Campaigns</h1>
            <p className="text-slate-600">Create and send Email & SMS campaigns to your audience.</p>
          </div>
        </div>

        <Tabs defaultValue="email">
          <div className="flex justify-between items-end mb-6">
            <TabsList>
              <TabsTrigger value="email"><Mail className="w-4 h-4 mr-2" />Email Campaigns</TabsTrigger>
              <TabsTrigger value="sms"><MessageSquare className="w-4 h-4 mr-2" />SMS Campaigns</TabsTrigger>
            </TabsList>
            <div className="flex gap-3">
              <Link to={createPageUrl('CrmCampaignCreator?channel=sms')}>
                <Button className="bg-red-600 hover:bg-red-700">
                  <Plus className="w-4 h-4 mr-2" /> New SMS Campaign
                </Button>
              </Link>
              <Link to={createPageUrl('CrmCampaignCreator?channel=email')}>
                <Button className="bg-red-600 hover:bg-red-700">
                  <Plus className="w-4 h-4 mr-2" /> New Email Campaign
                </Button>
              </Link>
            </div>
          </div>

          <TabsContent value="email" className="mt-6 space-y-4">
             <h3 className="text-2xl font-semibold text-slate-800">Email Marketing</h3>
             <p className="text-sm text-slate-500 -mt-2">Engage your audience with targeted email campaigns.</p>
             {renderCampaignList('email')}
          </TabsContent>
          <TabsContent value="sms" className="mt-6 space-y-4">
              <h3 className="text-2xl font-semibold text-slate-800">SMS Marketing</h3>
             <p className="text-sm text-slate-500 -mt-2">Send timely updates and alerts via SMS.</p>
             {renderCampaignList('sms')}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}