import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { SponsorshipApplication, SponsorshipTier } from '@/api/entities';
import { createPaymentSession } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { CheckCircle, Shield, CreditCard, AlertCircle } from 'lucide-react';
import StripeLoader from '../components/stripe/StripeLoader';

export default function SponsorshipPayment() {
    const location = useLocation();
    const [application, setApplication] = useState(null);
    const [tier, setTier] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [processing, setProcessing] = useState(false);

    useEffect(() => {
        const fetchApplication = async () => {
            const params = new URLSearchParams(location.search);
            const applicationId = params.get('applicationId');

            if (!applicationId) {
                setError('No application ID provided. Please use the link from your invoice email.');
                setLoading(false);
                return;
            }

            try {
                const appData = await SponsorshipApplication.get(applicationId);
                if (!appData) {
                    setError('Sponsorship application not found. It may have been processed or deleted.');
                    setLoading(false);
                    return;
                }
                
                if (appData.status === 'active') {
                    setError('This sponsorship has already been paid and activated. Thank you!');
                    setLoading(false);
                    return;
                }

                setApplication(appData);
                const tierData = await SponsorshipTier.get(appData.sponsorship_tier_id);
                setTier(tierData);

            } catch (err) {
                setError('Failed to load sponsorship details. Please try again or contact us.');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchApplication();
    }, [location.search]);
    
    const handlePayment = async () => {
        setProcessing(true);
        setError(null);
        try {
            const amount = application.custom_amount || tier.minimum_amount;
            
            const response = await createPaymentSession({
                type: 'sponsorship',
                applicationId: application.id,
                custom_amount: amount,
                payment_plan: application.payment_preference,
                installment_count: application.installment_months || 0
            });
            
            if (response.data && response.data.url) {
                window.location.href = response.data.url;
            } else {
                throw new Error('Failed to create payment session.');
            }
        } catch (err) {
            setError('Could not initiate payment. Please try again or contact support.');
            console.error(err);
            setProcessing(false);
        }
    };

    if (loading) {
        return <div className="min-h-screen flex items-center justify-center bg-gray-50"><StripeLoader /></div>;
    }

    if (error) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
                <Alert variant="destructive" className="max-w-lg">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>An Error Occurred</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            </div>
        );
    }
    
    const amount = application.custom_amount || tier.minimum_amount;

    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
            <Card className="w-full max-w-2xl shadow-lg">
                <CardHeader className="text-center bg-gray-100 p-6">
                    <Shield className="mx-auto h-12 w-12 text-blue-600" />
                    <CardTitle className="text-3xl font-bold mt-2">Sponsorship Payment</CardTitle>
                    <CardDescription className="text-lg text-gray-600">for Nepbourne FC</CardDescription>
                </CardHeader>
                <CardContent className="p-8 space-y-6">
                    <div className="p-6 border rounded-lg bg-gray-50">
                        <div className="flex justify-between items-center">
                            <div>
                                <p className="text-sm font-medium text-gray-500">Sponsor</p>
                                <p className="text-lg font-semibold">{application.company_name}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-medium text-gray-500">Sponsorship Tier</p>
                                <p className="text-lg font-semibold">{tier.name}</p>
                            </div>
                        </div>
                        <hr className="my-4" />
                        <div className="flex justify-between items-center">
                             <div>
                                <p className="text-sm font-medium text-gray-500">Payment Plan</p>
                                <p className="text-lg font-semibold capitalize">{application.payment_preference.replace('-', ' ')}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-medium text-gray-500">Total Amount</p>
                                <p className="text-3xl font-bold text-blue-700">${amount.toLocaleString()}</p>
                            </div>
                        </div>
                         {application.payment_preference === 'installments' && (
                            <p className="text-center text-sm text-gray-500 mt-4">To be paid in {application.installment_months} monthly installments.</p>
                        )}
                    </div>
                     <Alert>
                        <CheckCircle className="h-4 w-4" />
                        <AlertTitle>Secure Payment</AlertTitle>
                        <AlertDescription>
                            All payments are processed securely by Stripe. We do not store your card details.
                        </AlertDescription>
                    </Alert>
                </CardContent>
                <CardFooter className="p-6 bg-gray-100">
                    <Button onClick={handlePayment} disabled={processing} className="w-full text-lg py-6">
                        {processing ? <StripeLoader /> : <> <CreditCard className="mr-2 h-5 w-5" /> Proceed to Payment </>}
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}