import React, { useState, useEffect } from 'react';
import { SponsorshipTier } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Check, Loader2 } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function SponsorshipTiers() {
  const [tiers, setTiers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTiers = async () => {
      setLoading(true);
      try {
        // Fetch only active tiers, sorted by sort_order
        const activeTiers = await SponsorshipTier.filter({ is_active: true }, 'sort_order');
        setTiers(activeTiers);
      } catch (error) {
        console.error("Error loading sponsorship tiers:", error);
      } finally {
        setLoading(false);
      }
    };
    loadTiers();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <Loader2 className="h-12 w-12 animate-spin text-red-600" />
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-slate-900 mb-4">Become a Partner</h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Support Nepbourne FC and gain valuable exposure for your brand. Our sponsorship packages offer a unique opportunity to connect with a passionate local community.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
          {tiers.map((tier, index) => (
            <Card
              key={tier.id}
              className={`flex flex-col shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 rounded-xl overflow-hidden border-2 ${index === 1 ? 'border-red-600 scale-105' : 'border-transparent'}`}
              style={{ borderColor: index === 1 ? tier.color || '#dc2626' : 'transparent' }}
            >
              <CardHeader className="p-8 text-center" style={{ backgroundColor: tier.color ? `${tier.color}1A` : '#fef2f2' }}>
                <h3 className="text-3xl font-bold" style={{ color: tier.color || '#1e293b' }}>{tier.name}</h3>
                <p className="text-slate-600 mt-2">{tier.description}</p>
              </CardHeader>
              <CardContent className="p-8 flex-grow">
                <div className="text-center mb-8">
                  <span className="text-slate-500">From </span>
                  <span className="text-5xl font-bold text-slate-900">${tier.minimum_amount.toLocaleString()}</span>
                  <span className="text-slate-500"> / season</span>
                </div>
                <ul className="space-y-4">
                  {tier.benefits?.map((benefit, i) => (
                    <li key={i} className="flex items-start">
                      <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-1" />
                      <span className="text-slate-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="p-8 bg-slate-50/50 mt-auto">
                <Link to={createPageUrl(`SponsorshipInquiry?tierId=${tier.id}`)} className="w-full">
                  <Button size="lg" className="w-full bg-red-600 hover:bg-red-700">
                    Sponsor this Tier
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>

         {tiers.length === 0 && !loading && (
          <div className="text-center py-16 bg-white rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold text-slate-800">Sponsorship Tiers Coming Soon</h3>
            <p className="text-slate-500 mt-4">We are finalizing our partnership packages. Please check back later or contact us directly for more information.</p>
            <Link to={createPageUrl('SponsorshipInquiry')}>
              <Button className="mt-6 bg-red-600 hover:bg-red-700">Contact Us</Button>
            </Link>
          </div>
        )}

      </div>
    </div>
  );
}