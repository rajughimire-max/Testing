import { base44 } from './base44Client';


export const Club = base44.entities.Club;

export const Member = base44.entities.Member;

export const Team = base44.entities.Team;

export const Match = base44.entities.Match;

export const Event = base44.entities.Event;

export const AuditLog = base44.entities.AuditLog;

export const MembershipType = base44.entities.MembershipType;

export const InventoryItem = base44.entities.InventoryItem;

export const InventoryTransaction = base44.entities.InventoryTransaction;

export const Sponsor = base44.entities.Sponsor;

export const FinancialTransaction = base44.entities.FinancialTransaction;

export const TournamentType = base44.entities.TournamentType;

export const SponsorshipTier = base44.entities.SponsorshipTier;

export const WebsiteContent = base44.entities.WebsiteContent;

export const MembershipApplication = base44.entities.MembershipApplication;

export const SponsorshipApplication = base44.entities.SponsorshipApplication;

export const MerchandiseItem = base44.entities.MerchandiseItem;

export const ContractTemplate = base44.entities.ContractTemplate;

export const GeneratedContract = base44.entities.GeneratedContract;

export const NewsArticle = base44.entities.NewsArticle;

export const Player = base44.entities.Player;

export const TrainingAttendance = base44.entities.TrainingAttendance;

export const SocialGameSignup = base44.entities.SocialGameSignup;

export const SocialGameSettings = base44.entities.SocialGameSettings;

export const NewsPost = base44.entities.NewsPost;

export const Contact = base44.entities.Contact;

export const EmailTemplate = base44.entities.EmailTemplate;

export const SmsTemplate = base44.entities.SmsTemplate;

export const Suppression = base44.entities.Suppression;

export const Campaign = base44.entities.Campaign;

export const Conversation = base44.entities.Conversation;

export const Message = base44.entities.Message;

export const ConversationMember = base44.entities.ConversationMember;

export const PushNotification = base44.entities.PushNotification;

export const PushSubscription = base44.entities.PushSubscription;

export const Invoice = base44.entities.Invoice;

export const UniformAssignment = base44.entities.UniformAssignment;

export const TelegramSubscriber = base44.entities.TelegramSubscriber;

export const GameAttendance = base44.entities.GameAttendance;

export const Season = base44.entities.Season;

export const PlayerInjury = base44.entities.PlayerInjury;

export const TrainingEquipment = base44.entities.TrainingEquipment;

export const ExecutiveMember = base44.entities.ExecutiveMember;

export const Meeting = base44.entities.Meeting;

export const AgendaItem = base44.entities.AgendaItem;



// auth sdk:
export const User = base44.auth;