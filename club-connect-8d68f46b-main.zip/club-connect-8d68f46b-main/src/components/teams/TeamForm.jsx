
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Upload } from "lucide-react";
import { UploadFile } from "@/api/integrations";
import { Textarea } from "@/components/ui/textarea";

export default function TeamForm({ team, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    name: team?.name || "",
    sport: team?.sport || "soccer", // Ensure sport is always present with default
    season: team?.season || "",
    coach_name: team?.coach_name || "",
    assistant_coach_name: team?.assistant_coach_name || "",
    team_manager_name: team?.team_manager_name || "",
    team_color: team?.team_color || "#1e40af",
    logo_url: team?.logo_url || "",
    team_photo_url: team?.team_photo_url || "",
    status: team?.status || "active",
    notes: team?.notes || "",
    // Preserve existing fields if editing
    ...(team && {
      id: team.id,
      created_date: team.created_date,
      updated_date: team.updated_date,
      created_by_id: team.created_by_id,
      is_sample: team.is_sample
    })
  });
  
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploadingLogo(true);
    try {
      const { file_url } = await UploadFile({ file });
      handleChange('logo_url', file_url);
    } catch (error) {
      console.error("Error uploading logo:", error);
    } finally {
      setUploadingLogo(false);
    }
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const { file_url } = await UploadFile({ file });
      handleChange('team_photo_url', file_url);
    } catch (error) {
      console.error("Error uploading photo:", error);
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Ensure sport is always included in submission
    const submissionData = {
      ...formData,
      sport: formData.sport || "soccer" // Fallback to soccer if somehow missing
    };
    onSubmit(submissionData);
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
      <CardHeader>
        <CardTitle>
          {team ? "Edit Team" : "Add New Team"}
        </CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Team Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleChange("name", e.target.value)}
                  placeholder="e.g., Under 12 Eagles"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sport">Sport *</Label>
                <Select value={formData.sport} onValueChange={(value) => handleChange("sport", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select sport" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="soccer">Soccer</SelectItem>
                    <SelectItem value="basketball">Basketball</SelectItem>
                    <SelectItem value="hockey">Hockey</SelectItem>
                    <SelectItem value="netball">Netball</SelectItem>
                    <SelectItem value="rugby">Rugby</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="season">Season</Label>
                <Input
                  id="season"
                  value={formData.season}
                  onChange={(e) => handleChange("season", e.target.value)}
                  placeholder="e.g., 2024 Winter (Mar-Sep)"
                />
              </div>
            </div>
          </div>

          {/* Coaching & Management */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Coaching & Management</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="coach_name">Head Coach Name</Label>
                <Input
                  id="coach_name"
                  value={formData.coach_name}
                  onChange={(e) => handleChange("coach_name", e.target.value)}
                  placeholder="e.g., John Smith"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="assistant_coach_name">Assistant Coach Name</Label>
                <Input
                  id="assistant_coach_name"
                  value={formData.assistant_coach_name}
                  onChange={(e) => handleChange("assistant_coach_name", e.target.value)}
                  placeholder="e.g., Jane Doe"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="team_manager_name">Team Manager Name</Label>
                <Input
                  id="team_manager_name"
                  value={formData.team_manager_name}
                  onChange={(e) => handleChange("team_manager_name", e.target.value)}
                  placeholder="e.g., Mike Johnson"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Team Status</Label>
                <Select value={formData.status} onValueChange={(value) => handleChange("status", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="disbanded">Disbanded</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Team Appearance & Notes */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Team Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="team_color">Team Color</Label>
                <div className="flex gap-2">
                  <Input
                    id="team_color"
                    type="color"
                    value={formData.team_color}
                    onChange={(e) => handleChange("team_color", e.target.value)}
                    className="w-16"
                  />
                  <Input
                    value={formData.team_color}
                    onChange={(e) => handleChange("team_color", e.target.value)}
                    placeholder="#1e40af"
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="logo_url">Team Logo</Label>
                <div className="flex items-center gap-4">
                  {formData.logo_url && (
                    <img src={formData.logo_url} alt="Logo Preview" className="w-12 h-12 rounded-full object-cover"/>
                  )}
                  <div className="flex-1">
                    <Input
                      id="logo_url_input"
                      type="file"
                      onChange={handleLogoUpload}
                      disabled={uploadingLogo}
                      className="cursor-pointer"
                      accept="image/*"
                    />
                    {uploadingLogo && <p className="text-xs text-slate-500 mt-1">Uploading...</p>}
                  </div>
                </div>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="team_photo_url">Team Photo</Label>
                <div className="flex items-center gap-4">
                  {formData.team_photo_url && (
                    <img src={formData.team_photo_url} alt="Team Photo Preview" className="w-24 h-16 rounded-md object-cover"/>
                  )}
                  <div className="flex-1">
                    <Input
                      id="team_photo_input"
                      type="file"
                      onChange={handlePhotoUpload}
                      disabled={uploadingPhoto}
                      className="cursor-pointer"
                      accept="image/*"
                    />
                    {uploadingPhoto && <p className="text-xs text-slate-500 mt-1">Uploading team photo...</p>}
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-4 space-y-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleChange("notes", e.target.value)}
                placeholder="Any additional information about the team... You can use paragraphs."
                className="min-h-[100px]"
              />
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            {team ? "Update Team" : "Create Team"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
