import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarIcon, Edit, Trash2, Save, X, PlusCircle, Check, ShieldCheck } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function SeasonSetupModal({ isOpen, onClose, seasons, teams, onSeasonSubmit, onSeasonDelete, onBulkUpdate }) {
  const [editingSeason, setEditingSeason] = useState(null);
  const [newSeason, setNewSeason] = useState({ name: '', start_date: null, end_date: null, status: 'Upcoming' });
  const [selectedSeason, setSelectedSeason] = useState('');
  const [selectedTeams, setSelectedTeams] = useState([]);
  
  useEffect(() => {
    if (isOpen) {
      setEditingSeason(null);
      setNewSeason({ name: '', start_date: null, end_date: null, status: 'Upcoming' });
    }
  }, [isOpen]);

  const handleCreateOrUpdate = async () => {
    const seasonData = editingSeason ? { ...editingSeason } : { ...newSeason };

    if (!seasonData.name || !seasonData.start_date || !seasonData.end_date) {
      toast.error('Please fill in all fields for the season.');
      return;
    }
    
    await onSeasonSubmit(seasonData);
    setNewSeason({ name: '', start_date: null, end_date: null, status: 'Upcoming' });
    setEditingSeason(null);
  };

  const handleTeamSelection = (teamId) => {
    setSelectedTeams(prev => 
      prev.includes(teamId) ? prev.filter(id => id !== teamId) : [...prev, teamId]
    );
  };

  const handleBulkUpdate = async () => {
    if (!selectedSeason) {
      toast.error('Please select a season to apply.');
      return;
    }
    if (selectedTeams.length === 0) {
      toast.error('Please select at least one team to update.');
      return;
    }

    const seasonName = seasons.find(s => s.id === selectedSeason)?.name;
    if (!seasonName) {
      toast.error('Could not find the selected season name.');
      return;
    }

    await onBulkUpdate(seasonName, selectedTeams);
    setSelectedTeams([]);
  };
  
  const renderSeasonForm = (season, setSeason) => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-lg bg-slate-50">
      <div className="space-y-2">
        <Label>Season Name</Label>
        <Input 
          placeholder="e.g., 2025 Winter" 
          value={season.name} 
          onChange={(e) => setSeason({ ...season, name: e.target.value })}
        />
      </div>
       <div className="space-y-2">
        <Label>Status</Label>
        <Select value={season.status} onValueChange={(value) => setSeason({ ...season, status: value })}>
          <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Upcoming">Upcoming</SelectItem>
            <SelectItem value="Active">Active</SelectItem>
            <SelectItem value="Completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Start Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-start text-left font-normal">
              <CalendarIcon className="mr-2 h-4 w-4" />
              {season.start_date ? format(new Date(season.start_date), 'PPP') : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={season.start_date ? new Date(season.start_date) : null} onSelect={(date) => setSeason({ ...season, start_date: date })} /></PopoverContent>
        </Popover>
      </div>
      <div className="space-y-2">
        <Label>End Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-start text-left font-normal">
              <CalendarIcon className="mr-2 h-4 w-4" />
              {season.end_date ? format(new Date(season.end_date), 'PPP') : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={season.end_date ? new Date(season.end_date) : null} onSelect={(date) => setSeason({ ...season, end_date: date })} /></PopoverContent>
        </Popover>
      </div>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose} >
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl">Season Setup</DialogTitle>
          <DialogDescription>Manage your club's seasons and assign them to teams.</DialogDescription>
        </DialogHeader>

        <div className="flex-grow overflow-y-auto pr-4 space-y-6">
          {/* Season Management Section */}
          <div>
            <h3 className="text-lg font-semibold mb-2">Manage Seasons</h3>
            <div className="space-y-4">
              {seasons.map(season => (
                <div key={season.id}>
                  {editingSeason?.id === season.id ? (
                    <div>
                      {renderSeasonForm(editingSeason, setEditingSeason)}
                      <div className="flex justify-end gap-2 mt-2">
                        <Button variant="outline" size="sm" onClick={() => setEditingSeason(null)}><X className="w-4 h-4 mr-1"/> Cancel</Button>
                        <Button size="sm" onClick={handleCreateOrUpdate}><Save className="w-4 h-4 mr-1"/> Save</Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-semibold">{season.name} <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${season.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-700'}`}>{season.status}</span></p>
                        <p className="text-sm text-slate-500">{format(new Date(season.start_date), 'MMM d, yyyy')} - {format(new Date(season.end_date), 'MMM d, yyyy')}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" onClick={() => setEditingSeason(season)}><Edit className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-red-500" onClick={() => onSeasonDelete(season.id)}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-6">
              <h4 className="font-medium mb-2 text-slate-800">Add New Season</h4>
              {renderSeasonForm(newSeason, setNewSeason)}
              <div className="flex justify-end mt-2">
                <Button onClick={handleCreateOrUpdate}><PlusCircle className="w-4 h-4 mr-2"/> Add Season</Button>
              </div>
            </div>
          </div>

          {/* Bulk Update Section */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-2">Bulk Assign Season to Teams</h3>
            <div className="flex items-end gap-4 mb-4">
              <div className="flex-grow space-y-2">
                <Label>Select Season</Label>
                <Select onValueChange={setSelectedSeason}>
                  <SelectTrigger><SelectValue placeholder="Choose a season..." /></SelectTrigger>
                  <SelectContent>
                    {seasons.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleBulkUpdate} className="bg-green-600 hover:bg-green-700">
                <ShieldCheck className="w-4 h-4 mr-2" />
                Update {selectedTeams.length} Teams
              </Button>
            </div>
            
            <div className="space-y-2 max-h-64 overflow-y-auto border rounded-lg p-2 bg-slate-50">
              {teams.map(team => (
                <div 
                  key={team.id} 
                  onClick={() => handleTeamSelection(team.id)}
                  className={`flex items-center justify-between p-2 rounded-md cursor-pointer transition-colors ${selectedTeams.includes(team.id) ? 'bg-blue-100' : 'hover:bg-slate-100'}`}
                >
                  <div className="flex items-center gap-2">
                     <div className={`w-5 h-5 border rounded flex items-center justify-center ${selectedTeams.includes(team.id) ? 'bg-blue-600 border-blue-600' : 'border-slate-300'}`}>
                      {selectedTeams.includes(team.id) && <Check className="w-4 h-4 text-white" />}
                    </div>
                    <div>
                      <p className="font-semibold">{team.name}</p>
                      <p className="text-xs text-slate-500">Current Season: {team.season || 'Not Set'}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter className="border-t pt-4">
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}