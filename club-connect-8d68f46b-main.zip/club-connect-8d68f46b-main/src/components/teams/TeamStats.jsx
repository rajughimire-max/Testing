import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Users, Trophy, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function TeamStats({ teams, loading }) {
  const stats = {
    total: teams.length,
    active: teams.filter(t => t.status === 'active').length,
    sports: [...new Set(teams.map(t => t.sport))].length,
    withCoaches: teams.filter(t => t.coach_id).length
  };

  const statCards = [
    {
      title: "Total Teams",
      value: stats.total,
      icon: Shield,
      color: "text-blue-600 bg-blue-100"
    },
    {
      title: "Active Teams",
      value: stats.active,
      icon: Users,
      color: "text-green-600 bg-green-100"
    },
    {
      title: "Sports Covered",
      value: stats.sports,
      icon: Trophy,
      color: "text-purple-600 bg-purple-100"
    },
    {
      title: "With Coaches",
      value: stats.withCoaches,
      icon: Calendar,
      color: "text-orange-600 bg-orange-100"
    }
  ];

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map((stat, index) => (
          <Card key={index} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-8 w-12" />
                </div>
                <Skeleton className="h-12 w-12 rounded-full" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {statCards.map((stat) => (
        <Card key={stat.title} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">{stat.title}</p>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
              </div>
              <div className={`p-3 rounded-full ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}