
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Users, MapPin, Clock, User, Trophy } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

const sportColors = {
  soccer: "bg-green-100 text-green-800 border-green-200",
  basketball: "bg-orange-100 text-orange-800 border-orange-200", 
  hockey: "bg-blue-100 text-blue-800 border-blue-200",
  netball: "bg-pink-100 text-pink-800 border-pink-200",
  rugby: "bg-purple-100 text-purple-800 border-purple-200"
};

const statusColors = {
  active: "bg-green-100 text-green-800 border-green-200",
  inactive: "bg-gray-100 text-gray-800 border-gray-200",
  disbanded: "bg-red-100 text-red-800 border-red-200"
};

export default function TeamList({ teams, members, loading, onEditTeam, onDeleteTeam }) {
  // Helper to get coach name
  const getCoachName = (coachId) => {
    if (!coachId) return "No Coach Assigned";
    const coach = members.find(m => m.id === coachId);
    return coach ? `${coach.first_name} ${coach.last_name}` : "Unknown Coach";
  };

  if (loading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
        <CardHeader>
          <CardTitle>Teams</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="p-6 border border-slate-200 rounded-lg">
                <div className="flex justify-between items-start mb-4">
                  <div className="space-y-2">
                    <Skeleton className="h-6 w-40" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-16 rounded-full" />
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Array(4).fill(0).map((_, j) => (
                    <Skeleton key={j} className="h-4 w-20" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
      <CardHeader>
        <CardTitle>Teams ({teams.length})</CardTitle>
      </CardHeader>
      <CardContent>
        {teams.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">No teams found</h3>
            <p className="text-slate-500">Get started by creating your first team.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {teams.map((team) => (
              <div 
                key={team.id} 
                className="p-6 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors duration-200" 
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900 mb-2">{team.name}</h3>
                    <div className="flex gap-2 mb-2">
                      <Badge className={sportColors[team.sport]}>
                        {team.sport}
                      </Badge>
                      <Badge className={statusColors[team.status]}>
                        {team.status}
                      </Badge>
                      {team.age_group && (
                        <Badge variant="outline">
                          {team.age_group}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditTeam(team);
                      }}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteTeam(team.id);
                      }}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-slate-600">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    <span>{getCoachName(team.coach_id)}</span>
                  </div>
                  
                  {team.division && (
                    <div className="flex items-center gap-2">
                      <Trophy className="w-4 h-4" />
                      <span>{team.division}</span>
                    </div>
                  )}

                  {team.training_day && team.training_time && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{team.training_day}s at {team.training_time}</span>
                    </div>
                  )}

                  {team.home_venue && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{team.home_venue}</span>
                    </div>
                  )}
                </div>

                {team.season && (
                  <div className="mt-3 pt-3 border-t border-slate-200">
                    <span className="text-sm text-slate-600">Season: </span>
                    <span className="text-sm font-medium text-slate-900">{team.season}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
