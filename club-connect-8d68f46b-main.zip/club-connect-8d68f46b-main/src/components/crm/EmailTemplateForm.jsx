
import React, { useState, useEffect } from 'react';
import { EmailTemplate } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function EmailTemplateForm({ template, onSave, onCancel }) {
  const [formData, setFormData] = useState({ name: '', subject: '', body: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (template) {
      setFormData({ name: template.name, subject: template.subject, body: template.body });
    } else {
      setFormData({ name: '', subject: '', body: '' });
    }
  }, [template]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (template) {
        await EmailTemplate.update(template.id, formData);
      } else {
        await EmailTemplate.create(formData);
      }
      onSave();
    } catch (error) {
      console.error("Error saving email template:", error);
      alert("Failed to save template. Please check the fields and try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="bg-white/90">
      <CardHeader>
        <CardTitle>{template ? 'Edit' : 'Create'} Email Template</CardTitle>
        <CardDescription>Design a reusable email for your campaigns.</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="template-name">Template Name</Label>
            <Input
              id="template-name"
              placeholder="e.g., Monthly Newsletter, Welcome Email"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="template-subject">Email Subject</Label>
            <Input
              id="template-subject"
              placeholder="e.g., This Month at Nepbourne FC"
              value={formData.subject}
              onChange={(e) => handleChange('subject', e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="template-body">Body</Label>
            <Textarea
              id="template-body"
              placeholder="Write your email content here. Use {{first_name}} for personalization."
              value={formData.body}
              onChange={(e) => handleChange('body', e.target.value)}
              required
              rows={10}
            />
             <p className="text-xs text-slate-500">
              Variables available: {'`{{first_name}}`'}, {'`{{last_name}}`'}, {'`{{unsubscribe_url}}`'}
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? 'Saving...' : 'Save Template'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
