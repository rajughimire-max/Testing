
import React, { useState, useEffect } from 'react';
import { SmsTemplate } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function SmsTemplateForm({ template, onSave, onCancel }) {
  const [formData, setFormData] = useState({ name: '', body: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (template) {
      setFormData({ name: template.name, body: template.body });
    } else {
      setFormData({ name: '', body: '' });
    }
  }, [template]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (template) {
        await SmsTemplate.update(template.id, formData);
      } else {
        await SmsTemplate.create(formData);
      }
      onSave();
    } catch (error) {
      console.error("Error saving SMS template:", error);
      alert("Failed to save template. Please check the fields and try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="bg-white/90">
      <CardHeader>
        <CardTitle>{template ? 'Edit' : 'Create'} SMS Template</CardTitle>
        <CardDescription>Design a reusable SMS message for your campaigns.</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="template-name">Template Name</Label>
            <Input
              id="template-name"
              placeholder="e.g., Match Reminder, Event Update"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="template-body">Message</Label>
            <Textarea
              id="template-body"
              placeholder="Write your SMS content here. Use {{first_name}} for personalization."
              value={formData.body}
              onChange={(e) => handleChange('body', e.target.value)}
              required
              rows={5}
            />
            <p className="text-xs text-slate-500">
              Variables available: {'`{{first_name}}`'}, {'`{{last_name}}`'}. Remember to include opt-out text if required.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button type="submit" disabled={submitting}>
            {submitting ? 'Saving...' : 'Save Template'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
