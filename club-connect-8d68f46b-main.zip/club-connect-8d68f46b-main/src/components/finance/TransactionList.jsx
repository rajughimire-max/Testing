
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Edit, Trash2, Receipt, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

export default function TransactionList({ transactions, loading, onEdit, onDelete, showPeriod }) {
  if (loading) return <Skeleton className="h-96" />;

  const getSourceLink = (tx) => {
      if (tx.related_entity_name) {
          return <Badge variant="outline" className="font-normal">{tx.related_entity_name}</Badge>
      }
      return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction History</CardTitle>
        {showPeriod && (
          <p className="text-sm text-slate-600">Showing transactions for: {showPeriod}</p>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Invoice</TableHead>
              <TableHead>Source</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map(tx => (
              <TableRow key={tx.id}>
                <TableCell>{format(new Date(tx.date), 'dd MMM yyyy')}</TableCell>
                <TableCell>
                  <Badge variant={tx.type === 'Income' ? 'default' : 'destructive'}>{tx.type}</Badge>
                </TableCell>
                <TableCell>{tx.category}</TableCell>
                <TableCell>{tx.description}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {tx.invoice_number && (
                      <span className="text-xs text-slate-600">{tx.invoice_number}</span>
                    )}
                    {tx.invoice_photo_url && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => window.open(tx.invoice_photo_url, '_blank')}
                      >
                        <Receipt className="h-3 w-3 text-blue-600" />
                      </Button>
                    )}
                  </div>
                </TableCell>
                <TableCell>{getSourceLink(tx)}</TableCell>
                <TableCell className="text-right font-medium">${tx.amount.toFixed(2)}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => onEdit(tx)}><Edit className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" className="text-red-600" onClick={() => onDelete(tx.id)}><Trash2 className="w-4 h-4" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
