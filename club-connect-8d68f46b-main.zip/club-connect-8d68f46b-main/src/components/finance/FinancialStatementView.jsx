import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, DollarSign, BarChart3 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function FinancialStatementView({ transactions, loading, period }) {
  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-64" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  // Group transactions by category and type
  const incomeByCategory = {};
  const expensesByCategory = {};
  let totalIncome = 0;
  let totalExpenses = 0;

  transactions.forEach(tx => {
    if (tx.type === 'Income') {
      totalIncome += tx.amount;
      if (!incomeByCategory[tx.category]) {
        incomeByCategory[tx.category] = { total: 0, count: 0, transactions: [] };
      }
      incomeByCategory[tx.category].total += tx.amount;
      incomeByCategory[tx.category].count += 1;
      incomeByCategory[tx.category].transactions.push(tx);
    } else {
      totalExpenses += tx.amount;
      if (!expensesByCategory[tx.category]) {
        expensesByCategory[tx.category] = { total: 0, count: 0, transactions: [] };
      }
      expensesByCategory[tx.category].total += tx.amount;
      expensesByCategory[tx.category].count += 1;
      expensesByCategory[tx.category].transactions.push(tx);
    }
  });

  const netIncome = totalIncome - totalExpenses;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Total Income</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700">${totalIncome.toLocaleString()}</div>
            <p className="text-xs text-green-600 mt-1">{period}</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-red-800">Total Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-700">${totalExpenses.toLocaleString()}</div>
            <p className="text-xs text-red-600 mt-1">{period}</p>
          </CardContent>
        </Card>

        <Card className={`bg-gradient-to-br ${netIncome >= 0 ? 'from-blue-50 to-blue-100 border-blue-200' : 'from-orange-50 to-orange-100 border-orange-200'}`}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className={`text-sm font-medium ${netIncome >= 0 ? 'text-blue-800' : 'text-orange-800'}`}>Net Income</CardTitle>
            <DollarSign className={`h-4 w-4 ${netIncome >= 0 ? 'text-blue-600' : 'text-orange-600'}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netIncome >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
              ${netIncome.toLocaleString()}
            </div>
            <p className={`text-xs mt-1 ${netIncome >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>
              {netIncome >= 0 ? 'Profit' : 'Loss'} • {period}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-800">Transactions</CardTitle>
            <BarChart3 className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700">{transactions.length}</div>
            <p className="text-xs text-purple-600 mt-1">{period}</p>
          </CardContent>
        </Card>
      </div>

      {/* Financial Statement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Income Statement */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-700">
              <TrendingUp className="w-5 h-5" />
              Income Statement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.keys(incomeByCategory).length > 0 ? (
                Object.entries(incomeByCategory)
                  .sort(([,a], [,b]) => b.total - a.total)
                  .map(([category, data]) => (
                    <div key={category} className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                      <div>
                        <div className="font-medium text-slate-900">{category}</div>
                        <div className="text-sm text-slate-500">{data.count} transaction{data.count !== 1 ? 's' : ''}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-green-700">${data.total.toLocaleString()}</div>
                        <div className="text-xs text-slate-500">
                          {((data.total / totalIncome) * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  ))
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <TrendingUp className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p>No income recorded for this period</p>
                </div>
              )}
              <div className="border-t pt-3 mt-4">
                <div className="flex justify-between items-center font-bold text-lg">
                  <span>Total Income</span>
                  <span className="text-green-700">${totalIncome.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Expenses Statement */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <TrendingDown className="w-5 h-5" />
              Expenses Statement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.keys(expensesByCategory).length > 0 ? (
                Object.entries(expensesByCategory)
                  .sort(([,a], [,b]) => b.total - a.total)
                  .map(([category, data]) => (
                    <div key={category} className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                      <div>
                        <div className="font-medium text-slate-900">{category}</div>
                        <div className="text-sm text-slate-500">{data.count} transaction{data.count !== 1 ? 's' : ''}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-red-700">${data.total.toLocaleString()}</div>
                        <div className="text-xs text-slate-500">
                          {((data.total / totalExpenses) * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  ))
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <TrendingDown className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p>No expenses recorded for this period</p>
                </div>
              )}
              <div className="border-t pt-3 mt-4">
                <div className="flex justify-between items-center font-bold text-lg">
                  <span>Total Expenses</span>
                  <span className="text-red-700">${totalExpenses.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Net Income Summary */}
      <Card className={`${netIncome >= 0 ? 'bg-gradient-to-r from-blue-50 to-green-50' : 'bg-gradient-to-r from-orange-50 to-red-50'}`}>
        <CardContent className="pt-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-4">Financial Summary - {period}</h3>
            <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
              <div>
                <div className="text-2xl font-bold text-green-600">${totalIncome.toLocaleString()}</div>
                <div className="text-sm text-slate-600">Total Income</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-600">- ${totalExpenses.toLocaleString()}</div>
                <div className="text-sm text-slate-600">Total Expenses</div>
              </div>
              <div className="border-l-2 border-slate-200 pl-8">
                <div className={`text-3xl font-bold ${netIncome >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>
                  ${Math.abs(netIncome).toLocaleString()}
                </div>
                <div className={`text-sm font-medium ${netIncome >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>
                  Net {netIncome >= 0 ? 'Profit' : 'Loss'}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}