import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save, X, Upload, Receipt } from 'lucide-react';
import { UploadFile } from "@/api/integrations";

export default function TransactionForm({ transaction, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(transaction || {
    date: new Date().toISOString().slice(0, 10),
    type: 'Expense',
    category: 'Other',
    description: '',
    amount: '',
    invoice_number: '',
    invoice_photo_url: ''
  });

  const [uploading, setUploading] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({ ...prev, invoice_photo_url: file_url }));
    } catch (error) {
      console.error("Error uploading invoice:", error);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = e => {
    e.preventDefault();
    onSubmit({ ...formData, amount: parseFloat(formData.amount) });
  };

  return (
    <Card className="mb-6">
      <CardHeader><CardTitle>{transaction ? 'Edit Transaction' : 'Add New Transaction'}</CardTitle></CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" value={formData.date} onChange={e => handleChange('date', e.target.value)} required />
            </div>
            <div className="space-y-1">
              <Label htmlFor="type">Type</Label>
              <Select value={formData.type} onValueChange={v => handleChange('type', v)} required>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Income">Income</SelectItem>
                  <SelectItem value="Expense">Expense</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="category">Category</Label>
              <Select value={formData.category} onValueChange={v => handleChange('category', v)} required>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Membership Fees">Membership Fees</SelectItem>
                  <SelectItem value="Sponsorship">Sponsorship</SelectItem>
                  <SelectItem value="Donation">Donation</SelectItem>
                  <SelectItem value="Equipment">Equipment</SelectItem>
                  <SelectItem value="Venue Hire">Venue Hire</SelectItem>
                  <SelectItem value="Salaries">Salaries</SelectItem>
                  <SelectItem value="Utilities">Utilities</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="amount">Amount ($)</Label>
              <Input id="amount" type="number" step="0.01" value={formData.amount} onChange={e => handleChange('amount', e.target.value)} required />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="description">Description</Label>
            <Input id="description" value={formData.description} onChange={e => handleChange('description', e.target.value)} required />
          </div>

          {/* Invoice fields for expenses */}
          {formData.type === 'Expense' && (
            <>
              <div className="space-y-1">
                <Label htmlFor="invoice_number">Invoice Number</Label>
                <Input 
                  id="invoice_number" 
                  value={formData.invoice_number} 
                  onChange={e => handleChange('invoice_number', e.target.value)} 
                  placeholder="e.g., INV-2024-001"
                  required
                />
              </div>
              <div className="space-y-3">
                <Label>Invoice Photo</Label>
                <div className="flex items-center gap-4">
                  {formData.invoice_photo_url && (
                    <div className="relative">
                      <img 
                        src={formData.invoice_photo_url} 
                        alt="Invoice" 
                        className="w-16 h-16 object-cover border rounded-lg cursor-pointer"
                        onClick={() => window.open(formData.invoice_photo_url, '_blank')}
                      />
                      <Receipt className="absolute -top-1 -right-1 w-4 h-4 bg-blue-600 text-white rounded-full p-0.5" />
                    </div>
                  )}
                  <div className="flex-1">
                    <Input
                      type="file"
                      accept="image/*,application/pdf"
                      onChange={handleFileUpload}
                      disabled={uploading}
                      required={!formData.invoice_photo_url}
                    />
                    {uploading && <p className="text-sm text-slate-500 mt-1">Uploading invoice...</p>}
                    <p className="text-xs text-slate-500 mt-1">Upload image or PDF of the invoice</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button type="submit" disabled={uploading}><Save className="w-4 h-4 mr-2" />{transaction ? 'Update' : 'Save'}</Button>
        </CardFooter>
      </form>
    </Card>
  );
}