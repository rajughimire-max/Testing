import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Users, Megaphone, Plus, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

const getConversationIcon = (type) => {
  switch (type) {
    case 'team':
      return <Users className="w-4 h-4" />;
    case 'announcement':
      return <Megaphone className="w-4 h-4" />;
    default:
      return <MessageSquare className="w-4 h-4" />;
  }
};

const getConversationColor = (type) => {
  switch (type) {
    case 'team':
      return 'bg-blue-100 text-blue-800';
    case 'announcement':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export default function ConversationList({
  conversations,
  teams,
  loading,
  selectedConversation,
  onSelectConversation,
  onCreateTeamConversation,
  onDeleteConversation,
  currentUser
}) {
  if (loading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Conversations</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {Array(5).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  const handleDeleteConversation = async (conversationId, conversationName) => {
    if (window.confirm(`Are you sure you want to delete the conversation "${conversationName}"? This will permanently remove all messages and cannot be undone.`)) {
      await onDeleteConversation(conversationId);
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Conversations ({conversations.length})</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {conversations.map(conversation => (
          <div
            key={conversation.id}
            className={`p-3 rounded-lg transition-colors duration-200 ${
              selectedConversation?.id === conversation.id
                ? 'bg-blue-100 border-blue-200'
                : 'hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div 
                className="flex items-center gap-2 cursor-pointer flex-1"
                onClick={() => onSelectConversation(conversation)}
              >
                {getConversationIcon(conversation.type)}
                <span className="font-medium text-slate-900 truncate">
                  {conversation.name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={`text-xs ${getConversationColor(conversation.type)}`}>
                  {conversation.type}
                </Badge>
                {currentUser?.role === 'admin' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteConversation(conversation.id, conversation.name)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1 h-auto"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>{conversation.member_count || 0} members</span>
              {conversation.last_message_at && (
                <span>{format(new Date(conversation.last_message_at), 'MMM d, h:mm a')}</span>
              )}
            </div>
          </div>
        ))}

        {conversations.length === 0 && (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 mb-4">No conversations yet</p>
            <p className="text-sm text-slate-400">Create team chats to get started</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}