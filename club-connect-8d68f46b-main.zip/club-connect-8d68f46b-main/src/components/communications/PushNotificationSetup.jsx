import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Bell, BellOff, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { PushSubscription } from "@/api/entities";
import { User } from '@/api/entities';

export default function PushNotificationSetup({ pushEnabled, onStatusChange }) {
  const [status, setStatus] = useState('checking');
  const [subscription, setSubscription] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const getCurrentUser = useCallback(async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error getting current user:", error);
    }
  }, []);

  const checkNotificationStatus = useCallback(() => {
    if (!('Notification' in window)) {
      setStatus('not-supported');
      return;
    }

    if (!('serviceWorker' in navigator)) {
      setStatus('no-service-worker');
      return;
    }

    if (!('PushManager' in window)) {
      setStatus('no-push-manager');
      return;
    }

    switch (Notification.permission) {
      case 'granted':
        setStatus('granted');
        setupPushSubscription();
        break;
      case 'denied':
        setStatus('denied');
        break;
      default:
        setStatus('default');
        break;
    }
  }, []);

  useEffect(() => {
    checkNotificationStatus();
    getCurrentUser();
  }, [checkNotificationStatus, getCurrentUser]);

  const setupPushSubscription = async () => {
    try {
      // For now, we'll use browser notifications without service worker
      // This is a simplified approach that works without VAPID keys
      if (currentUser && 'Notification' in window && Notification.permission === 'granted') {
        // Store user preference for notifications
        await PushSubscription.create({
          member_id: currentUser.id,
          subscription_data: { 
            type: 'browser_notification',
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent
          },
          user_agent: navigator.userAgent
        });
        setSubscription({ type: 'browser_notification' });
      }
    } catch (error) {
      console.error('Error setting up push subscription:', error);
      setStatus('error');
    }
  };

  const requestNotificationPermission = async () => {
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        setStatus('granted');
        await setupPushSubscription();
        onStatusChange();
      } else {
        setStatus('denied');
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      setStatus('error');
    }
  };

  const testNotification = () => {
    if (Notification.permission === 'granted') {
      new Notification('Nepbourne FC', {
        body: 'Push notifications are working correctly!',
        icon: '/favicon.ico'
      });
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'granted':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'denied':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'not-supported':
      case 'no-service-worker':
      case 'no-push-manager':
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      default:
        return <Bell className="w-5 h-5 text-slate-600" />;
    }
  };

  const getStatusMessage = () => {
    switch (status) {
      case 'granted':
        return 'Browser notifications are enabled and working.';
      case 'denied':
        return 'Notifications are blocked. Please enable them in your browser settings.';
      case 'not-supported':
        return 'Notifications are not supported in this browser.';
      case 'no-service-worker':
        return 'Service Workers are not supported in this browser.';
      case 'no-push-manager':
        return 'Push messaging is not supported in this browser.';
      case 'error':
        return 'An error occurred while setting up notifications.';
      default:
        return 'Browser notifications are available but not yet enabled.';
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getStatusIcon()}
          Browser Notifications
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertDescription>
            {getStatusMessage()}
          </AlertDescription>
        </Alert>

        <div className="flex gap-3">
          {status === 'default' && (
            <Button onClick={requestNotificationPermission}>
              <Bell className="w-4 h-4 mr-2" />
              Enable Notifications
            </Button>
          )}
          
          {status === 'granted' && (
            <Button onClick={testNotification} variant="outline">
              Test Notification
            </Button>
          )}
        </div>

        {status === 'denied' && (
          <Alert>
            <AlertTriangle className="w-4 h-4" />
            <AlertDescription>
              To enable notifications:
              <ol className="list-decimal list-inside mt-2 space-y-1">
                <li>Click the bell or lock icon in your browser's address bar</li>
                <li>Select "Allow" for notifications</li>
                <li>Refresh this page</li>
              </ol>
            </AlertDescription>
          </Alert>
        )}

        <Alert>
          <AlertDescription className="text-sm text-slate-600">
            <strong>How it works:</strong> When you enable notifications, you'll receive browser alerts for new matches, training sessions, and important announcements. Notifications appear even when you're on other websites.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}