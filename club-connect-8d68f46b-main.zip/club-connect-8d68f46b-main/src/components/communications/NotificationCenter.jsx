import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PushNotification, Team, Member, Player } from "@/api/entities";
import { Send, Bell, Users, User, Calendar } from "lucide-react";

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    body: '',
    type: 'announcement',
    target_type: 'all',
    team_id: '',
    scheduled_at: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [notificationsData, teamsData] = await Promise.all([
        PushNotification.list('-created_date'),
        Team.list()
      ]);
      setNotifications(notificationsData);
      setTeams(teamsData);
    } catch (error) {
      console.error("Error loading notification data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNotification = async (e) => {
    e.preventDefault();
    try {
      const notificationData = {
        ...formData,
        click_action: window.location.origin,
        icon: '/favicon.ico',
        scheduled_at: formData.scheduled_at || new Date().toISOString()
      };

      await PushNotification.create(notificationData);
      setFormData({
        title: '',
        body: '',
        type: 'announcement',
        target_type: 'all',
        team_id: '',
        scheduled_at: ''
      });
      setShowCreateForm(false);
      loadData();
      alert("Notification scheduled successfully!");
    } catch (error) {
      console.error("Error creating notification:", error);
      alert("Failed to schedule notification. Please try again.");
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/80 backdrop-blur-sm">
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>Notification Center</CardTitle>
          <Button 
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4 mr-2" />
            Send Notification
          </Button>
        </CardHeader>
        <CardContent>
          {showCreateForm && (
            <form onSubmit={handleCreateNotification} className="space-y-4 p-4 bg-slate-50 rounded-lg mb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Notification title"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
                  <Select 
                    value={formData.type} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="announcement">Announcement</SelectItem>
                      <SelectItem value="match">Match</SelectItem>
                      <SelectItem value="event">Event</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
                <Textarea
                  value={formData.body}
                  onChange={(e) => setFormData(prev => ({ ...prev, body: e.target.value }))}
                  placeholder="Notification message"
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Send To</label>
                  <Select 
                    value={formData.target_type} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, target_type: value, team_id: '' }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Members</SelectItem>
                      <SelectItem value="team">Specific Team</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.target_type === 'team' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Team</label>
                    <Select 
                      value={formData.team_id} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, team_id: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select team..." />
                      </SelectTrigger>
                      <SelectContent>
                        {teams.map(team => (
                          <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Schedule (Optional)</label>
                <Input
                  type="datetime-local"
                  value={formData.scheduled_at}
                  onChange={(e) => setFormData(prev => ({ ...prev, scheduled_at: e.target.value }))}
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setShowCreateForm(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Schedule Notification
                </Button>
              </div>
            </form>
          )}

          <div className="space-y-3">
            {notifications.map(notification => (
              <div key={notification.id} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-900">{notification.title}</h4>
                    <p className="text-slate-600 mt-1">{notification.body}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-slate-500">
                      <span className="flex items-center gap-1">
                        {notification.target_type === 'all' ? <Users className="w-3 h-3" /> : <User className="w-3 h-3" />}
                        {notification.target_type === 'all' ? 'All Members' : 'Team'}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(notification.scheduled_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    notification.status === 'sent' 
                      ? 'bg-green-100 text-green-800' 
                      : notification.status === 'failed'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {notification.status}
                  </span>
                </div>
              </div>
            ))}

            {notifications.length === 0 && (
              <div className="text-center py-8">
                <Bell className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No notifications sent yet</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}