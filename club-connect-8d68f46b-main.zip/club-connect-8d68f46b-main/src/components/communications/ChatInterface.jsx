
import React, { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Message, ConversationMember, Member, Player } from "@/api/entities";
import { Send, Paperclip, Smile, MoreVertical, Users, Check, CheckCheck } from "lucide-react";
import { format } from "date-fns";
import { User } from '@/api/entities';

export default function ChatInterface({ conversation, onRefresh }) {
  const [messages, setMessages] = useState([]);
  const [members, setMembers] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  const getCurrentUser = useCallback(async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error getting current user:", error);
    }
  }, []);

  const updateMessageStatus = useCallback(async (messageId, status) => {
    try {
      await Message.update(messageId, { status });
    } catch (error) {
      console.error(`Error updating message ${messageId} to ${status}:`, error);
    }
  }, []);

  const loadMessages = useCallback(async () => {
    if (!conversation) return;
    setLoading(true);
    try {
      const messagesData = await Message.filter(
        { conversation_id: conversation.id },
        'created_date',
        100
      );
      setMessages(messagesData);

      // Mark received messages as 'delivered'
      messagesData.forEach(msg => {
        if (msg.status === 'sent' && msg.created_by !== currentUser?.email) {
          updateMessageStatus(msg.id, 'delivered');
        }
      });

    } catch (error) {
      console.error("Error loading messages:", error);
    } finally {
      setLoading(false);
    }
  }, [conversation, currentUser?.email, updateMessageStatus]);

  const loadMembers = useCallback(async () => {
    if (!conversation) return;
    try {
      const membersData = await ConversationMember.filter(
        { conversation_id: conversation.id }
      );
      setMembers(membersData);
    } catch (error) {
      console.error("Error loading members:", error);
    }
  }, [conversation]);
  
  const markVisibleMessagesAsRead = useCallback(() => {
    if (!messagesContainerRef.current || !messages.length) return;
    
    const container = messagesContainerRef.current;
    const containerRect = container.getBoundingClientRect(); // Get container's dimensions once
    
    messages.forEach(message => {
      if (message.status !== 'read' && message.created_by !== currentUser?.email) {
        const messageElement = document.getElementById(`message-${message.id}`);
        if (messageElement) {
          const rect = messageElement.getBoundingClientRect();
          if (rect.top >= containerRect.top && rect.bottom <= containerRect.bottom) {
            updateMessageStatus(message.id, 'read');
          }
        }
      }
    });
  }, [messages, currentUser?.email, updateMessageStatus]);

  useEffect(() => {
    if (conversation) {
      loadMessages();
      loadMembers();
      getCurrentUser();
    }
  }, [conversation, loadMessages, loadMembers, getCurrentUser]);

  useEffect(() => {
    scrollToBottom();
    markVisibleMessagesAsRead();
  }, [messages, markVisibleMessagesAsRead]);
  
  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;

    container.addEventListener('scroll', markVisibleMessagesAsRead);
    // Initial check on mount/container available
    markVisibleMessagesAsRead();
    return () => container.removeEventListener('scroll', markVisibleMessagesAsRead);
  }, [markVisibleMessagesAsRead]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !currentUser) return;

    try {
      // Find current user in members or players to get proper sender info
      let senderName = currentUser.full_name;
      let senderId = currentUser.id;

      // Try to find matching member or player
      const allMembers = await Member.list();
      const allPlayers = await Player.list();
      
      const matchingMember = allMembers.find(m => m.email === currentUser.email);
      const matchingPlayer = allPlayers.find(p => p.email === currentUser.email);

      if (matchingMember) {
        senderId = matchingMember.id;
        senderName = `${matchingMember.first_name} ${matchingMember.last_name}`;
      } else if (matchingPlayer) {
        senderId = matchingPlayer.id;
        senderName = `${matchingPlayer.first_name} ${matchingPlayer.last_name}`;
      }

      const messageData = {
        conversation_id: conversation.id,
        sender_id: senderId,
        sender_name: senderName,
        content: newMessage.trim(),
        message_type: 'text',
        status: 'sent'
      };

      await Message.create(messageData);
      setNewMessage('');
      await loadMessages();
      
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message. Please try again.");
    }
  };

  const isOwnMessage = (message) => {
    if (!currentUser) return false;
    return message.created_by === currentUser.email;
  };

  const formatMessageTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return format(date, 'h:mm a');
    } else if (diffInHours < 168) { // 7 days
      return format(date, 'EEE h:mm a');
    } else {
      return format(date, 'MMM d, h:mm a');
    }
  };

  const renderStatusIcon = (message) => {
    if (!isOwnMessage(message)) return null;

    if (message.status === 'read') {
      return <CheckCheck className="w-4 h-4 text-blue-300" />;
    }
    if (message.status === 'delivered') {
      return <CheckCheck className="w-4 h-4 text-slate-400" />;
    }
    return <Check className="w-4 h-4 text-slate-400" />;
  };

  if (!conversation) return null;

  return (
    <Card className="h-[600px] flex flex-col bg-white/80 backdrop-blur-sm">
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-4 border-b">
        <div>
          <CardTitle className="text-lg">{conversation.name}</CardTitle>
          <p className="text-sm text-slate-500">{members.length} members</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline">
            <Users className="w-3 h-3 mr-1" />
            {conversation.type}
          </Badge>
          <Button variant="ghost" size="sm">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Messages Area */}
        <div 
          ref={messagesContainerRef}
          className="flex-1 overflow-y-auto p-4 space-y-4"
          style={{ maxHeight: 'calc(100% - 80px)' }}
        >
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-slate-500">Loading messages...</div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="text-slate-400 mb-2">No messages yet</div>
                <div className="text-sm text-slate-500">Start the conversation!</div>
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                id={`message-${message.id}`}
                className={`flex ${isOwnMessage(message) ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[70%] ${isOwnMessage(message) ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-900'} rounded-lg p-3`}>
                  {!isOwnMessage(message) && (
                    <div className="text-xs font-semibold mb-1 opacity-75">
                      {message.sender_name}
                    </div>
                  )}
                  <div className="text-sm">{message.content}</div>
                  <div className={`flex items-center justify-end gap-1 text-xs mt-1 opacity-75 ${isOwnMessage(message) ? 'text-blue-100' : 'text-slate-500'}`}>
                    <span>{formatMessageTime(message.created_date)}</span>
                    {renderStatusIcon(message)}
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="p-4 border-t bg-slate-50/50">
          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            <Button type="button" variant="ghost" size="sm">
              <Paperclip className="w-4 h-4" />
            </Button>
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1"
            />
            <Button type="button" variant="ghost" size="sm">
              <Smile className="w-4 h-4" />
            </Button>
            <Button type="submit" size="sm" disabled={!newMessage.trim()}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  );
}
