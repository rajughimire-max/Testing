import React, { useState, useEffect } from 'react';
import { TelegramSubscriber } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Radio, FileCog } from 'lucide-react';
import { setupTelegramWebhook, clearTelegramWebhook, checkTelegramUpdates, processManualUpdates } from '@/api/functions';
import { toast } from 'sonner';

export default function TelegramSettings() {
    const [telegramSubscribers, setTelegramSubscribers] = useState([]);
    const [debugUpdates, setDebugUpdates] = useState(null);
    const [debugLoading, setDebugLoading] = useState(false);
    const [processingUpdates, setProcessingUpdates] = useState(false);

    useEffect(() => {
        loadSubscribers();
    }, []);

    const loadSubscribers = async () => {
        try {
            const subscribersData = await TelegramSubscriber.list('-joined_at');
            setTelegramSubscribers(subscribersData);
        } catch (error) {
            console.error("Error loading subscribers", error);
            toast.error("Could not load Telegram subscribers.");
        }
    };

    const handleSetupWebhook = async () => {
        toast.promise(setupTelegramWebhook(), {
            loading: 'Connecting to Telegram...',
            success: (res) => {
                if (res.data.success) {
                    return `Success! Your bot is now live and connected. Share your bot's username with members so they can subscribe!`;
                } else {
                    throw new Error(res.data.details || 'An unknown error occurred.');
                }
            },
            error: (err) => `Failed to register webhook: ${err.message}`
        });
    };

    const handleClearWebhook = async () => {
        setDebugLoading(true);
        try {
            await toast.promise(clearTelegramWebhook(), {
                loading: 'Clearing webhook...',
                success: (res) => {
                    if (res.data.success) {
                        return `Success! Webhook has been cleared. You can now check for messages manually.`;
                    } else {
                        throw new Error(res.data.details || 'An unknown error occurred.');
                    }
                },
                error: (err) => `Failed to clear webhook: ${err.message}`
            });
        } finally {
            setDebugLoading(false);
        }
    };

    const handleCheckUpdates = async () => {
        setDebugLoading(true);
        setDebugUpdates(null);
        try {
            await toast.promise(checkTelegramUpdates(), {
                loading: 'Checking for new messages from Telegram...',
                success: (res) => {
                    if (res.data.success) {
                        setDebugUpdates(res.data.updates);
                        return `Found ${res.data.updates.length} new messages. See below.`;
                    } else {
                        throw new Error(res.data.details || 'An unknown error occurred.');
                    }
                },
                error: (err) => {
                    return `Failed to check for messages: ${err.message}. This might be because a webhook is still active. Try clearing it first.`
                }
            });
        } finally {
            setDebugLoading(false);
        }
    };

    const handleProcessUpdates = async () => {
        if (!debugUpdates || debugUpdates.length === 0) {
            toast.info("No messages to process. Please check for messages first.");
            return;
        }
        setProcessingUpdates(true);
        try {
            const { data } = await processManualUpdates({ updates: debugUpdates });
            if (data.success) {
                toast.success(data.message);
                setDebugUpdates(null); // Clear the updates after processing
                loadSubscribers(); // Refresh the subscriber list
            } else {
                toast.error(data.error || "Failed to process updates.");
            }
        } catch (error) {
            console.error("Error processing manual updates:", error);
            toast.error("An error occurred while processing the messages.");
        } finally {
            setProcessingUpdates(false);
        }
    };

    return (
        <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-blue-600" />
                Telegram Bot Integration
              </CardTitle>
              <CardDescription>
                Activate your Telegram bot to enable instant, free communication with your members.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Once you've added your Telegram Bot Token in the secrets, click this button **once** to connect it to the platform. This makes your bot live.
                </p>
                <Button onClick={handleSetupWebhook}>
                  Activate Telegram Bot
                </Button>
                
                <div className="border-t pt-4">
                  <h4 className="font-semibold text-slate-900 mb-2">Debug Info</h4>
                  <p className="text-sm text-slate-600 mb-3">Current subscribers: {telegramSubscribers.length}</p>
                  {telegramSubscribers.length > 0 ? (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {telegramSubscribers.map(sub => (
                        <div key={sub.id} className="p-2 bg-slate-50 rounded text-sm">
                          <strong>{sub.display_name}</strong> ({sub.username || 'no username'}) - {sub.is_active ? 'Active' : 'Inactive'}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-amber-600 bg-amber-50 p-3 rounded">
                      No subscribers yet. Members need to search for your bot and send /start first.
                    </p>
                  )}
                  <Button 
                    onClick={loadSubscribers}
                    variant="outline" 
                    size="sm" 
                    className="mt-2"
                  >
                    Refresh Subscribers
                  </Button>
                </div>

                <div className="border-t pt-4 mt-4 space-y-3">
                    <h4 className="font-semibold text-slate-900 mb-2">Advanced Debugging</h4>
                    <p className="text-xs text-slate-500">If the bot is not responding, use these tools to diagnose the issue.</p>
                    <div className="flex gap-2">
                        <Button onClick={handleClearWebhook} variant="destructive" size="sm" disabled={debugLoading || processingUpdates}>
                            Step 1: Clear Webhook
                        </Button>
                        <Button onClick={handleCheckUpdates} variant="secondary" size="sm" disabled={debugLoading || processingUpdates}>
                            Step 2: Check Messages
                        </Button>
                    </div>
                     {debugUpdates && debugUpdates.length > 0 && (
                        <div className="mt-2">
                            <Button onClick={handleProcessUpdates} variant="outline" size="sm" className="bg-green-100 text-green-800 hover:bg-green-200 border-green-300" disabled={processingUpdates}>
                                <FileCog className="w-4 h-4 mr-2" />
                                {processingUpdates ? 'Processing...' : 'Step 3: Add Subscribers from Messages'}
                            </Button>
                            <p className="text-xs text-slate-500 mt-1">This will add new subscribers from the messages shown below.</p>
                        </div>
                    )}
                    {debugUpdates && (
                    <div className="p-3 bg-slate-100 rounded-lg mt-2">
                        <h5 className="font-semibold text-sm mb-2">Messages Received:</h5>
                        {debugUpdates.length > 0 ? (
                        <pre className="text-xs bg-slate-800 text-white p-2 rounded whitespace-pre-wrap max-h-60 overflow-auto">
                            {JSON.stringify(debugUpdates, null, 2)}
                        </pre>
                        ) : (
                        <p className="text-sm text-slate-600 italic">
                            No new messages found. Send a message to your bot (like /start) and try again.
                        </p>
                        )}
                    </div>
                    )}
                </div>
              </div>
            </CardContent>
        </Card>
    );
}