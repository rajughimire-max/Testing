import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Mail, Phone, User, Users } from 'lucide-react';
import { format } from 'date-fns';

export default function GameAttendeesModal({ isOpen, onClose, game, allSignups, allAttendances }) {
  if (!game) return null;

  const getSkillLevelColor = (level) => {
    const colors = {
      'Beginner': 'bg-green-100 text-green-800',
      'Intermediate': 'bg-yellow-100 text-yellow-800', 
      'Advanced': 'bg-red-100 text-red-800',
      'Unknown': 'bg-gray-100 text-gray-800'
    };
    return colors[level] || colors['Unknown'];
  };

  const attendanceRecordsForGame = allAttendances.filter(att => att.event_id === game.id);
  const signupIdsForGame = attendanceRecordsForGame.map(att => att.social_game_signup_id);
  const attendees = allSignups.filter(signup => signupIdsForGame.includes(signup.id));

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Participants for Social Game</DialogTitle>
          <DialogDescription>
            {format(new Date(game.event_date), 'EEEE, d MMM yyyy')} at {game.start_time}
            <Badge className="ml-3">{attendees.length} Signed Up</Badge>
          </DialogDescription>
        </DialogHeader>
        <div className="mt-4 max-h-[60vh] overflow-y-auto pr-4">
          {attendees.length > 0 ? (
            <div className="space-y-4">
              {attendees.map(signup => (
                <div key={signup.id} className="p-4 border rounded-lg bg-slate-50">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center gap-3">
                        <h4 className="font-semibold text-slate-800">{signup.first_name} {signup.last_name}</h4>
                        <Badge className={getSkillLevelColor(signup.skills_level)}>
                          {signup.skills_level}
                        </Badge>
                      </div>
                      <div className="text-sm text-slate-500 flex items-center gap-4">
                        <span className="flex items-center gap-1.5"><Mail className="w-4 h-4" />{signup.email}</span>
                        <span className="flex items-center gap-1.5"><Phone className="w-4 h-4" />{signup.phone}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="font-semibold">No participants have signed up for this game yet.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}