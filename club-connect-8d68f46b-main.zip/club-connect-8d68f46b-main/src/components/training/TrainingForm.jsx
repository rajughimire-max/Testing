
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Save, X, Users, CalendarDays, Clock, Repeat, AlertCircle, ClipboardCheck, Package, Plus, Shield, ShieldCheck, FilePenLine } from "lucide-react";
import { Member, Team, Event, InventoryItem, InventoryTransaction, Player, TrainingAttendance } from "@/api/entities"; // Player and TrainingAttendance might not be directly used here after changes, but keeping for safety.
import { addWeeks, format, addDays, startOfWeek } from "date-fns";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from 'sonner';

import TrainingEquipmentManager from "./TrainingEquipmentManager";
import TrainingAttendanceManager from "./TrainingAttendanceManager";

const generateId = () => `series_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

const dayOfWeekOptions = [
  { value: "monday", label: "Monday" },
  { value: "tuesday", label: "Tuesday" },
  { value: "wednesday", label: "Wednesday" },
  { value: "thursday", label: "Thursday" },
  { value: "friday", label: "Friday" },
  { value: "saturday", label: "Saturday" },
  { value: "sunday", label: "Sunday" }
];

function QuickTeamForm({ onSubmit, onCancel }) {
  const [formData, setFormData] = useState({ name: "", season: "", coach_name: "", assistant_coach_name: "", team_color: "#1e40af", status: "active" });
  const handleChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
  const handleSubmit = (e) => { e.preventDefault(); onSubmit(formData); };

  return (
    <Card className="border-0 shadow-none">
      <CardHeader><CardTitle className="flex items-center gap-2"><Shield className="w-5 h-5" />Create New Team</CardTitle></CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2"><Label htmlFor="name">Team Name *</Label><Input id="name" value={formData.name} onChange={(e) => handleChange("name", e.target.value)} placeholder="e.g., Under 12 Eagles" required /></div>
            <div className="space-y-2"><Label htmlFor="season">Season</Label><Input id="season" value={formData.season} onChange={(e) => handleChange("season", e.target.value)} placeholder="e.g., 2024 Winter" /></div>
            <div className="space-y-2"><Label htmlFor="coach_name">Head Coach Name</Label><Input id="coach_name" value={formData.coach_name} onChange={(e) => handleChange("coach_name", e.target.value)} placeholder="e.g., John Smith" /></div>
            <div className="space-y-2"><Label htmlFor="assistant_coach_name">Assistant Coach Name</Label><Input id="assistant_coach_name" value={formData.assistant_coach_name} onChange={(e) => handleChange("assistant_coach_name", e.target.value)} placeholder="e.g., Jane Doe" /></div>
            <div className="space-y-2"><Label htmlFor="team_color">Team Color</Label><Input id="team_color" type="color" value={formData.team_color} onChange={(e) => handleChange("team_color", e.target.value)} /></div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700"><Save className="w-4 h-4 mr-2" />Create Team</Button>
        </CardFooter>
      </form>
    </Card>
  );
}

function TrainingDetailsForm({ sessionData, teams, members, onDataChange, onCreateTeam }) {
  // NOTE: This component no longer holds its own state. It works directly with props.
  const [coaches, setCoaches] = useState([]);
  const [showCreateTeam, setShowCreateTeam] = useState(false);

  useEffect(() => {
    if (members) {
      setCoaches(members.filter(m => m.membership_type === 'coach' && m.membership_status === 'active'));
    }
  }, [members]);

  const handleChange = (field, value) => {
    // Call the parent's handler to update the central state
    onDataChange({ ...sessionData, [field]: value });
  };

  const calculateEndTime = (startTime, durationMinutes) => {
    if (!startTime || !durationMinutes) return "";
    const start = new Date(`2000-01-01T${startTime}`);
    const endTime = new Date(start.getTime() + durationMinutes * 60000);
    return endTime.toTimeString().slice(0, 5);
  };
  
  const handleTeamToggle = (teamId) => {
    const newTeamIds = (sessionData.team_ids || []).includes(teamId)
      ? (sessionData.team_ids || []).filter(id => id !== teamId)
      : [...(sessionData.team_ids || []), teamId];
    handleChange("team_ids", newTeamIds);
  };

  const handleTeamCreated = (newTeam) => {
    const newTeamIds = [...(sessionData.team_ids || []), newTeam.id];
    handleChange("team_ids", newTeamIds);
    setShowCreateTeam(false);
  };

  return (
    <CardContent className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="title">Training Title *</Label>
          <Input id="title" value={sessionData.title || ""} onChange={(e) => handleChange("title", e.target.value)} placeholder="e.g., Weekly Team Training" required />
        </div>
        <div className="space-y-2">
          <Label>Teams * (Select one or more)</Label>
          {teams?.length > 0 ? (
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="flex-1 border border-slate-300 rounded-md p-3 max-h-32 overflow-y-auto">
                  {(sessionData.team_ids || []).length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {(sessionData.team_ids || []).map(teamId => {
                        const team = teams.find(t => t.id === teamId);
                        return team ? <Badge key={teamId} variant="default" className="flex items-center gap-1">{team.name}<X className="w-3 h-3 cursor-pointer" onClick={() => handleTeamToggle(teamId)}/></Badge> : null;
                      })}
                    </div>
                  ) : <span className="text-slate-500 text-sm">No teams selected</span>}
                </div>
                <Button type="button" variant="outline" onClick={() => setShowCreateTeam(true)} className="px-3"><Plus className="w-4 h-4" /></Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-40 overflow-y-auto border rounded p-2">
                {teams.map(team => (
                  <div key={team.id} className="flex items-center gap-2">
                    <Checkbox id={`team_${team.id}`} checked={(sessionData.team_ids || []).includes(team.id)} onCheckedChange={() => handleTeamToggle(team.id)} />
                    <Label htmlFor={`team_${team.id}`} className="flex-1 text-sm cursor-pointer">{team.name}</Label>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-4 border border-dashed rounded-lg text-center">
              <Shield className="w-8 h-8 mx-auto text-slate-400 mb-2" />
              <p className="text-slate-600 text-sm mb-3">No teams created yet</p>
              <Button type="button" onClick={() => setShowCreateTeam(true)} className="bg-blue-600 hover:bg-blue-700"><Plus className="w-4 h-4 mr-2" />Create First Team</Button>
            </div>
          )}
        </div>
      </div>
      
      {showCreateTeam && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full"><QuickTeamForm onSubmit={(teamData) => onCreateTeam(teamData).then(handleTeamCreated)} onCancel={() => setShowCreateTeam(false)} /></div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="space-y-2"><Label htmlFor="event_date">Date *</Label><Input id="event_date" type="date" value={sessionData.event_date || ""} onChange={(e) => handleChange("event_date", e.target.value)} required /></div>
        <div className="space-y-2"><Label htmlFor="start_time">Start Time *</Label><Input id="start_time" type="time" value={sessionData.start_time || ""} onChange={(e) => handleChange("start_time", e.target.value)} required /></div>
        <div className="space-y-2"><Label htmlFor="duration_minutes">Duration (min) *</Label><Input id="duration_minutes" type="number" min="15" value={sessionData.duration_minutes || 90} onChange={(e) => handleChange("duration_minutes", parseInt(e.target.value))} required /><p className="text-xs text-slate-500">End time: {calculateEndTime(sessionData.start_time, sessionData.duration_minutes)}</p></div>
        <div className="space-y-2"><Label htmlFor="venue">Location</Label><Input id="venue" value={sessionData.venue || ""} onChange={(e) => handleChange("venue", e.target.value)} placeholder="Training ground" /></div>
      </div>
      <div className="space-y-2"><Label htmlFor="coach_id">Coach</Label><Select value={sessionData.coach_id || ""} onValueChange={(value) => handleChange("coach_id", value === 'none' ? '' : value)}><SelectTrigger><SelectValue placeholder="Select coach..." /></SelectTrigger><SelectContent><SelectItem value="none">No specific coach</SelectItem>{coaches.map(c => <SelectItem key={c.id} value={c.id}>{c.first_name} {c.last_name}</SelectItem>)}</SelectContent></Select></div>
      <div className="space-y-2"><Label htmlFor="coach_observations">Coach's Notes</Label><Textarea id="coach_observations" value={sessionData.coach_observations || ""} onChange={(e) => handleChange("coach_observations", e.target.value)} placeholder="Training objectives, focus areas..." rows={3} /></div>
    </CardContent>
  );
}

export default function TrainingForm({ session, teams, members, inventoryItems, onSubmit, onCreateTeam, onCancel, onInventoryUpdate, onStatusChange }) {
  const getInitialData = (session) => session ? { ...session } : {
      title: "",
      description: "",
      event_date: "",
      start_time: "",
      duration_minutes: 90,
      venue: "",
      status: "draft",
      team_ids: [],
      coach_id: "",
      coach_observations: "",
      equipment_taken: [],
  };

  const [sessionData, setSessionData] = useState(getInitialData(session));
  const [activeTab, setActiveTab] = useState("details");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    setSessionData(getInitialData(session));
  }, [session]);

  const handleDataChange = useCallback((newData) => {
    setSessionData(prev => ({ ...prev, ...newData }));
  }, []);

  const calculateEndTimeForSubmit = (startTime, durationMinutes) => {
    if (!startTime || !durationMinutes) return "";
    const start = new Date(`2000-01-01T${startTime}`);
    const endTime = new Date(start.getTime() + durationMinutes * 60000);
    return endTime.toTimeString().slice(0, 5);
  };

  const handleSaveSession = async () => {
    setError(null);
    if (!sessionData.title || !sessionData.event_date || !sessionData.start_time || !sessionData.team_ids || sessionData.team_ids.length === 0) {
        toast.error("Please fill in all required fields (Title, Date, Start Time, Teams).");
        return;
    }
    setLoading(true);
    try {
      const finalPayload = {
        ...sessionData,
        end_time: calculateEndTimeForSubmit(sessionData.start_time, sessionData.duration_minutes),
        event_type: "training",
      };

      const savedSession = await onSubmit(finalPayload);
      
      // No need to setSessionData here, as the parent will reload and close the form.
      toast.success("Session details saved successfully!");
      
    } catch (err) {
      console.error("Error saving session details:", err);
      toast.error("Failed to save session details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (newStatus) => {
    setLoading(true);
    setError(null);
    try {
      await Event.update(sessionData.id, { status: newStatus });
      setSessionData(prev => ({ ...prev, status: newStatus }));
      toast.success(`Session status updated to ${newStatus}`);
      if (onStatusChange) onStatusChange();
    } catch (err) {
      console.error('Error updating status:', err);
      toast.error('Failed to update session status.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Card className="mb-6 bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <FilePenLine className="w-5 h-5 text-blue-600" />
            {sessionData?.id ? "Manage Training Session" : "New Training Session"}
          </CardTitle>
          {sessionData?.status && <Badge variant={sessionData.status === 'completed' ? 'default' : 'outline'}>{sessionData.status.toUpperCase()}</Badge>}
        </div>
      </CardHeader>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="px-6 grid w-full grid-cols-3">
          <TabsTrigger value="details">1. Details</TabsTrigger>
          <TabsTrigger value="attendance" disabled={!sessionData?.id}>2. Attendance & Performance</TabsTrigger>
          <TabsTrigger value="equipment" disabled={!sessionData?.id}>3. Equipment</TabsTrigger>
        </TabsList>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mx-6 mt-4">
            <AlertCircle className="w-4 h-4 inline mr-2" /> {error}
          </div>
        )}

        <TabsContent value="details">
          <TrainingDetailsForm 
            sessionData={sessionData} 
            teams={teams} 
            members={members} 
            onDataChange={handleDataChange}
            onCreateTeam={onCreateTeam}
          />
        </TabsContent>
        
        <TabsContent value="attendance">
          {sessionData?.id && (
            <TrainingAttendanceManager
              session={sessionData}
              onFinalize={() => {}} 
            />
          )}
        </TabsContent>

        <TabsContent value="equipment">
          {sessionData?.id && (
            <TrainingEquipmentManager
              session={sessionData} 
              onSessionUpdate={handleDataChange} 
              inventoryItems={inventoryItems}
              isCompleted={sessionData.status === 'completed'}
              onInventoryUpdate={onInventoryUpdate}
            />
          )}
        </TabsContent>
      </Tabs>
      
      <CardFooter className="flex justify-between items-center mt-6 border-t pt-6">
        <div className="flex gap-2">
            {sessionData?.id && sessionData.status !== 'completed' && (
                <Button type="button" onClick={() => handleUpdateStatus('completed')} className="bg-green-600 hover:bg-green-700">
                    Mark as Completed
                </Button>
            )}
            {sessionData?.id && sessionData.status === 'completed' && (
                <Button type="button" onClick={() => handleUpdateStatus('in_progress')} variant="outline">
                    Revert to In Progress
                </Button>
            )}
        </div>
        <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
              <X className="w-4 h-4 mr-2" />
              Close
            </Button>
            <Button onClick={handleSaveSession} disabled={loading}>
              <Save className="w-4 h-4 mr-2" /> 
              {loading ? "Saving..." : (sessionData?.id ? "Save & Close" : "Save Session")}
            </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
