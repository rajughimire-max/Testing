
import React, { useState, useEffect, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { AlertCircle, Repeat } from "lucide-react";
import { addWeeks, format, addDays, startOfWeek } from "date-fns";
import { Member } from "@/api/entities";

const dayOfWeekOptions = [
  { value: "monday", label: "Monday" },
  { value: "tuesday", label: "Tuesday" },
  { value: "wednesday", label: "Wednesday" },
  { value: "thursday", label: "Thursday" },
  { value: "friday", label: "Friday" },
  { value: "saturday", label: "Saturday" },
  { value: "sunday", label: "Sunday" }
];

export default function TrainingDetailsForm({ session, teams, members, onSubmit, onCreateTeam, onCancel, nextStep, goToStep }) {
    const [formData, setFormData] = useState({
        title: "",
        description: "",
        event_date: "",
        start_time: "",
        duration_minutes: 90,
        venue: "",
        event_type: "training",
        team_ids: [], // Changed from team_id to team_ids
        coach_id: "",
        is_recurring: false,
        recurrence_pattern: {
          frequency: "weekly",
          days_of_week: [],
          end_condition: "end_date",
          end_date: "",
          number_of_occurrences: 10
        },
        ...session // Use 'session' instead of 'sessionData'
    });
    
    const [coaches, setCoaches] = useState([]);
    const [previewOccurrences, setPreviewOccurrences] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        Member.list().then(membersList => {
            const coachMembers = membersList.filter(m => m.membership_type === 'coach' && m.membership_status === 'active');
            setCoaches(coachMembers);
        });
    }, []);
    
    // Removed the useEffect for onDataChange as per the outline, now using handleSubmit

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleRecurrenceChange = (field, value) => {
        setFormData(prev => ({
          ...prev,
          recurrence_pattern: { ...prev.recurrence_pattern, [field]: value }
        }));
    };
    
    const handleDayOfWeekToggle = (day) => {
        const currentDays = formData.recurrence_pattern.days_of_week;
        const newDays = currentDays.includes(day)
          ? currentDays.filter(d => d !== day)
          : [...currentDays, day];
        handleRecurrenceChange("days_of_week", newDays);
    };

    const calculateEndTime = () => {
        if (!formData.start_time || !formData.duration_minutes) return "";
        const startTime = new Date(`2000-01-01T${formData.start_time}`);
        const endTime = new Date(startTime.getTime() + formData.duration_minutes * 60000);
        return endTime.toTimeString().slice(0, 5);
    };

    const generateOccurrences = useCallback(() => {
        if (!formData.is_recurring || !formData.event_date || !formData.start_time || formData.recurrence_pattern.days_of_week.length === 0) return [];
        const occurrences = [];
        const pattern = formData.recurrence_pattern;
        const startDate = new Date(formData.event_date);
        let currentWeek = startOfWeek(startDate, { weekStartsOn: 1 });
        const endDate = pattern.end_condition === "end_date" && pattern.end_date ? new Date(pattern.end_date) : addWeeks(startDate, 26);
        const maxOccurrences = pattern.end_condition === "occurrences" ? pattern.number_of_occurrences : 100;
        let occurrenceCount = 0;
        while (currentWeek <= endDate && occurrenceCount < maxOccurrences) {
            pattern.days_of_week.forEach(dayName => {
                const dayIndex = dayOfWeekOptions.findIndex(d => d.value === dayName);
                if (dayIndex !== -1) { // Ensure dayName is valid
                    const occurrenceDate = addDays(currentWeek, dayIndex);
                    if (occurrenceDate >= startDate && occurrenceDate <= endDate && occurrenceCount < maxOccurrences) {
                        occurrences.push({ date: format(occurrenceDate, 'yyyy-MM-dd'), dayName: dayOfWeekOptions[dayIndex].label });
                        occurrenceCount++;
                    }
                }
            });
            currentWeek = addWeeks(currentWeek, 1);
        }
        return occurrences.slice(0, maxOccurrences);
    }, [formData.is_recurring, formData.event_date, formData.start_time, formData.recurrence_pattern]);

    useEffect(() => {
        setPreviewOccurrences(generateOccurrences());
    }, [generateOccurrences]);

    // This form no longer has a submit button, validation is indicative
    useEffect(() => {
        let newError = null;
        if (formData.duration_minutes <= 0) newError = "Duration must be positive.";
        if (formData.is_recurring) {
            if (formData.recurrence_pattern.days_of_week.length === 0) newError = "Select at least one day for recurring sessions.";
            if (formData.recurrence_pattern.end_condition === "end_date" && !formData.recurrence_pattern.end_date) newError = "Specify an end date.";
        }
        setError(newError);
    }, [formData]);

    const handleSubmit = (e) => {
        e.preventDefault();
        // Basic validation before submission
        if (!formData.title || !formData.event_date || !formData.start_time || formData.team_ids.length === 0) {
            setError("Please fill in all required fields (Title, Date, Start Time, at least one Team).");
            return;
        }
        if (error) { // If there's a custom error from useEffect
            return;
        }
        onSubmit(formData);
    };

    return (
        <div className="p-6 space-y-6">
            <form onSubmit={handleSubmit}>
                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                        <AlertCircle className="w-4 h-4 inline mr-2" />{error}
                    </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="title">Training Title *</Label>
                        <Input id="title" value={formData.title} onChange={(e) => handleChange("title", e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="team_ids">Teams *</Label>
                        <div className="space-y-3">
                            <div className="flex gap-2">
                                <div className="flex-1 border border-slate-300 rounded-md p-3 max-h-32 overflow-y-auto">
                                    {(formData.team_ids || []).length > 0 ? (
                                        <div className="flex flex-wrap gap-2">
                                            {(formData.team_ids || []).map(teamId => {
                                                const team = teams.find(t => t.id === teamId);
                                                return team ? (
                                                    <div key={teamId} className="flex items-center gap-1 bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                                                        {team.name}
                                                        <button 
                                                            type="button"
                                                            onClick={() => handleChange("team_ids", (formData.team_ids || []).filter(id => id !== teamId))}
                                                            className="ml-1 text-blue-600 hover:text-blue-800"
                                                        >
                                                            ×
                                                        </button>
                                                    </div>
                                                ) : null;
                                            })}
                                        </div>
                                    ) : (
                                        <span className="text-slate-500 text-sm">No teams selected</span>
                                    )}
                                </div>
                            </div>
                            {teams && teams.length > 0 && (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-40 overflow-y-auto border rounded p-2">
                                    {teams.map(team => (
                                        <div key={team.id} className="flex items-center gap-2">
                                            <input
                                                type="checkbox"
                                                id={`team_${team.id}`}
                                                checked={(formData.team_ids || []).includes(team.id)}
                                                onChange={() => {
                                                    const currentIds = formData.team_ids || [];
                                                    const newIds = currentIds.includes(team.id)
                                                        ? currentIds.filter(id => id !== team.id)
                                                        : [...currentIds, team.id];
                                                    handleChange("team_ids", newIds);
                                                }}
                                            />
                                            <Label htmlFor={`team_${team.id}`} className="flex-1 text-sm cursor-pointer">
                                                {team.name}
                                            </Label>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
                
                <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" value={formData.description} onChange={(e) => handleChange("description", e.target.value)} rows={2} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="event_date">Date *</Label>
                        <Input id="event_date" type="date" value={formData.event_date} onChange={(e) => handleChange("event_date", e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="start_time">Start Time *</Label>
                        <Input id="start_time" type="time" value={formData.start_time} onChange={(e) => handleChange("start_time", e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="duration_minutes">Duration (minutes) *</Label>
                        <Input id="duration_minutes" type="number" min="15" value={formData.duration_minutes} onChange={(e) => handleChange("duration_minutes", parseInt(e.target.value))} required />
                        <p className="text-xs text-slate-500">End time: {calculateEndTime()}</p>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="venue">Location</Label>
                        <Input id="venue" value={formData.venue} onChange={(e) => handleChange("venue", e.target.value)} />
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="coach_id">Coach</Label>
                    <Select value={formData.coach_id} onValueChange={(value) => handleChange("coach_id", value)}>
                        <SelectTrigger><SelectValue placeholder="Select coach" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value={null}>No coach</SelectItem> {/* Changed value from null to empty string for consistency */}
                            {coaches.map(coach => <SelectItem key={coach.id} value={coach.id}>{coach.first_name} {coach.last_name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                {!session?.id && ( // Use 'session' instead of 'sessionData'
                    <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                        <div className="flex items-center gap-2 mb-4">
                            <Checkbox id="is_recurring" checked={formData.is_recurring} onCheckedChange={(checked) => handleChange("is_recurring", checked)} />
                            <Label htmlFor="is_recurring" className="text-lg font-medium flex items-center gap-2"><Repeat className="w-5 h-5 text-blue-600" />Recurring Session</Label>
                        </div>
                        {formData.is_recurring && (
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label>Days of Week *</Label>
                                    <div className="flex flex-wrap gap-2">{dayOfWeekOptions.map(day => <Button key={day.value} type="button" variant={formData.recurrence_pattern.days_of_week.includes(day.value) ? "default" : "outline"} size="sm" onClick={() => handleDayOfWeekToggle(day.value)}>{day.label}</Button>)}</div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>End Condition *</Label>
                                        <Select value={formData.recurrence_pattern.end_condition} onValueChange={(value) => handleRecurrenceChange("end_condition", value)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="end_date">End on date</SelectItem>
                                                <SelectItem value="occurrences">Number of sessions</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    {formData.recurrence_pattern.end_condition === "end_date" ? (
                                        <div className="space-y-2">
                                            <Label htmlFor="end_date">End Date *</Label>
                                            <Input id="end_date" type="date" value={formData.recurrence_pattern.end_date} onChange={(e) => handleRecurrenceChange("end_date", e.target.value)} min={formData.event_date} required />
                                        </div>
                                    ) : (
                                        <div className="space-y-2">
                                            <Label htmlFor="occurrences">Number of Sessions *</Label>
                                            <Input id="occurrences" type="number" min="1" max="100" value={formData.recurrence_pattern.number_of_occurrences} onChange={(e) => handleRecurrenceChange("number_of_occurrences", parseInt(e.target.value))} required />
                                        </div>
                                    )}
                                </div>
                                {previewOccurrences.length > 0 && (
                                    <div className="bg-white rounded-lg p-4 border">
                                        <h4 className="font-medium text-slate-900 mb-2">Preview: {previewOccurrences.length} sessions will be created</h4>
                                        <div className="max-h-32 overflow-y-auto grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">{previewOccurrences.slice(0, 12).map((occ, idx) => <div key={idx} className="text-slate-600">{format(new Date(occ.date), "MMM d")} ({occ.dayName})</div>)}{previewOccurrences.length > 12 && <div className="text-slate-400">+{previewOccurrences.length - 12} more...</div>}</div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                )}

                <div className="flex justify-between pt-6">
                    <Button type="button" variant="outline" onClick={onCancel}>
                        Cancel
                    </Button>
                    <div className="flex gap-2">
                        <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                            {session?.id ? 'Update Session' : 'Create Session'}
                        </Button>
                        {nextStep && (
                            <Button type="button" onClick={nextStep} variant="outline">
                                Next: Equipment
                            </Button>
                        )}
                    </div>
                </div>
            </form>
        </div>
    );
}
