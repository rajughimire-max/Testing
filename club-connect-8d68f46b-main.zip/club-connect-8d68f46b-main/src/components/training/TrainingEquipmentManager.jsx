import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Package, Plus, CheckCircle, RotateCcw, AlertTriangle } from 'lucide-react';
import { InventoryItem, InventoryTransaction, User as UserEntity, Event, TrainingEquipment } from '@/api/entities';
import { toast } from 'sonner';

export default function TrainingEquipmentManager({ session, inventoryItems, onInventoryUpdate, prevStep, nextStep }) {
    const [equipmentList, setEquipmentList] = useState([]);
    const [quantities, setQuantities] = useState({});
    const [returnQuantities, setReturnQuantities] = useState({});
    const [returnReasons, setReturnReasons] = useState({});
    const [returnedBy, setReturnedBy] = useState('Coach');
    const [processing, setProcessing] = useState(false);
    const [currentUser, setCurrentUser] = useState(null);
    const [localInventory, setLocalInventory] = useState(inventoryItems || []);
    const [loading, setLoading] = useState(true);

    const returnPersonOptions = [ /* ... */ ];
    const missingReasonOptions = [ /* ... */ ];

    const loadSessionEquipment = useCallback(async () => {
        if (!session?.id) return;
        setLoading(true);
        try {
            const data = await TrainingEquipment.filter({ session_id: session.id });
            setEquipmentList(data);
            
            const initialReturnQuantities = {};
            data.forEach(item => {
                const outstanding = item.quantity_issued - (item.quantity_returned || 0);
                initialReturnQuantities[item.id] = outstanding;
            });
            setReturnQuantities(initialReturnQuantities);
        } catch (error) {
            toast.error("Failed to load session equipment.");
        } finally {
            setLoading(false);
        }
    }, [session?.id]);

    useEffect(() => {
        const getCurrentUser = async () => { /* ... */ };
        getCurrentUser();
        setLocalInventory(inventoryItems || []);
        loadSessionEquipment();
    }, [inventoryItems, session, loadSessionEquipment]);

    const getAvailableStock = (itemId) => { /* ... */ };
    const handleQuantityChange = (itemId, value) => { /* ... */ };

    const addEquipment = async (item) => {
        const qtyToAdd = quantities[item.id] || 0;
        if (qtyToAdd <= 0) { toast.error('Please enter a quantity greater than 0'); return; }
        const availableStock = getAvailableStock(item.id);
        if (qtyToAdd > availableStock) { toast.error(`Not enough stock. Only ${availableStock} available.`); return; }

        setProcessing(true);
        try {
            const existingRecord = equipmentList.find(eq => eq.item_id === item.id);

            if (existingRecord) {
                await TrainingEquipment.update(existingRecord.id, {
                    quantity_issued: existingRecord.quantity_issued + qtyToAdd,
                });
            } else {
                await TrainingEquipment.create({
                    session_id: session.id,
                    item_id: item.id,
                    item_name: item.name,
                    quantity_issued: qtyToAdd,
                });
            }

            await InventoryItem.update(item.id, { quantity_allocated: (item.quantity_allocated || 0) + qtyToAdd });
            
            await InventoryTransaction.create({
                item_id: item.id,
                transaction_type: 'Check-out',
                quantity_change: -qtyToAdd,
                reason: `Issued for training session: ${session.title}`,
                assigned_to_person_id: currentUser?.email,
                training_session_id: session.id,
            });

            await loadSessionEquipment();
            onInventoryUpdate();
            
            toast.success(`${qtyToAdd} x ${item.name} added to session.`);
            setQuantities(prev => ({ ...prev, [item.id]: 0 }));

        } catch (error) {
            console.error('Error adding equipment:', error);
            toast.error('Failed to add equipment.');
        } finally {
            setProcessing(false);
        }
    };

    const removeEquipment = async (trainingEquipmentId) => {
        const itemToRemove = equipmentList.find(eq => eq.id === trainingEquipmentId);
        if (!itemToRemove) { toast.error("Item not found."); return; }
        if (itemToRemove.quantity_returned > 0) { toast.error("Cannot remove partially/fully returned items."); return; }

        setProcessing(true);
        try {
            const inventoryItem = localInventory.find(i => i.id === itemToRemove.item_id);
            if (inventoryItem) {
                await InventoryItem.update(inventoryItem.id, {
                    quantity_allocated: Math.max(0, (inventoryItem.quantity_allocated || 0) - itemToRemove.quantity_issued),
                });
            }
            
            await TrainingEquipment.delete(trainingEquipmentId);
            
            await loadSessionEquipment();
            onInventoryUpdate();

            toast.success(`${itemToRemove.item_name} removed from session.`);
        } catch (error) {
            console.error('Error removing equipment:', error);
            toast.error('Failed to remove equipment.');
        } finally {
            setProcessing(false);
        }
    };
    
    const handleReasonChange = (itemId, reason, note = null) => { /* ... */ };

    const handleProcessReturns = async () => {
        if (!returnedBy) { toast.error("Please select who is returning the equipment."); return; }
        
        for (const item of equipmentList) {
            const returnedQty = returnQuantities[item.id] || 0;
            const missingQty = item.quantity_issued - (item.quantity_returned || 0) - returnedQty;
            if (missingQty > 0 && !returnReasons[item.id]) {
                toast.error(`Please provide a reason for missing items: ${item.item_name}`);
                return;
            }
        }
        
        setProcessing(true);
        try {
            for (const item of equipmentList) {
                const returnedQty = returnQuantities[item.id] || 0;
                const totalReturned = (item.quantity_returned || 0) + returnedQty;
                const missingQty = item.quantity_issued - totalReturned;
                
                // Process returned items
                if (returnedQty > 0) {
                    const inventoryItem = await InventoryItem.get(item.item_id);
                    await InventoryItem.update(item.item_id, {
                        quantity_allocated: Math.max(0, (inventoryItem.quantity_allocated || 0) - returnedQty),
                    });
                    await InventoryTransaction.create({ /* ... */ });
                }

                // Handle missing items
                if (missingQty > 0 && returnedQty < item.quantity_issued) {
                    const reason = returnReasons[item.id];
                    if (!reason) continue; // Should have been caught earlier, but safety first
                    const reasonNote = returnReasons[`${item.id}_note`] || '';
                    const fullReason = reason === 'other' ? `Other: ${reasonNote}` : reason;
                    
                    const inventoryItem = await InventoryItem.get(item.item_id);
                    await InventoryItem.update(item.item_id, {
                        quantity_allocated: Math.max(0, (inventoryItem.quantity_allocated || 0) - missingQty),
                        quantity_damaged: (inventoryItem.quantity_damaged || 0) + missingQty
                    });
                    await InventoryTransaction.create({ /* ... */ });
                }

                // Update the TrainingEquipment record
                await TrainingEquipment.update(item.id, {
                    quantity_returned: totalReturned,
                    status: totalReturned >= item.quantity_issued ? 'Returned' : 'Partially Returned',
                    missing_reason: returnReasons[item.id],
                    missing_reason_note: returnReasons[`${item.id}_note`],
                    returned_by: returnedBy,
                });
            }

            await loadSessionEquipment();
            onInventoryUpdate();
            toast.success("Equipment returns processed successfully!");

        } catch (error) {
            console.error("Error processing returns:", error);
            toast.error("Failed to process equipment returns.");
        } finally {
            setProcessing(false);
        }
    };
    
    const allReturned = equipmentList.every(item => (item.quantity_returned || 0) >= item.quantity_issued);
    const hasOutstandingEquipment = equipmentList.some(item => (item.quantity_returned || 0) < item.quantity_issued);

    if (loading) {
        return <CardContent><p>Loading equipment...</p></CardContent>;
    }

    return (
        <Card className="border-0 shadow-none">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-blue-600"/>Equipment Management
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                {equipmentList.length > 0 && (
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Item</TableHead>
                                <TableHead className="text-center">Issued</TableHead>
                                <TableHead className="text-center">Returned</TableHead>
                                <TableHead className="text-center">Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {equipmentList.map(item => (
                                <TableRow key={item.id}>
                                    <TableCell>{item.item_name}</TableCell>
                                    <TableCell className="text-center">{item.quantity_issued}</TableCell>
                                    <TableCell className="text-center">{item.quantity_returned || 0}</TableCell>
                                    <TableCell className="text-center">
                                        <Badge variant={(item.quantity_returned || 0) >= item.quantity_issued ? 'default' : 'destructive'}>
                                            {item.status}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        {(item.quantity_returned || 0) === 0 && (
                                            <Button variant="destructive" size="sm" onClick={() => removeEquipment(item.id)} disabled={processing}>
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        )}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                )}
                
                {/* Add Equipment Section */}
                <div className="space-y-4 p-4 border rounded-lg bg-slate-50">
                    {/* ... Same as before ... */}
                </div>

                {/* Return Processing Form */}
                {hasOutstandingEquipment && (
                    <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                        {/* ... Adapted to use item.id instead of item.issue_id ... */}
                    </div>
                )}
                
                {/* All Returned Status */}
                {allReturned && equipmentList.length > 0 && (
                    <div className="p-4 text-center bg-green-50 rounded-lg border border-green-200 text-green-800">
                       {/* ... */}
                    </div>
                )}

                {/* Navigation */}
                <div className="flex justify-between pt-4 border-t">
                    <Button type="button" onClick={prevStep} variant="outline">
                        Previous: Details
                    </Button>
                    <Button type="button" onClick={nextStep} disabled={hasOutstandingEquipment}>
                        Next: Attendance {hasOutstandingEquipment && "(Complete Returns First)"}
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}