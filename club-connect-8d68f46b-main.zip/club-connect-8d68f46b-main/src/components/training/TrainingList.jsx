
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Edit, 
  Trash2, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  User, 
  Repeat, 
  CalendarDays, 
  AlertTriangle, 
  FilePenLine, 
  Package, 
  RotateCcw, 
  CheckCircle,
  MoreVertical, // Added from outline
  ShieldCheck // Added from outline
} from "lucide-react";
import { format, isAfter, isBefore, parseISO } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import EquipmentReturnModal from './EquipmentReturnModal'; // This is now imported as a separate component

const getSessionStatus = (session) => {
  if (session.status === 'completed') return 'completed';
  if (session.status === 'cancelled') return 'cancelled';
  
  const now = new Date();
  const startDateTime = new Date(`${session.event_date}T${session.start_time || '00:00'}`);

  if (isAfter(startDateTime, now)) return 'upcoming';
  
  // If the session is in the past and not completed/cancelled, it's past due
  return 'past_due';
};

const getStatusBadge = (status) => {
  const statusConfig = {
    upcoming: { color: "bg-blue-100 text-blue-800", label: "Upcoming" },
    in_progress: { color: "bg-yellow-100 text-yellow-800", label: "In Progress" },
    completed: { color: "bg-green-100 text-green-800", label: "Completed" },
    draft: { color: "bg-gray-100 text-gray-800", label: "Draft" },
    cancelled: { color: "bg-red-100 text-red-800", label: "Cancelled" },
    past_due: { color: "bg-orange-100 text-orange-800", label: "Past Due" } // Added past_due badge
  };
  
  const config = statusConfig[status] || statusConfig.draft;
  return <Badge className={config.color}>{config.label}</Badge>;
};

const SessionCard = ({ session, teams, members, onEdit, onDelete, onEquipmentReturn, onSessionDoubleClick }) => {
  const teamIds = session.team_ids || [];
  const sessionTeams = teamIds.map(id => teams.find(t => t.id === id)).filter(Boolean);

  const coachName = session.coach_id 
    ? (() => {
        const coach = members.find(m => m.id === session.coach_id);
        return coach ? `${coach.first_name} ${coach.last_name}` : "Unknown Coach";
      })()
    : "No Coach Assigned";
    
  const status = session.status || getSessionStatus(session);
  const isSeriesEvent = session.series_id;
  
  // Use a clear, safe check for equipment
  const hasEquipmentIssued = session.equipment_taken && session.equipment_taken.length > 0;
  const equipmentOutstandingCount = hasEquipmentIssued ? session.equipment_taken.filter(item => (item.quantity_returned || 0) < item.quantity_issued).length : 0;
  const totalEquipmentItems = hasEquipmentIssued ? session.equipment_taken.length : 0; // New calculation

  return (
    <Card 
      className="bg-white/90 backdrop-blur-sm hover:shadow-lg transition-shadow duration-300 cursor-pointer"
      onDoubleClick={() => onSessionDoubleClick(session)}
    >
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-bold text-xl text-slate-900">{session.title}</h3>
              {isSeriesEvent && (
                <Badge variant="outline" className="text-xs flex items-center gap-1">
                  <Repeat className="w-3 h-3" />
                  Series
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-4 text-sm text-slate-600 mb-3 flex-wrap">
              <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4"/>{format(new Date(session.event_date), "EEE, d MMM yyyy")}</span>
              <span className="flex items-center gap-1.5"><Clock className="w-4 h-4"/>{session.start_time} {session.duration_minutes && `(${session.duration_minutes}m)`}</span>
              {session.venue && <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4"/>{session.venue}</span>}
            </div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              {getStatusBadge(status)}
               {sessionTeams.map(team => (
                <Badge key={team.id} variant="secondary" style={{backgroundColor: team.team_color, color: 'white'}} className="border">
                  <Users className="w-3 h-3 mr-1" />
                  {team.name}
                </Badge>
              ))}
              {coachName !== "No Coach Assigned" && <Badge variant="outline" className="flex items-center gap-1"><User className="w-3 h-3" />{coachName}</Badge>}
              
              {/* Enhanced Equipment Status Badges */}
              {hasEquipmentIssued && (
                <>
                  <Badge className="bg-purple-100 text-purple-800 flex items-center gap-1">
                    <Package className="w-3 h-3"/>
                    {totalEquipmentItems} Equipment Item{totalEquipmentItems !== 1 ? 's' : ''}
                  </Badge>
                  
                  {equipmentOutstandingCount > 0 && (
                    <Badge variant="destructive" className="flex items-center gap-1 animate-pulse">
                      <AlertTriangle className="w-3 h-3" />
                      {equipmentOutstandingCount} Outstanding
                    </Badge>
                  )}
                  
                  {equipmentOutstandingCount === 0 && (
                    <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      All Returned
                    </Badge>
                  )}
                </>
              )}
            </div>

            {/* Equipment Details Section */}
            {hasEquipmentIssued && (
              <div className="mt-3 p-3 bg-slate-50 rounded-lg border">
                <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                  <Package className="w-4 h-4" />
                  Equipment Allocation Details
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                  {session.equipment_taken.map((item, index) => {
                    const returned = item.quantity_returned || 0;
                    const outstanding = item.quantity_issued - returned;
                    return (
                      <div key={index} className="flex justify-between items-center p-2 bg-white rounded border">
                        <span className="font-medium">{item.item_name}</span>
                        <div className="text-right">
                          <div className={outstanding > 0 ? "text-red-600 font-semibold" : "text-green-600"}>
                            {returned}/{item.quantity_issued}
                          </div>
                          <div className="text-slate-500">
                            {outstanding > 0 ? `${outstanding} missing` : 'Complete'}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
          <div className="flex gap-2 flex-col">
            <Button variant="outline" size="sm" onClick={() => onEdit(session)}>
              <FilePenLine className="w-4 h-4 mr-2"/>
              Manage
            </Button>
            
            {/* Always show equipment return button if there's equipment */}
            {hasEquipmentIssued && (
              <Button 
                variant="outline" 
                size="sm" 
                className={equipmentOutstandingCount > 0 ? "text-orange-600 border-orange-200 hover:bg-orange-50 animate-pulse" : "text-blue-600 border-blue-200 hover:bg-blue-50"}
                onClick={() => onEquipmentReturn(session)}
              >
                <RotateCcw className="w-4 h-4 mr-2"/>
                {equipmentOutstandingCount > 0 ? 'Process Returns' : 'View Returns'}
              </Button>
            )}
            
            <Button variant="outline" size="sm" className="text-red-600" onClick={() => onDelete(session.id)}>
              <Trash2 className="w-3 h-3 mr-1"/>
              Delete
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default function TrainingList({ sessions, teams, members, loading, onEdit, onDelete, onSessionDoubleClick }) {
  const [statusFilter, setStatusFilter] = useState("upcoming"); // Changed default to show upcoming by default
  const [showEquipmentReturn, setShowEquipmentReturn] = useState(false);
  const [selectedSession, setSelectedSession] = useState(null);

  const handleEquipmentReturn = (session) => {
    setSelectedSession(session);
    setShowEquipmentReturn(true);
  };

  const filteredSessions = sessions.filter(session => {
    const status = session.status || getSessionStatus(session);
    const now = new Date();
    const sessionDate = new Date(session.event_date);
    
    if (statusFilter === "all") return true;
    
    if (statusFilter === 'upcoming') {
      // Only show sessions that are actually in the future and not completed/cancelled
      return status === 'upcoming' || (status === 'draft' && sessionDate >= now);
    }
    
    if (statusFilter === 'completed') return status === 'completed';
    
    if (statusFilter === 'past_due') {
      // Sessions that are past their date but not completed or cancelled
      return status === 'past_due' || (!['completed', 'cancelled'].includes(status) && sessionDate < now);
    }
    
    return status === statusFilter;
  });

  // Update the count calculations to be more accurate
  const upcomingCount = sessions.filter(s => {
    const status = s.status || getSessionStatus(s);
    const now = new Date();
    const sessionDate = new Date(s.event_date);
    return status === 'upcoming' || (status === 'draft' && sessionDate >= now);
  }).length;

  const completedCount = sessions.filter(s => (s.status || getSessionStatus(s)) === 'completed').length;

  const pastDueCount = sessions.filter(s => {
    const status = s.status || getSessionStatus(s);
    const now = new Date();
    const sessionDate = new Date(s.event_date);
    return status === 'past_due' || (!['completed', 'cancelled'].includes(status) && sessionDate < now);
  }).length;

  if (loading) {
    return <div className="space-y-4">{Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-40" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2 mb-6 flex-wrap">
        <Button variant={statusFilter === "upcoming" ? "default" : "outline"} size="sm" onClick={() => setStatusFilter("upcoming")}>
          Upcoming ({upcomingCount})
        </Button>
        <Button variant={statusFilter === "completed" ? "default" : "outline"} size="sm" onClick={() => setStatusFilter("completed")}>
          Completed ({completedCount})
        </Button>
        <Button 
          variant={statusFilter === "past_due" ? "destructive" : "outline"} 
          size="sm" 
          onClick={() => setStatusFilter("past_due")}
          className={statusFilter === "past_due" ? "bg-orange-600 text-white" : "text-slate-600"}
        >
          Past Due ({pastDueCount})
        </Button>
        <Button variant={statusFilter === "all" ? "default" : "outline"} size="sm" onClick={() => setStatusFilter("all")}>
          All Sessions ({sessions.length})
        </Button>
      </div>

      {filteredSessions.length === 0 ? (
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardContent className="p-12 text-center">
            <CalendarDays className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              No {statusFilter === "all" ? "" : statusFilter.replace("_", " ")} training sessions
            </h3>
            <p className="text-slate-500">
              {statusFilter === "all" 
                ? "No training sessions found. Create your first training session to get started."
                : `No ${statusFilter.replace("_", " ")} training sessions found. Try changing the filter above.`
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredSessions
            .sort((a, b) => {
              const now = new Date();
              const dateA = new Date(a.event_date);
              const dateB = new Date(b.event_date);
              
              // Check if sessions are upcoming (future) or past
              const aIsUpcoming = dateA >= now;
              const bIsUpcoming = dateB >= now;
              
              // If one is upcoming and one is past, upcoming comes first
              if (aIsUpcoming && !bIsUpcoming) return -1;
              if (!aIsUpcoming && bIsUpcoming) return 1;
              
              // If both are upcoming, sort by earliest date first (closest to today)
              if (aIsUpcoming && bIsUpcoming) {
                return dateA - dateB;
              }
              
              // If both are past, sort by most recent first (latest date first)
              return dateB - dateA;
            })
            .map(session => (
              <SessionCard 
                key={session.id} 
                session={session} 
                teams={teams} 
                members={members} 
                onEdit={onEdit} 
                onDelete={onDelete}
                onEquipmentReturn={handleEquipmentReturn}
                onSessionDoubleClick={onSessionDoubleClick}
              />
            ))
          }
        </div>
      )}

      {/* Equipment Return Modal */}
      {showEquipmentReturn && selectedSession && (
        <EquipmentReturnModal 
          session={selectedSession}
          onClose={() => {
            setShowEquipmentReturn(false);
            setSelectedSession(null);
          }}
          onComplete={() => {
            setShowEquipmentReturn(false);
            setSelectedSession(null);
            // For a real app, you might want to trigger a data refetch here.
          }}
        />
      )}
    </div>
  );
}
