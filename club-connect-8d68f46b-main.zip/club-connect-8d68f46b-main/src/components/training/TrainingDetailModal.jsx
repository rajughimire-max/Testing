
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Calendar, Clock, MapPin, User, Users, CheckCircle, XCircle, LogIn, UserCheck, UserX, HelpCircle as HelpCircleIcon } from "lucide-react";
import { User as UserEntity, Player, TrainingAttendance } from "@/api/entities";
import { format } from "date-fns";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const RsvpStatusBadge = ({ status }) => {
  if (!status) {
    return <Badge variant="outline" className="flex items-center gap-1"><HelpCircleIcon className="w-3 h-3"/> Pending</Badge>;
  }
  if (status === 'Attending') {
    return <Badge className="bg-green-100 text-green-800 flex items-center gap-1"><UserCheck className="w-3 h-3"/> Attending</Badge>;
  }
  if (status === 'Not Attending') {
    return <Badge variant="destructive" className="flex items-center gap-1"><UserX className="w-3 h-3"/> Not Attending</Badge>;
  }
  return <Badge variant="secondary">{status}</Badge>;
};


export default function TrainingDetailModal({ session, teams, members, players, allAttendance, currentUser, isOpen, onClose, onRsvpUpdate }) {
  const [loading, setLoading] = useState(true);
  const [currentUserPlayer, setCurrentUserPlayer] = useState(null);
  const [currentUserAttendance, setCurrentUserAttendance] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const coach = members.find(m => m.id === session.coach_id);
  const sessionTeams = (session.team_ids || []).map(id => teams.find(t => t.id === id)).filter(Boolean);
  
  const eligiblePlayers = players.filter(p => session.team_ids?.includes(p.team_id));

  const loadData = useCallback(async () => {
    if (!session?.id) return;
    setLoading(true);
    try {
      // Current user is passed as a prop, so no need to fetch UserEntity.me() again
      if (currentUser) {
        // Check if this user is a registered player
        const playerRecord = players.find(p => p.email === currentUser.email);
        setCurrentUserPlayer(playerRecord);

        if (playerRecord) {
          // Get their attendance record for this session
          const attendanceRecord = allAttendance.find(a => a.session_id === session.id && a.player_id === playerRecord.id);
          setCurrentUserAttendance(attendanceRecord);
        } else {
            // If currentUser exists but is not a player, ensure these are null
            setCurrentUserPlayer(null);
            setCurrentUserAttendance(null);
        }
      } else {
        // If no current user (not logged in), clear current user related states
        setCurrentUserPlayer(null);
        setCurrentUserAttendance(null);
      }
    } catch (error) {
      console.error("Error loading session details:", error);
      // Fallback in case of unexpected errors during lookup
      setCurrentUserPlayer(null);
      setCurrentUserAttendance(null);
    } finally {
      setLoading(false);
    }
  }, [session, currentUser, players, allAttendance]);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen, loadData]);

  const handleRsvp = async (status) => {
    if (!currentUserPlayer) {
      toast.error("You must be a registered player to RSVP.");
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        session_id: session.id,
        player_id: currentUserPlayer.id,
        team_id: currentUserPlayer.team_id,
        status: status,
      };
      
      if (currentUserAttendance) {
        // Update existing attendance
        await TrainingAttendance.update(currentUserAttendance.id, { status });
      } else {
        // Create new attendance record
        await TrainingAttendance.create(payload);
      }
      
      toast.success(`Your RSVP has been updated to "${status}".`);
      if (onRsvpUpdate) onRsvpUpdate(); // Notify parent to reload all data
    } catch (error) {
      console.error("Error updating RSVP:", error);
      toast.error("Failed to update your RSVP. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{session.title}</DialogTitle>
          <DialogDescription>
            Training session details and attendance confirmation.
          </DialogDescription>
        </DialogHeader>
        
        {loading ? (
          <div className="flex justify-center items-center h-48">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : (
          <div className="space-y-6 max-h-[70vh] overflow-y-auto pr-4">
            {/* Session Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-start gap-3">
                <Calendar className="w-4 h-4 mt-1 text-slate-500" />
                <div>
                  <span className="font-semibold">Date:</span> {format(new Date(session.event_date), "EEEE, d MMMM yyyy")}
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 mt-1 text-slate-500" />
                <div>
                  <span className="font-semibold">Time:</span> {session.start_time} - {session.end_time || 'N/A'}
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 mt-1 text-slate-500" />
                <div>
                  <span className="font-semibold">Venue:</span> {session.venue || 'TBA'}
                </div>
              </div>
              <div className="flex items-start gap-3">
                <User className="w-4 h-4 mt-1 text-slate-500" />
                <div>
                  <span className="font-semibold">Coach:</span> {coach ? `${coach.first_name} ${coach.last_name}` : 'N/A'}
                </div>
              </div>
              <div className="flex items-start gap-3 md:col-span-2">
                <Users className="w-4 h-4 mt-1 text-slate-500" />
                <div>
                  <span className="font-semibold">Teams:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {sessionTeams.map(t => (
                      <Badge key={t.id} variant="secondary">{t.name}</Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Coach Notes */}
            {session.coach_observations && (
              <div className="p-4 bg-slate-50 rounded-lg">
                <h4 className="font-semibold mb-2">Training Focus</h4>
                <p className="text-sm text-slate-600">{session.coach_observations}</p>
              </div>
            )}

            {/* RSVP Section for Admin */}
            {currentUser?.role === 'admin' && eligiblePlayers.length > 0 && (
              <div className="p-4 bg-slate-50 rounded-lg">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <Users className="w-5 h-5 text-slate-700" />
                  Player RSVP Status ({eligiblePlayers.filter(p => allAttendance.find(a => a.session_id === session.id && a.player_id === p.id)?.status === 'Attending').length} / {eligiblePlayers.length})
                </h4>
                <div className="max-h-48 overflow-y-auto pr-2 space-y-2">
                  {eligiblePlayers.map(player => {
                    const rsvp = allAttendance.find(a => a.session_id === session.id && a.player_id === player.id);
                    return (
                      <div key={player.id} className="flex justify-between items-center bg-white p-2 rounded-md border">
                        <span>{player.first_name} {player.last_name}</span>
                        <RsvpStatusBadge status={rsvp?.status} />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            
            {/* RSVP Section - Only for logged-in players */}
            {!currentUser ? (
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
                <LogIn className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold text-blue-900 mb-2">Login Required</h3>
                <p className="text-sm text-blue-700 mb-4">
                  Please login to your player account to confirm your attendance.
                </p>
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <Link to={createPageUrl("PlayerPortal")}>Login</Link>
                </Button>
              </div>
            ) : !currentUserPlayer ? (
              <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg text-center">
                <User className="w-8 h-8 text-orange-600 mx-auto mb-3" />
                <h3 className="font-semibold text-orange-900 mb-2">Player Registration Required</h3>
                <p className="text-sm text-orange-700">
                  You need to be a registered player to RSVP for training sessions.
                </p>
              </div>
            ) : (
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-center">
                <h3 className="font-semibold text-green-900 mb-3">Will you be attending?</h3>
                <div className="flex justify-center gap-4">
                  <Button
                    onClick={() => handleRsvp('Attending')}
                    disabled={isSubmitting}
                    className={`w-32 ${
                      currentUserAttendance?.status === 'Attending' 
                        ? 'bg-green-600 hover:bg-green-700' 
                        : 'bg-green-500 hover:bg-green-600'
                    }`}
                  >
                    {isSubmitting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Attending
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={() => handleRsvp('Not Attending')}
                    disabled={isSubmitting}
                    variant="destructive"
                    className={`w-32 ${
                      currentUserAttendance?.status === 'Not Attending' 
                        ? 'bg-red-700 hover:bg-red-800' 
                        : 'bg-red-500 hover:bg-red-600'
                    }`}
                  >
                    {isSubmitting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <XCircle className="w-4 h-4 mr-2" />
                        Not Attending
                      </>
                    )}
                  </Button>
                </div>
                {currentUserAttendance && (
                  <p className="text-sm text-slate-600 mt-3">
                    Your current RSVP: <RsvpStatusBadge status={currentUserAttendance.status} />
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
