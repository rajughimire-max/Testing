import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RotateCcw, Package, AlertTriangle, CheckCircle, User, Save } from 'lucide-react';
import { Event, InventoryItem, InventoryTransaction } from '@/api/entities';
import { toast } from 'sonner';

export default function EquipmentReturnModal({ session, isOpen, onClose, onComplete }) {
  const [returnData, setReturnData] = useState({});
  const [returnReasons, setReturnReasons] = useState({});
  const [returnedBy, setReturnedBy] = useState('Coach');
  const [processing, setProcessing] = useState(false);

  const returnPersonOptions = [
    { value: 'Coach', label: 'Coach' },
    { value: 'Manager', label: 'Team Manager' },
    { value: 'Assistant Coach', label: 'Assistant Coach' },
    { value: 'Club Official', label: 'Club Official' }
  ];

  const missingReasonOptions = [
    { value: 'damaged', label: 'Damaged during use' },
    { value: 'lost', label: 'Lost/Misplaced' },
    { value: 'broken', label: 'Broken/Unusable' },
    { value: 'left_at_venue', label: 'Left at training venue' },
    { value: 'stolen', label: 'Stolen/Missing' },
    { value: 'other', label: 'Other (specify below)' }
  ];

  useEffect(() => {
    if (session?.equipment_taken) {
      // Initialize return quantities
      const initialReturnData = {};
      session.equipment_taken.forEach(item => {
        const outstanding = item.quantity_issued - (item.quantity_returned || 0);
        initialReturnData[item.issue_id] = {
          returnQuantity: outstanding,
          maxReturn: outstanding,
          reason: outstanding > 0 ? '' : 'already_returned'
        };
      });
      setReturnData(initialReturnData);
    }
  }, [session]);

  const handleReturnQuantityChange = (issueId, quantity) => {
    setReturnData(prev => ({
      ...prev,
      [issueId]: {
        ...prev[issueId],
        returnQuantity: parseInt(quantity) || 0
      }
    }));
  };

  const handleReasonChange = (issueId, reason) => {
    setReturnReasons(prev => ({
      ...prev,
      [issueId]: reason
    }));
  };

  const processReturns = async () => {
    setProcessing(true);
    try {
      const updatedEquipmentList = session.equipment_taken.map(item => {
        const returnInfo = returnData[item.issue_id];
        const currentReturned = item.quantity_returned || 0;
        const newReturned = currentReturned + (returnInfo?.returnQuantity || 0);
        
        return {
          ...item,
          quantity_returned: newReturned,
          status: newReturned >= item.quantity_issued ? 'Returned' : 
                  newReturned > 0 ? 'Partially Returned' : 'Issued'
        };
      });

      // Update the training session with new return data
      await Event.update(session.id, {
        equipment_taken: updatedEquipmentList
      });

      // Process each return transaction
      for (const item of session.equipment_taken) {
        const returnInfo = returnData[item.issue_id];
        const returnQty = returnInfo?.returnQuantity || 0;
        
        if (returnQty > 0) {
          // Update inventory quantities
          const inventoryItem = await InventoryItem.get(item.item_id);
          await InventoryItem.update(item.item_id, {
            quantity_allocated: Math.max(0, (inventoryItem.quantity_allocated || 0) - returnQty),
            quantity_on_hand: (inventoryItem.quantity_on_hand || 0) + returnQty
          });

          // Create return transaction
          await InventoryTransaction.create({
            item_id: item.item_id,
            transaction_type: 'Check-in',
            quantity_change: returnQty,
            reason: `Returned from training: ${session.title} by ${returnedBy}. ${returnReasons[item.issue_id] ? `Reason: ${returnReasons[item.issue_id]}` : ''}`,
            training_session_id: session.id
          });
        }

        // Handle missing/damaged items
        const missing = item.quantity_issued - (item.quantity_returned || 0) - returnQty;
        if (missing > 0) {
          const reason = returnReasons[item.issue_id];
          if (reason && reason !== 'other') {
            // Create a transaction for missing items
            await InventoryTransaction.create({
              item_id: item.item_id,
              transaction_type: reason === 'damaged' ? 'Damaged' : 'Missing',
              quantity_change: -missing,
              reason: `${reason} - Training: ${session.title}. Reported by: ${returnedBy}`,
              training_session_id: session.id
            });

            // Update inventory to reflect damage/loss
            if (reason === 'damaged') {
              const inventoryItem = await InventoryItem.get(item.item_id);
              await InventoryItem.update(item.item_id, {
                quantity_damaged: (inventoryItem.quantity_damaged || 0) + missing,
                quantity_allocated: Math.max(0, (inventoryItem.quantity_allocated || 0) - missing)
              });
            }
          }
        }
      }

      toast.success('Equipment returns processed successfully');
      onComplete();
      onClose();
    } catch (error) {
      console.error('Error processing returns:', error);
      toast.error('Failed to process equipment returns');
    } finally {
      setProcessing(false);
    }
  };

  if (!session?.equipment_taken?.length) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>No Equipment Found</DialogTitle>
          </DialogHeader>
          <p className="text-center text-slate-600 py-8">
            No equipment allocation found for this training session.
          </p>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-600" />
            Equipment Return - {session.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Session Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Training Session Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><strong>Date:</strong> {new Date(session.event_date).toLocaleDateString()}</div>
                <div><strong>Status:</strong> <Badge>{session.status || 'draft'}</Badge></div>
              </div>
            </CardContent>
          </Card>

          {/* Return Person */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Returned By</Label>
              <Select value={returnedBy} onValueChange={setReturnedBy}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {returnPersonOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Equipment List */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Equipment Return Details</h3>
            {session.equipment_taken.map((item, index) => {
              const outstanding = item.quantity_issued - (item.quantity_returned || 0);
              const returnInfo = returnData[item.issue_id] || { returnQuantity: 0 };
              
              return (
                <Card key={item.issue_id || index} className={outstanding === 0 ? 'bg-green-50' : 'bg-white'}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-semibold text-lg">{item.item_name}</h4>
                        <div className="text-sm text-slate-600 space-x-4">
                          <span>Issued: {item.quantity_issued}</span>
                          <span>Returned: {item.quantity_returned || 0}</span>
                          <span className={outstanding > 0 ? 'text-red-600 font-bold' : 'text-green-600'}>
                            Outstanding: {outstanding}
                          </span>
                        </div>
                      </div>
                      {outstanding === 0 ? (
                        <Badge className="bg-green-100 text-green-800">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Complete
                        </Badge>
                      ) : (
                        <Badge variant="destructive">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          {outstanding} Outstanding
                        </Badge>
                      )}
                    </div>

                    {outstanding > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Quantity Returning</Label>
                          <Input
                            type="number"
                            min="0"
                            max={outstanding}
                            value={returnInfo.returnQuantity}
                            onChange={(e) => handleReturnQuantityChange(item.issue_id, e.target.value)}
                            placeholder={`Max: ${outstanding}`}
                          />
                        </div>
                        <div>
                          <Label>If not returning all, why?</Label>
                          <Select 
                            value={returnReasons[item.issue_id] || ''} 
                            onValueChange={(value) => handleReasonChange(item.issue_id, value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select reason..." />
                            </SelectTrigger>
                            <SelectContent>
                              {missingReasonOptions.map(option => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} disabled={processing}>
              Cancel
            </Button>
            <Button onClick={processReturns} disabled={processing}>
              <Save className="w-4 h-4 mr-2" />
              {processing ? 'Processing...' : 'Process Returns'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}