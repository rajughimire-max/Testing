
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { User, Save, UserCheck, UserX, Clock, Star, Users, HelpCircle, Award, CheckCircle } from "lucide-react";
import { Player, TrainingAttendance, Team } from "@/api/entities";
import { toast } from 'sonner';

const RsvpStatusBadge = ({ status }) => {
  if (!status || (status !== 'Attending' && status !== 'Not Attending')) {
    return <Badge variant="outline" className="flex items-center gap-1 text-xs"><HelpCircle className="w-3 h-3"/> No RSVP</Badge>;
  }
  if (status === 'Attending') {
    return <Badge className="bg-green-100 text-green-800 flex items-center gap-1 text-xs"><UserCheck className="w-3 h-3"/> Will Attend</Badge>;
  }
  if (status === 'Not Attending') {
    return <Badge variant="destructive" className="flex items-center gap-1 text-xs"><UserX className="w-3 h-3"/> Won't Attend</Badge>;
  }
  return null;
};

export default function TrainingAttendanceManager({ session, allAttendance, onFinalize, prevStep, goToStep, onCompleteSession }) {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadPlayersAndAttendance = useCallback(async () => {
    if (!session?.id) return;
    
    setLoading(true);
    try {
      const [allPlayers, allTeams] = await Promise.all([
        Player.list(),
        Team.list(), 
      ]);

      setTeams(allTeams);

      // Filter players from assigned teams only
      const assignedTeamIds = session.team_ids || [];
      
      if (assignedTeamIds.length === 0) {
        console.log("No teams assigned to this session");
        setPlayers([]);
        setAttendanceRecords([]);
        return;
      }

      const eligiblePlayers = allPlayers.filter(player => 
        assignedTeamIds.includes(player.team_id) && player.is_active
      );

      console.log(`Found ${eligiblePlayers.length} players from ${assignedTeamIds.length} assigned teams`);
      setPlayers(eligiblePlayers);

      // Create attendance records for players who don't have one yet
      const existingAttendanceForSession = allAttendance.filter(record => record.session_id === session.id);
      const attendanceData = [];

      eligiblePlayers.forEach(player => {
        const existingRecord = existingAttendanceForSession.find(record => record.player_id === player.id);
        
        if (existingRecord) {
          if (existingRecord.status === 'Attending' || existingRecord.status === 'Not Attending') {
            attendanceData.push({
              ...existingRecord,
              status: existingRecord.status === 'Attending' ? 'present' : 'absent'
            });
          } else {
            attendanceData.push(existingRecord);
          }
        } else {
          attendanceData.push({
            session_id: session.id,
            player_id: player.id,
            team_id: player.team_id,
            status: 'present',
            rating: null,
            rpe: null,
            coach_note: '',
            reason: '',
            reason_note: '',
            late_minutes: 0
          });
        }
      });

      setAttendanceRecords(attendanceData);
    } catch (error) {
      console.error("Error loading players and attendance:", error);
      toast.error("Failed to load attendance data");
    } finally {
      setLoading(false);
    }
  }, [session?.id, session?.team_ids, allAttendance]);

  useEffect(() => {
    loadPlayersAndAttendance();
  }, [loadPlayersAndAttendance]);

  const updateAttendance = (playerId, field, value) => {
    setAttendanceRecords(prev => prev.map(record => 
      record.player_id === playerId ? { ...record, [field]: value } : record
    ));
  };

  const saveAttendance = async () => {
    setSaving(true);
    try {
      for (const record of attendanceRecords) {
        if (record.id) {
          await TrainingAttendance.update(record.id, record);
        } else {
          const newRecord = await TrainingAttendance.create(record);
          setAttendanceRecords(prev => prev.map(r => 
            r.player_id === record.player_id && !r.id ? { ...r, id: newRecord.id } : r
          ));
        }
      }
      
      toast.success("Attendance records saved successfully!");
      if (onFinalize) onFinalize();
    } catch (error) {
      console.error("Error saving attendance:", error);
      toast.error("Failed to save attendance records");
    } finally {
      setSaving(false);
    }
  };

  const getPlayerTeam = (playerId) => {
    const player = players.find(p => p.id === playerId);
    return teams.find(t => t.id === player?.team_id);
  };

  if (loading) {
    return (
      <CardContent>
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-slate-600">Loading players...</p>
        </div>
      </CardContent>
    );
  }

  if (!session?.team_ids || session.team_ids.length === 0) {
    return (
      <CardContent>
        <div className="text-center py-8">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-700 mb-2">No Teams Assigned</h3>
          <p className="text-slate-500">Please assign teams to this training session in the Details tab first.</p>
        </div>
      </CardContent>
    );
  }

  if (players.length === 0) {
    return (
      <CardContent>
        <div className="text-center py-8">
          <UserCheck className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-700 mb-2">No Active Players</h3>
          <p className="text-slate-500">
            No active players found in the assigned teams. Make sure players are assigned to teams and marked as active.
          </p>
          <div className="mt-4 text-sm text-slate-400">
            Assigned teams: {session.team_ids.map(teamId => {
              const team = teams.find(t => t.id === teamId);
              return team?.name;
            }).filter(Boolean).join(', ')}
          </div>
        </div>
      </CardContent>
    );
  }

  return (
    <CardContent className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold text-slate-900">Training Attendance & Performance</h3>
          <p className="text-slate-600">{players.length} players from assigned teams</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={saveAttendance} disabled={saving} className="bg-green-600 hover:bg-green-700 text-white shadow-md">
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Saving..." : "Save All Attendance"}
          </Button>
          {onCompleteSession && session?.id && (
            <Button 
              onClick={() => onCompleteSession(session.id)} 
              className="bg-blue-600 hover:bg-blue-700 text-white shadow-md"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Complete Session
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6">
        {attendanceRecords.map(record => {
          const player = players.find(p => p.id === record.player_id);
          const team = getPlayerTeam(record.player_id);
          const rsvpRecord = allAttendance.find(a => a.session_id === session.id && a.player_id === record.player_id);
          
          if (!player) return null;

          return (
            <Card key={record.player_id} className="bg-white border-l-4 border-l-blue-500 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                {/* Player Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    {player.profile_photo_url ? (
                      <img src={player.profile_photo_url} alt={player.first_name} className="w-14 h-14 rounded-full object-cover border-2 border-slate-200" />
                    ) : (
                      <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-lg">
                        {player.first_name.charAt(0)}{player.last_name.charAt(0)}
                      </div>
                    )}
                    <div>
                      <h4 className="text-lg font-bold text-slate-900">{player.first_name} {player.last_name}</h4>
                      <div className="flex items-center gap-3 mt-1">
                        <Badge variant="outline" className="text-xs">#{player.preferred_number}</Badge>
                        <Badge variant="secondary" className="text-xs">{team?.name}</Badge>
                        {player.position && <Badge variant="outline" className="text-xs">{player.position}</Badge>}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="mb-2">
                      <RsvpStatusBadge status={rsvpRecord?.status} />
                    </div>
                    {player.attendance_percent !== undefined && (
                      <div className="text-xs text-slate-500">
                        Attendance: {player.attendance_percent}%
                      </div>
                    )}
                  </div>
                </div>

                {/* Main Content Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Attendance Section */}
                  <div className="space-y-4">
                    <div className="border-b border-slate-200 pb-2">
                      <h5 className="font-semibold text-slate-700 flex items-center gap-2">
                        <UserCheck className="w-4 h-4" />
                        Attendance Status
                      </h5>
                    </div>
                    
                    <div className="space-y-3">
                      <Select 
                        value={record.status} 
                        onValueChange={(value) => updateAttendance(record.player_id, 'status', value)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="present">
                            <div className="flex items-center gap-2">
                              <UserCheck className="w-4 h-4 text-green-600" />
                              <span className="text-green-700 font-medium">Present</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="absent">
                            <div className="flex items-center gap-2">
                              <UserX className="w-4 h-4 text-red-600" />
                              <span className="text-red-700 font-medium">Absent</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="late">
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-yellow-600" />
                              <span className="text-yellow-700 font-medium">Late</span>
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>

                      {/* Reason and Late Minutes for Absent/Late */}
                      {(record.status === 'absent' || record.status === 'late') && (
                        <div className="space-y-2 p-3 bg-gray-50 rounded-lg">
                          <Select 
                            value={record.reason || ""} 
                            onValueChange={(value) => updateAttendance(record.player_id, 'reason', value)}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select reason..." />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Injured">🩹 Injured</SelectItem>
                              <SelectItem value="Sick">🤒 Sick</SelectItem>
                              <SelectItem value="Personal">👨‍👩‍👧‍👦 Personal</SelectItem>
                              <SelectItem value="Work">💼 Work</SelectItem>
                              <SelectItem value="Other">❓ Other</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          {record.status === 'late' && (
                            <div>
                              <Label className="text-xs text-slate-600 mb-1 block">Minutes Late</Label>
                              <Input
                                type="number"
                                placeholder="0"
                                value={record.late_minutes || ''}
                                onChange={(e) => updateAttendance(record.player_id, 'late_minutes', parseInt(e.target.value) || 0)}
                                className="w-full"
                              />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Performance Section */}
                  {record.status === 'present' && (
                    <div className="space-y-4">
                      <div className="border-b border-slate-200 pb-2">
                        <h5 className="font-semibold text-slate-700 flex items-center gap-2">
                          <Award className="w-4 h-4" />
                          Performance
                        </h5>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-xs text-slate-600 mb-2 block">Skill Rating (1-10)</Label>
                          <Select 
                            value={record.rating?.toString() || ""} 
                            onValueChange={(value) => updateAttendance(record.player_id, 'rating', parseInt(value))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Rate" />
                            </SelectTrigger>
                            <SelectContent>
                              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                                <SelectItem key={num} value={num.toString()}>
                                  <div className="flex items-center gap-1">
                                    <span>{num}</span>
                                    {num >= 8 && <Star className="w-3 h-3 text-yellow-500" />}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label className="text-xs text-slate-600 mb-2 block">Effort Level (1-10)</Label>
                          <Select 
                            value={record.rpe?.toString() || ""} 
                            onValueChange={(value) => updateAttendance(record.player_id, 'rpe', parseInt(value))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="RPE" />
                            </SelectTrigger>
                            <SelectContent>
                              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                                <SelectItem key={num} value={num.toString()}>
                                  <div className="flex items-center gap-1">
                                    <span>{num}</span>
                                    {num >= 9 && <span className="text-xs">🔥</span>}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Coach Notes Section */}
                  <div className="space-y-4">
                    <div className="border-b border-slate-200 pb-2">
                      <h5 className="font-semibold text-slate-700">Coach Notes</h5>
                    </div>
                    
                    <Textarea
                      placeholder="Performance notes, areas to improve, achievements..."
                      value={record.coach_note || ''}
                      onChange={(e) => updateAttendance(record.player_id, 'coach_note', e.target.value)}
                      className="w-full h-20 text-sm resize-none"
                      rows={3}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Summary Card */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-6">
          <h4 className="font-bold text-blue-900 mb-4 text-lg">Session Summary</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">
                {attendanceRecords.filter(r => r.status === 'present').length}
              </div>
              <div className="text-sm text-slate-600 font-medium">Present</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600 mb-1">
                {attendanceRecords.filter(r => r.status === 'absent').length}
              </div>
              <div className="text-sm text-slate-600 font-medium">Absent</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-600 mb-1">
                {attendanceRecords.filter(r => r.status === 'late').length}
              </div>
              <div className="text-sm text-slate-600 font-medium">Late</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">{players.length}</div>
              <div className="text-sm text-slate-600 font-medium">Total Players</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between pt-4 border-t">
        <Button type="button" onClick={prevStep} variant="outline">
          Previous: Equipment
        </Button>
        <Button type="button" onClick={goToStep ? () => goToStep(0) : undefined} variant="outline">
          Back to Details
        </Button>
      </div>
    </CardContent>
  );
}
