import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { ChevronsUpDown, Check } from 'lucide-react';

export default function PortalSwitcher({ portals, currentPage }) {
  const currentPortal = portals.find(p => p.page === currentPage) || portals[0];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="w-48 justify-between">
          <span>{currentPortal?.name || 'Select Portal'}</span>
          <ChevronsUpDown className="w-4 h-4 text-slate-500" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-48">
        <DropdownMenuLabel>Switch Portal</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {portals.map(portal => (
          <DropdownMenuItem key={portal.page} asChild>
            <Link to={createPageUrl(portal.page)} className="flex justify-between items-center">
              <span>{portal.name}</span>
              {currentPage === portal.page && <Check className="w-4 h-4" />}
            </Link>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}