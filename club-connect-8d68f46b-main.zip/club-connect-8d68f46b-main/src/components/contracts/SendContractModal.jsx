import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { generateContract } from "@/api/functions";
import { generatePlayerContract } from "@/api/functions";
import { generateMembershipContract } from "@/api/functions";
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info, Search } from 'lucide-react';

export default function SendContractModal({ isOpen, onClose, template, sponsorshipApplications, players, membershipApplications, onContractSent, allContracts, activeSeason }) {
  const [selectedApplicationId, setSelectedApplicationId] = useState('');
  const [selectedPlayerId, setSelectedPlayerId] = useState('');
  const [selectedMembershipAppId, setSelectedMembershipAppId] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [hasSignedContract, setHasSignedContract] = useState(false);
  const [playerSearch, setPlayerSearch] = useState('');

  useEffect(() => {
    // Reset selections when modal opens or template changes
    setSelectedApplicationId('');
    setSelectedPlayerId('');
    setSelectedMembershipAppId('');
    setHasSignedContract(false);
    setPlayerSearch('');
  }, [isOpen, template]);

  useEffect(() => {
    if (template?.contract_type === 'player' && selectedPlayerId && activeSeason) {
      const signedContractExists = allContracts.some(c =>
        c.application_id === selectedPlayerId &&
        c.application_type === 'player' &&
        c.status === 'signed' &&
        c.season_id === activeSeason.id
      );
      setHasSignedContract(signedContractExists);
    } else {
      setHasSignedContract(false);
    }
  }, [selectedPlayerId, allContracts, activeSeason, template]);

  const handleSend = async () => {
    setIsSending(true);
    try {
      let response;
      if (template.contract_type === 'sponsorship' && selectedApplicationId) {
        response = await generateContract({ applicationId: selectedApplicationId, templateId: template.id });
      } else if (template.contract_type === 'player' && selectedPlayerId) {
        response = await generatePlayerContract({ playerId: selectedPlayerId, templateId: template.id });
      } else if (template.contract_type === 'membership' && selectedMembershipAppId) {
        response = await generateMembershipContract({ membershipApplicationId: selectedMembershipAppId, templateId: template.id });
      } else {
        toast.error("Please select a recipient.");
        setIsSending(false);
        return;
      }

      if (response?.data?.success) {
        // Show success message
        toast.success("Contract generated and ready to send!");
        
        // Show warning if no active season
        if (response.data.warning) {
          toast.warning(response.data.warning, { duration: 5000 });
        }
        
        console.log("Signing URL:", response.data.signing_url);
        onContractSent();
        onClose();
      } else {
        throw new Error(response?.data?.error || "Failed to generate contract.");
      }
    } catch (error) {
      console.error("Error sending contract:", error);
      toast.error(error.message || "An error occurred.");
    } finally {
      setIsSending(false);
    }
  };

  // Filter players based on search
  const filteredPlayers = players.filter(player => 
    `${player.first_name} ${player.last_name}`.toLowerCase().includes(playerSearch.toLowerCase()) ||
    player.preferred_number?.toString().includes(playerSearch) ||
    player.player_uid?.toLowerCase().includes(playerSearch.toLowerCase())
  );

  if (!template) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Send Contract: {template.name}</DialogTitle>
          <DialogDescription>
            Select a recipient for this contract. The contract will be generated and a signing link will be created.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Season Warning */}
          {!activeSeason && (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>No Active Season Found</AlertTitle>
              <AlertDescription>
                No active season is configured. The contract will use default season information. 
                <br />
                <strong>To fix this:</strong> Go to <em>Teams &rarr; Season Setup</em> and create/activate a season.
              </AlertDescription>
            </Alert>
          )}
          
          {template.contract_type === 'sponsorship' && (
            <div className="space-y-2">
              <Label htmlFor="recipient-sponsor">Sponsorship Application</Label>
              <Select onValueChange={setSelectedApplicationId} value={selectedApplicationId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a pending sponsorship application..." />
                </SelectTrigger>
                <SelectContent>
                  {sponsorshipApplications.map(app => (
                    <SelectItem key={app.id} value={app.id}>
                      {app.company_name} - {app.contact_person}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {template.contract_type === 'player' && (
            <div className="space-y-2">
              <Label htmlFor="recipient-player">Player</Label>
              
              {/* Search input */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search players by name, number, or ID..."
                  value={playerSearch}
                  onChange={(e) => setPlayerSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              {/* Player selection */}
              <Select onValueChange={setSelectedPlayerId} value={selectedPlayerId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a player..." />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {filteredPlayers.length > 0 ? (
                    filteredPlayers.map(player => (
                      <SelectItem key={player.id} value={player.id}>
                        <div className="flex justify-between items-center w-full">
                          <span>{player.first_name} {player.last_name}</span>
                          <div className="flex gap-2 text-xs text-slate-500">
                            {player.preferred_number && <span>#{player.preferred_number}</span>}
                            {player.player_uid && <span>{player.player_uid}</span>}
                          </div>
                        </div>
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="no-results" disabled>
                      {playerSearch ? 'No players match your search' : 'No players found'}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              
              {players.length > filteredPlayers.length && (
                <p className="text-xs text-slate-500">
                  Showing {filteredPlayers.length} of {players.length} players
                </p>
              )}
              
              {hasSignedContract && (
                 <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Contract Already Signed</AlertTitle>
                  <AlertDescription>
                    This player already has a signed contract for the {activeSeason?.name || 'current'} season.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {template.contract_type === 'membership' && (
            <div className="space-y-2">
              <Label htmlFor="recipient-member">Membership Application</Label>
              <Select onValueChange={setSelectedMembershipAppId} value={selectedMembershipAppId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select an approved membership application..." />
                </SelectTrigger>
                <SelectContent>
                  {membershipApplications.map(app => (
                    <SelectItem key={app.id} value={app.id}>
                      {app.first_name} {app.last_name} ({app.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSend} disabled={isSending || hasSignedContract}>
            {isSending ? "Sending..." : "Generate & Send"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}