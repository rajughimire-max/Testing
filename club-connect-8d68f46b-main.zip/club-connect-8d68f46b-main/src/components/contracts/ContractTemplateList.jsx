import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, FileText, Eye } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function ContractTemplateList({ templates, loading, onEdit, onDelete }) {
  if (loading) {
    return (
      <div className="grid gap-4">
        {[1, 2, 3].map(i => (
          <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-6 w-1/3 mb-2" />
              <Skeleton className="h-4 w-2/3 mb-4" />
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const typeColors = {
    sponsorship: "bg-blue-100 text-blue-800",
    membership: "bg-green-100 text-green-800",
    general: "bg-gray-100 text-gray-800"
  };

  return (
    <div className="grid gap-4">
      {templates.map(template => (
        <Card key={template.id} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <FileText className="w-5 h-5 text-slate-600" />
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <Badge className={typeColors[template.contract_type]}>
                    {template.contract_type}
                  </Badge>
                  <Badge variant={template.is_active ? "default" : "secondary"}>
                    {template.is_active ? "Active" : "Inactive"}
                  </Badge>
                  {template.requires_witness && (
                    <Badge variant="outline">Requires Witness</Badge>
                  )}
                </div>
                {template.description && (
                  <p className="text-slate-600 text-sm">{template.description}</p>
                )}
                <p className="text-xs text-slate-500 mt-2">
                  Created: {format(new Date(template.created_date), 'MMM d, yyyy')} • 
                  Variables: {template.variables?.length || 0}
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => onEdit(template)}>
                  <Edit className="w-3 h-3 mr-1" />
                  Edit
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-600 hover:bg-red-50"
                  onClick={() => onDelete(template.id)}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-medium text-sm text-slate-700 mb-2">Contract Preview:</h4>
              <p className="text-xs text-slate-600 font-mono leading-relaxed">
                {template.content.substring(0, 300)}
                {template.content.length > 300 && "..."}
              </p>
            </div>
            
            {template.variables && template.variables.length > 0 && (
              <div className="mt-4">
                <h4 className="font-medium text-sm text-slate-700 mb-2">Available Variables:</h4>
                <div className="flex flex-wrap gap-2">
                  {template.variables.slice(0, 6).map((variable, index) => (
                    <Badge key={index} variant="outline" className="text-xs font-mono">
                      {variable.name}
                    </Badge>
                  ))}
                  {template.variables.length > 6 && (
                    <Badge variant="outline" className="text-xs">
                      +{template.variables.length - 6} more
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
      
      {templates.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-700 mb-2">No Contract Templates</h3>
            <p className="text-slate-500">Create your first contract template to get started</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}