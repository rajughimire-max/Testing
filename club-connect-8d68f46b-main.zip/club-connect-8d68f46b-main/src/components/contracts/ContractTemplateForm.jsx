
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, Plus, Trash2, Info, Copy } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function ContractTemplateForm({ template, onSubmit, onCancel }) {

  const [formData, setFormData] = useState(template || {
    name: "",
    description: "",
    contract_type: "sponsorship",
    content: "", 
    variables: [],
    is_active: true,
    requires_witness: false
  });

  // Define available variables by contract type
  const getAvailableVariables = (contractType) => {
    const commonVariables = [
      { name: "{{CONTRACT_SIGNING_DATE}}", description: "Date when contract is signed", category: "Contract Info" },
      { name: "{{CLUB_NAME}}", description: "Club name (Nepbourne FC)", category: "Club Info" },
      { name: "{{CLUB_ADDRESS}}", description: "Club's registered address", category: "Club Info" },
      { name: "{{CLUB_EMAIL}}", description: "Club contact email", category: "Club Info" },
      { name: "{{CLUB_PHONE}}", description: "Club contact phone", category: "Club Info" },
      { name: "{{CURRENT_SEASON}}", description: "Current active season name", category: "Season Info" },
      { name: "{{SEASON_START_DATE}}", description: "Season start date", category: "Season Info" },
      { name: "{{SEASON_END_DATE}}", description: "Season end date", category: "Season Info" },
      // Signature placeholders
      { name: "[CLUB_SIGNATURE]", description: "Club representative signature block", category: "Signatures" },
    ];

    if (contractType === 'player') {
      return [
        ...commonVariables,
        // Add player signature placeholder
        { name: "[PLAYER_SIGNATURE]", description: "Player signature block", category: "Signatures" },
        // Personal Information
        { name: "{{PLAYER_FULL_NAME}}", description: "Player's full name", category: "Personal Info" },
        { name: "{{PLAYER_FIRST_NAME}}", description: "Player's first name", category: "Personal Info" },
        { name: "{{PLAYER_LAST_NAME}}", description: "Player's last name", category: "Personal Info" },
        { name: "{{PLAYER_EMAIL}}", description: "Player's email address", category: "Personal Info" },
        { name: "{{PLAYER_PHONE}}", description: "Player's phone number", category: "Personal Info" },
        { name: "{{PLAYER_DOB}}", description: "Player's date of birth", category: "Personal Info" },
        { name: "{{PLAYER_AGE}}", description: "Player's current age", category: "Personal Info" },
        { name: "{{PLAYER_ADDRESS}}", description: "Player's full address", category: "Personal Info" },
        { name: "{{PLAYER_STREET_ADDRESS}}", description: "Street address only", category: "Personal Info" },
        { name: "{{PLAYER_SUBURB}}", description: "Suburb/City", category: "Personal Info" },
        { name: "{{PLAYER_STATE}}", description: "State/Territory", category: "Personal Info" },
        { name: "{{PLAYER_POSTCODE}}", description: "Postcode", category: "Personal Info" },
        { name: "{{PLAYER_ID_DOCUMENT_NUMBER}}", description: "Player's ID document number", category: "Personal Info" },
        
        // Football Information
        { name: "{{PLAYER_POSITION}}", description: "Playing position", category: "Football Info" },
        { name: "{{PLAYER_JERSEY_NUMBER}}", description: "Preferred jersey number", category: "Football Info" },
        { name: "{{PLAYER_TEAM_NAME}}", description: "Assigned team name", category: "Football Info" },
        { name: "{{PLAYER_HEIGHT}}", description: "Player height in cm", category: "Football Info" },
        { name: "{{PLAYER_WEIGHT}}", description: "Player weight in kg", category: "Football Info" },
        { name: "{{PLAYER_PLAYING_FOOT}}", description: "Preferred playing foot", category: "Football Info" },
        { name: "{{PLAYER_UNIFORM_SIZE}}", description: "Uniform size", category: "Football Info" },
        
        // Additional Information
        { name: "{{PLAYER_ID}}", description: "Unique player ID", category: "System Info" },
        { name: "{{PLAYER_MEDICAL_CONDITIONS}}", description: "Medical conditions/notes", category: "Medical Info" },
        { name: "{{EMERGENCY_CONTACT}}", description: "Emergency contact details", category: "Personal Info" },
        { name: "{{CONTRACT_EXPIRY_DATE}}", description: "Contract expiry date (season end)", category: "Contract Info" },
      ];
    }

    if (contractType === 'sponsorship') {
      return [
        ...commonVariables,
        // Add sponsor signature placeholder
        { name: "[SPONSOR_SIGNATURE]", description: "Sponsor signature block", category: "Signatures" },
        { name: "{{SPONSOR_COMPANY_NAME}}", description: "Sponsor company name", category: "Sponsor Info" },
        { name: "{{SPONSOR_ABN}}", description: "Sponsor company ABN/ACN", category: "Sponsor Info" },
        { name: "{{SPONSOR_ADDRESS}}", description: "Sponsor company address", category: "Sponsor Info" },
        { name: "{{SPONSOR_CONTACT_PERSON}}", description: "Sponsor contact person", category: "Sponsor Info" },
        { name: "{{SPONSOR_CONTACT_POSITION}}", description: "Contact person position", category: "Sponsor Info" },
        { name: "{{SPONSOR_AMOUNT}}", description: "Sponsorship amount", category: "Financial Info" },
        { name: "{{PAYMENT_TERMS}}", description: "Payment terms and schedule", category: "Financial Info" },
        { name: "{{SPONSORSHIP_BENEFITS}}", description: "List of sponsorship benefits", category: "Sponsorship Info" },
        { name: "{{SPONSORSHIP_TIER_NAME}}", description: "Sponsorship tier name", category: "Sponsorship Info" },
      ];
    }

    if (contractType === 'membership') {
      return [
        ...commonVariables,
        // Add member signature placeholder
        { name: "[MEMBER_SIGNATURE]", description: "Member signature block", category: "Signatures" },
        { name: "{{MEMBER_FULL_NAME}}", description: "Member's full name", category: "Member Info" },
        { name: "{{MEMBER_EMAIL}}", description: "Member's email address", category: "Member Info" },
        { name: "{{MEMBER_PHONE}}", description: "Member's phone number", category: "Member Info" },
        { name: "{{MEMBERSHIP_TYPE}}", description: "Membership type/tier", category: "Membership Info" },
        { name: "{{MEMBERSHIP_FEE}}", description: "Membership fee amount", category: "Membership Info" },
      ];
    }

    return commonVariables;
  };

  const availableVariables = getAvailableVariables(formData.contract_type);

  // Group variables by category
  const groupedVariables = availableVariables.reduce((acc, variable) => {
    if (!acc[variable.category]) {
      acc[variable.category] = [];
    }
    acc[variable.category].push(variable);
    return acc;
  }, {});

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success(`Copied ${text} to clipboard`);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>{template ? "Edit Contract Template" : "New Contract Template"}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Template Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={e => handleChange("name", e.target.value)}
                placeholder="e.g., Standard Player Agreement"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contract_type">Contract Type</Label>
              <Select value={formData.contract_type} onValueChange={value => handleChange("contract_type", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select contract type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sponsorship">Sponsorship</SelectItem>
                  <SelectItem value="player">Player</SelectItem>
                  <SelectItem value="membership">Membership</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={e => handleChange("description", e.target.value)}
              placeholder="Brief description of this contract template"
              rows={2}
            />
          </div>

          {/* Available Variables Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Info className="w-5 h-5 text-blue-500" />
              <Label className="text-lg font-semibold">Available Auto-Fill Variables</Label>
            </div>
            <p className="text-sm text-slate-600 mb-4">
              These variables will be automatically filled when generating contracts. <strong>Signature blocks</strong> ([PLAYER_SIGNATURE], [CLUB_SIGNATURE], etc.) will be replaced with formatted signature sections when the contract is signed.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-60 overflow-y-auto border rounded-lg p-4">
              {Object.entries(groupedVariables).map(([category, variables]) => (
                <div key={category} className="space-y-2">
                  <h4 className="font-medium text-slate-700 text-sm">{category}</h4>
                  <div className="space-y-1">
                    {variables.map((variable) => (
                      <div 
                        key={variable.name}
                        className="flex items-center justify-between p-2 bg-slate-50 rounded cursor-pointer hover:bg-slate-100"
                        onClick={() => copyToClipboard(variable.name)}
                      >
                        <div className="flex-1 min-w-0">
                          <code className="text-xs font-mono text-slate-800">{variable.name}</code>
                          <p className="text-xs text-slate-500 truncate">{variable.description}</p>
                        </div>
                        <Copy className="w-3 h-3 text-slate-400" />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Contract Content</Label>
            <Textarea
              id="content"
              value={formData.content}
              onChange={e => handleChange("content", e.target.value)}
              placeholder={`Contract content with variables like {{PLAYER_FULL_NAME}}, {{CLUB_NAME}}, etc.

Example for player contract:
This Player Agreement is entered into between {{CLUB_NAME}} and {{PLAYER_FULL_NAME}} (Jersey #{{PLAYER_JERSEY_NUMBER}}) for the {{CURRENT_SEASON}} season.

Player Details:
- Full Name: {{PLAYER_FULL_NAME}}
- Email: {{PLAYER_EMAIL}}
- Phone: {{PLAYER_PHONE}}
- Address: {{PLAYER_ADDRESS}}
- Position: {{PLAYER_POSITION}}
- Team: {{PLAYER_TEAM_NAME}}

This agreement is valid from {{SEASON_START_DATE}} to {{SEASON_END_DATE}}.

Signed on {{CONTRACT_SIGNING_DATE}}.

[PLAYER_SIGNATURE]                                  [CLUB_SIGNATURE]
`}
              rows={25}
              className="font-mono text-sm"
              required
            />
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={checked => handleChange("is_active", checked)}
              />
              <Label htmlFor="is_active">Template is active</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="requires_witness"
                checked={formData.requires_witness}
                onCheckedChange={checked => handleChange("requires_witness", checked)}
              />
              <Label htmlFor="requires_witness">Requires witness signature</Label>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit">
            <Save className="w-4 h-4 mr-2" />
            {template ? "Update Template" : "Create Template"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
