
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Percent, CheckCircle, XCircle, Star, Shield, Target } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export default function PerformanceTracker({ attendanceRecords, trainingSessions, matches, playerId }) {
  // Calculate Training Attendance for past sessions
  const pastSessionIds = trainingSessions
    .filter(ts => new Date(ts.event_date) < new Date())
    .map(ts => ts.id);

  const pastAttendanceRecords = attendanceRecords.filter(ar => pastSessionIds.includes(ar.session_id));
  
  const attendedSessions = pastAttendanceRecords.filter(r => r.status === 'Present' || r.status === 'Attending').length;
  const totalTrackedSessions = pastAttendanceRecords.length;
  const attendancePercentage = totalTrackedSessions > 0 ? Math.round((attendedSessions / totalTrackedSessions) * 100) : 0;
  
  // Calculate Match Performance
  let totalGoals = 0;
  let totalAssists = 0;
  let matchesPlayed = 0;

  matches.forEach(match => {
    if (match.selected_players?.includes(playerId)) {
      matchesPlayed++;
    }
    const performance = match.player_performance?.find(p => p.player_id === playerId);
    if (performance) {
      totalGoals += performance.goals_scored || 0;
      totalAssists += performance.assists || 0;
    }
  });

  const recentAttendance = attendanceRecords
    .map(ar => {
      const session = trainingSessions.find(ts => ts.id === ar.session_id);
      return { ...ar, sessionDate: session?.event_date };
    })
    .filter(ar => ar.sessionDate)
    .sort((a, b) => new Date(b.sessionDate) - new Date(a.sessionDate))
    .slice(0, 5);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Training Attendance */}
      <Card className="lg:col-span-2 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Percent className="w-6 h-6 text-green-600" />
            Training Attendance
          </CardTitle>
          <CardDescription>Your attendance record for past training sessions.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="relative w-24 h-24">
              <svg className="w-full h-full" viewBox="0 0 36 36">
                <path
                  className="text-slate-200"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none" stroke="currentColor" strokeWidth="3"
                />
                <path
                  className="text-green-500"
                  strokeDasharray={`${attendancePercentage}, 100`}
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155"
                  fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-slate-800">{attendancePercentage}%</span>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800">Overall Attendance</h3>
              <p className="text-slate-500">{attendedSessions} of {totalTrackedSessions} past sessions attended.</p>
            </div>
          </div>
          <h4 className="font-semibold text-slate-700 mb-2">Recent Sessions:</h4>
          <div className="space-y-2">
            {recentAttendance.length > 0 ? recentAttendance.map(rec => (
              <div key={rec.id} className="flex items-center justify-between p-2 bg-slate-50 rounded-md">
                <span className="text-sm font-medium">{new Date(rec.sessionDate).toLocaleDateString()}</span>
                {rec.status === 'Present' ? (
                  <span className="flex items-center gap-1 text-xs text-green-600 font-bold"><CheckCircle className="w-3 h-3"/> Attended</span>
                ) : (
                  <span className="flex items-center gap-1 text-xs text-red-600 font-bold"><XCircle className="w-3 h-3"/> {rec.status}</span>
                )}
              </div>
            )) : <p className="text-sm text-slate-500">No recent training records found.</p>}
          </div>
        </CardContent>
      </Card>
      
      {/* Match Performance */}
      <Card className="bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart className="w-6 h-6 text-indigo-600" />
            Match Stats
          </CardTitle>
          <CardDescription>Your performance statistics from recent matches.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
           <div className="p-4 bg-slate-100 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Matches Played</p>
              <p className="text-3xl font-bold text-slate-800">{matchesPlayed}</p>
            </div>
            <Shield className="w-8 h-8 text-slate-400" />
          </div>
          <div className="p-4 bg-slate-100 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Goals</p>
              <p className="text-3xl font-bold text-slate-800">{totalGoals}</p>
            </div>
            <Target className="w-8 h-8 text-slate-400" />
          </div>
          <div className="p-4 bg-slate-100 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Assists</p>
              <p className="text-3xl font-bold text-slate-800">{totalAssists}</p>
            </div>
            <Star className="w-8 h-8 text-slate-400" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
