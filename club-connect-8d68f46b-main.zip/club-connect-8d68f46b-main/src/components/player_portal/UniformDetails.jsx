import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Shirt, Check } from 'lucide-react';

export default function UniformDetails({ uniformAssignments, inventoryItems }) {
  const assignedItems = uniformAssignments
    .filter(ua => ua.status === 'Assigned')
    .map(ua => {
      const item = inventoryItems.find(i => i.id === ua.item_id);
      return {
        ...ua,
        itemName: item?.name || 'Unknown Item',
        itemCategory: item?.category || 'N/A',
      };
    });

  return (
    <Card className="bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shirt className="w-6 h-6 text-purple-600" />
          Assigned Uniforms
        </CardTitle>
        <CardDescription>The uniform and equipment currently assigned to you.</CardDescription>
      </CardHeader>
      <CardContent>
        {assignedItems.length === 0 ? (
          <div className="text-center py-12">
            <Shirt className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-700 mb-2">No Uniforms Assigned</h3>
            <p className="text-slate-500">Your uniform details will appear here once assigned by the club manager.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {assignedItems.map(item => (
              <div key={item.id} className="p-4 border rounded-lg flex justify-between items-center bg-slate-50">
                <div>
                  <h4 className="font-semibold text-slate-800">{item.itemName}</h4>
                  <p className="text-sm text-slate-500">
                    Size/Variant: {item.variant_name} &bull; Quantity: {item.quantity}
                  </p>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-600 font-medium">
                  <Check className="w-4 h-4" />
                  Assigned
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}