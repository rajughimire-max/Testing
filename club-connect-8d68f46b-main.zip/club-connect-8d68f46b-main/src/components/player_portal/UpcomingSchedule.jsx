import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Trophy, Zap, Users, MapPin, Clock, CheckCircle, XCircle, Gamepad2 } from 'lucide-react';
import { format } from 'date-fns';

const EventIcon = ({ type }) => {
  const iconProps = { className: "w-5 h-5" };
  switch (type) {
    case 'match':
      return <div className={`p-2 rounded-full bg-red-100 text-red-600`}><Trophy {...iconProps} /></div>;
    case 'training':
      return <div className={`p-2 rounded-full bg-blue-100 text-blue-600`}><Zap {...iconProps} /></div>;
    case 'social_game':
      return <div className={`p-2 rounded-full bg-green-100 text-green-600`}><Gamepad2 {...iconProps} /></div>;
    case 'event':
      return <div className={`p-2 rounded-full bg-purple-100 text-purple-600`}><Users {...iconProps} /></div>;
    default:
      return <div className={`p-2 rounded-full bg-gray-100 text-gray-600`}><Calendar {...iconProps} /></div>;
  }
};

const EventCard = ({ item, attendance, onRsvp, onSocialGameRsvp }) => {
  const rsvpStatus = attendance?.status;

  const eventDate = item.date instanceof Date ? item.date : new Date(item.date);
  
  const handleRsvp = (status) => {
    if (item.type === 'social_game') {
      onSocialGameRsvp(item.eventId, status);
    } else {
      onRsvp(item.eventId, status);
    }
  };

  return (
    <Card className="bg-slate-800/50 backdrop-blur-md border-slate-700 text-white transition-shadow hover:shadow-lg hover:border-blue-500/50">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <EventIcon type={item.type} />
          <div className="flex-1">
            <p className="font-bold text-slate-100">{item.title}</p>
            <div className="flex items-center gap-4 text-sm text-slate-400 mt-1 flex-wrap">
              <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4"/>{format(eventDate, "EEE, d MMM yyyy")}</span>
              <span className="flex items-center gap-1.5"><Clock className="w-4 h-4"/>{item.time}</span>
              {item.location && <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4"/>{item.location}</span>}
            </div>
            {item.description && <p className="text-sm text-slate-400 mt-2">{item.description}</p>}
            
            {item.type !== 'match' && (
              <div className="border-t border-slate-700 mt-4 pt-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-medium text-slate-100">Your RSVP</h4>
                    {rsvpStatus === 'Attending' && <Badge variant="default" className="bg-green-600 hover:bg-green-600">Attending</Badge>}
                    {rsvpStatus === 'Not Attending' && <Badge variant="destructive" className="bg-red-600 hover:bg-red-600">Not Attending</Badge>}
                    {!rsvpStatus && <Badge variant="outline" className="bg-slate-700 border-slate-600">No Response</Badge>}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={rsvpStatus === 'Attending' ? 'default' : 'outline'}
                      onClick={() => handleRsvp('Attending')}
                      disabled={rsvpStatus === 'Attending'}
                      className={`
                        ${rsvpStatus === 'Attending' ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-green-800/50 text-green-300 hover:bg-green-800'}
                        border-green-700 disabled:opacity-100 disabled:cursor-not-allowed
                      `}
                    >
                      <CheckCircle className="w-4 h-4 mr-2"/> Attending
                    </Button>
                    <Button
                      size="sm"
                      variant={rsvpStatus === 'Not Attending' ? 'destructive' : 'outline'}
                      onClick={() => handleRsvp('Not Attending')}
                      disabled={rsvpStatus === 'Not Attending'}
                      className="disabled:opacity-100 disabled:cursor-not-allowed border-red-700 bg-red-800/50 text-red-300 hover:bg-red-800"
                    >
                      <XCircle className="w-4 h-4 mr-2"/> Not Attending
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function UpcomingSchedule({ matches, trainingSessions, events, socialGames, attendanceRecords, socialGameAttendances, onRsvp, onSocialGameRsvp }) {
  const upcomingMatches = matches.map(m => ({
      id: `match-${m.id}`,
      eventId: m.id,
      type: 'match',
      date: new Date(`${m.match_date}T${m.match_time || '00:00:00'}`),
      time: m.match_time || 'TBC',
      title: `Match vs ${m.opponent_name}`,
      subtitle: m.competition || 'Friendly',
      location: m.venue,
    }));

  const upcomingTraining = trainingSessions.map(t => ({
      id: `training-${t.id}`,
      eventId: t.id,
      type: 'training',
      date: new Date(`${t.event_date}T${t.start_time || '00:00:00'}`),
      time: t.start_time || 'TBC',
      title: t.title || 'Team Training',
      subtitle: `Training Session`,
      location: t.venue,
    }));

  const upcomingEvents = events.map(e => ({
      id: `event-${e.id}`,
      eventId: e.id,
      type: 'event',
      date: new Date(`${e.event_date}T${e.start_time || '00:00:00'}`),
      time: e.start_time || 'TBC',
      title: e.title,
      subtitle: e.event_type,
      location: e.venue,
    }));

  const upcomingSocialGames = socialGames.map(sg => ({
      id: `social-${sg.id}`,
      eventId: sg.id,
      type: 'social_game',
      date: new Date(`${sg.event_date}T${sg.start_time || '00:00:00'}`),
      time: sg.start_time || 'TBC',
      title: sg.title,
      description: sg.description,
      location: sg.venue,
    }));

  const allItems = [...upcomingMatches, ...upcomingTraining, ...upcomingEvents, ...upcomingSocialGames]
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  const getAttendance = (item) => {
    if (item.type === 'training') {
      return attendanceRecords.find(a => a.session_id === item.eventId);
    }
    if (item.type === 'social_game') {
      return socialGameAttendances.find(a => a.event_id === item.eventId);
    }
    return null;
  };

  return (
    <Card className="bg-transparent border-none shadow-none">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-white">
          <Calendar className="w-6 h-6 text-blue-400" />
          Your Upcoming Schedule
        </CardTitle>
        <CardDescription className="text-slate-300">Your next matches, training sessions, and club events.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {allItems.length === 0 ? (
            <div className="text-center py-10 px-6 bg-slate-800/50 rounded-lg">
              <Zap className="mx-auto h-12 w-12 text-slate-400" />
              <h3 className="mt-2 text-lg font-medium text-slate-200">All Clear!</h3>
              <p className="mt-1 text-sm text-slate-400">You have no upcoming events on your schedule.</p>
            </div>
          ) : (
            allItems.map(item => (
              <EventCard
                key={item.id}
                item={item}
                attendance={getAttendance(item)}
                onRsvp={onRsvp}
                onSocialGameRsvp={onSocialGameRsvp}
              />
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}