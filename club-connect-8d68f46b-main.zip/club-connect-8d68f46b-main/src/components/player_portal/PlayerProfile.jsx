import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, Shield, Mail, Phone, Calendar, Upload, Loader2, Star } from 'lucide-react';
import { format } from 'date-fns';

export default function PlayerProfile({ player, team, uploading, onPhotoUpload }) {
  const stats = [
    { label: 'Position', value: player.position || 'N/A', icon: Star },
    { label: 'Height', value: player.height ? `${player.height} cm` : 'N/A' },
    { label: 'Weight', value: player.weight ? `${player.weight} kg` : 'N/A' },
    { label: 'Preferred Foot', value: player.playing_foot || 'N/A' },
    { label: 'Jersey #', value: player.preferred_number, special: true },
  ];

  return (
    <Card className="bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle>My Profile</CardTitle>
        <CardDescription>Your personal and player information.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Profile Picture */}
          <div className="md:col-span-1 flex flex-col items-center space-y-4">
            <div className="relative">
              {player.profile_photo_url ? (
                <img src={player.profile_photo_url} alt="Profile" className="w-40 h-40 rounded-full object-cover border-4 border-white shadow-lg" />
              ) : (
                <div className="w-40 h-40 rounded-full bg-slate-200 flex items-center justify-center border-4 border-white shadow-lg">
                  <User className="w-20 h-20 text-slate-400" />
                </div>
              )}
              {uploading && (
                <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center">
                  <Loader2 className="w-8 h-8 text-white animate-spin" />
                </div>
              )}
            </div>
            <Button asChild variant="outline" size="sm">
              <label htmlFor="photo-upload">
                <Upload className="w-4 h-4 mr-2" />
                Change Photo
                <input id="photo-upload" type="file" className="sr-only" onChange={onPhotoUpload} disabled={uploading} accept="image/*"/>
              </label>
            </Button>
          </div>

          {/* Player Details */}
          <div className="md:col-span-2">
            <h2 className="text-3xl font-bold text-slate-900">{player.first_name} {player.last_name}</h2>
            <div className="flex items-center gap-2 text-lg text-blue-600 font-semibold mb-6">
              <Shield className="w-5 h-5" />
              <span>{team?.name || 'No Team Assigned'}</span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6 text-center">
              {stats.map(stat => (
                <div key={stat.label} className={`p-3 rounded-lg ${stat.special ? 'bg-blue-600 text-white' : 'bg-slate-100'}`}>
                  <p className={`text-sm font-semibold ${stat.special ? 'opacity-80' : 'text-slate-500'}`}>{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              ))}
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-slate-400" />
                <span className="text-slate-700">{player.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-slate-400" />
                <span className="text-slate-700">{player.phone || 'Not Provided'}</span>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span className="text-slate-700">Born on {player.date_of_birth ? format(new Date(player.date_of_birth), 'MMMM d, yyyy') : 'N/A'}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}