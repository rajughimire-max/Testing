// Stripe.js loader utility
let stripePromise = null;

// Get the Stripe publishable key from environment
function getStripePublishableKey() {
  // Check if it's available on window (sometimes injected there)
  if (typeof window !== 'undefined' && window.__STRIPE_PUBLISHABLE_KEY__) {
    return window.__STRIPE_PUBLISHABLE_KEY__;
  }
  
  // For now, we'll need to set this manually or get it from the server
  // This is a temporary fallback - you'll need to set the actual key
  console.warn('Stripe publishable key not found in environment variables');
  return null;
}

export function loadStripe() {
  if (!stripePromise) {
    stripePromise = new Promise((resolve, reject) => {
      const publishableKey = getStripePublishableKey();
      
      if (!publishableKey) {
        reject(new Error('Stripe publishable key not configured. Please set PUBLIC_STRIPE_PUBLISHABLE_KEY environment variable.'));
        return;
      }

      if (window.Stripe) {
        resolve(window.Stripe(publishableKey));
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://js.stripe.com/v3/';
      script.onload = () => {
        if (window.Stripe) {
          resolve(window.Stripe(publishableKey));
        } else {
          reject(new Error('Stripe.js failed to load'));
        }
      };
      script.onerror = () => {
        reject(new Error('Failed to load Stripe.js script'));
      };
      document.head.appendChild(script);
    });
  }
  
  return stripePromise;
}

export async function redirectToStripeCheckout({ sessionId, checkoutUrl }) {
  try {
    // Try to use Stripe.js redirectToCheckout first
    const stripe = await loadStripe();
    const { error } = await stripe.redirectToCheckout({ sessionId });
    
    if (error) {
      console.warn('Stripe redirectToCheckout failed:', error);
      // Fallback to manual redirect
      if (checkoutUrl) {
        window.location.href = checkoutUrl;
      } else {
        throw new Error('No checkout URL available for fallback');
      }
    }
  } catch (stripeError) {
    console.warn('Stripe.js loading failed, using fallback redirect:', stripeError);
    // Fallback to manual redirect
    if (checkoutUrl) {
      window.location.href = checkoutUrl;
    } else {
      throw new Error('Stripe checkout failed and no fallback URL available');
    }
  }
}