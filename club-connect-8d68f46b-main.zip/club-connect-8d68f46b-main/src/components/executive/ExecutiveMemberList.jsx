
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Edit, Trash2, Calendar, User, Crown, Mail, Phone, ExternalLink, MoreVertical } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { format, isBefore, isAfter } from 'date-fns';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const ExecutiveCard = ({ executive, onEdit, onDelete, isPast }) => {
  const getInitials = (name) => {
    if (!name) return '?';
    const names = name.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return `${names[0].charAt(0)}${names[names.length - 1].charAt(0)}`.toUpperCase();
  };

  const role = executive.position === 'Other' ? executive.custom_position_title : executive.position;

  return (
    <Card className="hover:shadow-lg transition-shadow duration-300 bg-white/60">
      <CardContent className="p-4 flex flex-col justify-between h-full">
        <div>
          <div className="flex justify-between items-start">
              <div className="flex items-center gap-4">
                  {executive.person_photo ? (
                      <img src={executive.person_photo} alt={executive.person_name} className="w-16 h-16 rounded-full object-cover border-2 border-slate-100" />
                  ) : (
                      <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold text-xl">
                          {getInitials(executive.person_name)}
                      </div>
                  )}
                  <div>
                      <h3 className="font-bold text-lg text-slate-900">{executive.person_name}</h3>
                      <p className="text-blue-600 font-semibold">{role}</p>
                  </div>
              </div>
              {!executive.is_core_only && (
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-slate-500">
                            <MoreVertical className="w-5 h-5" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(executive)}>
                            <Edit className="w-4 h-4 mr-2" /> Edit Role
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onDelete(executive.id)} className="text-red-600">
                            <Trash2 className="w-4 h-4 mr-2" /> Remove Role
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
              )}
          </div>
          
          <p className="text-sm text-slate-500 mt-2">{executive.person_email}</p>

          {!executive.is_core_only && (
            <div className="mt-4 text-xs text-slate-600 space-y-1">
              <p><strong>Appointed:</strong> {executive.appointment_date ? format(new Date(executive.appointment_date), 'dd MMM yyyy') : 'N/A'}</p>
              <p><strong>Term Ends:</strong> {executive.term_end_date ? format(new Date(executive.term_end_date), 'dd MMM yyyy') : 'N/A'}</p>
            </div>
          )}
        </div>
        
        <div className="mt-4 flex justify-end">
            <Badge variant={executive.status === 'Active' ? 'default' : 'secondary'} className={executive.status === 'Active' ? 'bg-green-100 text-green-800' : ''}>
                {executive.status}
            </Badge>
        </div>
      </CardContent>
    </Card>
  );
};

export default function ExecutiveMemberList({ executives, loading, onEdit, onDelete, showActions = true, isPast = false }) {

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex items-center space-x-4 p-4">
            <Skeleton className="h-12 w-12 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-[250px]" />
              <Skeleton className="h-4 w-[200px]" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!executives || executives.length === 0) {
    return (
      <div className="text-center py-12 text-slate-500">
        <Crown className="mx-auto h-12 w-12 text-slate-400" />
        <h3 className="mt-4 text-lg font-medium">No Executive Members Found</h3>
        <p className="mt-1 text-sm">{isPast ? "There are no past executive members to display." : "Add a new executive member to get started."}</p>
      </div>
    );
  }

  // The getPositionTitle and getTermStatus functions are now handled within ExecutiveCard or by direct 'status' property,
  // so they are no longer needed in this parent component for card rendering.
  // const getPositionTitle = (exec) => {
  //   return exec.position === 'Other' ? exec.custom_position_title : exec.position;
  // }
  
  // const getTermStatus = (termEndDate) => {
  //   if (!termEndDate) return { text: 'Ongoing', color: 'bg-green-100 text-green-800' };
  //   const today = new Date();
  //   const endDate = new Date(termEndDate);
  //   if (isBefore(endDate, today)) return { text: 'Term Ended', color: 'bg-red-100 text-red-800' };
  //   if (isAfter(endDate, today)) return { text: 'Active Term', color: 'bg-blue-100 text-blue-800' };
  //   return { text: 'Term Ends Today', color: 'bg-yellow-100 text-yellow-800' };
  // }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
      {executives.map(exec => (
        <ExecutiveCard
          key={exec.id}
          executive={exec}
          onEdit={onEdit}
          onDelete={onDelete}
          isPast={isPast}
        />
      ))}
    </div>
  );
}
