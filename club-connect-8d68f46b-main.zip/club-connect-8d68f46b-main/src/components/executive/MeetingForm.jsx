import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Save, X } from 'lucide-react';

export default function MeetingForm({ meeting, onSubmit, onCancel }) {
    const [formData, setFormData] = useState(meeting || {
        title: '',
        meeting_date: '',
        meeting_time: '',
        end_time: '',
        location: '',
        meeting_type: 'Board Meeting',
        status: 'Scheduled'
    });

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <Card className="mb-6 bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader>
                <CardTitle>{meeting ? 'Edit Meeting' : 'Schedule New Meeting'}</CardTitle>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6 p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <Label htmlFor="title">Meeting Title</Label>
                            <Input
                                id="title"
                                value={formData.title}
                                onChange={e => handleChange('title', e.target.value)}
                                placeholder="e.g., Monthly Board Meeting"
                                required
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="meeting_type">Meeting Type</Label>
                            <Select value={formData.meeting_type} onValueChange={v => handleChange('meeting_type', v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Board Meeting">Board Meeting</SelectItem>
                                    <SelectItem value="Executive Committee">Executive Committee</SelectItem>
                                    <SelectItem value="Annual General Meeting">Annual General Meeting</SelectItem>
                                    <SelectItem value="Special Meeting">Special Meeting</SelectItem>
                                    <SelectItem value="Other">Other</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <Label htmlFor="meeting_date">Meeting Date</Label>
                            <Input
                                id="meeting_date"
                                type="date"
                                value={formData.meeting_date}
                                onChange={e => handleChange('meeting_date', e.target.value)}
                                required
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="meeting_time">Start Time</Label>
                            <Input
                                id="meeting_time"
                                type="time"
                                value={formData.meeting_time}
                                onChange={e => handleChange('meeting_time', e.target.value)}
                                required
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="end_time">End Time</Label>
                            <Input
                                id="end_time"
                                type="time"
                                value={formData.end_time}
                                onChange={e => handleChange('end_time', e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="location">Location</Label>
                        <Input
                            id="location"
                            value={formData.location}
                            onChange={e => handleChange('location', e.target.value)}
                            placeholder="e.g., Club House Conference Room or Zoom Link"
                            required
                        />
                    </div>
                </CardContent>
                <CardFooter className="flex justify-end gap-3 p-6 bg-slate-50/50 rounded-b-lg">
                    <Button type="button" variant="outline" onClick={onCancel}>
                        <X className="w-4 h-4 mr-2" />Cancel
                    </Button>
                    <Button type="submit">
                        <Save className="w-4 h-4 mr-2" />{meeting ? 'Update Meeting' : 'Schedule Meeting'}
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}