import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Save, X, Plus, List } from 'lucide-react';

export default function AgendaItemForm({ meeting, initialData, onSubmit, onCancel }) {
    const [isBulkMode, setIsBulkMode] = useState(false);
    const [formData, setFormData] = useState({});
    const [bulkData, setBulkData] = useState({
        items_text: '',
        category: 'Other',
        priority: 'Medium',
        estimated_duration: 15
    });

    useEffect(() => {
        if (initialData) {
            // Editing an existing item - always single mode
            setIsBulkMode(false);
            setFormData(initialData);
        } else if (meeting) {
            // Creating new item(s)
            setFormData({
                meeting_id: meeting.id,
                title: '',
                description: '',
                category: 'Other',
                priority: 'Medium',
                estimated_duration: 15,
                status: 'Pending'
            });
        }
    }, [initialData, meeting]);

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleBulkChange = (field, value) => {
        setBulkData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        
        if (isBulkMode && !initialData) {
            // Handle bulk creation
            const items = bulkData.items_text
                .split('\n')
                .map(line => line.trim())
                .filter(line => line.length > 0)
                .map(line => {
                    // Check if line has a format like "Title | Description"
                    const parts = line.split('|').map(part => part.trim());
                    const title = parts[0];
                    const description = parts[1] || '';

                    return {
                        meeting_id: meeting.id,
                        title: title,
                        description: description,
                        category: bulkData.category,
                        priority: bulkData.priority,
                        estimated_duration: bulkData.estimated_duration,
                        status: 'Pending'
                    };
                });

            if (items.length === 0) {
                alert('Please enter at least one agenda item.');
                return;
            }

            // Submit multiple items
            onSubmit({ bulkItems: items });
        } else {
            // Handle single item creation/edit
            onSubmit(formData);
        }
    };

    // Guard against rendering if formData is not yet initialized
    if (!formData.meeting_id && !initialData) {
        return null;
    }

    return (
        <Card className="mb-6 bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle>
                        {initialData ? 'Edit Agenda Item' : `Add Agenda Item${isBulkMode ? 's' : ''} for ${meeting?.title || 'Meeting'}`}
                    </CardTitle>
                    {!initialData && (
                        <div className="flex items-center space-x-2">
                            <Label htmlFor="bulk-mode" className="text-sm">
                                {isBulkMode ? <List className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                            </Label>
                            <Switch
                                id="bulk-mode"
                                checked={isBulkMode}
                                onCheckedChange={setIsBulkMode}
                            />
                            <Label htmlFor="bulk-mode" className="text-sm font-medium">
                                {isBulkMode ? 'Bulk Add' : 'Single Item'}
                            </Label>
                        </div>
                    )}
                </div>
            </CardHeader>
            <form onSubmit={handleSubmit}>
                <CardContent className="space-y-6 p-6">
                    {isBulkMode && !initialData ? (
                        <>
                            {/* Bulk Mode */}
                            <div className="space-y-2">
                                <Label htmlFor="items_text">Agenda Items</Label>
                                <Textarea
                                    id="items_text"
                                    value={bulkData.items_text}
                                    onChange={e => handleBulkChange('items_text', e.target.value)}
                                    placeholder={`Enter multiple agenda items, one per line:

Budget Review for 2025
Team Performance Analysis | Discuss Q4 results and set goals
Facility Upgrades | Review quotes and approve contractors

You can optionally add descriptions using: Title | Description`}
                                    className="h-32"
                                    required
                                />
                                <p className="text-xs text-slate-500">
                                    Tip: Use "Title | Description" format to add descriptions, or just titles alone.
                                </p>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="space-y-2">
                                    <Label htmlFor="bulk_category">Category (for all items)</Label>
                                    <Select value={bulkData.category} onValueChange={v => handleBulkChange('category', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Financial">Financial</SelectItem>
                                            <SelectItem value="Operations">Operations</SelectItem>
                                            <SelectItem value="Strategy">Strategy</SelectItem>
                                            <SelectItem value="Governance">Governance</SelectItem>
                                            <SelectItem value="Facilities">Facilities</SelectItem>
                                            <SelectItem value="Membership">Membership</SelectItem>
                                            <SelectItem value="Other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="bulk_priority">Priority (for all items)</Label>
                                    <Select value={bulkData.priority} onValueChange={v => handleBulkChange('priority', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="High">High</SelectItem>
                                            <SelectItem value="Medium">Medium</SelectItem>
                                            <SelectItem value="Low">Low</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="bulk_duration">Duration per item (minutes)</Label>
                                    <Input
                                        id="bulk_duration"
                                        type="number"
                                        min="5"
                                        max="120"
                                        value={bulkData.estimated_duration}
                                        onChange={e => handleBulkChange('estimated_duration', parseInt(e.target.value))}
                                    />
                                </div>
                            </div>
                        </>
                    ) : (
                        <>
                            {/* Single Item Mode */}
                            <div className="space-y-2">
                                <Label htmlFor="title">Agenda Item Title</Label>
                                <Input
                                    id="title"
                                    value={formData.title || ''}
                                    onChange={e => handleChange('title', e.target.value)}
                                    placeholder="e.g., Budget Review for 2025"
                                    required
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="description">Description</Label>
                                <Textarea
                                    id="description"
                                    value={formData.description || ''}
                                    onChange={e => handleChange('description', e.target.value)}
                                    placeholder="Provide details about what will be discussed..."
                                    className="h-24"
                                    required
                                />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="space-y-2">
                                    <Label htmlFor="category">Category</Label>
                                    <Select value={formData.category || 'Other'} onValueChange={v => handleChange('category', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Financial">Financial</SelectItem>
                                            <SelectItem value="Operations">Operations</SelectItem>
                                            <SelectItem value="Strategy">Strategy</SelectItem>
                                            <SelectItem value="Governance">Governance</SelectItem>
                                            <SelectItem value="Facilities">Facilities</SelectItem>
                                            <SelectItem value="Membership">Membership</SelectItem>
                                            <SelectItem value="Other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="priority">Priority</Label>
                                    <Select value={formData.priority || 'Medium'} onValueChange={v => handleChange('priority', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="High">High</SelectItem>
                                            <SelectItem value="Medium">Medium</SelectItem>
                                            <SelectItem value="Low">Low</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="estimated_duration">Duration (minutes)</Label>
                                    <Input
                                        id="estimated_duration"
                                        type="number"
                                        min="5"
                                        max="120"
                                        value={formData.estimated_duration || 15}
                                        onChange={e => handleChange('estimated_duration', parseInt(e.target.value))}
                                    />
                                </div>
                            </div>
                        </>
                    )}
                </CardContent>
                <CardFooter className="flex justify-end gap-3 p-6 bg-slate-50/50 rounded-b-lg">
                    <Button type="button" variant="outline" onClick={onCancel}>
                        <X className="w-4 h-4 mr-2" />Cancel
                    </Button>
                    <Button type="submit">
                        <Save className="w-4 h-4 mr-2" />
                        {isBulkMode && !initialData ? 'Add All Items' : (initialData ? 'Update Item' : 'Add to Agenda')}
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
}