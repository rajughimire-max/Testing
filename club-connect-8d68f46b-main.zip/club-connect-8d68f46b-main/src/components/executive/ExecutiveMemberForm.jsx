import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Save, X } from 'lucide-react';
import { Combobox } from '@/components/ui/combobox';
import { addYears } from 'date-fns';

export default function ExecutiveMemberForm({ executive, members, players, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(executive || {
    member_id: null,
    player_id: null,
    position: '',
    custom_position_title: '',
    appointment_date: '',
    term_end_date: '',
    status: 'Active',
    responsibilities: '',
    notes: ''
  });

  const [selectedPerson, setSelectedPerson] = useState(null);

  useEffect(() => {
    // If editing, ensure we have the correct ID fields populated
    if (executive) {
      setFormData(executive);
      // Find the selected person details
      if (executive.member_id) {
        const person = members.find(m => m.id === executive.member_id);
        setSelectedPerson(person ? { ...person, type: 'Member' } : null);
      } else if (executive.player_id) {
        const person = players.find(p => p.id === executive.player_id);
        setSelectedPerson(person ? { ...person, type: 'Player' } : null);
      }
    }
  }, [executive, members, players]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Auto-set term end date when appointment date changes (for new executives)
    if (field === 'appointment_date' && !executive && value) {
      const appointmentDate = new Date(value);
      const termEndDate = addYears(appointmentDate, 2);
      setFormData(prev => ({ ...prev, term_end_date: termEndDate.toISOString().split('T')[0] }));
    }
  };
  
  const handlePersonSelect = (personId) => {
    const member = members.find(m => m.id === personId);
    const player = players.find(p => p.id === personId);
    
    if (player) {
      setFormData(prev => ({ ...prev, player_id: personId, member_id: null }));
      setSelectedPerson({ ...player, type: 'Player' });
    } else if (member) {
      setFormData(prev => ({ ...prev, member_id: personId, player_id: null }));
      setSelectedPerson({ ...member, type: 'Member' });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const peopleOptions = [
      ...members.map(m => ({ value: m.id, label: `${m.first_name} ${m.last_name} (Member)` })),
      ...players.map(p => ({ value: p.id, label: `${p.first_name} ${p.last_name} (Player)` }))
  ];

  const selectedPersonId = formData.player_id || formData.member_id;

  return (
    <Card className="mb-6 bg-white/80 backdrop-blur-sm border-slate-200/60">
      <CardHeader>
        <CardTitle>{executive ? 'Edit Executive Member' : 'Add New Executive Member'}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6 p-6">
          {/* Person Selection */}
          <div className="space-y-2">
            <Label htmlFor="person">Select Person</Label>
            <Combobox
              options={peopleOptions}
              value={selectedPersonId}
              onChange={handlePersonSelect}
              placeholder="Search for a member or player..."
            />
          </div>

          {/* Show selected person details */}
          {selectedPerson && (
            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {selectedPerson.photo_url || selectedPerson.profile_photo_url ? (
                    <img 
                      src={selectedPerson.photo_url || selectedPerson.profile_photo_url} 
                      alt={`${selectedPerson.first_name} ${selectedPerson.last_name}`}
                      className="w-16 h-16 rounded-full object-cover border-2 border-slate-200"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-slate-300 flex items-center justify-center text-slate-600 font-bold text-lg">
                      {selectedPerson.first_name?.charAt(0)}{selectedPerson.last_name?.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="font-semibold text-lg text-slate-900">
                      {selectedPerson.first_name} {selectedPerson.last_name}
                    </h4>
                    <p className="text-slate-600">{selectedPerson.email}</p>
                    <p className="text-sm text-slate-500">{selectedPerson.phone}</p>
                    <Badge className="mt-1" variant="outline">{selectedPerson.type}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Position */}
            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Select value={formData.position} onValueChange={v => handleChange('position', v)} required>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="President">President</SelectItem>
                  <SelectItem value="Vice President">Vice President</SelectItem>
                  <SelectItem value="Secretary">Secretary</SelectItem>
                  <SelectItem value="Treasurer">Treasurer</SelectItem>
                  <SelectItem value="Committee Member">Committee Member</SelectItem>
                  <SelectItem value="Board Member">Board Member</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Custom Position Title (if 'Other') */}
            {formData.position === 'Other' && (
              <div className="space-y-2">
                <Label htmlFor="custom_position_title">Custom Position Title</Label>
                <Input
                  id="custom_position_title"
                  value={formData.custom_position_title}
                  onChange={e => handleChange('custom_position_title', e.target.value)}
                  placeholder="e.g., Head of Youth Development"
                  required
                />
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Appointment Date */}
            <div className="space-y-2">
              <Label htmlFor="appointment_date">Appointment Date</Label>
              <Input
                id="appointment_date"
                type="date"
                value={formData.appointment_date}
                onChange={e => handleChange('appointment_date', e.target.value)}
                required
              />
            </div>

            {/* Term End Date */}
            <div className="space-y-2">
              <Label htmlFor="term_end_date">Term End Date <span className="text-sm text-slate-500">(Default: 2 years)</span></Label>
              <Input
                id="term_end_date"
                type="date"
                value={formData.term_end_date}
                onChange={e => handleChange('term_end_date', e.target.value)}
              />
            </div>

            {/* Status */}
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={v => handleChange('status', v)} required>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Past">Past</SelectItem>
                  <SelectItem value="Suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Responsibilities */}
          <div className="space-y-2">
              <Label htmlFor="responsibilities">Responsibilities</Label>
              <Textarea
                  id="responsibilities"
                  value={formData.responsibilities}
                  onChange={e => handleChange('responsibilities', e.target.value)}
                  placeholder="Summarize key responsibilities of this role..."
                  className="h-24"
              />
          </div>

          {/* Notes */}
          <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={e => handleChange('notes', e.target.value)}
                  placeholder="Add any additional notes about this appointment..."
              />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3 p-6 bg-slate-50/50 rounded-b-lg">
          <Button type="button" variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button type="submit"><Save className="w-4 h-4 mr-2" />{executive ? 'Update Member' : 'Add Member'}</Button>
        </CardFooter>
      </form>
    </Card>
  );
}