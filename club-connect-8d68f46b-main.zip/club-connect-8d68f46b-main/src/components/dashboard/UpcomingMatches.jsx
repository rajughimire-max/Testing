import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Calendar, MapPin, Clock } from "lucide-react";
import { format, isToday, isTomorrow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function UpcomingMatches({ matches, loading }) {
  const upcomingMatches = matches.filter(match => 
    new Date(match.match_date) >= new Date() && match.match_status === 'scheduled'
  ).slice(0, 4);

  const getDateLabel = (date) => {
    if (isToday(new Date(date))) return "Today";
    if (isTomorrow(new Date(date))) return "Tomorrow";
    return format(new Date(date), "EEE, MMM d");
  };

  if (loading) {
    return (
      <>
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-white">
            <Trophy className="w-5 h-5" />
            Upcoming Matches
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32 bg-white/20" />
                  <Skeleton className="h-3 w-48 bg-white/20" />
                </div>
                <Skeleton className="h-6 w-16 rounded-full bg-white/20" />
              </div>
            ))}
          </div>
        </CardContent>
      </>
    );
  }

  return (
    <>
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-white">
          <Trophy className="w-5 h-5" />
          Upcoming Matches
        </CardTitle>
      </CardHeader>
      <CardContent>
        {upcomingMatches.length === 0 ? (
          <div className="text-center py-8">
            <Trophy className="w-12 h-12 text-slate-500/50 mx-auto mb-3" />
            <p className="text-slate-400">No upcoming matches scheduled</p>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingMatches.map((match) => (
              <div key={match.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-200">
                <div className="space-y-1">
                  <p className="font-semibold text-white">vs {match.opponent_name}</p>
                  <div className="flex items-center gap-4 text-sm text-blue-200">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3 h-3" />
                      {getDateLabel(match.match_date)}
                    </span>
                    {match.match_time && (
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-3 h-3" />
                        {match.match_time}
                      </span>
                    )}
                    {match.venue && (
                      <span className="flex items-center gap-1.5">
                        <MapPin className="w-3 h-3" />
                        {match.is_home_game ? "Home" : match.venue}
                      </span>
                    )}
                  </div>
                </div>
                <Badge className={`border-0 ${match.is_home_game ? "bg-blue-500/80 text-white" : "bg-white/10 text-blue-200"}`}>
                  {match.is_home_game ? "Home" : "Away"}
                </Badge>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </>
  );
}