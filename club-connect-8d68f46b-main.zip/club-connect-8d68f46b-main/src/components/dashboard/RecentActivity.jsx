import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, UserPlus, Calendar, Clock } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function RecentActivity({ members, events, loading }) {
  const recentActivities = [
    ...members.slice(0, 3).map(member => ({
      id: `member-${member.id}`,
      type: "member_joined",
      title: `${member.first_name} ${member.last_name} joined`,
      subtitle: `New ${member.membership_type}`,
      time: member.created_date,
      icon: UserPlus
    })),
    ...events.slice(0, 2).map(event => ({
      id: `event-${event.id}`,
      type: "event_created", 
      title: event.title,
      subtitle: `${event.event_type} event`,
      time: event.created_date,
      icon: Calendar
    }))
  ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 5);

  if (loading) {
    return (
      <>
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-white">
            <Activity className="w-5 h-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="flex items-start gap-3">
                <Skeleton className="h-8 w-8 rounded-full bg-white/20" />
                <div className="space-y-1 flex-1">
                  <Skeleton className="h-4 w-full bg-white/20" />
                  <Skeleton className="h-3 w-20 bg-white/20" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </>
    );
  }

  return (
    <>
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-white">
          <Activity className="w-5 h-5" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {recentActivities.length === 0 ? (
          <div className="text-center py-6">
            <Activity className="w-8 h-8 text-slate-500/50 mx-auto mb-2" />
            <p className="text-slate-400 text-sm">No recent activity</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3">
                <div className="p-2 bg-white/10 rounded-full">
                  <activity.icon className="w-4 h-4 text-blue-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">
                    {activity.title}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-blue-300">
                    <span>{activity.subtitle}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {format(new Date(activity.time), "MMM d, h:mm a")}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </>
  );
}