import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Users, Trophy, Calendar } from "lucide-react";
import { Team, Player } from "@/api/entities";
import { Skeleton } from "@/components/ui/skeleton";

export default function TeamOverview({ loading }) {
  const [teams, setTeams] = useState([]);
  const [teamStats, setTeamStats] = useState({});
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    loadTeamData();
  }, []);

  const loadTeamData = async () => {
    try {
      const teamsData = await Team.list("-created_date", 8);
      const playersData = await Player.list();
      
      // Count players per team
      const playerCounts = {};
      playersData.forEach(player => {
        playerCounts[player.team_id] = (playerCounts[player.team_id] || 0) + 1;
      });

      setTeams(teamsData);
      setTeamStats(playerCounts);
    } catch (error) {
      console.error("Error loading team data:", error);
    } finally {
      setDataLoading(false);
    }
  };

  const getSportColor = (sport) => {
    const colors = {
      soccer: "bg-green-100 text-green-800 border-green-200",
      basketball: "bg-orange-100 text-orange-800 border-orange-200", 
      hockey: "bg-blue-100 text-blue-800 border-blue-200",
      netball: "bg-pink-100 text-pink-800 border-pink-200",
      rugby: "bg-purple-100 text-purple-800 border-purple-200"
    };
    return colors[sport] || "bg-gray-100 text-gray-800 border-gray-200";
  };

  if (loading || dataLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-slate-600" />
            Team Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="p-4 border border-slate-200 rounded-lg">
                <div className="space-y-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-4 w-24" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-slate-600" />
          Team Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        {teams.length === 0 ? (
          <div className="text-center py-8">
            <Shield className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">No teams created yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {teams.map((team) => (
              <div key={team.id} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors duration-200">
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold text-slate-900">{team.name}</h3>
                    <Badge className={getSportColor(team.sport)}>
                      {team.sport}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    {team.age_group && (
                      <p className="text-sm text-slate-600">{team.age_group}</p>
                    )}
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {teamStats[team.id] || 0} players
                      </span>
                      {team.season && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {team.season}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}