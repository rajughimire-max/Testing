import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InventoryTransaction, InventoryItem, Event } from "@/api/entities";
import { Package, Search, Download, AlertTriangle, CheckCircle, TrendingDown, TrendingUp, Filter } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function EquipmentAuditLog() {
    const [transactions, setTransactions] = useState([]);
    const [items, setItems] = useState([]);
    const [sessions, setSessions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [filterType, setFilterType] = useState("all");

    useEffect(() => {
        loadAuditData();
    }, []);

    const loadAuditData = async () => {
        setLoading(true);
        try {
            const [transactionsData, itemsData, sessionsData] = await Promise.all([
                InventoryTransaction.list("-created_date", 100),
                InventoryItem.list(),
                Event.list("-event_date", 50)
            ]);
            
            setTransactions(transactionsData);
            setItems(itemsData);
            setSessions(sessionsData);
        } catch (error) {
            console.error("Error loading audit data:", error);
        } finally {
            setLoading(false);
        }
    };

    const getItemName = (itemId) => {
        const item = items.find(i => i.id === itemId);
        return item?.name || "Unknown Item";
    };

    const getSessionName = (sessionId) => {
        const session = sessions.find(s => s.id === sessionId);
        return session?.title || "Unknown Session";
    };

    const getTransactionIcon = (type) => {
        const icons = {
            "Check-out": TrendingDown,
            "Check-in": TrendingUp,
            "Missing": AlertTriangle,
            "Adjustment": Package,
            "Initial Stock": CheckCircle,
            "Damaged": AlertTriangle
        };
        return icons[type] || Package;
    };

    const getBadgeVariant = (type) => {
        const variants = {
            "Check-out": "destructive",
            "Check-in": "default",
            "Missing": "destructive",
            "Adjustment": "secondary",
            "Initial Stock": "default",
            "Damaged": "secondary"
        };
        const baseClass = {
          destructive: "bg-red-500/20 text-red-300 border-red-500/30",
          default: "bg-green-500/20 text-green-300 border-green-500/30",
          secondary: "bg-blue-500/20 text-blue-300 border-blue-500/30",
          outline: "bg-white/10 text-slate-300 border-white/20"
        }
        return baseClass[variants[type] || "outline"];
    };

    const filteredTransactions = transactions.filter(tx => {
        const matchesSearch = searchTerm === "" || 
            getItemName(tx.item_id).toLowerCase().includes(searchTerm.toLowerCase()) ||
            (tx.training_session_id && getSessionName(tx.training_session_id).toLowerCase().includes(searchTerm.toLowerCase())) ||
            tx.reason?.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesType = filterType === "all" || tx.transaction_type === filterType;

        return matchesSearch && matchesType;
    });

    const exportAuditLog = () => {
        const csvContent = [
            ['Date', 'Item', 'Transaction Type', 'Quantity', 'Session', 'Reason'].join(','),
            ...filteredTransactions.map(tx => [
                format(new Date(tx.created_date), 'yyyy-MM-dd HH:mm:ss'),
                getItemName(tx.item_id),
                tx.transaction_type,
                tx.quantity_change,
                tx.training_session_id ? getSessionName(tx.training_session_id) : '',
                tx.reason || ''
            ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `equipment-audit-log-${format(new Date(), 'yyyy-MM-dd')}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
    };

    if (loading) {
        return (
            <>
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-3"><Package className="w-5 h-5" />Equipment Audit Log</CardTitle>
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-96 w-full bg-white/10" />
                </CardContent>
            </>
        );
    }

    return (
        <>
            <CardHeader>
                <CardTitle className="flex items-center gap-3 text-white">
                    <Package className="w-5 h-5" />
                    Equipment Audit Log
                </CardTitle>
                <div className="flex flex-col md:flex-row gap-4 mt-4">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                            placeholder="Search by item, session, or reason..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10 bg-white/5 border-white/20 text-white focus:bg-white/10"
                        />
                    </div>
                    <select
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value)}
                        className="px-3 py-2 bg-white/5 border border-white/20 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                        <option value="all">All Types</option>
                        <option value="Check-out">Check-out</option>
                        <option value="Check-in">Check-in</option>
                        <option value="Missing">Missing</option>
                        <option value="Adjustment">Adjustment</option>
                        <option value="Initial Stock">Initial Stock</option>
                        <option value="Damaged">Damaged</option>
                    </select>
                    <Button onClick={exportAuditLog} variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                {filteredTransactions.length === 0 ? (
                    <div className="text-center py-8">
                        <Package className="w-12 h-12 text-slate-500/50 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-white mb-2">No transactions found</h3>
                        <p className="text-slate-400">No equipment transactions match your search criteria.</p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="border-b-white/20">
                                    <TableHead className="text-white/80">Date/Time</TableHead>
                                    <TableHead className="text-white/80">Item</TableHead>
                                    <TableHead className="text-white/80">Type</TableHead>
                                    <TableHead className="text-right text-white/80">Quantity</TableHead>
                                    <TableHead className="text-white/80">Session</TableHead>
                                    <TableHead className="text-white/80">Reason/Notes</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredTransactions.slice(0, 10).map(tx => {
                                    const Icon = getTransactionIcon(tx.transaction_type);
                                    const isNegative = tx.quantity_change < 0;
                                    
                                    return (
                                        <TableRow key={tx.id} className="border-b-white/10 hover:bg-white/5">
                                            <TableCell className="text-sm text-slate-300">
                                                {format(new Date(tx.created_date), 'MMM d, yyyy HH:mm')}
                                            </TableCell>
                                            <TableCell className="font-medium text-white">
                                                {getItemName(tx.item_id)}
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline" className={`flex items-center gap-1 w-fit border-0 ${getBadgeVariant(tx.transaction_type)}`}>
                                                    <Icon className="w-3 h-3" />
                                                    {tx.transaction_type}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <span className={`font-semibold ${isNegative ? 'text-red-400' : 'text-green-400'}`}>
                                                    {isNegative ? '' : '+'}{tx.quantity_change}
                                                </span>
                                            </TableCell>
                                            <TableCell className="text-sm text-slate-400">
                                                {tx.training_session_id ? getSessionName(tx.training_session_id) : '-'}
                                            </TableCell>
                                            <TableCell className="text-sm text-slate-400 max-w-xs truncate">
                                                {tx.reason || '-'}
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </div>
                )}
            </CardContent>
        </>
    );
}