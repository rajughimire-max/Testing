import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function StatsCard({ title, value, icon: Icon, color, trend, loading, gradient }) {
  if (loading) {
    return (
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <Skeleton className="h-4 w-24 bg-white/20" />
              <Skeleton className="h-8 w-16 bg-white/20" />
            </div>
            <Skeleton className="h-12 w-12 rounded-xl bg-white/20" />
          </div>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-3 w-32 bg-white/20" />
        </CardContent>
      </Card>
    );
  }

  const displayValue = typeof value === 'string' ? value : value.toLocaleString();

  return (
    <Card className="group bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/25 relative overflow-hidden">
      {/* Gradient Background */}
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-10 group-hover:opacity-20 transition-opacity duration-500`}></div>
      
      <CardHeader className="pb-3 relative z-10">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-blue-200 mb-2">{title}</p>
            <CardTitle className="text-3xl font-black text-white group-hover:scale-110 transition-transform duration-300">
              {displayValue}
            </CardTitle>
          </div>
          <div className={`p-4 rounded-2xl bg-gradient-to-br ${gradient} shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:rotate-12`}>
            <Icon className="w-8 h-8 text-white" />
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="relative z-10">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm text-blue-200">{trend}</span>
        </div>
      </CardContent>

      {/* Animated Border */}
      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
    </Card>
  );
}