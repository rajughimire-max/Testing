import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { WebsiteContent } from '@/api/entities';
import { ChevronDown, Menu, X, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function MegaMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const [clubInfo, setClubInfo] = useState({ logoUrl: '' });
  const location = useLocation();

  useEffect(() => {
    const fetchClubInfo = async () => {
      try {
        const content = await WebsiteContent.list();
        if (content.length > 0) {
          setClubInfo({ logoUrl: content[0].club_logo_url });
        }
      } catch (error) {
        console.error("Failed to fetch club info:", error);
      }
    };
    fetchClubInfo();
  }, []);
  
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navItems = [
    { name: 'Home', href: createPageUrl('Home') },
    {
      name: 'The Club',
      children: [
        { name: 'About Us', href: createPageUrl('Home') + '#about', description: 'Our history, mission, and values.' },
        { name: 'Squad', href: createPageUrl('Squad'), description: 'Meet our talented roster of players.' },
        { name: 'Teams', href: createPageUrl('PublicTeams'), description: 'Explore all our club teams.' },
        { name: 'News', href: createPageUrl('News'), description: 'The latest updates from the club.' },
        { name: 'Loan Players', href: createPageUrl('LoanPlayers'), description: 'Players available for loan opportunities.' },
      ],
    },
    { name: 'Fixtures', href: createPageUrl('Fixtures') },
    { name: 'Sponsorship', href: createPageUrl('SponsorshipInquiry') },
    { name: 'Shop', href: createPageUrl('Shop') },
    {
      name: 'Get Involved',
      children: [
        { name: 'Become a Member', href: createPageUrl('MembershipSignup'), description: 'Join the Nepbourne FC family.' },
        { name: 'Social Games', href: createPageUrl('SocialGameJoin'), description: 'Sign up for our fun social matches.' },
      ],
    },
  ];

  return (
    <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link to={createPageUrl('Home')} className="flex items-center gap-2">
              {clubInfo.logoUrl ? (
                <img className="h-10 w-auto" src={clubInfo.logoUrl} alt="Club Logo" />
              ) : (
                <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
              )}
              <span className="font-bold text-xl text-slate-800 hidden sm:block">Nepbourne FC</span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex md:items-center md:space-x-8">
            {navItems.map((item) => (
              item.children ? (
                <div key={item.name} className="relative group">
                  <button className="inline-flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-red-600 transition-colors">
                    {item.name}
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                    <div className="py-2">
                      {item.children.map((child) => (
                        <Link
                          key={child.name}
                          to={child.href}
                          className="block px-4 py-3 text-sm text-slate-700 hover:bg-slate-100 hover:text-red-600"
                        >
                          <p className="font-semibold">{child.name}</p>
                          <p className="text-xs text-slate-500">{child.description}</p>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <Link
                  key={item.name}
                  to={item.href}
                  className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors"
                >
                  {item.name}
                </Link>
              )
            ))}
          </div>

          {/* Login Button */}
          <div className="hidden md:block">
            <Button asChild className="bg-red-600 hover:bg-red-700">
              <Link to={createPageUrl('PortalLogin')}>Portal Login</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-100">
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-lg z-50">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <div key={item.name}>
                {item.children ? (
                  <>
                    <h3 className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">{item.name}</h3>
                    {item.children.map((child) => (
                      <Link
                        key={child.name}
                        to={child.href}
                        className="block rounded-md px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-red-600"
                      >
                        {child.name}
                      </Link>
                    ))}
                  </>
                ) : (
                  <Link
                    to={item.href}
                    className="block rounded-md px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-red-600"
                  >
                    {item.name}
                  </Link>
                )}
              </div>
            ))}
             <div className="border-t border-slate-200 mt-4 pt-4">
                <Button asChild className="w-full bg-red-600 hover:bg-red-700">
                  <Link to={createPageUrl('PortalLogin')}>Portal Login</Link>
                </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}