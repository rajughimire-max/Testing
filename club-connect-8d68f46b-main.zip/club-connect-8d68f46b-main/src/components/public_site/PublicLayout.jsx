
import React, { useState, useEffect } from 'react';
import { WebsiteContent } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Menu, X, Phone, Mail, MapPin, Facebook, Instagram, Twitter, ChevronDown, Search, Trophy } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { User } from '@/api/entities';

export default function PublicLayout({ children }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [content, setContent] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);

  useEffect(() => {
    const loadContent = async () => {
      try {
        const contentData = await WebsiteContent.list();
        setContent(contentData[0] || {});
      } catch (error) {
        console.error("Error loading website content:", error);
      }
    };
    loadContent();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigation = [
    { 
      name: 'Teams', 
      href: createPageUrl('PublicTeams')
    },
    { 
      name: 'Squad', 
      href: createPageUrl('Squad')
    },
    { 
      name: 'Fixtures', 
      href: createPageUrl('Fixtures')
    },
    { 
      name: 'Loan Players', 
      href: createPageUrl('LoanPlayers')
    },
    { 
      name: 'Members', 
      href: createPageUrl('MembershipSignup')
    },
    { 
      name: 'Sponsors', 
      href: createPageUrl('SponsorshipInquiry')
    },
    { 
      name: 'Shop', 
      href: createPageUrl('Shop')
    },
    { 
      name: 'News', 
      href: createPageUrl('News')
    },
    { 
      name: 'Join Social Games', 
      href: createPageUrl('SocialGames')
    }
  ];

  const handleLogin = async () => {
    try {
      const dashboardUrl = `${window.location.origin}${createPageUrl('Dashboard')}`;
      await User.loginWithRedirect(dashboardUrl);
    } catch (error) {
      console.error("Login failed:", error);
      // Fallback to simple login if redirect fails
      await User.login();
    }
  };

  return (
    <div className="bg-black">
      <style>{`
        :root {
          --primary-red: #B8002B;
          --primary-yellow: #F4B942;
          --dark-bg: #0A0A0A;
          --darker-bg: #000000;
        }
        
        .gradient-text {
          background: linear-gradient(135deg, #B8002B 0%, #F4B942 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        .hover-lift:hover {
          transform: translateY(-2px);
        }
        
        .nav-item:hover .dropdown {
          opacity: 1;
          visibility: visible;
          transform: translateY(0);
        }
        
        .dropdown {
          opacity: 0;
          visibility: hidden;
          transform: translateY(-10px);
          transition: all 0.3s ease;
        }
      `}</style>

      {/* Top Bar */}
      <div className="bg-gradient-to-r from-red-700 to-red-600 text-white py-2 text-xs">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Trophy className="w-4 h-4" />
            <span>Official Website | Season 2025-2026 | Join Us</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-black/95 backdrop-blur-md shadow-2xl' : 'bg-black/80'}`}>
        <nav className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to={createPageUrl('Home')} className="flex items-center space-x-3 hover-lift transition-all duration-300">
              {content?.club_logo_url ? (
                <img src={content.club_logo_url} alt="Nepbourne FC" className="h-10 w-auto" />
              ) : (
                <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">N</span>
                </div>
              )}
              <div className="text-white font-bold text-xl tracking-wider">
                NEPBOURNE FC
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-6">
              {navigation.map((item, index) => (
                <div key={index} className="relative nav-item">
                  {item.items ? (
                    <>
                      <button className="text-white hover:text-red-500 font-medium text-xs tracking-wider flex items-center space-x-1 py-2 transition-colors">
                        <span>{item.name}</span>
                        <ChevronDown className="w-3 h-3" />
                      </button>
                      <div className="dropdown absolute top-full left-0 bg-black border border-red-900/30 rounded-lg shadow-2xl py-3 min-w-44 mt-2">
                        {item.items.map((subItem, subIndex) => (
                          <Link
                            key={subIndex}
                            to={subItem.href}
                            className="block px-4 py-2 text-gray-300 hover:text-white hover:bg-red-900/20 transition-colors text-xs"
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    </>
                  ) : (
                    <Link
                      to={item.href}
                      className="text-white hover:text-red-500 font-medium text-xs tracking-wider py-2 transition-colors"
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
              
              <div className="flex items-center space-x-3 ml-4 border-l border-gray-700 pl-4">
                <Button variant="ghost" size="sm" className="text-white hover:bg-red-900/20 p-2">
                  <Search className="w-3 h-3" />
                </Button>
                <Link to={createPageUrl('PortalLogin')}>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-gray-500 text-gray-300 hover:bg-gray-700 hover:text-white text-xs px-3 py-1"
                  >
                    VISIT PORTAL
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white text-xs px-3 py-1"
                  onClick={handleLogin}
                >
                  ADMIN LOGIN
                </Button>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden text-white hover:text-red-500 transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="lg:hidden absolute top-full left-0 right-0 bg-black border-t border-gray-800 shadow-2xl">
              <div className="px-4 py-6 space-y-4">
                {navigation.map((item, index) => (
                  <div key={index}>
                    {item.items ? (
                      <div className="space-y-2">
                        <div className="text-white font-semibold text-sm tracking-wider">
                          {item.name}
                        </div>
                        <div className="pl-4 space-y-2">
                          {item.items.map((subItem, subIndex) => (
                            <Link
                              key={subIndex}
                              to={subItem.href}
                              className="block text-gray-400 hover:text-white transition-colors text-sm"
                              onClick={() => setIsMenuOpen(false)}
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <Link
                        to={item.href}
                        className="block text-white hover:text-red-500 font-semibold text-sm tracking-wider"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {item.name}
                      </Link>
                    )}
                  </div>
                ))}
                <div className="border-t border-gray-800 pt-4 space-y-3">
                    <Link to={createPageUrl('PortalLogin')} className="block w-full">
                      <Button
                        variant="outline"
                        className="w-full border-gray-500 text-gray-300 hover:bg-gray-700 hover:text-white"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        VISIT PORTAL
                      </Button>
                    </Link>
                    <Button 
                      variant="outline" 
                      className="w-full border-red-600 text-red-600 hover:bg-red-600 hover:text-white"
                      onClick={() => {
                        setIsMenuOpen(false);
                        handleLogin();
                      }}
                    >
                      ADMIN LOGIN
                    </Button>
                </div>
              </div>
            </div>
          )}
        </nav>
      </header>

      {/* Main Content */}
      <main className="bg-white">
        {children}
      </main>

      {/* Footer */}
      <footer id="footer" className="bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Club Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                {content?.club_logo_url ? (
                  <img src={content.club_logo_url} alt="Nepbourne FC" className="h-8 w-auto" />
                ) : (
                  <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-700 rounded flex items-center justify-center">
                    <span className="text-white font-bold text-sm">N</span>
                  </div>
                )}
                <span className="font-bold text-lg">NEPBOURNE FC</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                {content?.welcome_text?.substring(0, 120)}...
              </p>
              <div className="flex space-x-4">
                {content?.facebook_url && (
                  <a href={content.facebook_url} className="text-gray-400 hover:text-white transition-colors">
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
                {content?.instagram_url && (
                  <a href={content.instagram_url} className="text-gray-400 hover:text-white transition-colors">
                    <Instagram className="w-5 h-5" />
                  </a>
                )}
                {content?.twitter_url && (
                  <a href={content.twitter_url} className="text-gray-400 hover:text-white transition-colors">
                    <Twitter className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="font-bold text-lg">QUICK LINKS</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to={createPageUrl('Squad')} className="text-gray-400 hover:text-white transition-colors">First Team</Link></li>
                <li><Link to={createPageUrl('Fixtures')} className="text-gray-400 hover:text-white transition-colors">Fixtures & Results</Link></li>
                <li><Link to={createPageUrl('Shop')} className="text-gray-400 hover:text-white transition-colors">Official Shop</Link></li>
                <li><Link to={createPageUrl('MembershipSignup')} className="text-gray-400 hover:text-white transition-colors">Memberships</Link></li>
              </ul>
            </div>

            {/* Support */}
            <div className="space-y-4">
              <h3 className="font-bold text-lg">SUPPORT</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to={createPageUrl('SponsorshipInquiry')} className="text-gray-400 hover:text-white transition-colors">Become a Partner</Link></li>
                <li><Link to={createPageUrl('SocialGames')} className="text-gray-400 hover:text-white transition-colors">Social Football</Link></li>
                <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h3 className="font-bold text-lg">CONTACT</h3>
              <div className="space-y-3 text-sm">
                {content?.contact_address && (
                  <div className="flex items-start space-x-3 text-gray-400">
                    <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span>{content.contact_address}</span>
                  </div>
                )}
                {content?.contact_phone && (
                  <div className="flex items-center space-x-3 text-gray-400">
                    <Phone className="w-4 h-4" />
                    <span>{content.contact_phone}</span>
                  </div>
                )}
                {content?.contact_email && (
                  <div className="flex items-center space-x-3 text-gray-400">
                    <Mail className="w-4 h-4" />
                    <span>{content.contact_email}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
            <div>
              © 2025 Nepbourne Football Club. All rights reserved.
            </div>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
