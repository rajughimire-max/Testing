import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, Users, Shield } from 'lucide-react';
import PlayerGrid from './PlayerGrid';
import PlayerModal from './PlayerModal';

export default function PublicTeamsSection({ allTeams }) {
  const [expandedTeamId, setExpandedTeamId] = useState(null);
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Main Teams are assumed to be the first 3 for this display
  const mainTeams = allTeams.slice(0, 3);

  const handleToggleTeam = (teamId) => {
    setExpandedTeamId(prevId => (prevId === teamId ? null : teamId));
  };

  const handlePlayerSelect = (player) => {
    setSelectedPlayer(player);
    setIsModalOpen(true);
    // For deep linking
    window.history.pushState(null, '', `#player-${player.id}`);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedPlayer(null);
    // Clear the hash from the URL
    window.history.pushState(null, '', window.location.pathname + window.location.search);
  };
  
  // Handle deep linking on initial load
  useEffect(() => {
    const hash = window.location.hash;
    if (hash && hash.startsWith('#player-')) {
      const playerId = hash.substring(8);
      // This is a simplified approach. A robust solution would need to fetch the player.
      // Assuming `allPlayers` were available on a parent component, this could work.
      // For now, this logic is illustrative. The main functionality is in handlePlayerSelect.
      console.log("Deep link to player ID:", playerId);
    }
  }, []);

  return (
    <section id="teams" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-slate-900 mb-6">Our Main Teams</h2>
          <div className="h-1 w-24 bg-red-600 mx-auto mb-6"></div>
          <p className="text-xl text-slate-600">Discover the talent in our leading squads.</p>
        </div>
        
        <div className="space-y-6 max-w-5xl mx-auto">
          {mainTeams.map(team => (
            <div key={team.id} className="border border-slate-200 rounded-2xl overflow-hidden transition-shadow duration-300 hover:shadow-xl">
              <button
                onClick={() => handleToggleTeam(team.id)}
                aria-expanded={expandedTeamId === team.id}
                className="w-full text-left p-6 bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 rounded-t-2xl"
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-slate-900">{team.name}</h3>
                      <p className="text-slate-500">{team.season || 'Current Season'}</p>
                    </div>
                  </div>
                  <ChevronDown className={`w-6 h-6 text-slate-500 transition-transform duration-300 ${expandedTeamId === team.id ? 'rotate-180' : ''}`} />
                </div>
              </button>
              
              <div
                className={`transition-all duration-500 ease-in-out overflow-hidden ${expandedTeamId === team.id ? 'max-h-[2000px]' : 'max-h-0'}`}
              >
                <div className="p-6 bg-slate-50 border-t border-slate-200">
                  {expandedTeamId === team.id && (
                    <PlayerGrid teamId={team.id} onPlayerSelect={handlePlayerSelect} />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedPlayer && (
        <PlayerModal
          player={selectedPlayer}
          isOpen={isModalOpen}
          onClose={handleCloseModal}
        />
      )}
    </section>
  );
}