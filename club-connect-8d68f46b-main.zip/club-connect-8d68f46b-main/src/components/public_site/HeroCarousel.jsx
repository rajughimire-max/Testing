import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function HeroCarousel({ slides = [] }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Default slides if none provided
  const defaultSlides = [
    {
      title: "NEPBOURNE FC",
      subtitle: "Excellence • Unity • Victory",
      content_type: "image",
      image_url: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=2940&auto=format&fit=crop",
      link_url: createPageUrl('MembershipSignup'),
      link_text: "Join Our Club"
    },
    {
      title: "UPCOMING FIXTURES", 
      subtitle: "Don't miss our next matches - support your team",
      content_type: "image",
      image_url: "https://images.unsplash.com/photo-1556056504-5c7696c4c28d?q=80&w=2940&auto=format&fit=crop",
      link_url: createPageUrl('Fixtures'),
      link_text: "View Fixtures"
    },
    {
      title: "CLUB STORE",
      subtitle: "Show your pride with official merchandise",
      content_type: "image",
      image_url: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=2940&auto=format&fit=crop", 
      link_url: createPageUrl('Shop'),
      link_text: "Shop Now"
    }
  ];

  const activeSlides = slides && slides.length > 0 ? slides : defaultSlides;

  useEffect(() => {
    if (isAutoPlaying && activeSlides.length > 1) {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % activeSlides.length);
      }, 5000);
      return () => clearInterval(timer);
    }
  }, [isAutoPlaying, activeSlides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % activeSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + activeSlides.length) % activeSlides.length);
  };

  const getVideoId = (url) => {
    if (!url) return null;
    
    // YouTube
    const youtubeMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
    if (youtubeMatch) return { type: 'youtube', id: youtubeMatch[1] };
    
    // Vimeo
    const vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
    if (vimeoMatch) return { type: 'vimeo', id: vimeoMatch[1] };
    
    // Direct video file
    if (url.match(/\.(mp4|webm|ogg)$/)) return { type: 'direct', id: url };
    
    return null;
  };

  if (!activeSlides || activeSlides.length === 0) {
    return null;
  }

  const currentSlideData = activeSlides[currentSlide];
  const videoInfo = currentSlideData.content_type === 'video' ? getVideoId(currentSlideData.video_url) : null;

  return (
    <div 
      className="relative h-screen flex items-center justify-center overflow-hidden"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Background Content */}
      {activeSlides.map((slide, index) => (
        <div
          key={slide.id || index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {slide.content_type === 'video' && videoInfo ? (
            <div className="relative w-full h-full">
              {videoInfo.type === 'youtube' && (
                <iframe
                  src={`https://www.youtube.com/embed/${videoInfo.id}?autoplay=1&mute=1&loop=1&playlist=${videoInfo.id}&controls=0&showinfo=0&rel=0`}
                  className="absolute inset-0 w-full h-full object-cover"
                  frameBorder="0"
                  allow="autoplay; encrypted-media"
                  allowFullScreen
                />
              )}
              {videoInfo.type === 'vimeo' && (
                <iframe
                  src={`https://player.vimeo.com/video/${videoInfo.id}?autoplay=1&muted=1&loop=1&background=1&controls=0`}
                  className="absolute inset-0 w-full h-full object-cover"
                  frameBorder="0"
                  allow="autoplay; fullscreen"
                />
              )}
              {videoInfo.type === 'direct' && (
                <video
                  className="absolute inset-0 w-full h-full object-cover"
                  autoPlay
                  muted
                  loop
                  playsInline
                >
                  <source src={videoInfo.id} type="video/mp4" />
                </video>
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-red-900/60 via-transparent to-red-900/60"></div>
            </div>
          ) : (
            <div
              className="absolute inset-0"
              style={{
                backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url(${slide.image_url})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            />
          )}
        </div>
      ))}

      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-red-900/60 via-transparent to-red-900/60"></div>

      {/* Content */}
      <div className="relative z-10 text-center text-white max-w-7xl mx-auto px-6">
        <div className="space-y-12">
          <div className="space-y-8">
            <h1 className="text-5xl md:text-7xl lg:text-8xl xl:text-9xl font-black tracking-tight leading-none">
              {currentSlideData?.title || "NEPBOURNE FC"}
            </h1>
            <div className="h-2 w-40 bg-red-600 mx-auto"></div>
            <p className="text-xl md:text-2xl lg:text-3xl font-light max-w-4xl mx-auto leading-relaxed tracking-wide">
              {currentSlideData?.subtitle || "Excellence • Unity • Victory"}
            </p>
          </div>

          {/* Call to Action Button - Always visible */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link to={currentSlideData?.link_url || createPageUrl('MembershipSignup')}>
              <Button 
                size="lg" 
                className="bg-red-600 hover:bg-red-700 text-white px-10 py-6 text-xl font-bold shadow-2xl transform hover:scale-105 transition-all duration-300 z-30 relative"
              >
                <Play className="w-6 h-6 mr-3" />
                {currentSlideData?.link_text || "Join Our Club"}
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Navigation Arrows */}
      {activeSlides.length > 1 && (
        <>
          <button
            onClick={prevSlide}
            className="absolute left-8 top-1/2 transform -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all duration-200"
            aria-label="Previous slide"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-8 top-1/2 transform -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all duration-200"
            aria-label="Next slide"
          >
            <ChevronRight className="w-8 h-8" />
          </button>
        </>
      )}

      {/* Slide Indicators */}
      {activeSlides.length > 1 && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-30 flex space-x-3">
          {activeSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-4 h-4 rounded-full transition-all duration-200 ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}