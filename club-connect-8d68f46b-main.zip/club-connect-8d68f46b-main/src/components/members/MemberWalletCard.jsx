
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Smartphone,
  CreditCard,
  AlertTriangle,
  CheckCircle,
  Download,
  Clock,
  User,
  ShieldCheck,
  Share2,
  Copy,
  Info,
  Nfc // Added NFC icon
} from "lucide-react";
import { generateWalletCard } from "@/api/functions"; // This is likely a client-side wrapper for API calls
import { toast } from "sonner";
import { format, parseISO } from 'date-fns';
import { createPageUrl } from '@/utils';

export default function MemberWalletCard({ member, membershipType, isPublicView = false }) {
  const [loading, setLoading] = useState(false);
  const [walletData, setWalletData] = useState(null); // This state variable is not used after modifications, could be removed if not needed elsewhere.
  const [shareableLink, setShareableLink] = useState('');

  useEffect(() => {
    const setupWalletToken = async () => {
      if (member.wallet_card_token) {
        setShareableLink(`${window.location.origin}${createPageUrl('DigitalCard')}?token=${member.wallet_card_token}`);
      }
    };
    setupWalletToken();
  }, [member, isPublicView]);

  const isEligible = () => {
    if (member.membership_status !== 'active') return false;
    if (!member.membership_type_id || !member.membership_number) return false;
    if (membershipType?.price_aud > 0 && !member.payment_verified) return false;
    return true;
  };

  const getIneligibilityReason = () => {
    if (member.membership_status !== 'active') {
      return { title: "Awaiting Approval", message: "Your card will be available after approval.", icon: Clock };
    }
    if (!member.membership_type_id) {
      return { title: "Missing Membership Tier", message: "Please contact admin to assign your membership tier.", icon: AlertTriangle };
    }
    if (!member.membership_number) {
      return { title: "Missing Membership Number", message: "Please contact admin to assign your membership number.", icon: AlertTriangle };
    }
    if (membershipType?.price_aud > 0 && !member.payment_verified) {
      return { title: "Payment Required", message: "Please complete payment verification to access your card.", icon: AlertTriangle };
    }
    return null;
  };

  const addToAppleWallet = async () => {
    if (shareableLink) {
        window.open(shareableLink, '_blank');
    } else {
        toast.error("Card link not available yet. Please refresh.");
    }
  };

  const addToGoogleWallet = async () => {
    setLoading(true);
    try {
      // Use the imported generateWalletCard function which handles the API call
      const response = await generateWalletCard({ memberId: member.id, walletType: 'google' });
      if (response.data?.success && response.data?.saveUrl) {
        window.open(response.data.saveUrl, '_blank');
        toast.success("Opening Google Wallet...");
      } else {
        toast.error(response.data?.error || "Failed to generate Google Wallet pass.");
      }
    } catch (error) {
      console.error("Error generating Google Wallet pass:", error);
      toast.error("Failed to generate Google Wallet pass. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getValidityText = (dateString, formatString = "MMM d, yyyy") => {
    if (!dateString) return "N/A";
    try {
      return format(parseISO(dateString), formatString);
    } catch {
      return "Invalid Date";
    }
  };

  const copyShareableLink = () => {
    if (shareableLink) {
      navigator.clipboard.writeText(shareableLink);
      toast.success("Shareable link copied to clipboard!");
    } else {
      toast.error("No shareable link available.");
    }
  };

  if (!isEligible()) {
    const reason = getIneligibilityReason();
    const Icon = reason?.icon || AlertTriangle;
    return (
      <Card className="bg-gradient-to-br from-slate-50 to-slate-100 border-slate-300">
        <CardHeader><CardTitle className="flex items-center gap-2"><CreditCard className="w-5 h-5" />Digital Membership Card</CardTitle></CardHeader>
        <CardContent>
          <Alert className="border-amber-200 bg-amber-50">
            <Icon className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              <strong>{reason?.title}</strong><br />{reason?.message}
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  // Use wallet_card_token for QR code if available, otherwise fallback to membership_number
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(member.wallet_card_token || member.membership_number)}`;
  const nepbourneLogo = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68b36654bead34b28d68f46b/3c1f5c291_Main.jpg";

  // Check if this is a lifetime membership
  const isLifetime = membershipType?.billing_model === 'lifetime' || 
                     member.membership_type_name?.toLowerCase().includes('lifetime') ||
                     member.membership_type_name?.toLowerCase().includes('life time');

  return (
    <Card className="border-none bg-transparent shadow-none">
      <CardContent className="space-y-4 p-0">
        <div className="bg-slate-800 text-white rounded-xl shadow-lg font-sans w-full max-w-sm mx-auto overflow-hidden">
          {/* Top Banner */}
          <div className="bg-red-900 p-3 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-white flex items-center justify-center">
                <img src={nepbourneLogo} alt="Nepbourne FC" className="w-6 h-6 object-contain" />
              </div>
              <div>
                <h3 className="font-bold text-sm leading-tight">Nepbourne FC</h3>
                <p className="text-slate-300 text-xs uppercase tracking-wider">Est. 2025</p>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="p-4">
            <div className="flex justify-between items-start mb-4">
              {/* Left Side: Member Details */}
              <div className="space-y-3">
                <div>
                  <p className="text-xs uppercase text-slate-300">Member</p>
                  <p className="font-bold text-xl">{member.first_name} {member.last_name}</p>
                  <p className="font-medium text-amber-300">{membershipType?.name || 'N/A'}</p>
                </div>
                <div className="grid grid-cols-2 gap-4 text-xs pt-2">
                  <div>
                    <p className="uppercase text-slate-300">Since</p>
                    <p className="font-medium">{getValidityText(member.created_date || member.membership_valid_from, "MMM yyyy")}</p>
                  </div>
                  <div>
                    <p className="uppercase text-slate-300">Number</p>
                    <p className="font-medium">{member.membership_number}</p>
                  </div>
                </div>
                {/* Only show expiry for non-lifetime memberships */}
                {!isLifetime && member.membership_valid_to && (
                  <div className="pt-2">
                    <p className="text-xs uppercase text-slate-300">Expiry</p>
                    <p className="font-medium text-sm">{getValidityText(member.membership_valid_to, "MMM d, yyyy")}</p>
                  </div>
                )}
              </div>

              {/* Right Side: Photo */}
              <div className="flex-shrink-0">
                {member.photo_url ? (
                  <img src={member.photo_url} alt="Member" className="w-24 h-24 rounded-md object-cover border-2 border-slate-500" />
                ) : (
                  <div className="w-24 h-24 rounded-md bg-slate-700 flex items-center justify-center border-2 border-slate-500">
                    <User className="w-10 h-10 text-slate-400" />
                  </div>
                )}
              </div>
            </div>

            {/* QR Code */}
            <div className="flex justify-center items-center mt-4">
              <div className="bg-white p-2 rounded-lg">
                <img src={qrCodeUrl} alt="Membership QR Code" className="w-20 h-20" />
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Wallet Buttons with NFC indicators */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={addToAppleWallet}
            disabled={loading}
            className="bg-black hover:bg-gray-800 text-white flex items-center gap-2 h-12 text-sm" // Increased height to h-12
          >
            <div className="flex flex-col items-center">
              <Smartphone className="w-4 h-4" />
              <Nfc className="w-3 h-3 opacity-70" /> {/* NFC icon added */}
            </div>
            <div className="text-left">
              <div className="text-xs opacity-80">Add to</div>
              <div className="font-semibold text-xs">Apple Wallet</div>
            </div>
          </Button>
          <Button
            onClick={addToGoogleWallet}
            disabled={loading}
            variant="outline"
            className="border-blue-500 text-blue-600 hover:bg-blue-50 flex items-center gap-2 h-12 text-sm" // Increased height to h-12
          >
            <div className="flex flex-col items-center">
              <Smartphone className="w-4 h-4" />
              <Nfc className="w-3 h-3 opacity-70" /> {/* NFC icon added */}
            </div>
            <div className="text-left">
              <div className="text-xs opacity-80">Add to</div>
              <div className="font-semibold text-xs">Google Wallet</div>
            </div>
          </Button>
        </div>

        {!isPublicView && shareableLink && (
           <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 space-y-1 mt-4">
              <h4 className="font-medium text-blue-900 text-xs flex items-center gap-1">
                <Share2 className="w-3 h-3" />
                Share Link with Member
              </h4>
              <div className="flex items-center gap-1">
                <input type="text" readOnly value={shareableLink} className="flex-grow p-1.5 text-xs bg-white border border-blue-200 rounded-md" />
                <Button onClick={copyShareableLink} size="sm" variant="outline" className="bg-white text-xs px-2 h-auto">
                  <Copy className="w-3 h-3 mr-1" />
                  Copy
                </Button>
              </div>
          </div>
        )}

        {/* Simplified NFC Info */}
        <Alert className="mt-4 border-green-200 bg-green-50 text-green-800">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertTitle className="font-semibold">Digital Membership Card</AlertTitle>
          <AlertDescription className="text-xs">
            <p>✓ Tap-enabled for contactless access at club facilities</p>
            <p>✓ Works offline and updates automatically</p>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
