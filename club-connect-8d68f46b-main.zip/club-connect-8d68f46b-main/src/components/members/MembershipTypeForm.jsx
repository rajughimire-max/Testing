import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Save, X, Plus, Trash2, GripVertical } from "lucide-react";
import { upsertMembershipType } from "@/api/functions";
import { Skeleton } from "@/components/ui/skeleton";

export default function MembershipTypeForm({ membershipType, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    name: membershipType?.name || "",
    description: membershipType?.description || "",
    price_aud: membershipType?.price_aud || 0,
    billing_model: membershipType?.billing_model || "annually",
    features: membershipType?.features || [],
    is_active: membershipType?.is_active !== false,
    is_visible: membershipType?.is_visible !== false,
    has_proration: membershipType?.has_proration || false,
    has_trial: membershipType?.has_trial || false
  });

  const [loading, setLoading] = useState(false);
  const [newFeature, setNewFeature] = useState("");

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addFeature = () => {
    if (newFeature.trim()) {
      setFormData(prev => ({
        ...prev,
        features: [...prev.features, newFeature.trim()]
      }));
      setNewFeature("");
    }
  };

  const removeFeature = (index) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const moveFeature = (fromIndex, toIndex) => {
    if (toIndex < 0 || toIndex >= formData.features.length) return;
    
    const newFeatures = [...formData.features];
    const [movedItem] = newFeatures.splice(fromIndex, 1);
    newFeatures.splice(toIndex, 0, movedItem);
    
    setFormData(prev => ({
      ...prev,
      features: newFeatures
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const membershipTypeId = membershipType?.id;
      const response = await upsertMembershipType({
        membershipTypeId,
        ...formData
      });
      
      onSubmit(); // Signal success to parent
    } catch (error) {
      console.error("Error saving membership type:", error);
      alert("Failed to save membership type. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-96 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
      <CardHeader>
        <CardTitle>
          {membershipType ? "Edit Membership Type" : "Add New Membership Type"}
        </CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Membership Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleChange("name", e.target.value)}
                  placeholder="e.g., General Member"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price_aud">Price (AUD) *</Label>
                <Input
                  id="price_aud"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.price_aud}
                  onChange={(e) => handleChange("price_aud", parseFloat(e.target.value) || 0)}
                  placeholder="0.00"
                  required
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleChange("description", e.target.value)}
                  placeholder="Describe what this membership includes..."
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* Billing & Features */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Billing & Features</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="billing_model">Billing Model *</Label>
                <Select value={formData.billing_model} onValueChange={(value) => handleChange("billing_model", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="annually">Annually</SelectItem>
                    <SelectItem value="one-off">One-off</SelectItem>
                    <SelectItem value="lifetime">Lifetime</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Membership Benefits */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Membership Benefits</h3>
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={newFeature}
                  onChange={(e) => setNewFeature(e.target.value)}
                  placeholder="Add a membership benefit..."
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addFeature())}
                />
                <Button type="button" onClick={addFeature} variant="outline">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              
              {formData.features.length > 0 && (
                <div className="space-y-2">
                  {formData.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg">
                      <GripVertical className="w-4 h-4 text-slate-400 cursor-grab" />
                      <span className="flex-1">{feature}</span>
                      <div className="flex gap-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => moveFeature(index, index - 1)}
                          disabled={index === 0}
                        >
                          ↑
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => moveFeature(index, index + 1)}
                          disabled={index === formData.features.length - 1}
                        >
                          ↓
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFeature(index)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Settings */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="is_active">Active</Label>
                  <p className="text-sm text-slate-500">Allow new signups for this membership type</p>
                </div>
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => handleChange("is_active", checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="is_visible">Visible on Public Site</Label>
                  <p className="text-sm text-slate-500">Show this membership on the signup page</p>
                </div>
                <Switch
                  id="is_visible"
                  checked={formData.is_visible}
                  onCheckedChange={(checked) => handleChange("is_visible", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="has_proration">Enable Proration</Label>
                  <p className="text-sm text-slate-500">Prorate billing when users upgrade/downgrade</p>
                </div>
                <Switch
                  id="has_proration"
                  checked={formData.has_proration}
                  onCheckedChange={(checked) => handleChange("has_proration", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="has_trial">Enable Trial Period</Label>
                  <p className="text-sm text-slate-500">Offer a trial period for this membership</p>
                </div>
                <Switch
                  id="has_trial"
                  checked={formData.has_trial}
                  onCheckedChange={(checked) => handleChange("has_trial", checked)}
                />
              </div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-red-600 hover:bg-red-700">
            <Save className="w-4 h-4 mr-2" />
            {membershipType ? "Update Membership Type" : "Create Membership Type"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}