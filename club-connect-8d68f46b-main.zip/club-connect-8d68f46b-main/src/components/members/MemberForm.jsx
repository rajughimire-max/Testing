
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, AlertTriangle, Upload, Plus, CreditCard, User } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { UploadFile } from "@/api/integrations";

import MembershipTypeForm from "./MembershipTypeForm";

export default function MemberForm({ member, membershipTypes, user, onSubmit, onCancel, onCreateMembershipType }) {
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    date_of_birth: "",
    gender: "",
    street_address: "",
    suburb: "",
    state: "",
    postcode: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    membership_type_id: "",
    membership_status: "pending",
    notes: "",
    payment_verified: false,
    is_verified: false, // Added is_verified to default state
    is_core_member: false, // Added is_core_member to default state
    photo_url: "",
    membership_number: "", // Added membership_number
    membership_valid_from: "", // Added membership_valid_from
    membership_valid_to: "", // Added membership_valid_to
  });
  
  const [manualCreationReason, setManualCreationReason] = useState("");
  const [evidenceFile, setEvidenceFile] = useState(null);
  const [errors, setErrors] = useState({});
  const [showMembershipTypeForm, setShowMembershipTypeForm] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (member) {
      setFormData({
        first_name: member.first_name || "",
        last_name: member.last_name || "",
        email: member.email || "",
        phone: member.phone || "",
        date_of_birth: member.date_of_birth || "",
        gender: member.gender || "",
        street_address: member.street_address || "",
        suburb: member.suburb || "",
        state: member.state || "",
        postcode: member.postcode || "",
        emergency_contact_name: member.emergency_contact_name || "",
        emergency_contact_phone: member.emergency_contact_phone || "",
        membership_type_id: member.membership_type_id || "",
        membership_status: member.membership_status || "pending",
        notes: member.notes || "",
        payment_verified: member.payment_verified || false,
        is_verified: member.is_verified || false, // Populate is_verified
        is_core_member: member.is_core_member || false, // Populate is_core_member
        photo_url: member.photo_url || "",
        membership_number: member.membership_number || "", // Populate membership_number
        membership_valid_from: member.membership_valid_from || "", // Populate membership_valid_from
        membership_valid_to: member.membership_valid_to || "" // Populate membership_valid_to
      });
    }
  }, [member]);

  const isAdmin = user?.role === 'admin';

  const validate = () => {
    const newErrors = {};
    const auPhoneRegex = /^(\+61|0)[45][0-9]{8}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!formData.first_name.trim()) newErrors.first_name = "First name is required";
    if (!formData.last_name.trim()) newErrors.last_name = "Last name is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }
    
    if (formData.phone && !auPhoneRegex.test(formData.phone.replace(/\s/g, ''))) {
      newErrors.phone = "Please enter a valid Australian mobile or landline number";
    }
    
    if(isAdmin && !member && manualCreationReason.length < 15) {
      newErrors.manualCreationReason = "A reason of at least 15 characters is required for manual creation.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('Please select an image smaller than 5MB');
      return;
    }

    setUploading(true);
    try {
      const response = await UploadFile({ file });
      handleChange('photo_url', response.file_url);
    } catch (error) {
      console.error("Error uploading photo:", error);
      alert('Failed to upload photo. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const removePhoto = () => {
    handleChange('photo_url', '');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    
    let formattedPhone = formData.phone;
    if (formattedPhone && formattedPhone.startsWith('0')) {
      formattedPhone = '+61' + formattedPhone.slice(1);
    }
    
    const dataToSubmit = {
      ...formData,
      phone: formattedPhone,
    };
    
    try {
      await onSubmit(dataToSubmit, manualCreationReason, evidenceFile);
      
      // Reload the Executive Team page if it's open
      if (window.reloadExecutiveTeamData) {
        window.reloadExecutiveTeamData();
      }
    } catch (error) {
      console.error('Error submitting member form:', error);
    }
  };

  const handleCreateMembershipType = async (membershipTypeData) => {
    try {
      const newType = await onCreateMembershipType(membershipTypeData);
      handleChange("membership_type_id", newType.id);
      setShowMembershipTypeForm(false);
    } catch (error) {
      console.error("Error creating membership type:", error);
    }
  };

  if (showMembershipTypeForm) {
    return (
      <MembershipTypeForm
        onSubmit={handleCreateMembershipType}
        onCancel={() => setShowMembershipTypeForm(false)}
      />
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
      <CardHeader>
        <CardTitle>
          {member ? "Edit Member" : "Add New Member"}
        </CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6">
          <div className="space-y-6">
            {/* Personal Information */}
            <div>
              <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="first_name">First Name *</Label>
                  <Input 
                    id="first_name" 
                    value={formData.first_name} 
                    onChange={(e) => handleChange("first_name", e.target.value)} 
                    className={errors.first_name ? "border-red-500" : ""} 
                  />
                  {errors.first_name && <p className="text-xs text-red-500">{errors.first_name}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last_name">Last Name *</Label>
                  <Input 
                    id="last_name" 
                    value={formData.last_name} 
                    onChange={(e) => handleChange("last_name", e.target.value)} 
                    className={errors.last_name ? "border-red-500" : ""} 
                  />
                  {errors.last_name && <p className="text-xs text-red-500">{errors.last_name}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={formData.email} 
                    onChange={(e) => handleChange("email", e.target.value)} 
                    className={errors.email ? "border-red-500" : ""} 
                  />
                  {errors.email && <p className="text-xs text-red-500">{errors.email}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone (AU)</Label>
                  <Input 
                    id="phone" 
                    type="tel" 
                    value={formData.phone} 
                    onChange={(e) => handleChange("phone", e.target.value)} 
                    placeholder="0412 345 678" 
                    className={errors.phone ? "border-red-500" : ""} 
                  />
                  {errors.phone && <p className="text-xs text-red-500">{errors.phone}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date_of_birth">Date of Birth</Label>
                  <Input 
                    id="date_of_birth" 
                    type="date" 
                    value={formData.date_of_birth} 
                    onChange={(e) => handleChange("date_of_birth", e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={formData.gender} onValueChange={(value) => handleChange("gender", value)}>
                    <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Photo Upload Section */}
              <div className="mt-6 pt-6 border-t">
                <Label htmlFor="photo_upload">Member Photo</Label>
                <p className="text-sm text-slate-500 mb-4">Upload a photo for the member's digital card and profile (Max 5MB)</p>
                
                <div className="flex items-start gap-6">
                  {/* Photo Preview */}
                  <div className="flex-shrink-0">
                    {formData.photo_url ? (
                      <div className="relative">
                        <img 
                          src={formData.photo_url} 
                          alt="Member photo" 
                          className="w-24 h-24 rounded-lg object-cover border-2 border-slate-300"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={removePhoto}
                          className="absolute -top-2 -right-2 w-6 h-6 p-0 rounded-full"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ) : (
                      <div className="w-24 h-24 rounded-lg bg-slate-100 flex items-center justify-center border-2 border-dashed border-slate-300">
                        <User className="w-8 h-8 text-slate-400" />
                      </div>
                    )}
                  </div>

                  {/* Upload Controls */}
                  <div className="flex-1">
                    <Input
                      id="photo_upload"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      disabled={uploading}
                      className="mb-2"
                    />
                    {uploading && (
                      <p className="text-sm text-blue-600">
                        <Upload className="w-4 h-4 inline mr-1" />
                        Uploading photo...
                      </p>
                    )}
                    <p className="text-xs text-slate-500">
                      Supported formats: JPG, PNG, GIF. This photo will appear on the member's digital membership card.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Address Information */}
            <div>
              <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Address Details</h3>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                    <Label htmlFor="street_address">Street Address</Label>
                    <Input 
                      id="street_address" 
                      value={formData.street_address} 
                      onChange={(e) => handleChange("street_address", e.target.value)} 
                      placeholder="e.g., 123 Sports Lane" 
                    />
                    <p className="text-xs text-slate-500">Address autocomplete coming soon.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="suburb">Suburb / Locality</Label>
                        <Input 
                          id="suburb" 
                          value={formData.suburb} 
                          onChange={(e) => handleChange("suburb", e.target.value)} 
                          placeholder="e.g., Richmond" 
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="state">State</Label>
                        <Select value={formData.state} onValueChange={(value) => handleChange("state", value)}>
                            <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="ACT">ACT</SelectItem>
                                <SelectItem value="NSW">NSW</SelectItem>
                                <SelectItem value="NT">NT</SelectItem>
                                <SelectItem value="QLD">QLD</SelectItem>
                                <SelectItem value="SA">SA</SelectItem>
                                <SelectItem value="TAS">TAS</SelectItem>
                                <SelectItem value="VIC">VIC</SelectItem>
                                <SelectItem value="WA">WA</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="postcode">Postcode</Label>
                        <Input 
                          id="postcode" 
                          value={formData.postcode} 
                          onChange={(e) => handleChange("postcode", e.target.value)} 
                          placeholder="e.g., 3121" 
                        />
                    </div>
                </div>
              </div>
            </div>

            {/* Membership Details */}
            <div>
              <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Membership Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="membership_type_id">Membership Type</Label>
                  <div className="flex gap-2">
                    <Select 
                      value={formData.membership_type_id} 
                      onValueChange={(value) => handleChange("membership_type_id", value)}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {membershipTypes.length > 0 ? (
                            membershipTypes.map(type => (
                                <SelectItem key={type.id} value={type.id}>
                                  {type.name} - ${type.price_aud}
                                </SelectItem>
                            ))
                        ) : (
                            <SelectItem value={null} disabled>No membership types defined</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    {isAdmin && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowMembershipTypeForm(true)}
                        className="px-3"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  {isAdmin && membershipTypes.length === 0 && (
                    <p className="text-xs text-amber-600">No membership types defined. Click + to create one.</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="membership_status">Status</Label>
                  <Select 
                    value={formData.membership_status} 
                    onValueChange={(value) => handleChange("membership_status", value)} 
                    disabled={!isAdmin}
                  >
                    <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                    </SelectContent>
                  </Select>
                  {!isAdmin && <p className="text-xs text-slate-500">Status is managed by admins.</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="membership_number">Membership Number</Label>
                  <Input 
                    id="membership_number" 
                    value={formData.membership_number} 
                    onChange={(e) => handleChange("membership_number", e.target.value)} 
                    placeholder="e.g., #00123"
                    disabled={!isAdmin}
                  />
                  {!isAdmin && <p className="text-xs text-slate-500">Managed by admins.</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="membership_valid_from">Valid From</Label>
                  <Input 
                    id="membership_valid_from" 
                    type="date" 
                    value={formData.membership_valid_from} 
                    onChange={(e) => handleChange("membership_valid_from", e.target.value)} 
                    disabled={!isAdmin}
                  />
                  {!isAdmin && <p className="text-xs text-slate-500">Managed by admins.</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="membership_valid_to">Valid To</Label>
                  <Input 
                    id="membership_valid_to" 
                    type="date" 
                    value={formData.membership_valid_to} 
                    onChange={(e) => handleChange("membership_valid_to", e.target.value)} 
                    disabled={!isAdmin}
                  />
                  {!isAdmin && <p className="text-xs text-slate-500">Managed by admins.</p>}
                </div>
              </div>
            </div>

            {/* Emergency Contact */}
            <div>
              <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Emergency Contact</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_name">Emergency Contact Name</Label>
                  <Input 
                    id="emergency_contact_name" 
                    value={formData.emergency_contact_name} 
                    onChange={(e) => handleChange("emergency_contact_name", e.target.value)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_phone">Emergency Contact Phone</Label>
                  <Input 
                    id="emergency_contact_phone" 
                    value={formData.emergency_contact_phone} 
                    onChange={(e) => handleChange("emergency_contact_phone", e.target.value)} 
                  />
                </div>
              </div>
            </div>

            {/* Settings & Status */}
            {isAdmin && (
              <div>
                <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Settings & Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center mt-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="payment_verified"
                      checked={formData.payment_verified}
                      onCheckedChange={(checked) => handleChange('payment_verified', checked)}
                    />
                    <Label htmlFor="payment_verified">Payment Verified</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="is_verified"
                      checked={formData.is_verified}
                      onCheckedChange={(checked) => handleChange('is_verified', checked)}
                    />
                    <Label htmlFor="is_verified">Email Verified</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="is_core_member"
                      checked={formData.is_core_member}
                      onCheckedChange={(checked) => handleChange('is_core_member', checked)}
                    />
                    <Label htmlFor="is_core_member">Core Member (Decision Maker)</Label>
                  </div>
                </div>
              </div>
            )}


            {/* Notes */}
            <div>
              <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Additional Information</h3>
              <div className="space-y-2 mt-4">
                <Label htmlFor="notes">Notes</Label>
                <Textarea 
                  id="notes" 
                  value={formData.notes} 
                  onChange={(e) => handleChange("notes", e.target.value)} 
                  placeholder="Any additional notes about the member..."
                  rows={3}
                />
              </div>
            </div>

            {/* Admin Manual Creation */}
            {isAdmin && !member && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                    Admin: Manual Creation
                  </h3>
                  <div className="space-y-4">
                      <div className="space-y-2">
                          <Label htmlFor="manualCreationReason">Reason for Manual Creation *</Label>
                          <Textarea 
                            id="manualCreationReason" 
                            value={manualCreationReason} 
                            onChange={(e) => setManualCreationReason(e.target.value)} 
                            placeholder="e.g., Member paid in cash at the club rooms." 
                            rows={3} 
                            className={errors.manualCreationReason ? "border-red-500" : ""} 
                          />
                          {errors.manualCreationReason && <p className="text-xs text-red-500">{errors.manualCreationReason}</p>}
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="evidenceFile">Evidence (Optional PDF/JPG)</Label>
                          <Input 
                            id="evidenceFile" 
                            type="file" 
                            onChange={(e) => setEvidenceFile(e.target.files[0])} 
                            accept=".pdf,.jpg,.jpeg,.png" 
                          />
                      </div>
                  </div>
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={uploading}>
            <Save className="w-4 h-4 mr-2" />
            {member ? "Update Member" : "Add Member"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
