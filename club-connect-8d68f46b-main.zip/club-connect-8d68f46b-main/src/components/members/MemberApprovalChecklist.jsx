import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Clock, UserCheck } from 'lucide-react';
import { approveMember } from '@/api/functions';
import { toast } from 'sonner';

export default function MemberApprovalChecklist({ member, membershipType, onApproved }) {
  const [loading, setLoading] = React.useState(false);

  // Check approval requirements
  const checks = [
    {
      id: 'membership_type',
      label: 'Membership tier assigned',
      passed: !!member.membership_type_id,
      required: true
    },
    {
      id: 'membership_number',
      label: 'Membership number assigned', 
      passed: !!member.membership_number,
      required: true
    },
    {
      id: 'payment_verified',
      label: 'Payment verified',
      passed: membershipType?.price_aud === 0 || member.payment_verified,
      required: membershipType?.price_aud > 0,
      note: membershipType?.price_aud === 0 ? 'No payment required' : 'Required for paid membership'
    },
    {
      id: 'profile_complete',
      label: 'Basic profile complete',
      passed: !!(member.first_name && member.last_name && member.email),
      required: true
    }
  ];

  const allRequiredPassed = checks.filter(check => check.required).every(check => check.passed);
  const canApprove = member.membership_status === 'pending' && allRequiredPassed;

  const handleApprove = async () => {
    if (!canApprove) return;

    setLoading(true);
    try {
      const response = await approveMember({
        memberId: member.id,
        reason: 'Approved via admin checklist'
      });

      if (response.data?.success) {
        toast.success('Member approved successfully! Wallet card is now available.');
        onApproved?.(response.data.member);
      }
    } catch (error) {
      console.error('Error approving member:', error);
      toast.error('Failed to approve member. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (member.membership_status === 'active') {
    return (
      <Card className="bg-green-50 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 text-green-800">
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">Member is approved and active</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserCheck className="w-5 h-5" />
          Approval Checklist
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {checks.map((check) => (
            <div key={check.id} className="flex items-center gap-3">
              {check.passed ? (
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
              ) : check.required ? (
                <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              ) : (
                <Clock className="w-5 h-5 text-amber-600 flex-shrink-0" />
              )}
              
              <div className="flex-1">
                <span className={check.passed ? 'text-slate-900' : 'text-slate-600'}>
                  {check.label}
                </span>
                {check.note && (
                  <p className="text-xs text-slate-500 mt-1">{check.note}</p>
                )}
              </div>
              
              {check.required && !check.passed && (
                <span className="text-xs text-red-600 font-medium">Required</span>
              )}
            </div>
          ))}
        </div>

        {member.membership_status === 'pending' && (
          <div className="pt-4 border-t">
            <Button
              onClick={handleApprove}
              disabled={!canApprove || loading}
              className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-300"
            >
              {loading ? 'Approving...' : 'Approve Member & Issue Digital Card'}
            </Button>
            
            {!allRequiredPassed && (
              <p className="text-sm text-red-600 mt-2 text-center">
                Complete all required items before approval
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}