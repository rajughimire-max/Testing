
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Edit, Repeat, Infinity, Trash2, Award, Hash, CreditCard, Send, FileText, Eye, Download } from "lucide-react";
import { format, isFuture } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger, // Added TooltipTrigger here as per the outline
} from "@/components/ui/tooltip";
import { toast } from "sonner";

const statusColors = {
  active: "bg-green-100 text-green-800 border-green-200",
  inactive: "bg-gray-100 text-gray-800 border-gray-200",
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  expired: "bg-red-100 text-red-800 border-red-200"
};

const getTierStyle = (tierName) => {
  const name = tierName?.toLowerCase() || '';
  if (name.includes('lifetime') || name.includes('life time')) {
    return {
      card: 'border-l-4 border-yellow-400 bg-yellow-50/50',
      badge: 'bg-yellow-100 text-yellow-800 border border-yellow-200/80',
    };
  }
  if (name.includes('foundation')) {
    return {
      card: 'border-l-4 border-blue-600 bg-blue-50/50',
      badge: 'bg-blue-100 text-blue-800 border border-blue-200/80',
    };
  }
  if (name.includes('gold')) {
    return {
      card: 'border-l-4 border-amber-500 bg-amber-50/50',
      badge: 'bg-amber-100 text-amber-800 border border-amber-200/80',
    };
  }
  return {
    card: 'border-l-4 border-slate-300',
    badge: 'bg-slate-100 text-slate-800 border border-slate-200/80',
  };
};

export default function MemberList({ members, loading, onEditMember, onDeleteMember, membershipTypes, onViewWalletCard, onSendCardEmail, sendingCardId, invoices, onInvoiceGenerated }) {
  const [generatingInvoiceId, setGeneratingInvoiceId] = React.useState(null);
  const [downloadingInvoiceId, setDownloadingInvoiceId] = React.useState(null);
  const [sendingInvoiceId, setSendingInvoiceId] = React.useState(null);

  const handleGenerateInvoice = async (member) => {
    setGeneratingInvoiceId(member.id);
    try {
      // Dynamically import the function to ensure it's fresh
      const { generateInvoice } = await import('@/api/functions');
      const response = await generateInvoice({ 
        entityId: member.id, 
        entityType: 'member' 
      });
      
      if (response.data.success) {
        toast.success(`Invoice generated successfully for ${member.first_name}`);
        if (onInvoiceGenerated) onInvoiceGenerated();
      } else {
        // Handle case where invoice already exists or other non-success
        toast.info(response.data.message || 'Could not generate invoice.');
      }
    } catch (error) {
      console.error('Error generating invoice:', error);
      toast.error('An error occurred while generating the invoice.');
    } finally {
      setGeneratingInvoiceId(null);
    }
  };

  const handleDownloadInvoice = async (invoiceId) => {
    setDownloadingInvoiceId(invoiceId);
    try {
      const { getInvoiceDownloadUrl } = await import('@/api/functions');
      const response = await getInvoiceDownloadUrl({ invoiceId });
      if (response.data.signed_url) {
        window.open(response.data.signed_url, '_blank');
      } else {
        toast.error(response.data.error || "Could not get download link.");
      }
    } catch (error) {
       console.error('Error downloading invoice:', error);
       toast.error("Failed to download invoice.");
    } finally {
      setDownloadingInvoiceId(null);
    }
  };

  const handleSendInvoiceEmail = async (invoiceId, memberName, memberEmail) => {
    setSendingInvoiceId(invoiceId);
    try {
      const { sendInvoiceEmail } = await import('@/api/functions');
      const response = await sendInvoiceEmail({ invoiceId });
      if (response.data.success) {
        toast.success(`Invoice sent successfully to ${memberEmail}`);
      } else {
        toast.error(response.data.error || "Could not send invoice email.");
      }
    } catch (error) {
      console.error('Error sending invoice email:', error);
      toast.error('An error occurred while sending the email.');
    } finally {
      setSendingInvoiceId(null);
    }
  };

  if (loading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
        <CardHeader>
          <CardTitle>Members</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
                <div className="flex items-center gap-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Skeleton className="h-6 w-16 rounded-full" />
                  <Skeleton className="h-6 w-20 rounded-full" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getRenewalInfo = (member) => {
    const membershipType = membershipTypes.find(t => t.id === member.membership_type_id);

    // Prioritize checking the billing model, which is the most reliable data point.
    if (membershipType?.billing_model === 'lifetime') {
        return <span className="flex items-center gap-1 text-blue-600"><Infinity className="w-4 h-4" /> Lifetime</span>;
    }

    // Add a secondary check on the tier name itself to handle existing data inconsistencies.
    const typeName = member.membership_type_name?.toLowerCase() || '';
    if (typeName.includes('lifetime') || typeName.includes('life time')) {
        return <span className="flex items-center gap-1 text-blue-600"><Infinity className="w-4 h-4" /> Lifetime</span>;
    }
    
    // Only if it's confirmed NOT to be a lifetime membership, show the expiry date.
    if (member.membership_expiry_date) {
        const expiryDate = new Date(member.membership_expiry_date);
        const isExpired = !isFuture(expiryDate);
        return (
            <span className={`flex items-center gap-1 ${isExpired ? 'text-red-600' : 'text-slate-600'}`}>
                <Repeat className="w-4 h-4" />
                {isExpired ? 'Expired' : 'Renews'}: {format(expiryDate, "d MMM yyyy")}
            </span>
        );
    }
    
    return null;
  };

  const isCardReady = (member, membershipType) => {
     if (member.membership_status !== 'active') return false;
     if (!member.membership_type_id || !member.membership_number) return false;
     if (membershipType?.price_aud > 0 && !member.payment_verified) return false;
     return true;
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
      <CardHeader>
        <CardTitle>Members ({members.length})</CardTitle>
        <p className="text-sm text-slate-500">Club members only (players are managed separately).</p>
      </CardHeader>
      <CardContent>
        {members.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">No members found</h3>
            <p className="text-slate-500">Your search or filter returned no results, or you can get started by adding your first member.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {members.map((member) => {
              const tierStyle = getTierStyle(member.membership_type_name);
              const membershipType = membershipTypes.find(t => t.id === member.membership_type_id);
              const isPaidTier = membershipType && membershipType.price_aud > 0;
              const cardIsReady = isCardReady(member, membershipType);
              const memberInvoice = invoices?.find(inv => inv.related_entity_id === member.id);

              return (
                <div key={member.id} className={`p-4 border rounded-lg hover:bg-slate-50 transition-colors duration-200 ${tierStyle.card}`}>
                  <div className="flex items-start justify-between">
                    {/* Left side - Member info */}
                    <div className="flex items-center gap-4 flex-1">
                      {/* Member photo or initials */}
                      {member.photo_url ? (
                        <img 
                          src={member.photo_url} 
                          alt={`${member.first_name} ${member.last_name}`}
                          className="w-12 h-12 rounded-full object-cover border-2 border-slate-300"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                          {member.first_name?.[0]}{member.last_name?.[0]}
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="font-semibold text-slate-900">
                            {member.first_name} {member.last_name}
                          </h3>
                          {member.membership_number && (
                            <Badge className="bg-slate-100 text-slate-700 font-mono text-xs flex items-center gap-1">
                              <Hash className="w-3 h-3" />
                              {member.membership_number}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-slate-500 mb-3">
                          {member.email && (
                            <span className="flex items-center gap-1">
                              <Mail className="w-3 h-3" />
                              {member.email}
                            </span>
                          )}
                          {member.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {member.phone}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right side - Action buttons */}
                    <div className="flex gap-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEditMember(member)}
                        className="text-slate-600 hover:text-slate-900"
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="inline-block">
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => onDeleteMember(member.id)}
                                disabled={member.membership_status === 'active'}
                                className="bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </TooltipTrigger>
                          {member.membership_status === 'active' && (
                            <TooltipContent>
                              <p>Active members cannot be deleted. Change status first.</p>
                            </TooltipContent>
                          )}
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>

                  {/* Bottom section - Status badges and actions */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-sm border-t border-slate-200/80 pt-3 mt-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge className={statusColors[member.membership_status]}>
                        {member.membership_status}
                      </Badge>
                      <Badge className={`${tierStyle.badge} flex items-center gap-1.5`}>
                        <Award className="w-3 h-3" />
                        {member.membership_type_name}
                      </Badge>
                      
                      {isPaidTier && (
                        <Badge variant="default" className={`border ${member.payment_verified ? 'bg-green-100 text-green-800 border-green-200' : 'bg-amber-100 text-amber-800 border-amber-200'}`}>
                          <CreditCard className="w-3 h-3 mr-1.5" />
                          {member.payment_verified ? 'Payment Verified' : 'Payment Pending'}
                        </Badge>
                      )}
                      
                      <div className="font-medium">
                        {getRenewalInfo(member)}
                      </div>
                    </div>

                    {/* Action buttons positioned on the right */}
                    <div className="flex flex-wrap gap-2">
                      {/* Smart Invoice Button */}
                      {memberInvoice ? (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownloadInvoice(memberInvoice.id)}
                            disabled={downloadingInvoiceId === memberInvoice.id}
                            className="text-green-600 hover:text-green-700 bg-green-50 border-green-200"
                          >
                            <Download className="w-4 h-4 mr-1" />
                            {downloadingInvoiceId === memberInvoice.id ? 'Loading...' : 'View Invoice'}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSendInvoiceEmail(memberInvoice.id, `${member.first_name} ${member.last_name}`, member.email)}
                            disabled={sendingInvoiceId === memberInvoice.id}
                            className="text-blue-600 hover:text-blue-700 bg-blue-50 border-blue-200"
                          >
                            <Send className="w-4 h-4 mr-1" />
                            {sendingInvoiceId === memberInvoice.id ? 'Sending...' : 'Send Invoice'}
                          </Button>
                        </>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleGenerateInvoice(member)}
                          disabled={generatingInvoiceId === member.id || member.membership_status !== 'active'}
                          className="text-purple-600 hover:text-purple-700 bg-purple-50 border-purple-200"
                        >
                          <FileText className="w-4 h-4 mr-1" />
                          {generatingInvoiceId === member.id ? 'Generating...' : 'Generate Invoice'}
                        </Button>
                      )}

                      {cardIsReady && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onSendCardEmail(member.id)}
                          disabled={sendingCardId === member.id}
                          className="text-blue-600 hover:text-blue-700 bg-blue-50 border-blue-200"
                        >
                          <Send className="w-4 h-4 mr-1" />
                          {sendingCardId === member.id ? 'Sending...' : 'Send Card'}
                        </Button>
                      )}
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onViewWalletCard(member)}
                        className="bg-gradient-to-r from-red-50 to-red-100 text-red-600 border-red-200 hover:from-red-100 hover:to-red-200"
                      >
                        <CreditCard className="w-4 h-4 mr-1" />
                        Card
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
