import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Package, Inbox } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function InventoryTransactions({ transactions, items, loading }) {
  const getItemName = (itemId) => items.find(i => i.id === itemId)?.name || "Unknown Item";

  const typeDetails = {
    "Initial Stock": { icon: TrendingUp, color: "text-green-500" },
    "Check-in": { icon: TrendingUp, color: "text-green-500" },
    "Adjustment": { icon: TrendingUp, color: "text-blue-500" },
    "Check-out": { icon: TrendingDown, color: "text-red-500" },
    "Missing": { icon: TrendingDown, color: "text-red-500" },
    "Damaged": { icon: TrendingDown, color: "text-orange-500" },
  };

  if (loading) {
    return <Skeleton className="h-96 w-full" />;
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          Recent Transactions
        </CardTitle>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
          <div className="text-center py-16">
            <Inbox className="mx-auto h-12 w-12 text-slate-400" />
            <h3 className="mt-2 text-sm font-medium text-slate-900">No transactions yet</h3>
            <p className="mt-1 text-sm text-slate-500">Item movements will appear here.</p>
          </div>
        ) : (
          <ul className="divide-y divide-slate-200">
            {transactions.map(tx => {
              const details = typeDetails[tx.transaction_type] || { icon: Package, color: "text-slate-500" };
              const isPositive = tx.quantity_change > 0;
              return (
                <li key={tx.id} className="py-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <details.icon className={`w-5 h-5 ${details.color}`} />
                    <div>
                      <p className="font-medium">{getItemName(tx.item_id)}</p>
                      <p className="text-sm text-slate-500">{tx.reason}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                      {isPositive ? '+' : ''}{tx.quantity_change}
                    </p>
                    <p className="text-xs text-slate-400">{format(new Date(tx.created_date), "MMM d, yyyy")}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}