
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Package, DollarSign, AlertTriangle, Shapes, AlertCircle, Wrench } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function InventoryStats({ items, loading }) {
  const stats = {
    totalValue: items.reduce((sum, item) => sum + (item.quantity_on_hand || 0) * (item.purchase_cost || 0), 0),
    totalItems: items.reduce((sum, item) => sum + (item.quantity_on_hand || 0), 0),
    allocatedItems: items.reduce((sum, item) => sum + (item.quantity_allocated || 0), 0),
    damagedItems: items.reduce((sum, item) => sum + (item.quantity_damaged || 0), 0),
    lowStock: items.filter(item => 
        (item.quantity_on_hand - (item.quantity_allocated || 0)) <= item.minimum_level && item.minimum_level > 0
    ).length
  };

  const statCards = [
    { title: "Est. Total Value", value: `$${stats.totalValue.toLocaleString('en-AU')}`, icon: DollarSign, color: "text-green-600 bg-green-100" },
    { title: "Items on Hand", value: stats.totalItems.toLocaleString(), icon: Package, color: "text-blue-600 bg-blue-100" },
    { title: "Allocated", value: stats.allocatedItems.toLocaleString(), icon: AlertCircle, color: "text-purple-600 bg-purple-100" },
    { title: "Damaged", value: stats.damagedItems.toLocaleString(), icon: Wrench, color: "text-yellow-600 bg-yellow-100" },
    { title: "Low Stock Items", value: stats.lowStock, icon: AlertTriangle, color: "text-orange-600 bg-orange-100" }
  ];

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
        {statCards.map((stat, index) => (
          <Card key={index} className="bg-white/80"><CardContent className="p-3"><Skeleton className="h-12 w-full" /></CardContent></Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
      {statCards.map(stat => (
        <Card key={stat.title} className="bg-white/80 backdrop-blur-sm">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-slate-600 mb-1 truncate">{stat.title}</p>
                <p className="text-lg font-bold text-slate-900 leading-none">{stat.value}</p>
              </div>
              <div className={`p-2 rounded-lg ${stat.color} flex-shrink-0 ml-2`}>
                <stat.icon className="w-4 h-4" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
