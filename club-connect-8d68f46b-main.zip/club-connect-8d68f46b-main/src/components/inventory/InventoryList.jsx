
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Package, DollarSign, GripVertical } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function StockAdjustmentModal({ item, onStockAdjustment, children }) {
  const [quantity, setQuantity] = useState(0);
  const [reason, setReason] = useState("");

  const handleAdjust = () => {
    if (quantity !== 0 && reason) {
      onStockAdjustment(item.id, quantity, reason);
    }
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{children}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Adjust Stock for {item.name}</AlertDialogTitle>
          <AlertDialogDescription>
            Enter a quantity (positive to add, negative to remove) and a reason for the adjustment. Current stock: {item.quantity_on_hand}.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="quantity">Quantity Change</Label>
            <Input 
              id="quantity" 
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
              placeholder="e.g., -5 or 10"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Adjustment</Label>
            <Input 
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g., Stocktake correction, Damaged items"
            />
          </div>
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={handleAdjust} disabled={!reason || quantity === 0}>
            Apply Adjustment
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export default function InventoryList({ items, loading, onEditItem, onDeleteItem, onStockAdjustment, onItemDoubleClick }) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {Array(12).fill(0).map((_, i) => (
          <Card key={i}><CardContent className="p-3"><Skeleton className="h-32 w-full" /></CardContent></Card>
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-16 border-dashed border-2 border-slate-300 rounded-lg">
        <Package className="mx-auto h-12 w-12 text-slate-400" />
        <h3 className="mt-2 text-sm font-medium text-slate-900">No inventory items</h3>
        <p className="mt-1 text-sm text-slate-500">Get started by adding a new item.</p>
      </div>
    );
  }
  
  const conditionColors = {
    New: "bg-green-100 text-green-800",
    Good: "bg-blue-100 text-blue-800",
    Fair: "bg-yellow-100 text-yellow-800",
    Poor: "bg-orange-100 text-orange-800",
    Damaged: "bg-red-100 text-red-800",
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-3">
      {items.map(item => {
        const availableStock = (item.quantity_on_hand || 0) - (item.quantity_allocated || 0);
        const totalValue = (item.quantity_on_hand || 0) * (item.purchase_cost || 0);
        return (
          <Card 
            key={item.id} 
            className="bg-white/90 backdrop-blur-sm flex flex-col hover:shadow-lg transition-shadow cursor-pointer"
            onDoubleClick={() => onItemDoubleClick(item)}
          >
            <CardContent className="p-3 flex-grow flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-slate-800 text-sm leading-tight line-clamp-2">{item.name}</h3>
                <div className="flex gap-1 ml-2">
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => { e.stopPropagation(); onEditItem(item); }}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500 hover:text-red-600" onClick={(e) => { e.stopPropagation(); onDeleteItem(item.id); }}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div className="flex justify-between items-baseline mb-2">
                <p className="text-xl font-bold text-green-600">{availableStock}</p>
                <p className="text-xs font-medium text-slate-500">Available</p>
              </div>
              
              {item.has_variants && item.variants?.length > 0 ? (
                <div className="text-xs text-slate-600 space-y-1 border-t border-slate-200/60 pt-2 mb-2">
                  {item.variants.map((variant, idx) => (
                    <div key={idx} className="flex justify-between">
                      <span>{variant.name}:</span>
                      <span className="font-medium text-green-600">{variant.quantity}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-wrap gap-1 mb-2">
                  <Badge variant="secondary" className="text-xs font-normal px-1.5 py-0.5">{item.category}</Badge>
                  <Badge className={`text-xs font-normal px-1.5 py-0.5 ${conditionColors[item.condition]}`}>{item.condition}</Badge>
                </div>
              )}


              <div className="text-xs text-slate-600 space-y-1 border-t border-slate-200/60 pt-2 mb-3">
                <div className="flex justify-between">
                    <span>On Hand:</span>
                    <span className="font-medium text-green-600">{item.quantity_on_hand || 0}</span>
                </div>
                <div className="flex justify-between">
                    <span>Allocated:</span>
                    <span className="font-medium text-green-600">{item.quantity_allocated || 0}</span>
                </div>
                {totalValue > 0 && (
                   <div className="flex justify-between text-green-700">
                     <span className="flex items-center gap-1">
                       <DollarSign className="w-3 h-3" />
                       Value:
                     </span> 
                     <span className="font-bold">${totalValue.toLocaleString()}</span>
                   </div>
                 )}
              </div>
              
              <div className="mt-auto">
                <StockAdjustmentModal item={item} onStockAdjustment={onStockAdjustment}>
                  <Button variant="outline" size="sm" className="w-full text-xs h-8" onClick={(e) => e.stopPropagation()}>Adjust Stock</Button>
                </StockAdjustmentModal>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
