
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, Package, Calculator, Plus, Trash2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function InventoryForm({ item, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(item || {
    name: "",
    category: "Other",
    sku: "",
    quantity_on_hand: 0,
    minimum_level: 0,
    location: "",
    condition: "New",
    purchase_date: "",
    purchase_cost: "",
    gst_included: false,
    invoice_number: "",
    supplier: "",
    notes: "",
    photo_url: "",
    has_variants: false, // New field for variant support
    variants: [] // New field for variants array
  });

  const [newVariantName, setNewVariantName] = useState("");
  const [newVariantQty, setNewVariantQty] = useState(0);

  // Effect to update quantity_on_hand based on variants when has_variants is true
  useEffect(() => {
    if (formData.has_variants) {
      const totalQuantity = formData.variants.reduce((sum, v) => sum + (Number(v.quantity) || 0), 0);
      setFormData(prev => ({ ...prev, quantity_on_hand: totalQuantity }));
    }
  }, [formData.variants, formData.has_variants]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleGSTChange = (checked) => {
    setFormData(prev => ({ ...prev, gst_included: checked }));
  };

  // Calculate total cost including GST if applicable
  const calculateTotalCost = () => {
    const baseCost = parseFloat(formData.purchase_cost) || 0;
    if (formData.gst_included && baseCost > 0) {
      return (baseCost * 1.1).toFixed(2);
    }
    return baseCost.toFixed(2);
  };

  const getDisplayCost = () => {
    const baseCost = parseFloat(formData.purchase_cost) || 0;
    const totalCost = calculateTotalCost();
    
    if (formData.gst_included && baseCost > 0) {
      const gstAmount = (baseCost * 0.1).toFixed(2);
      return `$${baseCost} + $${gstAmount} GST = $${totalCost}`;
    }
    return `$${totalCost}`;
  };
  
  const handleVariantChange = (index, field, value) => {
      const updatedVariants = [...formData.variants];
      updatedVariants[index][field] = value;
      setFormData(prev => ({ ...prev, variants: updatedVariants }));
  };

  const addVariant = () => {
      if (!newVariantName) return; // Prevent adding empty variant names
      setFormData(prev => ({
          ...prev,
          variants: [...prev.variants, { name: newVariantName, quantity: Number(newVariantQty) }]
      }));
      setNewVariantName("");
      setNewVariantQty(0); // Reset quantity to 0 for next input
  };

  const removeVariant = (index) => {
      setFormData(prev => ({
          ...prev,
          variants: prev.variants.filter((_, i) => i !== index)
      }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Calculate final purchase cost including GST if selected
    const finalCost = formData.gst_included && formData.purchase_cost ? 
      parseFloat(calculateTotalCost()) : 
      parseFloat(formData.purchase_cost) || null;

    let submissionData = { ...formData, purchase_cost: finalCost };

    // Adjust quantity_on_hand and variants based on has_variants flag
    if (submissionData.has_variants) {
      // Calculate total quantity from variants for submission
      submissionData.quantity_on_hand = submissionData.variants.reduce((sum, v) => sum + (Number(v.quantity) || 0), 0);
    } else {
      // If no variants, ensure variants array is empty and quantity_on_hand is parsed
      submissionData.variants = [];
      submissionData.quantity_on_hand = parseInt(submissionData.quantity_on_hand) || 0;
    }

    onSubmit({
      ...submissionData,
      minimum_level: parseInt(formData.minimum_level) || 0,
    });
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          {item ? "Edit Inventory Item" : "Add New Inventory Item"}
        </CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6 pt-6"> {/* Added pt-6 as per outline */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="name">Item Name</Label>
              <Input id="name" value={formData.name} onChange={e => handleChange("name", e.target.value)} required />
            </div>
            <div className="space-y-1">
              <Label htmlFor="sku">SKU/Code {formData.has_variants ? "(for base item if applicable)" : ""}</Label>
              <Input id="sku" value={formData.sku} onChange={e => handleChange("sku", e.target.value)} placeholder="Unique identifier" />
            </div>
          </div>
          
          {/* Variant Management Section */}
          <div className="space-y-3 p-4 border rounded-lg bg-slate-50">
            <div className="flex items-center space-x-2">
              <Switch
                id="has-variants"
                checked={formData.has_variants}
                onCheckedChange={value => {
                  handleChange('has_variants', value);
                  // Optionally reset variants or quantity when toggling
                  if (!value) {
                    setFormData(prev => ({ ...prev, variants: [] }));
                  }
                }}
              />
              <Label htmlFor="has-variants">This item has variants (e.g., colors, sizes)</Label>
            </div>
            {formData.has_variants && (
              <div className="space-y-4 pt-4 border-t border-slate-200 mt-4">
                <h4 className="font-medium text-slate-700">Manage Variants</h4>
                {formData.variants.length === 0 && <p className="text-sm text-slate-500">No variants added yet.</p>}
                {formData.variants.map((variant, index) => (
                  <div key={index} className="flex items-end gap-2 p-2 bg-white rounded-md shadow-sm border border-slate-100">
                    <div className="flex-1">
                        <Label htmlFor={`variant-name-${index}`} className="sr-only">Variant Name</Label>
                        <Input id={`variant-name-${index}`} placeholder="Variant Name (e.g., Red, Small)" value={variant.name} onChange={e => handleVariantChange(index, 'name', e.target.value)} />
                    </div>
                    <div className="w-24">
                        <Label htmlFor={`variant-qty-${index}`} className="sr-only">Quantity</Label>
                        <Input id={`variant-qty-${index}`} type="number" placeholder="Qty" value={variant.quantity} onChange={e => handleVariantChange(index, 'quantity', e.target.value)} />
                    </div>
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeVariant(index)} title="Remove Variant"><Trash2 className="w-4 h-4 text-red-500"/></Button>
                  </div>
                ))}
                <div className="flex items-end gap-2 pt-2 border-t border-slate-200">
                  <div className="flex-1">
                      <Label htmlFor="new-variant-name" className="text-xs text-slate-600">New Variant Name</Label>
                      <Input id="new-variant-name" placeholder="e.g., Gold, Large" value={newVariantName} onChange={e => setNewVariantName(e.target.value)} />
                  </div>
                   <div className="w-24">
                      <Label htmlFor="new-variant-qty" className="text-xs text-slate-600">Quantity</Label>
                      <Input id="new-variant-qty" type="number" placeholder="Qty" value={newVariantQty} onChange={e => setNewVariantQty(Number(e.target.value))}/>
                   </div>
                  <Button type="button" onClick={addVariant} disabled={!newVariantName}><Plus className="w-4 h-4 mr-2"/>Add</Button>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="category">Category</Label>
              <Select value={formData.category} onValueChange={(v) => handleChange("category", v)} required>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Ball">Balls</SelectItem>
                  <SelectItem value="Bibs">Bibs</SelectItem>
                  <SelectItem value="Cones">Cones</SelectItem>
                  <SelectItem value="Kits">Kits</SelectItem>
                  <SelectItem value="Medical">Medical</SelectItem>
                  <SelectItem value="Electronics">Electronics</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="condition">Condition</Label>
              <Select value={formData.condition} onValueChange={(v) => handleChange("condition", v)} required>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="New">New</SelectItem>
                  <SelectItem value="Good">Good</SelectItem>
                  <SelectItem value="Fair">Fair</SelectItem>
                  <SelectItem value="Poor">Poor</SelectItem>
                  <SelectItem value="Damaged">Damaged</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="location">Storage Location</Label>
              <Input id="location" value={formData.location} onChange={e => handleChange("location", e.target.value)} placeholder="e.g., Shed A, Locker 5" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="quantity_on_hand">Current Quantity</Label>
              <Input 
                id="quantity_on_hand" 
                type="number" 
                value={formData.quantity_on_hand} 
                onChange={e => handleChange("quantity_on_hand", e.target.value)} 
                required 
                disabled={formData.has_variants} // Disable if variants are enabled
              />
              {formData.has_variants && <p className="text-xs text-slate-500">Total quantity is calculated from variants.</p>}
            </div>
            <div className="space-y-1">
              <Label htmlFor="minimum_level">Minimum Stock Level</Label>
              <Input id="minimum_level" type="number" value={formData.minimum_level} onChange={e => handleChange("minimum_level", e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="purchase_date">Purchase Date</Label>
              <Input id="purchase_date" type="date" value={formData.purchase_date} onChange={e => handleChange("purchase_date", e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="purchase_cost">Purchase Cost (AUD)</Label>
              <div className="space-y-2">
                <Input 
                  id="purchase_cost" 
                  type="number" 
                  step="0.01" 
                  value={formData.purchase_cost} 
                  onChange={e => handleChange("purchase_cost", e.target.value)}
                  placeholder="Enter base cost"
                />
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="gst_included" 
                    checked={formData.gst_included}
                    onCheckedChange={handleGSTChange}
                  />
                  <Label htmlFor="gst_included" className="text-sm">Add 10% GST</Label>
                </div>
                {formData.purchase_cost && (
                  <div className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 p-2 rounded">
                    <Calculator className="w-4 h-4" />
                    <span>Total Cost: {getDisplayCost()}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="invoice_number">Invoice Number</Label>
              <Input id="invoice_number" value={formData.invoice_number} onChange={e => handleChange("invoice_number", e.target.value)} placeholder="INV-2024-001" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="supplier">Supplier</Label>
              <Input id="supplier" value={formData.supplier} onChange={e => handleChange("supplier", e.target.value)} placeholder="Supplier name" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="photo_url">Photo URL</Label>
              <Input id="photo_url" type="url" value={formData.photo_url} onChange={e => handleChange("photo_url", e.target.value)} placeholder="https://" />
            </div>
          </div>

          <div className="space-y-1">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" value={formData.notes} onChange={e => handleChange("notes", e.target.value)} placeholder="Additional notes about this item" />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button type="submit"><Save className="w-4 h-4 mr-2" />{item ? "Update" : "Create"}</Button>
        </CardFooter>
      </form>
    </Card>
  );
}
