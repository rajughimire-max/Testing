
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area'; // Still needed for other ScrollArea uses, but not for the main content wrapper now.
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { InventoryTransaction, Event, Match, InventoryItem } from '@/api/entities';
import { format } from 'date-fns';
import { TrendingUp, TrendingDown, Package, Inbox, AlertTriangle, Wrench, Plus, Minus } from "lucide-react";
import { toast } from 'sonner';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function ReconcileStockForm({ item, onReconcile }) {
    const [adjustment, setAdjustment] = useState('');
    const [reason, setReason] = useState("");

    const handleReconcile = () => {
        const quantity = Number(adjustment);
        if (quantity <= 0 || !reason) {
            toast.error("Please provide a positive quantity and a reason.");
            return;
        }
        onReconcile(quantity, reason);
        setAdjustment('');
        setReason("");
    };
    
    return (
        <Card className="bg-amber-50 border-amber-200 mt-4">
            <CardHeader>
                <CardTitle className="text-base flex items-center gap-2 text-amber-900">
                    <Wrench className="w-5 h-5" />
                    Reconcile Allocated Stock
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-4">
                <p className="text-sm text-amber-800">
                    Use this to manually return stock that is "stuck" as allocated (e.g., from a deleted session). Enter a positive number to decrease the 'allocated' count and return items to 'on hand' stock.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div className="space-y-1">
                        <Label htmlFor="adjustment" className="text-amber-900 font-semibold">Quantity to Return</Label>
                        <Input 
                            id="adjustment" 
                            type="number" 
                            value={adjustment}
                            onChange={e => setAdjustment(e.target.value)}
                            placeholder="e.g., 5"
                        />
                    </div>
                    <div className="space-y-1 col-span-2">
                        <Label htmlFor="reason" className="text-amber-900 font-semibold">Reason for Reconciliation</Label>
                        <Input 
                            id="reason"
                            value={reason}
                            onChange={e => setReason(e.target.value)}
                            placeholder="e.g., Return from deleted session"
                        />
                    </div>
                </div>
                 <Button onClick={handleReconcile} className="bg-amber-600 hover:bg-amber-700 text-white mt-4">
                    Apply Reconciliation
                </Button>
            </CardContent>
        </Card>
    );
}

export default function InventoryDetailModal({ item, isOpen, onClose }) {
  const [transactions, setTransactions] = useState([]);
  const [events, setEvents] = useState([]);
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentItem, setCurrentItem] = useState(item);

  const fetchData = useCallback(async () => {
    if (!item?.id) return;
    setLoading(true);
    try {
      const [transactionsData, eventsData, matchesData, itemData] = await Promise.all([
        InventoryTransaction.filter({ item_id: item.id }, '-created_date'),
        Event.list(),
        Match.list(),
        InventoryItem.get(item.id)
      ]);
      setTransactions(transactionsData);
      setEvents(eventsData);
      setMatches(matchesData);
      setCurrentItem(itemData);
    } catch (error) {
      console.error("Error loading item details:", error);
      toast.error("Failed to load item history.");
    } finally {
      setLoading(false);
    }
  }, [item?.id]);

  useEffect(() => {
    if (isOpen) {
      fetchData();
    }
  }, [isOpen, fetchData]);

  const handleReconcileStock = async (quantity, reason) => {
    if (!currentItem) return;

    try {
        const quantityToAdjust = Math.abs(quantity); // Ensure positive number for logic
        
        // Create an adjustment transaction
        await InventoryTransaction.create({
            item_id: currentItem.id,
            transaction_type: "Adjustment",
            quantity_change: quantityToAdjust, // Positive change to stock
            reason: `Reconciliation: ${reason}`
        });

        // Update the inventory item itself
        const newAllocated = Math.max(0, (currentItem.quantity_allocated || 0) - quantityToAdjust);
        await InventoryItem.update(currentItem.id, {
            quantity_allocated: newAllocated
        });
        
        toast.success("Stock reconciled successfully!");
        fetchData(); // Refresh data
    } catch (error) {
        console.error("Error reconciling stock:", error);
        toast.error("Failed to reconcile stock.");
    }
  };

  const getTransactionDetails = (tx) => {
    let details = {
        icon: Package,
        color: "text-slate-500",
        related: "System",
        sign: ""
    };
    if (tx.quantity_change > 0) details.sign = "+";
    if (tx.quantity_change < 0) details.sign = ""; // Negative is implied

    switch (tx.transaction_type) {
        case "Initial Stock":
        case "Check-in":
        case "Adjustment":
            details.icon = TrendingUp;
            details.color = "text-green-600";
            break;
        case "Check-out":
        case "Missing":
        case "Damaged":
            details.icon = TrendingDown;
            details.color = "text-red-600";
            break;
    }

    if (tx.training_session_id) {
        details.related = events.find(e => e.id === tx.training_session_id)?.title || "Training Session";
    } else if (tx.match_id) {
        details.related = matches.find(m => m.id === tx.match_id)?.opponent_name || "Match";
    }

    return details;
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col p-0">
        <DialogHeader className="flex-shrink-0 p-6 border-b">
          <DialogTitle className="text-2xl">{currentItem?.name}</DialogTitle>
          <DialogDescription>
            Detailed transaction history and stock levels.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-4 gap-4 p-6 flex-shrink-0 border-b">
            <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">On Hand</CardTitle></CardHeader>
                <CardContent><p className="text-2xl font-bold">{currentItem?.quantity_on_hand || 0}</p></CardContent>
            </Card>
            <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Allocated</CardTitle></CardHeader>
                <CardContent><p className="text-2xl font-bold text-orange-600">{currentItem?.quantity_allocated || 0}</p></CardContent>
            </Card>
            <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Available</CardTitle></CardHeader>
                <CardContent><p className="text-2xl font-bold text-green-600">{(currentItem?.quantity_on_hand || 0) - (currentItem?.quantity_allocated || 0)}</p></CardContent>
            </Card>
             <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Condition</CardTitle></CardHeader>
                <CardContent><p className="text-xl font-semibold">{currentItem?.condition}</p></CardContent>
            </Card>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-semibold mb-4">Transaction History</h3>
                    {loading ? (
                        <p>Loading history...</p>
                    ) : transactions.length === 0 ? (
                         <div className="text-center py-10 border-dashed border-2 rounded-lg">
                            <Inbox className="mx-auto h-12 w-12 text-slate-400" />
                            <h3 className="mt-2 text-sm font-medium text-slate-900">No transactions recorded</h3>
                            <p className="mt-1 text-sm text-slate-500">All movements for this item will appear here.</p>
                        </div>
                    ) : (
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Date</TableHead>
                                        <TableHead>Type</TableHead>
                                        <TableHead className="text-right">Quantity</TableHead>
                                        <TableHead>Related To</TableHead>
                                        <TableHead>Reason</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {transactions.map(tx => {
                                        const details = getTransactionDetails(tx);
                                        return (
                                            <TableRow key={tx.id}>
                                                <TableCell>{format(new Date(tx.created_date), 'd MMM yyyy, h:mm a')}</TableCell>
                                                <TableCell>
                                                    <Badge variant={details.color.includes('red') ? 'destructive' : 'default'} className="flex items-center gap-1 w-fit">
                                                        <details.icon className="w-3 h-3"/>
                                                        {tx.transaction_type}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell className={`text-right font-bold ${details.color}`}>
                                                    {details.sign}{tx.quantity_change}
                                                </TableCell>
                                                <TableCell>{details.related}</TableCell>
                                                <TableCell>{tx.reason}</TableCell>
                                            </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </div>

                {(currentItem?.quantity_allocated || 0) > 0 && (
                    <ReconcileStockForm item={currentItem} onReconcile={handleReconcileStock} />
                )}
            </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
