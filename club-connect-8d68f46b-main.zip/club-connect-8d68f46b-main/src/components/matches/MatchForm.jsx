
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, Plus, Minus, User, Star, Footprints, Info, Check } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

const awardsOptions = [
  "Man of the Match",
  "Best Player",
  "Highest Scorer",
  "Best Defender",
  "Best Midfielder",
  "Best Forward",
  "Fair Play Award",
];

export default function MatchForm({ match, teams, tournamentTypes, players, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(
    match || {
      team_id: "",
      opponent_name: "",
      match_date: "",
      match_time: "",
      venue: "",
      is_home_game: true,
      tournament_type_id: "",
      competition: "",
      round: "",
      match_status: "scheduled",
      home_score: 0,
      away_score: 0,
      match_report: "",
      team_achievements: [],
      selected_players: [],
      player_performance: [],
    }
  );

  useEffect(() => {
    if (match) {
      setFormData({
        ...match,
        team_achievements: match.team_achievements || [],
        selected_players: match.selected_players || [],
        player_performance: match.player_performance || [],
      });
    }
  }, [match]);

  const handleChange = useCallback((field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }, []);
  
  // Sync player_performance array with selected_players
  useEffect(() => {
    const selected = formData.selected_players || [];
    const performance = formData.player_performance || [];
    
    // Add new performance entries for newly selected players
    const newPerformance = [...performance];
    selected.forEach(playerId => {
      if (!newPerformance.some(p => p.player_id === playerId)) {
        newPerformance.push({
          player_id: playerId,
          goals_scored: 0,
          assists: 0,
          awards: [],
          notes: "",
        });
      }
    });

    // Filter out performance entries for deselected players
    const finalPerformance = newPerformance.filter(p => selected.includes(p.player_id));
    
    // Check if performance array actually changed before updating state
    if (JSON.stringify(finalPerformance) !== JSON.stringify(performance)) {
        handleChange("player_performance", finalPerformance);
    }
  }, [formData.selected_players, formData.player_performance, handleChange]);

  const teamPlayers = useMemo(() => {
    if (!formData.team_id) return [];
    return players.filter(p => p.team_id === formData.team_id);
  }, [formData.team_id, players]);

  const handleTeamAchievementChange = (index, value) => {
    const newAchievements = [...(formData.team_achievements || [])];
    newAchievements[index] = value;
    handleChange("team_achievements", newAchievements);
  };
  
  const addTeamAchievement = () => {
    handleChange("team_achievements", [...(formData.team_achievements || []), ""]);
  };
  
  const removeTeamAchievement = (index) => {
    const newAchievements = (formData.team_achievements || []).filter((_, i) => i !== index);
    handleChange("team_achievements", newAchievements);
  };

  const handlePlayerSelection = (playerId, isSelected) => {
    const currentSelected = formData.selected_players || [];
    const newSelected = isSelected
      ? [...currentSelected, playerId]
      : currentSelected.filter(id => id !== playerId);
    handleChange("selected_players", newSelected);
  };

  const handlePerformanceChange = (playerId, field, value) => {
    const updatedPerformance = (formData.player_performance || []).map(p =>
      p.player_id === playerId ? { ...p, [field]: value } : p
    );
    handleChange("player_performance", updatedPerformance);
  };

  const handleAwardToggle = (playerId, award) => {
    const performance = (formData.player_performance || []).find(p => p.player_id === playerId);
    if (!performance) return;

    const currentAwards = performance.awards || [];
    const newAwards = currentAwards.includes(award)
      ? currentAwards.filter(a => a !== award)
      : [...currentAwards, award];
    
    handlePerformanceChange(playerId, 'awards', newAwards);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.team_id) {
        toast.error("Please select a team.");
        return;
    }
    const dataToSubmit = {
      ...formData,
      team_achievements: (formData.team_achievements || []).filter((a) => a.trim() !== ""),
      home_score: Number(formData.home_score) || 0,
      away_score: Number(formData.away_score) || 0,
    };
    onSubmit(dataToSubmit);
  };

  return (
    <Card className="mb-6 bg-white/80 backdrop-blur-sm border-slate-200/60">
      <CardHeader>
        <CardTitle>{match ? "Edit Match" : "Add New Match"}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          {/* Basic Match Details */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Match Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="team_id">Our Team *</Label>
                <Select
                  value={formData.team_id}
                  onValueChange={(v) => handleChange("team_id", v)}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select team..." />
                  </SelectTrigger>
                  <SelectContent>
                    {(teams || []).map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="opponent_name">Opponent Team *</Label>
                <Input
                  id="opponent_name"
                  value={formData.opponent_name}
                  onChange={(e) => handleChange("opponent_name", e.target.value)}
                  required
                />
              </div>
            </div>
          </div>

          {/* Date, Time, Venue */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Schedule & Venue</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="match_date">Date *</Label>
                <Input
                  id="match_date"
                  type="date"
                  value={formData.match_date}
                  onChange={(e) => handleChange("match_date", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="match_time">Time</Label>
                <Input
                  id="match_time"
                  type="time"
                  value={formData.match_time}
                  onChange={(e) => handleChange("match_time", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="venue">Venue *</Label>
                <Input
                  id="venue"
                  value={formData.venue}
                  onChange={(e) => handleChange("venue", e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="flex items-center space-x-2 pt-3">
              <Checkbox
                id="is_home_game"
                checked={formData.is_home_game}
                onCheckedChange={(v) => handleChange("is_home_game", v)}
              />
              <Label htmlFor="is_home_game">This is a home game</Label>
            </div>
          </div>

          {/* Competition Details */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Competition Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tournament_type_id">Tournament Type</Label>
                <Select
                  value={formData.tournament_type_id}
                  onValueChange={(v) => handleChange("tournament_type_id", v)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {(tournamentTypes || []).map((type) => (
                      <SelectItem key={type.id} value={type.id}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="competition">Competition/League</Label>
                <Input
                  id="competition"
                  value={formData.competition}
                  onChange={(e) => handleChange("competition", e.target.value)}
                  placeholder="e.g., Premier League"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="round">Round/Fixture</Label>
                <Input
                  id="round"
                  value={formData.round}
                  onChange={(e) => handleChange("round", e.target.value)}
                  placeholder="e.g., Round 5"
                />
              </div>
            </div>
          </div>

          {/* Match Status and Results */}
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4">Status & Results</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="match_status">Match Status</Label>
                <Select
                  value={formData.match_status}
                  onValueChange={(v) => handleChange("match_status", v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="postponed">Postponed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.match_status === "completed" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="home_score">Home Score</Label>
                    <Input
                      id="home_score"
                      type="number"
                      min="0"
                      value={formData.home_score}
                      onChange={(e) => handleChange("home_score", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="away_score">Away Score</Label>
                    <Input
                      id="away_score"
                      type="number"
                      min="0"
                      value={formData.away_score}
                      onChange={(e) => handleChange("away_score", e.target.value)}
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Match Report, Achievements, Player Performance */}
          {formData.match_status === "completed" && (
            <div className="space-y-6">
              {/* Report and Team Achievements */}
              <div>
                <h3 className="text-lg font-medium text-slate-900 mb-4">Post-Match Details</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="match_report">Match Report</Label>
                    <Textarea
                      id="match_report"
                      value={formData.match_report}
                      onChange={(e) => handleChange("match_report", e.target.value)}
                      rows={3}
                      placeholder="Describe how the match went..."
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Team Achievements</Label>
                    <div className="space-y-3 mt-2">
                      {(formData.team_achievements || []).map(
                        (achievement, index) => (
                          <div key={index} className="flex gap-2">
                            <Input
                              value={achievement}
                              onChange={(e) =>
                                handleTeamAchievementChange(index, e.target.value)
                              }
                              placeholder="e.g., Qualified for finals"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeTeamAchievement(index)}
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                          </div>
                        )
                      )}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={addTeamAchievement}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Team Achievement
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Player Performance */}
              <div>
                <h3 className="text-lg font-medium text-slate-900 mb-4">Player Performance</h3>
                
                {formData.team_id ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* Player Selection */}
                        <div className="space-y-4">
                            <Label className="font-semibold">Select Participating Players</Label>
                            <ScrollArea className="h-72 w-full rounded-md border p-4">
                            {teamPlayers.length > 0 ? (
                                teamPlayers.map(player => (
                                <div key={player.id} className="flex items-center space-x-2 mb-2">
                                    <Checkbox
                                    id={`player-${player.id}`}
                                    checked={(formData.selected_players || []).includes(player.id)}
                                    onCheckedChange={(checked) => handlePlayerSelection(player.id, checked)}
                                    />
                                    <Label htmlFor={`player-${player.id}`} className="flex-1 cursor-pointer">
                                    {player.first_name} {player.last_name} #{player.preferred_number}
                                    </Label>
                                </div>
                                ))
                            ) : (
                                <p className="text-slate-500 text-sm">No players found for this team.</p>
                            )}
                            </ScrollArea>
                        </div>
    
                        {/* Performance Entry for Selected Players */}
                        <div className="space-y-4">
                             <Label className="font-semibold">Record Performance</Label>
                            {(formData.selected_players || []).length > 0 ? (
                                <ScrollArea className="h-72 w-full">
                                    <div className="space-y-4">
                                        {(formData.player_performance || []).map(perf => {
                                        const player = players.find(p => p.id === perf.player_id);
                                        if (!player) return null;
                                        return (
                                            <div key={perf.player_id} className="p-4 border rounded-lg bg-slate-50">
                                            <p className="font-semibold text-slate-800 mb-3">{player.first_name} {player.last_name}</p>
                                            <div className="grid grid-cols-2 gap-4 mb-3">
                                                <div className="space-y-1">
                                                <Label>Goals</Label>
                                                <Input type="number" min="0" value={perf.goals_scored || 0} onChange={e => handlePerformanceChange(perf.player_id, 'goals_scored', Number(e.target.value))}/>
                                                </div>
                                                <div className="space-y-1">
                                                <Label>Assists</Label>
                                                <Input type="number" min="0" value={perf.assists || 0} onChange={e => handlePerformanceChange(perf.player_id, 'assists', Number(e.target.value))}/>
                                                </div>
                                            </div>
                                            <div className="space-y-2 mb-3">
                                                <Label>Awards</Label>
                                                <div className="flex flex-wrap gap-2">
                                                    {awardsOptions.map(award => (
                                                        <Button key={award} type="button" size="sm" variant={(perf.awards || []).includes(award) ? 'default' : 'outline'} onClick={() => handleAwardToggle(perf.player_id, award)}>
                                                            {(perf.awards || []).includes(award) && <Check className="w-3 h-3 mr-1"/>}
                                                            {award}
                                                        </Button>
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="space-y-1">
                                                <Label>Notes</Label>
                                                <Textarea value={perf.notes || ""} onChange={e => handlePerformanceChange(perf.player_id, 'notes', e.target.value)} rows={2} placeholder="e.g., Key defensive play"/>
                                            </div>
                                            </div>
                                        );
                                        })}
                                    </div>
                                </ScrollArea>
                            ) : (
                                <div className="h-72 flex items-center justify-center border rounded-lg bg-slate-50">
                                    <p className="text-slate-500 text-sm">Select players to record their performance.</p>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="text-center p-8 border rounded-lg bg-slate-50">
                        <Info className="w-8 h-8 mx-auto text-slate-400 mb-2"/>
                        <p className="text-slate-500">Please select a team first to manage player performance.</p>
                    </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            {match ? "Update Match" : "Create Match"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
