import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Calendar, Target, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function MatchStats({ matches, loading }) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {Array(4).fill(0).map((_, i) => (
          <Card key={i} className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <Skeleton className="h-16" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const stats = {
    total: matches.length,
    upcoming: matches.filter(m => new Date(m.match_date) >= new Date() && m.match_status === 'scheduled').length,
    completed: matches.filter(m => m.match_status === 'completed').length,
    wins: matches.filter(m => {
      if (m.match_status !== 'completed') return false;
      const homeWon = m.home_score > m.away_score;
      const draw = m.home_score === m.away_score;
      if (draw) return false;
      return m.is_home_game ? homeWon : !homeWon;
    }).length
  };

  const statCards = [
    { title: "Total Matches", value: stats.total, icon: Calendar, color: "blue" },
    { title: "Upcoming", value: stats.upcoming, icon: Target, color: "orange" },
    { title: "Completed", value: stats.completed, icon: Trophy, color: "green" },
    { title: "Wins", value: stats.wins, icon: TrendingUp, color: "purple" }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat) => (
        <Card key={stat.title} className="bg-white/80 backdrop-blur-sm border-slate-200/60">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">{stat.title}</p>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
              </div>
              <div className={`p-3 rounded-xl bg-${stat.color}-100`}>
                <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}