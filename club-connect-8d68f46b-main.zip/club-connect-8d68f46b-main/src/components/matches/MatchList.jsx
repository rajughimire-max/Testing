import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Edit, Trash2, Calendar, Clock, MapPin, Trophy, Users, ChevronDown, ChevronUp, Star, Award } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function MatchList({ matches, upcomingMatches, completedMatches, teams, tournamentTypes, players, loading, onEdit, onDelete, onUpdateResults }) {
  const getTeamName = (teamId) => teams.find(t => t.id === teamId)?.name || "Unknown Team";
  const getTournamentType = (typeId) => tournamentTypes.find(t => t.id === typeId)?.name || "Friendly";
  const getPlayerName = (playerId) => {
    const player = players.find(p => p.id === playerId);
    return player ? `${player.first_name} ${player.last_name}` : "Unknown Player";
  };

  const getResultBadge = (match) => {
    if (match.match_status !== 'completed') return null;
    const homeWon = match.home_score > match.away_score;
    const draw = match.home_score === match.away_score;
    if (draw) return <Badge className="bg-yellow-100 text-yellow-800">Draw</Badge>;
    if (match.is_home_game) {
      return homeWon ? <Badge className="bg-green-100 text-green-800">Win</Badge> : <Badge className="bg-red-100 text-red-800">Loss</Badge>;
    } else {
      return homeWon ? <Badge className="bg-red-100 text-red-800">Loss</Badge> : <Badge className="bg-green-100 text-green-800">Win</Badge>;
    }
  };

  const MatchCard = ({ match, showResult = false }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    
    const performanceData = match.player_performance?.map(perf => ({
      ...perf,
      playerName: getPlayerName(perf.player_id)
    })).filter(p => p.playerName !== 'Unknown Player');

    const goalScorers = performanceData?.filter(p => p.goals_scored > 0)
        .sort((a,b) => b.goals_scored - a.goals_scored);

    const awardWinners = performanceData?.filter(p => p.awards && p.awards.length > 0);

    const handleDeleteClick = async () => {
      if (isDeleting) return;

      if (window.confirm(`Are you sure you want to delete the match "${getTeamName(match.team_id)} vs ${match.opponent_name}"?`)) {
        setIsDeleting(true);
        try {
          await onDelete(match.id);
        } catch (error) {
          console.error("Error in delete handler:", error);
        } finally {
          setIsDeleting(false);
        }
      }
    };

    return (
      <Card className="bg-white/90 backdrop-blur-sm overflow-hidden transition-all duration-300 hover:shadow-lg">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-semibold text-lg text-slate-900">
                  {getTeamName(match.team_id)} vs {match.opponent_name}
                </h3>
                <Badge variant="outline" className="text-xs">
                  {getTournamentType(match.tournament_type_id)}
                </Badge>
              </div>

              <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
                <span className="flex items-center gap-1"><Calendar className="w-4 h-4"/>{format(new Date(match.match_date), "EEE, d MMM yyyy")}</span>
                {match.match_time && (<span className="flex items-center gap-1"><Clock className="w-4 h-4"/>{match.match_time}</span>)}
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4"/>{match.venue}</span>
              </div>

              <div className="flex items-center gap-2 flex-wrap mb-3">
                <Badge variant={match.is_home_game ? "default" : "outline"}>{match.is_home_game ? "Home" : "Away"}</Badge>
                {getResultBadge(match)}
                <Badge variant="outline" className="capitalize">{match.match_status}</Badge>
                {(match.selected_players?.length > 0) && (<Badge variant="outline" className="flex items-center gap-1"><Users className="w-3 h-3"/>{match.selected_players.length} players</Badge>)}
              </div>
              
              {match.match_status === 'completed' && goalScorers && goalScorers.length > 0 && (
                <div className="text-sm text-slate-600">
                    <strong>Goals:</strong> {goalScorers.map(p => `${p.playerName} (${p.goals_scored})`).join(', ')}
                </div>
              )}
            </div>

            <div className="text-right">
              {showResult && match.match_status === 'completed' && (<div className="mb-3"><p className="font-bold text-2xl text-slate-900">{match.home_score} - {match.away_score}</p></div>)}
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => onEdit(match)}>
                  <Edit className="w-3 h-3 mr-1"/> Details
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:text-red-700"
                  onClick={handleDeleteClick}
                  disabled={isDeleting}
                >
                  <Trash2 className="w-3 h-3 mr-1"/>
                  {isDeleting ? 'Deleting...' : 'Delete'}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {isExpanded && match.match_status === 'completed' && (
          <div className="p-6 border-t bg-slate-50/50">
            <h4 className="text-lg font-semibold mb-4">Game Performance Records</h4>
            <div className="space-y-4">
              {performanceData && performanceData.length > 0 ? (
                performanceData.map(perf => (
                  <div key={perf.player_id} className="p-4 bg-white rounded-lg border">
                    <p className="font-semibold text-slate-800 mb-3">{perf.playerName}</p>
                    <div className="grid grid-cols-2 md:grid-cols-2 gap-4 mb-3 text-sm">
                      <div className="flex items-center gap-2"><Star className="w-4 h-4 text-yellow-500"/>Goals: <span className="font-bold">{perf.goals_scored || 0}</span></div>
                      <div className="flex items-center gap-2"><Star className="w-4 h-4 text-blue-500"/>Assists: <span className="font-bold">{perf.assists || 0}</span></div>
                    </div>
                    {perf.awards && perf.awards.length > 0 && (
                        <div className="flex items-start gap-2 text-sm mb-3">
                            <Award className="w-4 h-4 text-amber-500 mt-0.5"/>
                            <div>
                                <strong>Awards:</strong>
                                <div className="flex flex-wrap gap-2 mt-1">
                                    {perf.awards.map(award => <Badge key={award} variant="secondary">{award}</Badge>)}
                                </div>
                            </div>
                        </div>
                    )}
                    {perf.notes && (<p className="text-sm text-slate-600 italic mt-2"><strong>Notes:</strong> "{perf.notes}"</p>)}
                  </div>
                ))
              ) : (
                <p className="text-slate-500 text-sm">No player performance data recorded for this game.</p>
              )}
            </div>
          </div>
        )}

        {match.match_status === 'completed' && (match.player_performance?.length > 0) && (
          <CardFooter className="p-0">
            <Button variant="ghost" className="w-full justify-center py-3 text-sm text-slate-600 hover:bg-slate-50 rounded-t-none" onClick={() => setIsExpanded(!isExpanded)}>
              {isExpanded ? "Hide Performance" : "Show Performance"}
              {isExpanded ? <ChevronUp className="w-4 h-4 ml-2" /> : <ChevronDown className="w-4 h-4 ml-2" />}
            </Button>
          </CardFooter>
        )}
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {Array(3).fill(0).map((_, i) => (
          <Skeleton key={i} className="h-40" />
        ))}
      </div>
    );
  }

  return (
    <>
      <Tabs defaultValue="all" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">All Matches ({matches.length})</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming ({upcomingMatches.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedMatches.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>All Matches</CardTitle></CardHeader>
            <CardContent>
              {matches.length === 0 ? (<div className="text-center py-8"><Trophy className="w-12 h-12 text-slate-300 mx-auto mb-3" /><p className="text-slate-500">No matches scheduled yet</p></div>) : (<div className="space-y-4">{matches.map(match => (<MatchCard key={match.id} match={match} showResult={true} />))}</div>)}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Upcoming Matches</CardTitle></CardHeader>
            <CardContent>
              {upcomingMatches.length === 0 ? (<div className="text-center py-8"><Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" /><p className="text-slate-500">No upcoming matches scheduled</p></div>) : (<div className="space-y-4">{upcomingMatches.map(match => (<MatchCard key={match.id} match={match} />))}</div>)}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Completed Matches</CardTitle></CardHeader>
            <CardContent>
              {completedMatches.length === 0 ? (<div className="text-center py-8"><Trophy className="w-12 h-12 text-slate-300 mx-auto mb-3" /><p className="text-slate-500">No completed matches yet</p></div>) : (<div className="space-y-4">{completedMatches.map(match => (<MatchCard key={match.id} match={match} showResult={true} />))}</div>)}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}