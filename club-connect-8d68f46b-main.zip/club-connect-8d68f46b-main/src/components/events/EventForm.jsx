import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";

export default function EventForm({ event, onSubmit, onCancel, eventType }) {
  const [formData, setFormData] = useState(event || {
    title: "",
    description: "",
    event_date: "",
    start_time: "",
    end_time: "",
    venue: "",
    event_type: "other",
  });
  
  useEffect(() => {
    if (!event && eventType === 'training') {
      setFormData(prev => ({ ...prev, event_type: 'training' }));
    }
  }, [event, eventType]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card className="mb-6">
      <CardHeader><CardTitle>{event ? `Edit ${formData.event_type}` : `Add New ${formData.event_type}`}</CardTitle></CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <Label htmlFor="title">Title</Label>
            <Input id="title" value={formData.title} onChange={e => handleChange("title", e.target.value)} required />
          </div>
          <div className="space-y-1">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={formData.description} onChange={e => handleChange("description", e.target.value)} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="event_date">Date</Label>
              <Input id="event_date" type="date" value={formData.event_date} onChange={e => handleChange("event_date", e.target.value)} required />
            </div>
            <div className="space-y-1">
              <Label htmlFor="start_time">Start Time</Label>
              <Input id="start_time" type="time" value={formData.start_time} onChange={e => handleChange("start_time", e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="end_time">End Time</Label>
              <Input id="end_time" type="time" value={formData.end_time} onChange={e => handleChange("end_time", e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="venue">Venue</Label>
              <Input id="venue" value={formData.venue} onChange={e => handleChange("venue", e.target.value)} />
            </div>
             <div className="space-y-1">
              <Label htmlFor="event_type">Type</Label>
              <Select value={formData.event_type} onValueChange={(v) => handleChange("event_type", v)} required disabled={eventType === 'training'}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {eventType === 'training' ? (
                    <SelectItem value="training">Training</SelectItem>
                  ) : (
                    <>
                      <SelectItem value="social">Social</SelectItem>
                      <SelectItem value="fundraising">Fundraising</SelectItem>
                      <SelectItem value="meeting">Meeting</SelectItem>
                      <SelectItem value="tournament">Tournament</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button type="submit"><Save className="w-4 h-4 mr-2" />{event ? "Update" : "Create"}</Button>
        </CardFooter>
      </form>
    </Card>
  );
}