
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Calendar, Clock, MapPin, Download } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function EventList({ events, loading, onEdit, onDelete, onDownloadICS }) {
  if (loading) return <Skeleton className="h-64" />;

  return (
    <Card>
      <CardHeader><CardTitle>Events ({events.length})</CardTitle></CardHeader>
      <CardContent>
        <div className="space-y-4">
          {events.map(event => (
            <div key={event.id} className="p-4 border rounded-lg hover:bg-slate-50">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-lg">{event.title}</h3>
                  <p className="text-sm text-slate-500 capitalize">{event.event_type} Event</p>
                  <p className="text-sm text-slate-600 mt-1">{event.description}</p>
                  <div className="flex items-center gap-4 text-sm text-slate-600 mt-2">
                    <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {format(new Date(event.event_date), "EEE, d MMM yyyy")}</span>
                    <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {event.start_time} - {event.end_time}</span>
                    <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {event.venue}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                    <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => onEdit(event)}><Edit className="w-3 h-3 mr-1" /> Edit</Button>
                        <Button variant="outline" size="sm" onClick={() => onDownloadICS(event)}><Download className="w-3 h-3 mr-1" /> ICS</Button>
                        <Button variant="outline" size="sm" className="text-red-600" onClick={() => onDelete(event.id)}><Trash2 className="w-3 h-3 mr-1" /> Delete</Button>
                    </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
