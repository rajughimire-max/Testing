import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, AlertTriangle } from "lucide-react";

export default function PlayerInjuryForm({ 
  injury, 
  player, 
  matches, 
  trainingSessions, 
  onSubmit, 
  onCancel 
}) {
  const [formData, setFormData] = useState({
    player_id: player?.id || '',
    injury_date: injury?.injury_date || new Date().toISOString().split('T')[0],
    injury_type: injury?.injury_type || '',
    body_part: injury?.body_part || '',
    severity: injury?.severity || '',
    how_it_happened: injury?.how_it_happened || '',
    match_id: injury?.match_id || '',
    training_session_id: injury?.training_session_id || '',
    immediate_treatment: injury?.immediate_treatment || '',
    medical_assessment: injury?.medical_assessment || '',
    treatment_plan: injury?.treatment_plan || '',
    current_status: injury?.current_status || 'Active injury',
    expected_return_date: injury?.expected_return_date || '',
    actual_return_date: injury?.actual_return_date || '',
    medical_clearance: injury?.medical_clearance || false,
    clearance_notes: injury?.clearance_notes || '',
    follow_up_required: injury?.follow_up_required || false,
    notes: injury?.notes || ''
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const injuryTypes = [
    "Muscle strain", "Ligament sprain", "Fracture", "Concussion", 
    "Cut/Laceration", "Bruise/Contusion", "Joint dislocation", 
    "Overuse injury", "Other"
  ];

  const bodyParts = [
    "Head", "Neck", "Shoulder", "Arm", "Elbow", "Wrist", "Hand", 
    "Chest", "Back", "Abdomen", "Hip", "Thigh", "Knee", "Calf", "Ankle", "Foot"
  ];

  const severityLevels = ["Minor", "Moderate", "Severe"];
  const statusOptions = ["Active injury", "Under treatment", "Recovering", "Cleared to play"];

  return (
    <Card className="bg-white/90 backdrop-blur-sm border-orange-200/60 mb-6">
      <CardHeader className="bg-orange-50/50">
        <CardTitle className="flex items-center gap-2 text-orange-800">
          <AlertTriangle className="w-5 h-5" />
          {injury ? 'Update Injury Record' : 'Record New Injury'}
        </CardTitle>
        <p className="text-sm text-orange-600">
          Player: {player?.first_name} {player?.last_name}
        </p>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6 p-6">
          
          {/* Basic Injury Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="injury_date">Injury Date *</Label>
              <Input 
                id="injury_date"
                type="date"
                value={formData.injury_date}
                onChange={(e) => handleChange('injury_date', e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="injury_type">Injury Type *</Label>
              <Select value={formData.injury_type} onValueChange={(value) => handleChange('injury_type', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select injury type" />
                </SelectTrigger>
                <SelectContent>
                  {injuryTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="body_part">Body Part *</Label>
              <Select value={formData.body_part} onValueChange={(value) => handleChange('body_part', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select body part" />
                </SelectTrigger>
                <SelectContent>
                  {bodyParts.map(part => (
                    <SelectItem key={part} value={part}>{part}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="severity">Severity *</Label>
              <Select value={formData.severity} onValueChange={(value) => handleChange('severity', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select severity" />
                </SelectTrigger>
                <SelectContent>
                  {severityLevels.map(level => (
                    <SelectItem key={level} value={level}>{level}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* How it happened */}
          <div className="space-y-2">
            <Label htmlFor="how_it_happened">How did the injury happen? *</Label>
            <Textarea 
              id="how_it_happened"
              value={formData.how_it_happened}
              onChange={(e) => handleChange('how_it_happened', e.target.value)}
              placeholder="Describe how the injury occurred..."
              rows={3}
              required
            />
          </div>

          {/* Context - Match or Training */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="match_id">During Match (optional)</Label>
              <Select value={formData.match_id} onValueChange={(value) => handleChange('match_id', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select match if applicable" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>No specific match</SelectItem>
                  {matches?.map(match => (
                    <SelectItem key={match.id} value={match.id}>
                      vs {match.opponent_name} ({match.match_date})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="training_session_id">During Training (optional)</Label>
              <Select value={formData.training_session_id} onValueChange={(value) => handleChange('training_session_id', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select training if applicable" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>No specific training</SelectItem>
                  {trainingSessions?.map(session => (
                    <SelectItem key={session.id} value={session.id}>
                      {session.title} ({session.event_date})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Treatment Details */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="immediate_treatment">Immediate Treatment</Label>
              <Textarea 
                id="immediate_treatment"
                value={formData.immediate_treatment}
                onChange={(e) => handleChange('immediate_treatment', e.target.value)}
                placeholder="What was done immediately after the injury?"
                rows={2}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="medical_assessment">Medical Assessment</Label>
              <Textarea 
                id="medical_assessment"
                value={formData.medical_assessment}
                onChange={(e) => handleChange('medical_assessment', e.target.value)}
                placeholder="Professional medical assessment and diagnosis..."
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="treatment_plan">Treatment Plan</Label>
              <Textarea 
                id="treatment_plan"
                value={formData.treatment_plan}
                onChange={(e) => handleChange('treatment_plan', e.target.value)}
                placeholder="Recommended treatment and rehabilitation plan..."
                rows={4}
              />
            </div>
          </div>

          {/* Current Status and Recovery */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="current_status">Current Status</Label>
              <Select value={formData.current_status} onValueChange={(value) => handleChange('current_status', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select current status" />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="expected_return_date">Expected Return Date</Label>
              <Input 
                id="expected_return_date"
                type="date"
                value={formData.expected_return_date}
                onChange={(e) => handleChange('expected_return_date', e.target.value)}
              />
            </div>
          </div>

          {/* Medical Clearance */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="medical_clearance"
                checked={formData.medical_clearance}
                onCheckedChange={(checked) => handleChange('medical_clearance', checked)}
              />
              <Label htmlFor="medical_clearance">Medical clearance received</Label>
            </div>
            
            {formData.medical_clearance && (
              <div className="space-y-2">
                <Label htmlFor="clearance_notes">Clearance Notes</Label>
                <Textarea 
                  id="clearance_notes"
                  value={formData.clearance_notes}
                  onChange={(e) => handleChange('clearance_notes', e.target.value)}
                  placeholder="Notes from medical clearance..."
                  rows={2}
                />
                <div className="space-y-2">
                  <Label htmlFor="actual_return_date">Actual Return Date</Label>
                  <Input 
                    id="actual_return_date"
                    type="date"
                    value={formData.actual_return_date}
                    onChange={(e) => handleChange('actual_return_date', e.target.value)}
                  />
                </div>
              </div>
            )}
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="follow_up_required"
                checked={formData.follow_up_required}
                onCheckedChange={(checked) => handleChange('follow_up_required', checked)}
              />
              <Label htmlFor="follow_up_required">Follow-up appointments required</Label>
            </div>
          </div>

          {/* Additional Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes</Label>
            <Textarea 
              id="notes"
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="Any additional notes or updates..."
              rows={3}
            />
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-end gap-3 border-t pt-6 bg-slate-50/50">
          <Button variant="outline" type="button" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-orange-600 hover:bg-orange-700">
            <Save className="w-4 h-4 mr-2" />
            Save Injury Record
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}