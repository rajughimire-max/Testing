import React, { useState, useEffect } from 'react';
import { UniformAssignment, InventoryItem } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, Shirt, RotateCcw } from 'lucide-react';
import { format } from 'date-fns';

export default function AssignedUniformsList({ player, onUniformReturned }) {
  const [assignments, setAssignments] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (player?.id) {
      const loadData = async () => {
        setLoading(true);
        try {
          const assignmentData = await UniformAssignment.filter({ player_id: player.id, status: 'Assigned' });
          const itemIds = [...new Set(assignmentData.map(a => a.item_id))];
          if (itemIds.length > 0) {
            const itemData = await InventoryItem.filter({ id: { $in: itemIds } });
            setItems(itemData);
          }
          setAssignments(assignmentData);
        } catch (error) {
          console.error("Error loading assigned uniforms:", error);
        } finally {
          setLoading(false);
        }
      };
      loadData();
    }
  }, [player]);
  
  const getItemName = (itemId) => items.find(i => i.id === itemId)?.name || 'Unknown Item';

  const handleReturn = async (assignment) => {
     if (window.confirm(`Are you sure you want to mark the ${assignment.variant_name} ${getItemName(assignment.item_id)} as returned?`)) {
       await onUniformReturned(assignment);
       // Refresh list after parent handles the logic
       setAssignments(prev => prev.filter(a => a.id !== assignment.id));
     }
  }

  if (loading) {
    return <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin" /></div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Shirt className="w-5 h-5"/>Currently Assigned Uniforms</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Item</TableHead>
              <TableHead>Size</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Assigned Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assignments.length > 0 ? assignments.map(assignment => (
              <TableRow key={assignment.id}>
                <TableCell>{getItemName(assignment.item_id)}</TableCell>
                <TableCell>{assignment.variant_name}</TableCell>
                <TableCell>{assignment.quantity}</TableCell>
                <TableCell>{format(new Date(assignment.assigned_date), 'dd MMM yyyy')}</TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm" onClick={() => handleReturn(assignment)}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Return
                  </Button>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan="5" className="text-center h-24">No uniforms currently assigned.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}