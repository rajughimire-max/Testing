
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Shirt } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

import PlayerCard from "./PlayerCard";

export default function PlayerList({
  players,
  teams,
  loading,
  onEdit,
  onDelete,
  highlightedPlayer,
  onDistributeUniform,
  onPlayerDoubleClick,
  onIssueCard // New prop
}) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
        {Array(12).fill(0).map((_, i) => (
          <div key={i} className="w-full max-w-[190px] mx-auto">
            <Skeleton className="h-[280px] rounded-xl" />
          </div>
        ))}
      </div>
    );
  }

  if (players.length === 0) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
        <CardContent className="p-12 text-center">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-medium text-slate-900 mb-2">No players found</h3>
          <p className="text-slate-500">Start building your roster by adding your first player.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 place-items-center">
      {players.map((player) => (
        <PlayerCard
          key={player.id}
          player={player}
          teams={teams}
          onEdit={() => onEdit(player)}
          onDelete={() => onDelete(player.id)}
          isHighlighted={highlightedPlayer === player.id}
          onDistributeUniform={() => onDistributeUniform(player)}
          onPlayerDoubleClick={onPlayerDoubleClick}
          onIssueCard={() => onIssueCard(player)} // Pass handler to PlayerCard
        />
      ))}
    </div>
  );
}
