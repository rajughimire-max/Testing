import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Edit, Eye, Calendar, User } from "lucide-react";
import { format } from 'date-fns';

export default function PlayerInjuryList({ 
  injuries, 
  players, 
  loading, 
  onEdit, 
  onView,
  onAdd 
}) {
  const getPlayerName = (playerId) => {
    const player = players?.find(p => p.id === playerId);
    return player ? `${player.first_name} ${player.last_name}` : 'Unknown Player';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active injury':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Under treatment':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Recovering':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Cleared to play':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Minor':
        return 'bg-blue-100 text-blue-800';
      case 'Moderate':
        return 'bg-yellow-100 text-yellow-800';
      case 'Severe':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading injury records...</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {injuries && injuries.length > 0 ? (
        injuries.map((injury) => (
          <Card key={injury.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-orange-500" />
                    <h4 className="font-semibold text-gray-900">
                      {injury.injury_type} - {injury.body_part}
                    </h4>
                    <Badge className={getSeverityColor(injury.severity)}>
                      {injury.severity}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>{format(new Date(injury.injury_date), 'MMM d, yyyy')}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      <span>{getPlayerName(injury.player_id)}</span>
                    </div>
                    <div>
                      <Badge className={`${getStatusColor(injury.current_status)} text-xs`}>
                        {injury.current_status}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-700 mb-2">
                    <strong>How it happened:</strong> {injury.how_it_happened}
                  </p>
                  
                  {injury.expected_return_date && (
                    <p className="text-sm text-gray-600">
                      <strong>Expected return:</strong> {format(new Date(injury.expected_return_date), 'MMM d, yyyy')}
                    </p>
                  )}
                </div>
                
                <div className="flex gap-2 ml-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => onView(injury)}
                    className="text-blue-600 hover:text-blue-700"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => onEdit(injury)}
                    className="text-gray-600 hover:text-gray-700"
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))
      ) : (
        <Card>
          <CardContent className="text-center py-8">
            <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-700 mb-2">No Injury Records</h3>
            <p className="text-gray-500">This player has no recorded injuries.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}