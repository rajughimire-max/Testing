
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Upload, Plus, Trash2, Loader2, User, Shirt, HeartPulse, Trophy, ChevronsRight, AlertTriangle, FileLock, Camera, UploadCloud, FileText, Settings } from "lucide-react";
import { UploadFile } from "@/api/integrations";
import { Checkbox } from "@/components/ui/checkbox"; // Keep Checkbox for other uses if any
import { Switch } from "@/components/ui/switch"; // New import for Switch
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AssignedUniformsList from "./AssignedUniformsList";
import PlayerInjuryList from "./PlayerInjuryList";
import PlayerInjuryForm from "./PlayerInjuryForm";
import { UniformAssignment, InventoryItem, InventoryTransaction, PlayerInjury, Match, Event, Player } from "@/api/entities";
import { Badge } from "@/components/ui/badge";
import { toast } from 'sonner';
import PlayerContractHistory from './PlayerContractHistory';

// Helper component for image/document uploads
const ImageUpload = ({ label, imageUrl, onImageChange, onImageRemove, accept }) => {
  const fileInputRef = React.useRef(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setLoading(true);
      try {
        await onImageChange(file); // Pass the file up to the parent handler
        toast.success(`'${label}' uploaded successfully.`);
      } catch (error) {
        console.error("Upload error:", error);
        toast.error(`Failed to upload '${label}'.`);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleRemove = () => {
    onImageRemove();
    toast.info(`'${label}' removed.`);
  };

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex items-center gap-4">
        {imageUrl ? (
          <div className="relative group">
            {label.includes('ID Document') ? (
              <a href={imageUrl} target="_blank" rel="noopener noreferrer" className="w-16 h-16 flex items-center justify-center bg-gray-100 rounded-md border border-gray-200" title="View Document">
                <FileText className="w-8 h-8 text-gray-400" />
              </a>
            ) : (
              <img src={imageUrl} alt={label} className="w-16 h-16 rounded-md object-cover border border-gray-200" />
            )}
            <button
              type="button"
              onClick={handleRemove}
              className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              title="Remove"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ) : (
          <div className="w-16 h-16 flex items-center justify-center bg-gray-100 rounded-md border border-gray-200">
            <Camera className="w-8 h-8 text-gray-400" />
          </div>
        )}
        <Input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          disabled={loading}
          className="flex-1"
          accept={accept || "image/*"} // Default to image, but allow specific types like PDF
        />
        {loading && <Loader2 className="w-5 h-5 animate-spin" />}
      </div>
      {label.includes('ID Document') && (
        <p className="text-xs text-slate-500">This document is stored securely and is only visible to administrators.</p>
      )}
    </div>
  );
};

export default function PlayerForm({ player, teams, allPlayers, allContracts, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    first_name: player?.first_name || "",
    last_name: player?.last_name || "",
    email: player?.email || "",
    phone: player?.phone || "",
    date_of_birth: player?.date_of_birth || "",
    id_document_url: player?.id_document_url || "",
    id_document_number: player?.id_document_number || "",
    id_document_expiry_date: player?.id_document_expiry_date || "",
    street_address: player?.street_address || "",
    suburb: player?.suburb || "",
    state: player?.state || "",
    postcode: player?.postcode || "",
    position: player?.position || "",
    preferred_number: player?.preferred_number || "",
    team_id: player?.team_id || "",
    medical_conditions: player?.medical_conditions || "",
    profile_photo_url: player?.profile_photo_url || player?.photo_url || "",
    hero_photo_1_url: player?.hero_photo_1_url || "",
    hero_photo_2_url: player?.hero_photo_2_url || "",
    hero_photo_css_position: player?.hero_photo_css_position || "center",
    achievements: player?.achievements || [],
    status: player?.status || "fit",
    is_active: player?.is_active ?? true,
    is_publicly_visible: player?.is_publicly_visible ?? false,
    height: player?.height || "",
    weight: player?.weight || "",
    uniform_size: player?.uniform_size || "",
    playing_foot: player?.playing_foot || "",
    club_experience: player?.club_experience || "",
    strengths: player?.strengths || [],
    is_available_for_loan: player?.is_available_for_loan ?? false,
    loan_availability: player?.loan_availability || "",
    loan_fee: player?.loan_fee || "",
    is_core_member: player?.is_core_member ?? false, // Add is_core_member to default state
  });

  const [errors, setErrors] = useState({});
  // `uploading` state is now handled within the ImageUpload component, so it can be removed from here.

  const [injuries, setInjuries] = useState([]);
  const [matches, setMatches] = useState([]);
  const [trainingSessions, setTrainingSessions] = useState([]);
  const [showInjuryForm, setShowInjuryForm] = useState(false);
  const [editingInjury, setEditingInjury] = useState(null);
  const [activeTab, setActiveTab] = useState('personal'); // New state for active tab

  const loadInjuryData = useCallback(async () => {
    if (!player?.id) return;

    try {
      const [injuriesData, matchesData, eventsData] = await Promise.all([
        PlayerInjury.filter({ player_id: player.id }),
        Match.list('-match_date'),
        Event.filter({ event_type: 'training' })
      ]);

      setInjuries(injuriesData);
      setMatches(matchesData);
      setTrainingSessions(eventsData);
    } catch (error) {
      console.error('Error loading injury data:', error);
    }
  }, [player?.id]);

  // Main useEffect to initialize form data and load related data when player prop changes
  useEffect(() => {
    if (player) {
      // Set form data from player object for editing
      setFormData({
        first_name: player.first_name || "",
        last_name: player.last_name || "",
        email: player.email || "",
        phone: player.phone || "",
        date_of_birth: player.date_of_birth || "",
        id_document_url: player.id_document_url || "",
        id_document_number: player.id_document_number || "",
        id_document_expiry_date: player.id_document_expiry_date || "",
        street_address: player.street_address || "",
        suburb: player.suburb || "",
        state: player.state || "",
        postcode: player.postcode || "",
        position: player.position || "",
        preferred_number: player.preferred_number || "",
        team_id: player.team_id || "",
        medical_conditions: player.medical_conditions || "",
        profile_photo_url: player.profile_photo_url || player.photo_url || "",
        hero_photo_1_url: player.hero_photo_1_url || "",
        hero_photo_2_url: player.hero_photo_2_url || "",
        hero_photo_css_position: player.hero_photo_css_position || "center",
        achievements: player.achievements || [],
        status: player.status || "fit",
        is_active: player.is_active ?? true,
        is_publicly_visible: player.is_publicly_visible ?? false,
        height: player.height || "",
        weight: player.weight || "",
        uniform_size: player.uniform_size || "",
        playing_foot: player.playing_foot || "",
        club_experience: player.club_experience || "",
        strengths: player.strengths || [],
        is_available_for_loan: player.is_available_for_loan ?? false,
        loan_availability: player.loan_availability || "",
        loan_fee: player.loan_fee || "",
        is_core_member: player.is_core_member ?? false, // Load existing value
      });
      loadInjuryData(); // Load injury data if editing an existing player
    } else {
      // Reset form for adding a new player
      setFormData({
        first_name: "", last_name: "", email: "", phone: "", date_of_birth: "",
        id_document_url: "", id_document_number: "", id_document_expiry_date: "",
        street_address: "", suburb: "", state: "", postcode: "",
        position: "", preferred_number: "", team_id: "", medical_conditions: "",
        profile_photo_url: "", hero_photo_1_url: "", hero_photo_2_url: "",
        hero_photo_css_position: "center", achievements: [], status: "fit",
        is_active: true, is_publicly_visible: false, height: "", weight: "",
        uniform_size: "", playing_foot: "", club_experience: "", strengths: [],
        is_available_for_loan: false, loan_availability: "", loan_fee: "",
        is_core_member: false, // Default for new player
      });
      // Clear injuries and related data for a new player
      setInjuries([]);
      setMatches([]);
      setTrainingSessions([]);
    }
  }, [player, loadInjuryData]);


  const handleInjurySubmit = async (injuryData) => {
    try {
      if (editingInjury) {
        await PlayerInjury.update(editingInjury.id, injuryData);
      } else {
        await PlayerInjury.create(injuryData);
      }

      // Update player status based on injury status
      if (injuryData.current_status === 'Active injury' || injuryData.current_status === 'Under treatment') {
        await Player.update(player.id, { status: 'injured' });
      } else if (injuryData.current_status === 'Recovering') {
        await Player.update(player.id, { status: 'recovering' });
      } else if (injuryData.current_status === 'Cleared to play') {
        await Player.update(player.id, { status: 'fit' });
      }

      setShowInjuryForm(false);
      setEditingInjury(null);
      loadInjuryData(); // Reload injuries after submission
      toast.success('Injury record saved successfully!');
    } catch (error) {
      console.error('Error saving injury:', error);
      toast.error('Failed to save injury record.');
    }
  };

  const handleUniformReturned = async (assignment) => {
    try {
      // 1. Update the assignment status
      await UniformAssignment.update(assignment.id, {
        status: 'Returned',
        returned_date: new Date().toISOString().slice(0, 10),
      });

      // 2. Update inventory
      const item = await InventoryItem.get(assignment.item_id);
      if (item) {
        const updatedVariants = item.variants.map(v =>
          v.name === assignment.variant_name ? { ...v, quantity: v.quantity + assignment.quantity } : v
        );
        const newTotalQuantity = updatedVariants.reduce((sum, v) => sum + v.quantity, 0);

        await InventoryItem.update(item.id, {
          variants: updatedVariants,
          quantity_on_hand: newTotalQuantity
        });
      }

      // 3. Create audit transaction
      await InventoryTransaction.create({
        item_id: assignment.item_id,
        transaction_type: "Check-in",
        quantity_change: assignment.quantity,
        assigned_to_person_id: player.id,
        reason: `Returned by ${player.first_name} ${player.last_name}`
      });

      toast.success("Uniform marked as returned and stock updated.");
      // Optionally, you might want to trigger a re-fetch of uniforms in AssignedUniformsList
      // For this example, we assume AssignedUniformsList handles its own state updates or parent re-renders.
    } catch (error) {
      console.error("Error returning uniform:", error);
      toast.error("Failed to return uniform. See console for details.");
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // New centralized image upload handler for ImageUpload component
  const handleImageUploadChange = async (fieldName, file) => {
    if (!file) {
      handleChange(fieldName, "");
      return;
    }
    try {
      const { file_url } = await UploadFile({ file });
      handleChange(fieldName, file_url);
    } catch (error) {
      console.error(`Error uploading ${fieldName}:`, error);
      throw error; // Re-throw to allow ImageUpload component to catch and show toast
    }
  };

  const handleImageRemove = (fieldName) => {
    handleChange(fieldName, "");
  };

  const handleAchievementChange = (index, value) => {
    const newAchievements = [...formData.achievements];
    newAchievements[index] = value;
    handleChange('achievements', newAchievements);
  };

  const addAchievement = () => {
    handleChange('achievements', [...formData.achievements, ""]);
  };

  const removeAchievement = (index) => {
    const newAchievements = formData.achievements.filter((_, i) => i !== index);
    handleChange('achievements', newAchievements);
  };

  const handleStrengthChange = (index, value) => {
    const newStrengths = [...formData.strengths];
    newStrengths[index] = value;
    handleChange('strengths', newStrengths);
  };

  const addStrength = () => {
    handleChange('strengths', [...formData.strengths, ""]);
  };

  const removeStrength = (index) => {
    const newStrengths = formData.strengths.filter((_, i) => i !== index);
    handleChange('strengths', newStrengths);
  };

  const validateJerseyNumber = (number, teamId) => {
    if (!number || !teamId) {
      setErrors(prev => ({ ...prev, preferred_number: null }));
      return true;
    }

    const isTaken = allPlayers.some(p =>
      String(p.team_id) === String(teamId) &&
      Number(p.preferred_number) === Number(number) &&
      p.id !== player?.id
    );

    if (isTaken) {
      setErrors(prev => ({ ...prev, preferred_number: `Jersey #${number} is already taken on this team.` }));
      return false;
    } else {
      setErrors(prev => ({ ...prev, preferred_number: null }));
      return true;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateJerseyNumber(formData.preferred_number, formData.team_id)) {
      return;
    }
    
    try {
      await onSubmit(formData);
      
      // Reload the Executive Team page if it's open and the function exists
      if (typeof window.reloadExecutiveTeamData === 'function') {
        window.reloadExecutiveTeamData();
      }
    } catch (error) {
      console.error('Error submitting player form:', error);
      toast.error('Failed to save player. Please try again.');
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 mb-6">
      <CardHeader>
        <CardTitle>{player ? "Edit Player" : "Add New Player"}</CardTitle>
        {player && player.player_uid && (
          <Badge variant="outline" className="mt-2 w-fit">ID: {player.player_uid}</Badge>
        )}
      </CardHeader>
      <form onSubmit={handleSubmit}> {/* Form now wraps Tabs and Footer */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-7 px-6"> {/* Increased grid columns for new tab */}
            <TabsTrigger value="personal"><User className="w-4 h-4 mr-2" />Personal</TabsTrigger>
            <TabsTrigger value="playing"><ChevronsRight className="w-4 h-4 mr-2" />Playing Details</TabsTrigger>
            <TabsTrigger value="uniforms" disabled={!player}><Shirt className="w-4 h-4 mr-2" />Uniforms</TabsTrigger>
            <TabsTrigger value="injuries" disabled={!player}><AlertTriangle className="w-4 h-4 mr-2" />Injuries</TabsTrigger>
            <TabsTrigger value="contracts" disabled={!player}><FileText className="w-4 h-4 mr-2" />Contracts</TabsTrigger>
            <TabsTrigger value="medical"><HeartPulse className="w-4 h-4 mr-2" />Medical</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="w-4 h-4 mr-2" />Settings</TabsTrigger> {/* New tab trigger */}
          </TabsList>

          <TabsContent value="personal" className="p-6 space-y-8">
            {/* Player Info */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first_name">First Name *</Label>
                  <Input id="first_name" value={formData.first_name} onChange={(e) => handleChange('first_name', e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last_name">Last Name *</Label>
                  <Input id="last_name" value={formData.last_name} onChange={(e) => handleChange('last_name', e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date_of_birth">Date of Birth</Label>
                  <Input id="date_of_birth" type="date" value={formData.date_of_birth} onChange={(e) => handleChange('date_of_birth', e.target.value)} />
                </div>
              </div>

              {/* ID Document Section */}
              <div className="space-y-4">
                <h4 className="font-medium text-slate-700 text-md">ID Documentation</h4>

                {/* ID Document Upload */}
                <ImageUpload
                  label="ID Document (Passport/License)"
                  imageUrl={formData.id_document_url}
                  onImageChange={(file) => handleImageUploadChange('id_document_url', file)}
                  onImageRemove={() => handleImageRemove('id_document_url')}
                  accept="image/*,application/pdf"
                />

                {/* ID Document Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="id_document_number">ID Document Number</Label>
                    <Input
                      id="id_document_number"
                      value={formData.id_document_number}
                      onChange={(e) => handleChange('id_document_number', e.target.value)}
                      placeholder="e.g., Passport or License Number"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="id_document_expiry_date">ID Document Expiry Date</Label>
                    <Input
                      id="id_document_expiry_date"
                      type="date"
                      value={formData.id_document_expiry_date}
                      onChange={(e) => handleChange('id_document_expiry_date', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Photo Uploads using new ImageUpload */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Player Photos</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <ImageUpload
                  label="Profile Photo"
                  imageUrl={formData.profile_photo_url}
                  onImageChange={(file) => handleImageUploadChange('profile_photo_url', file)}
                  onImageRemove={() => handleImageRemove('profile_photo_url')}
                />
                <ImageUpload
                  label="Hero Photo 1 (Action Shot)"
                  imageUrl={formData.hero_photo_1_url}
                  onImageChange={(file) => handleImageUploadChange('hero_photo_1_url', file)}
                  onImageRemove={() => handleImageRemove('hero_photo_1_url')}
                />
                <ImageUpload
                  label="Hero Photo 2 (Action Shot)"
                  imageUrl={formData.hero_photo_2_url}
                  onImageChange={(file) => handleImageUploadChange('hero_photo_2_url', file)}
                  onImageRemove={() => handleImageRemove('hero_photo_2_url')}
                />
              </div>
              <div className="mt-4 space-y-2 md:w-1/3">
                <Label htmlFor="hero_photo_css_position">Hero Photo Position</Label>
                <Select value={formData.hero_photo_css_position} onValueChange={(value) => handleChange('hero_photo_css_position', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select focal point" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="center">Center</SelectItem>
                    <SelectItem value="top">Top</SelectItem>
                    <SelectItem value="bottom">Bottom</SelectItem>
                    <SelectItem value="left">Left</SelectItem>
                    <SelectItem value="right">Right</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">Adjusts the focus of the main bio image.</p>
              </div>
            </div>

            {/* Contact Details */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Contact Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={formData.email} onChange={(e) => handleChange('email', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" value={formData.phone} onChange={(e) => handleChange('phone', e.target.value)} />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="street_address">Street Address</Label>
                  <Input id="street_address" value={formData.street_address} onChange={(e) => handleChange('street_address', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="suburb">Suburb</Label>
                  <Input id="suburb" value={formData.suburb} onChange={(e) => handleChange('suburb', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Select value={formData.state} onValueChange={(value) => handleChange('state', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACT">ACT</SelectItem>
                      <SelectItem value="NSW">NSW</SelectItem>
                      <SelectItem value="NT">NT</SelectItem>
                      <SelectItem value="QLD">QLD</SelectItem>
                      <SelectItem value="SA">SA</SelectItem>
                      <SelectItem value="TAS">TAS</SelectItem>
                      <SelectItem value="VIC">VIC</SelectItem>
                      <SelectItem value="WA">WA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="postcode">Postcode</Label>
                  <Input id="postcode" value={formData.postcode} onChange={(e) => handleChange('postcode', e.target.value)} />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="playing" className="p-6 space-y-8">
            {/* Physical Attributes */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Physical Attributes</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input id="height" type="number" value={formData.height} onChange={(e) => handleChange('height', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input id="weight" type="number" value={formData.weight} onChange={(e) => handleChange('weight', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uniform_size">Uniform Size</Label>
                  <Select value={formData.uniform_size} onValueChange={(value) => handleChange('uniform_size', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="XS">XS</SelectItem>
                      <SelectItem value="S">S</SelectItem>
                      <SelectItem value="M">M</SelectItem>
                      <SelectItem value="L">L</SelectItem>
                      <SelectItem value="XL">XL</SelectItem>
                      <SelectItem value="XXL">XXL</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="playing_foot">Playing Foot</Label>
                  <Select value={formData.playing_foot} onValueChange={(value) => handleChange('playing_foot', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select foot" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Left">Left</SelectItem>
                      <SelectItem value="Right">Right</SelectItem>
                      <SelectItem value="Both">Both</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Team Details */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Team Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="position">Position</Label>
                  <Input id="position" value={formData.position} onChange={(e) => handleChange('position', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="preferred_number">Preferred Number *</Label>
                  <Input
                    id="preferred_number"
                    type="number"
                    value={formData.preferred_number}
                    onChange={(e) => handleChange('preferred_number', e.target.value)}
                    onBlur={(e) => validateJerseyNumber(e.target.value, formData.team_id)}
                    required
                    className={errors.preferred_number ? 'border-red-500' : ''}
                  />
                  {errors.preferred_number && <p className="text-red-500 text-xs mt-1">{errors.preferred_number}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="team_id">Team</Label>
                  <Select
                    value={formData.team_id}
                    onValueChange={(value) => {
                      handleChange('team_id', value);
                      validateJerseyNumber(formData.preferred_number, value);
                    }}
                  >
                    <SelectTrigger className={errors.preferred_number ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Assign a team" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>No Team</SelectItem>
                      {teams.map(team => (
                        <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Experience & Skills */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Experience & Skills</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="club_experience">Club Experience</Label>
                  <Textarea id="club_experience" value={formData.club_experience} onChange={(e) => handleChange('club_experience', e.target.value)} placeholder="Previous clubs and experience..." rows={4} />
                </div>
                <div className="space-y-2">
                  <Label>Player Strengths</Label>
                  <div className="space-y-2">
                    {formData.strengths.map((strength, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          value={strength}
                          onChange={(e) => handleStrengthChange(index, e.target.value)}
                          placeholder={`Strength #${index + 1}`}
                        />
                        <Button type="button" variant="outline" size="icon" onClick={() => removeStrength(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <Button type="button" variant="outline" size="sm" onClick={addStrength}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Strength
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Achievements</Label>
                <div className="space-y-2">
                  {formData.achievements.map((ach, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input
                        value={ach}
                        onChange={(e) => handleAchievementChange(index, e.target.value)}
                        placeholder={`Achievement #${index + 1}`}
                      />
                      <Button type="button" variant="outline" size="icon" onClick={() => removeAchievement(index)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button type="button" variant="outline" size="sm" onClick={addAchievement}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Achievement
                </Button>
              </div>
            </div>

            {/* Loan Information */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Loan Availability</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch id="is_available_for_loan" checked={formData.is_available_for_loan} onCheckedChange={(checked) => handleChange('is_available_for_loan', checked)} />
                  <Label htmlFor="is_available_for_loan">Available for Loan</Label>
                </div>
                {formData.is_available_for_loan && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="loan_availability">Loan Type</Label>
                      <Select value={formData.loan_availability} onValueChange={(value) => handleChange('loan_availability', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select loan type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Single game">Single game</SelectItem>
                          <SelectItem value="Tournament">Tournament</SelectItem>
                          <SelectItem value="Season loan">Season loan</SelectItem>
                          <SelectItem value="Flexible">Flexible</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="loan_fee">Loan Fee (AUD)</Label>
                      <Input id="loan_fee" type="number" value={formData.loan_fee} onChange={(e) => handleChange('loan_fee', e.target.value)} placeholder="0" />
                    </div>
                  </>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="uniforms" className="p-6 space-y-8">
            {player && <AssignedUniformsList player={player} onUniformReturned={handleUniformReturned} />}
          </TabsContent>

          <TabsContent value="injuries" className="p-6 space-y-8">
            {player && (
              <>
                <div className="flex justify-between items-center">
                  <h3 className="font-medium text-slate-800 text-lg">Injury History</h3>
                  <Button
                    type="button"
                    onClick={() => { setEditingInjury(null); setShowInjuryForm(true); }}
                    className="bg-orange-600 hover:bg-orange-700"
                    size="sm"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Record New Injury
                  </Button>
                </div>

                {showInjuryForm ? (
                  <PlayerInjuryForm
                    injury={editingInjury}
                    player={player}
                    matches={matches}
                    trainingSessions={trainingSessions}
                    onSubmit={handleInjurySubmit}
                    onCancel={() => { setShowInjuryForm(false); setEditingInjury(null); }}
                  />
                ) : (
                  <PlayerInjuryList
                    injuries={injuries}
                    players={[player]} // PlayerInjuryList expects a 'players' array
                    loading={false} // Assume loading is handled by this component's useEffect
                    onEdit={(injury) => { setEditingInjury(injury); setShowInjuryForm(true); }}
                    onView={(injury) => { setEditingInjury(injury); setShowInjuryForm(true); }}
                    onAdd={() => { setEditingInjury(null); setShowInjuryForm(true); }}
                  />
                )}
              </>
            )}
          </TabsContent>

          {/* New Contracts Tab Content */}
          <TabsContent value="contracts" className="p-6 space-y-8">
            {player && <PlayerContractHistory player={player} allContracts={allContracts} />}
          </TabsContent>

          <TabsContent value="medical" className="p-6 space-y-8">
            {/* Medical & Status */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Medical & Status</h3>
              <div className="space-y-2">
                <Label htmlFor="medical_conditions">Medical Conditions & Notes</Label>
                <Textarea id="medical_conditions" value={formData.medical_conditions} onChange={(e) => handleChange('medical_conditions', e.target.value)} rows={4} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Fitness Status</Label>
                <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fit">Fit</SelectItem>
                    <SelectItem value="injured">Injured</SelectItem>
                    <SelectItem value="recovering">Recovering</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          {/* New Settings Tab Content */}
          <TabsContent value="settings" className="p-6 space-y-8">
            <h3 className="font-medium text-slate-800 text-lg border-b pb-2">Player Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-center">
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => handleChange('is_active', checked)}
                />
                <Label htmlFor="is_active">Player is Active</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_publicly_visible"
                  checked={formData.is_publicly_visible}
                  onCheckedChange={(checked) => handleChange('is_publicly_visible', checked)}
                />
                <Label htmlFor="is_publicly_visible">Visible on Public Website</Label>
              </div>
               <div className="flex items-center space-x-2">
                <Switch
                  id="is_core_member"
                  checked={formData.is_core_member}
                  onCheckedChange={(checked) => handleChange('is_core_member', checked)}
                />
                <Label htmlFor="is_core_member">Core Member (Decision Maker)</Label>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <CardFooter className="flex justify-end gap-3 border-t pt-6">
          <Button variant="outline" type="button" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            Save Player
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
