
import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  User, 
  Phone, 
  Mail, 
  Calendar, 
  MapPin, 
  Shirt, 
  Shield,
  Edit,
  Stethoscope, // New icon for injuries
  FileText // New icon for contracts
} from 'lucide-react';
import { format, differenceInYears } from 'date-fns';
import PlayerInjuryList from './PlayerInjuryList'; // New component
import AssignedUniformsList from './AssignedUniformsList'; // New component
import PlayerContractHistory from './PlayerContractHistory'; // New component

export default function PlayerDetailModal({ isOpen, player, teams, allContracts, onClose, onEdit }) {
  // allContracts is passed from parent now, so no need to fetch within modal for contracts.

  if (!player) return null;

  // Helper function to get team name
  const getTeamName = useCallback((teamId) => {
    const team = teams?.find(t => t.id === teamId);
    return team?.name || 'N/A';
  }, [teams]);

  // Helper function to calculate age
  const getAge = (dob) => {
    if (!dob) return 'N/A';
    try {
      return differenceInYears(new Date(), new Date(dob));
    } catch (error) {
      console.error("Error calculating age for DOB:", dob, error);
      return 'N/A';
    }
  };

  // Helper function to get player status badge
  const getStatusBadge = useCallback((status) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'injured':
        return <Badge className="bg-orange-100 text-orange-800">Injured</Badge>;
      case 'inactive':
        return <Badge className="bg-red-100 text-red-800">Inactive</Badge>;
      case 'loaned':
        return <Badge className="bg-blue-100 text-blue-800">Loaned</Badge>;
      default:
        return <Badge variant="secondary">{status || 'Unknown'}</Badge>;
    }
  }, []);

  // DetailItem component for consistent display of player details
  const DetailItem = ({ icon, label, value }) => (
    <div className="flex items-center gap-3">
      <div className="flex-shrink-0 text-slate-500">{icon}</div>
      <div>
        <div className="text-xs text-slate-500">{label}</div>
        <div className="font-medium text-slate-800">{value || 'N/A'}</div>
      </div>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full p-0">
        <div className="flex">
          {/* Left Panel - Player Image and Basic Info */}
          <div className="w-1/3 bg-slate-50 rounded-l-lg p-6 flex flex-col items-center justify-center border-r">
            <img 
              src={player.profile_photo_url || 'https://via.placeholder.com/150'} 
              alt={`${player.first_name} ${player.last_name}`}
              className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-lg"
            />
            <DialogTitle className="text-2xl font-bold mt-4 text-slate-800">{player.first_name} {player.last_name}</DialogTitle>
            <p className="text-slate-600">{player.position}</p>
            <div className="mt-2">{getStatusBadge(player.status)}</div>
          </div>

          {/* Right Panel - Detailed Info */}
          <div className="w-2/3 p-6">
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-4"> {/* Adjusted grid-cols for 4 tabs */}
                <TabsTrigger value="details"><User className="w-4 h-4 mr-2" />Details</TabsTrigger>
                <TabsTrigger value="injuries"><Stethoscope className="w-4 h-4 mr-2" />Injuries</TabsTrigger>
                <TabsTrigger value="uniforms"><Shirt className="w-4 h-4 mr-2" />Uniforms</TabsTrigger>
                <TabsTrigger value="contracts"><FileText className="w-4 h-4 mr-2" />Contracts</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4"> {/* Use grid for better layout */}
                    <DetailItem icon={<Mail className="w-4 h-4" />} label="Email" value={player.email} />
                    <DetailItem icon={<Phone className="w-4 h-4" />} label="Phone" value={player.phone} />
                    <DetailItem icon={<Calendar className="w-4 h-4" />} label="Date of Birth" value={player.date_of_birth ? `${format(new Date(player.date_of_birth), 'PPP')} (${getAge(player.date_of_birth)} years old)` : 'N/A'} />
                    <DetailItem icon={<Shield className="w-4 h-4" />} label="Team" value={getTeamName(player.team_id)} />
                    <DetailItem icon={<Shirt className="w-4 h-4" />} label="Jersey #" value={player.preferred_number} />
                    <DetailItem icon={<User className="w-4 h-4" />} label="Height" value={player.height ? `${player.height} cm` : 'N/A'} />
                    <DetailItem icon={<User className="w-4 h-4" />} label="Weight" value={player.weight ? `${player.weight} kg` : 'N/A'} />
                    <DetailItem icon={<MapPin className="w-4 h-4" />} label="Address" value={[player.suburb, player.state, player.postcode].filter(Boolean).join(', ')} />
                    <DetailItem icon={<FileText className="w-4 h-4" />} label="Loan Status" value={player.is_available_for_loan ? `Available (Fee: $${player.loan_fee || 0})` : 'Not Available'} />
                    {player.achievements && player.achievements.length > 0 && (
                      <div className="col-span-1 md:col-span-2">
                        <div className="text-xs text-slate-500 mb-1">Achievements</div>
                        <div className="flex flex-wrap gap-2">
                          {player.achievements.map((achievement, index) => (
                            <Badge key={index} className="bg-yellow-100 text-yellow-800">
                              {achievement}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                </div>
              </TabsContent>
              
              <TabsContent value="injuries" className="mt-4">
                <PlayerInjuryList player={player} />
              </TabsContent>

              <TabsContent value="uniforms" className="mt-4">
                <AssignedUniformsList player={player} />
              </TabsContent>

              <TabsContent value="contracts" className="mt-4">
                <PlayerContractHistory player={player} allContracts={allContracts} />
              </TabsContent>

            </Tabs>
            
            <DialogFooter className="mt-6 pt-6 border-t">
              <Button variant="outline" onClick={onClose}>Close</Button>
              <Button onClick={() => onEdit(player)}>
                <Edit className="w-4 h-4 mr-2" />
                Edit Player
              </Button>
            </DialogFooter>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
