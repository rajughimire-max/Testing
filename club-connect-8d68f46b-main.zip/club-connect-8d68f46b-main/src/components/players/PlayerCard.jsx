
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Shirt, Star, Edit, Trash2, Eye, CreditCard } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function PlayerCard({
  player,
  teams,
  onEdit,
  onDelete,
  isHighlighted,
  onDistributeUniform,
  onPlayerDoubleClick,
  onIssueCard
}) {
  const team = teams.find((t) => t.id === player.team_id);
  // cardStyle is no longer explicitly used because the new className handles highlighting directly.
  // const cardStyle = isHighlighted ? { boxShadow: '0 0 15px rgba(59, 130, 246, 0.8)' } : {};

  return (
    <Card 
      className={`w-full max-w-[190px] mx-auto relative hover:shadow-xl transition-all duration-300 cursor-pointer group ${
        isHighlighted ? 'ring-2 ring-blue-500 bg-blue-50' : 'bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-lg hover:bg-white'
      }`}
      onDoubleClick={() => onPlayerDoubleClick?.(player)}
    >
      <div className="relative">
        <div className="h-24 bg-slate-200" style={{ backgroundColor: team?.team_color || '#e2e8f0' }}>
          {(player.profile_photo_url) ? (
            <img src={player.profile_photo_url} alt={player.first_name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Users className="w-10 h-10 text-slate-400" />
            </div>
          )}
        </div>
        <Badge className="absolute top-2 right-2 bg-black/50 text-white font-bold text-lg">
          {player.preferred_number}
        </Badge>
      </div>

      <CardContent className="text-center pt-4 pb-3 flex-grow flex flex-col justify-between">
        <div>
          {player.player_uid && (
            <p className="text-xs text-slate-500 font-semibold mb-1">{player.player_uid}</p>
          )}
            <p className="font-bold text-slate-800 leading-tight truncate">{player.first_name} {player.last_name}</p>
            <p className="text-sm text-slate-600">{player.position}</p>
        </div>
        <div className="mt-2">
            {team && (
                <Badge variant="outline" style={{borderColor: team.team_color, color: team.team_color}}>
                    {team.name}
                </Badge>
            )}
        </div>
      </CardContent>
      <div className="p-2 bg-slate-50 border-t">
         <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="w-full text-xs">Actions</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuItem onClick={onEdit}><Edit className="w-3 h-3 mr-2" />Edit Player</DropdownMenuItem>
                <DropdownMenuItem onClick={() => onPlayerDoubleClick?.(player)}><Eye className="w-3 h-3 mr-2" />View Details</DropdownMenuItem>
                <DropdownMenuItem onClick={onDistributeUniform}><Shirt className="w-3 h-3 mr-2" />Distribute Uniform</DropdownMenuItem>
                <DropdownMenuItem onClick={onIssueCard}><CreditCard className="w-3 h-3 mr-2" />Issue Digital Card</DropdownMenuItem>
                <DropdownMenuItem onClick={onDelete} className="text-red-500"><Trash2 className="w-3 h-3 mr-2" />Delete Player</DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </Card>
  );
}
