import React, { useState, useEffect } from 'react';
import { InventoryItem } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Shirt, X, Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function UniformDistributionModal({ player, isOpen, onClose, onDistribute }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);

  useEffect(() => {
    if (isOpen) {
      const fetchUniforms = async () => {
        setLoading(true);
        try {
          const uniformItems = await InventoryItem.filter({ category: 'Kits', has_variants: true });
          setItems(uniformItems.filter(item => item.variants?.some(v => v.quantity > 0)));
        } catch (error) {
          console.error("Error fetching uniform items:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchUniforms();
      setSelectedItems([]); // Reset selected items when modal opens
    }
  }, [isOpen]);

  const addNewItem = () => {
    setSelectedItems([...selectedItems, {
      itemId: '',
      variantName: '',
      quantity: 1,
      availableVariants: []
    }]);
  };

  const removeItem = (index) => {
    setSelectedItems(selectedItems.filter((_, i) => i !== index));
  };

  const updateItem = (index, field, value) => {
    const updated = [...selectedItems];
    updated[index] = { ...updated[index], [field]: value };
    
    // If item is changed, update available variants
    if (field === 'itemId') {
      const item = items.find(i => i.id === value);
      updated[index].availableVariants = item?.variants?.filter(v => v.quantity > 0) || [];
      updated[index].variantName = ''; // Reset variant selection
    }
    
    setSelectedItems(updated);
  };

  const handleDistribute = () => {
    const validItems = selectedItems.filter(item => 
      item.itemId && item.variantName && item.quantity > 0
    );
    
    if (validItems.length === 0) return;
    
    const distributionData = validItems.map(selectedItem => {
      const item = items.find(i => i.id === selectedItem.itemId);
      const variant = selectedItem.availableVariants.find(v => v.name === selectedItem.variantName);
      return {
        item,
        variant,
        quantity: selectedItem.quantity
      };
    });
    
    onDistribute(distributionData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shirt className="w-5 h-5" />
            Distribute Uniforms to {player?.first_name} {player?.last_name}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="w-8 h-8 animate-spin" />
            </div>
          ) : (
            <>
              <div className="space-y-4">
                {selectedItems.map((selectedItem, index) => (
                  <Card key={index} className="p-4 bg-gray-50">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                      <div className="space-y-2">
                        <Label>Uniform Item</Label>
                        <Select 
                          value={selectedItem.itemId} 
                          onValueChange={(value) => updateItem(index, 'itemId', value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select item..." />
                          </SelectTrigger>
                          <SelectContent>
                            {items.map(item => (
                              <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Size</Label>
                        <Select 
                          value={selectedItem.variantName} 
                          onValueChange={(value) => updateItem(index, 'variantName', value)}
                          disabled={!selectedItem.itemId}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select size..." />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedItem.availableVariants.map(variant => (
                              <SelectItem key={variant.name} value={variant.name}>
                                {variant.name} 
                                <Badge variant="outline" className="ml-2">
                                  {variant.quantity} in stock
                                </Badge>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Quantity</Label>
                        <Input
                          type="number"
                          value={selectedItem.quantity}
                          onChange={(e) => updateItem(index, 'quantity', Number(e.target.value))}
                          min="1"
                          max={selectedItem.availableVariants.find(v => v.name === selectedItem.variantName)?.quantity || 1}
                        />
                      </div>
                      
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => removeItem(index)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
              
              <Button 
                variant="outline" 
                onClick={addNewItem} 
                className="w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Another Item
              </Button>
              
              {selectedItems.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Shirt className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Click "Add Another Item" to start selecting uniforms to distribute</p>
                </div>
              )}
            </>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />Cancel
          </Button>
          <Button 
            onClick={handleDistribute} 
            disabled={selectedItems.length === 0 || loading}
            className="bg-red-600 hover:bg-red-700"
          >
            <Shirt className="w-4 h-4 mr-2" />
            Distribute {selectedItems.length > 0 ? `(${selectedItems.length} items)` : ''}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}