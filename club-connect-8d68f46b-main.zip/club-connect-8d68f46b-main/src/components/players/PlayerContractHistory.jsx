import React, { useState, useEffect, useCallback } from 'react';
import { GeneratedContract } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, ExternalLink, RefreshCw, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function PlayerContractHistory({ player, allContracts }) {
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  // Load contracts specifically for this player
  const loadPlayerContracts = useCallback(async () => {
    if (!player?.id) return;
    
    setLoading(true);
    try {
      const playerContracts = await GeneratedContract.filter({
        application_id: player.id,
        application_type: 'player'
      });
      setContracts(playerContracts);
    } catch (error) {
      console.error('Error loading player contracts:', error);
      toast.error('Failed to load contracts');
    } finally {
      setLoading(false);
    }
  }, [player?.id]);

  useEffect(() => {
    loadPlayerContracts();
  }, [loadPlayerContracts]);

  // Delete contract handler with improved error handling
  const handleDeleteContract = async (contract) => {
    if (!window.confirm(`Are you sure you want to delete this contract?\n\nContract: ${contract.template?.name || 'Player Contract'}\nSeason: ${contract.season_name || 'N/A'}\nStatus: ${contract.status}\n\nThis action cannot be undone.`)) {
      return;
    }

    setDeletingId(contract.id);
    try {
      await GeneratedContract.delete(contract.id);
      toast.success('Contract deleted successfully');
      // Remove from local state immediately
      setContracts(prev => prev.filter(c => c.id !== contract.id));
    } catch (error) {
      console.error('Error deleting contract:', error);
      
      // Handle the case where contract doesn't exist anymore
      if (error.message?.includes('Object not found') || error.response?.status === 404) {
        toast.info('Contract was already deleted. Refreshing the list...');
        // Remove from local state since it doesn't exist
        setContracts(prev => prev.filter(c => c.id !== contract.id));
        // Refresh the contracts list to sync with database
        loadPlayerContracts();
      } else {
        toast.error('Failed to delete contract. Please try again.');
      }
    } finally {
      setDeletingId(null);
    }
  };

  // Clean up the contracts list - only show valid contracts
  const displayContracts = contracts.length > 0 ? contracts : 
    (allContracts?.filter(c => c.application_id === player?.id && c.application_type === 'player') || []);

  const sortedContracts = displayContracts.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  const getStatusBadge = (status) => {
    switch (status) {
      case 'signed':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Signed</Badge>;
      case 'sent':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Sent</Badge>;
      case 'viewed':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Viewed</Badge>;
      case 'draft':
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Draft</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (!player) {
    return null;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-medium text-slate-800 text-lg">Contract History</h3>
        <Button variant="outline" size="sm" onClick={loadPlayerContracts} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>
      
      {loading ? (
        <div className="text-center py-8 text-slate-500">
          <RefreshCw className="w-8 h-8 mx-auto mb-4 animate-spin" />
          <p>Loading contracts...</p>
        </div>
      ) : sortedContracts.length === 0 ? (
        <div className="text-center py-8 text-slate-500 bg-slate-50 rounded-lg">
          <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No contracts have been sent to this player yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedContracts.map(contract => (
            <div key={contract.id} className="p-4 border rounded-lg bg-white flex flex-col sm:flex-row justify-between sm:items-center gap-3">
              <div className="flex-1">
                <p className="font-semibold text-slate-800">
                  {contract.template?.name || 'Player Contract'}
                </p>
                <div className="text-sm text-slate-500 mt-1 flex flex-wrap gap-x-4 gap-y-1">
                  <span>Season: <span className="font-medium">{contract.season_name || 'N/A'}</span></span>
                  <span>Sent: <span className="font-medium">
                    {format(new Date(contract.created_date), 'd MMM yyyy')}
                  </span></span>
                  {contract.signed_at && (
                    <span>Signed: <span className="font-medium">
                      {format(new Date(contract.signed_at), 'd MMM yyyy')}
                    </span></span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                {getStatusBadge(contract.status)}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    asChild
                    className="flex items-center gap-2"
                  >
                    <a 
                      href={`/SignPlayerContract?contractId=${contract.id}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                    >
                      View <ExternalLink className="w-3 h-3" />
                    </a>
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleDeleteContract(contract)}
                    disabled={deletingId === contract.id}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                  >
                    {deletingId === contract.id ? (
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    ) : (
                      <Trash2 className="w-3 h-3" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}