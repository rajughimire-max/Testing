import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Smartphone, 
  Download, 
  CreditCard, 
  Shield, 
  Calendar,
  User,
  Trophy,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import { generatePlayerWalletCard } from '@/api/functions';
import { format } from 'date-fns';

export default function PlayerWalletCard({ player, team, season }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [cardStatus, setCardStatus] = useState(null);

  const handleGenerateCard = async (walletType) => {
    setIsGenerating(true);
    try {
      const response = await generatePlayerWalletCard({
        playerId: player.id,
        walletType: walletType
      });

      if (walletType === 'apple') {
        // For Apple, the response should be a downloadable file
        const blob = new Blob([response.data], { type: 'application/vnd.apple.pkpass' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nepbourne-fc-player-${player.preferred_number}.pkpass`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        
        setCardStatus('Apple Wallet card downloaded successfully!');
      } else if (walletType === 'google') {
        // For Google, open the save URL
        if (response.saveUrl) {
          window.open(response.saveUrl, '_blank');
          setCardStatus('Google Wallet save link opened!');
        }
      }
    } catch (error) {
      console.error('Error generating player wallet card:', error);
      setCardStatus('Failed to generate wallet card. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const seasonEndDate = season?.end_date ? new Date(season.end_date) : null;
  const isValidCard = player.is_active && seasonEndDate && seasonEndDate > new Date();

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-800">
          <CreditCard className="w-5 h-5" />
          Player Digital Card
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Player Card Preview */}
        <div 
          className="rounded-xl p-4 text-white relative overflow-hidden"
          style={{ 
            backgroundColor: team?.team_color || '#dc2626',
            backgroundImage: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%)'
          }}
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="text-xs opacity-80 mb-1">NEPBOURNE FC</div>
              <div className="font-bold text-lg">{player.first_name} {player.last_name}</div>
              <div className="text-sm opacity-90">{player.position || 'Player'}</div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-black">#{player.preferred_number}</div>
              <div className="text-xs opacity-80">{team?.name || 'Team'}</div>
            </div>
          </div>
          
          <div className="mt-4 flex justify-between items-end">
            <div className="text-xs opacity-80">
              {season?.name || `${new Date().getFullYear()} Season`}
            </div>
            <div className="flex items-center gap-1">
              {isValidCard ? (
                <>
                  <CheckCircle className="w-3 h-3" />
                  <span className="text-xs">Valid</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3 h-3" />
                  <span className="text-xs">Inactive</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Card Details */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="font-medium text-slate-700">Season</div>
            <div className="text-slate-600">{season?.name || 'Current Season'}</div>
          </div>
          <div>
            <div className="font-medium text-slate-700">Valid Until</div>
            <div className="text-slate-600">
              {seasonEndDate ? format(seasonEndDate, 'MMM d, yyyy') : 'Season End'}
            </div>
          </div>
          <div>
            <div className="font-medium text-slate-700">Last Issued</div>
            <div className="text-slate-600">
              {player.last_card_issued_at ? 
                format(new Date(player.last_card_issued_at), 'MMM d, yyyy') : 
                'Never'
              }
            </div>
          </div>
          <div>
            <div className="font-medium text-slate-700">Status</div>
            <Badge variant={isValidCard ? 'default' : 'secondary'}>
              {isValidCard ? 'Active' : 'Inactive'}
            </Badge>
          </div>
        </div>

        {/* Generate Buttons */}
        {isValidCard && (
          <div className="space-y-2 pt-2 border-t">
            <div className="text-sm font-medium text-slate-700 mb-2">Add to Wallet:</div>
            <div className="flex gap-2">
              <Button
                onClick={() => handleGenerateCard('apple')}
                disabled={isGenerating}
                variant="outline"
                size="sm"
                className="flex-1"
              >
                <Smartphone className="w-4 h-4 mr-2" />
                Apple Wallet
              </Button>
              <Button
                onClick={() => handleGenerateCard('google')}
                disabled={isGenerating}
                variant="outline"
                size="sm"
                className="flex-1"
              >
                <Download className="w-4 h-4 mr-2" />
                Google Wallet
              </Button>
            </div>
          </div>
        )}

        {!isValidCard && (
          <div className="text-center py-4 text-slate-500 text-sm">
            <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-50" />
            Digital card unavailable. Player must be active with a valid season.
          </div>
        )}

        {cardStatus && (
          <div className="text-sm text-center p-2 bg-blue-100 text-blue-800 rounded">
            {cardStatus}
          </div>
        )}
      </CardContent>
    </Card>
  );
}