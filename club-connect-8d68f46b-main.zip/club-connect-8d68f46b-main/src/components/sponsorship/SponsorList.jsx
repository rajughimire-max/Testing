import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, ExternalLink, Facebook, Instagram, Twitter, Linkedin, Calendar, Building, DollarSign, User, Receipt, Send, FileText, Download } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { toast } from "sonner";

export default function SponsorList({ sponsors, tiers, loading, onEdit, onDelete, onGenerateInvoice, invoices }) {
  const [generatingInvoiceId, setGeneratingInvoiceId] = React.useState(null);
  const [sendingInvoiceId, setSendingInvoiceId] = React.useState(null);
  const [downloadingInvoiceId, setDownloadingInvoiceId] = React.useState(null);

  if (loading) return <Skeleton className="h-64" />;

  const getTierName = (tierId) => tiers.find(t => t.id === tierId)?.name || "Unknown Tier";

  const statusColors = {
    Active: "bg-green-100 text-green-800 border-green-200",
    Inactive: "bg-red-100 text-red-800 border-red-200",
    Pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
    "Past Due": "bg-red-100 text-red-800 border-red-200"
  };

  const sponsorTypeColors = {
    general: "bg-blue-100 text-blue-800 border-blue-200",
    event: "bg-purple-100 text-purple-800 border-purple-200"
  };

  const handleGenerateInvoice = async (sponsor) => {
    setGeneratingInvoiceId(sponsor.id);
    try {
      const { generateInvoice } = await import('@/api/functions');
      const response = await generateInvoice({ 
        entityId: sponsor.id, 
        entityType: 'sponsorship' 
      });
      
      if (response.data.success) {
        toast.success(`Invoice generated successfully for ${sponsor.name}`);
        if (onGenerateInvoice) onGenerateInvoice(); // Refresh invoices list
      } else {
        toast.info(response.data.message || 'Could not generate invoice.');
      }
    } catch (error) {
      console.error('Error generating invoice:', error);
      toast.error('Failed to generate invoice. Please try again.');
    } finally {
      setGeneratingInvoiceId(null);
    }
  };

  const handleDownloadInvoice = async (invoiceId) => {
    setDownloadingInvoiceId(invoiceId);
    try {
      const { getInvoiceDownloadUrl } = await import('@/api/functions');
      const response = await getInvoiceDownloadUrl({ invoiceId });
      if (response.data.signed_url) {
        window.open(response.data.signed_url, '_blank');
      } else {
        toast.error(response.data.error || "Could not get download link.");
      }
    } catch (error) {
      console.error('Error downloading invoice:', error);
      toast.error("Failed to download invoice.");
    } finally {
      setDownloadingInvoiceId(null);
    }
  };

  const handleSendInvoiceEmail = async (invoiceId, sponsorName, sponsorEmail) => {
    setSendingInvoiceId(invoiceId);
    try {
      const { sendInvoiceEmail } = await import('@/api/functions');
      const response = await sendInvoiceEmail({ invoiceId });
      if (response.data.success) {
        toast.success(`Invoice sent successfully to ${sponsorEmail}`);
      } else {
        toast.error(response.data.error || "Could not send invoice email.");
      }
    } catch (error) {
      console.error('Error sending invoice email:', error);
      toast.error('Failed to send invoice email.');
    } finally {
      setSendingInvoiceId(null);
    }
  };

  const sortedSponsors = [...sponsors].sort((a, b) => (b.amount || 0) - (a.amount || 0));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sortedSponsors.map(sponsor => {
        const tier = tiers.find(t => t.id === sponsor.sponsorship_tier_id);
        const sponsorInvoice = invoices?.find(inv => 
          inv.related_entity_id === sponsor.id && inv.related_entity_type === 'sponsorship'
        );

        return (
          <Card key={sponsor.id} className="flex flex-col bg-white/80 backdrop-blur-sm border-slate-200/60 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-start gap-4">
              {sponsor.logo_url ? (
                <img src={sponsor.logo_url} alt={sponsor.name} className="w-16 h-16 object-contain rounded-lg border p-1 bg-white"/>
              ) : (
                <div className="w-16 h-16 bg-slate-200 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-slate-500 font-bold text-xl">{sponsor.name.charAt(0)}</span>
                </div>
              )}
              <div className="flex-1">
                <h3 className="font-bold text-xl text-slate-900">{sponsor.name}</h3>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <Badge style={{backgroundColor: tier?.color || '#6b7280', color: 'white'}} className="border-transparent">
                    {getTierName(sponsor.sponsorship_tier_id)}
                  </Badge>
                  <Badge className={statusColors[sponsor.status]}>
                    {sponsor.status}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-grow space-y-4">
              <div className="p-4 bg-slate-50 rounded-lg text-center">
                  <p className="text-sm text-slate-500">Sponsorship Amount</p>
                  <p className="text-3xl font-bold text-slate-800">${sponsor.amount.toLocaleString()}</p>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3 text-slate-600">
                  <User className="w-4 h-4 text-slate-400 flex-shrink-0"/>
                  <span>{sponsor.contact_person || <span className="text-slate-400">No contact person</span>}</span>
                </div>
                <div className="flex items-center gap-3 text-slate-600">
                  <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0"/>
                  {sponsor.start_date && sponsor.end_date ? (
                    <span>{format(new Date(sponsor.start_date), 'MMM d, yyyy')} - {format(new Date(sponsor.end_date), 'MMM d, yyyy')}</span>
                  ) : (
                    <span className="text-slate-400">No sponsorship period set</span>
                  )}
                </div>
                <div className="flex items-center gap-3 text-slate-600">
                  {sponsor.sponsor_type === 'general' ? <Building className="w-4 h-4 text-slate-400 flex-shrink-0"/> : <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0"/>}
                  <span>{sponsor.sponsor_type === 'general' ? 'General Sponsor' : 'Event Sponsor'}</span>
                </div>
              </div>
              
              {tier && tier.benefits && tier.benefits.length > 0 && (
                  <div className="p-3 bg-blue-50/50 rounded-lg">
                    <h4 className="text-sm font-medium text-blue-800 mb-2">Key Benefits:</h4>
                    <ul className="text-xs text-blue-700 space-y-1">
                      {tier.benefits.slice(0, 3).map((benefit, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <span className="w-1 h-1 bg-blue-400 rounded-full"></span>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-between items-center bg-slate-50/70 p-4 border-t">
              <div className="flex gap-1">
                {sponsor.website && (
                  <Button variant="ghost" size="icon" asChild className="text-slate-500 hover:bg-slate-200">
                    <a href={sponsor.website} target="_blank" rel="noopener noreferrer"><ExternalLink className="w-4 h-4"/></a>
                  </Button>
                )}
                {sponsor.facebook_url && (
                  <Button variant="ghost" size="icon" asChild className="text-slate-500 hover:bg-slate-200">
                    <a href={sponsor.facebook_url} target="_blank" rel="noopener noreferrer"><Facebook className="w-4 h-4 text-blue-600"/></a>
                  </Button>
                )}
                {sponsor.instagram_url && (
                  <Button variant="ghost" size="icon" asChild className="text-slate-500 hover:bg-slate-200">
                    <a href={sponsor.instagram_url} target="_blank" rel="noopener noreferrer"><Instagram className="w-4 h-4 text-pink-600"/></a>
                  </Button>
                )}
                {sponsor.linkedin_url && (
                  <Button variant="ghost" size="icon" asChild className="text-slate-500 hover:bg-slate-200">
                    <a href={sponsor.linkedin_url} target="_blank" rel="noopener noreferrer"><Linkedin className="w-4 h-4 text-blue-700"/></a>
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => onEdit(sponsor)}>
                  <Edit className="w-3 h-3 mr-1"/> Edit
                </Button>
                <Button variant="outline" size="sm" className="text-red-600 hover:bg-red-50 hover:text-red-700" onClick={() => onDelete(sponsor.id)}>
                  <Trash2 className="w-3 h-3"/>
                </Button>
              </div>
            </CardFooter>

            {/* Financial Actions Section */}
            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 border-t">
              <h4 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
                <Receipt className="w-4 h-4" />
                Financial Actions
              </h4>
              <div className="flex flex-wrap gap-2">
                {/* Invoice Management */}
                {sponsorInvoice ? (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownloadInvoice(sponsorInvoice.id)}
                      disabled={downloadingInvoiceId === sponsorInvoice.id}
                      className="text-green-600 hover:text-green-700 bg-green-50 border-green-200"
                    >
                      <Download className="w-3 h-3 mr-1" />
                      {downloadingInvoiceId === sponsorInvoice.id ? 'Loading...' : 'View Invoice'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSendInvoiceEmail(sponsorInvoice.id, sponsor.name, sponsor.email)}
                      disabled={sendingInvoiceId === sponsorInvoice.id}
                      className="text-blue-600 hover:text-blue-700 bg-blue-50 border-blue-200"
                    >
                      <Send className="w-3 h-3 mr-1" />
                      {sendingInvoiceId === sponsorInvoice.id ? 'Sending...' : 'Send Invoice'}
                    </Button>
                  </>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleGenerateInvoice(sponsor)}
                    disabled={generatingInvoiceId === sponsor.id}
                    className="text-purple-600 hover:text-purple-700 bg-purple-50 border-purple-200"
                  >
                    <FileText className="w-3 h-3 mr-1" />
                    {generatingInvoiceId === sponsor.id ? 'Generating...' : 'Generate Invoice'}
                  </Button>
                )}

                {/* Tax Receipt (only show for active sponsors with invoices) */}
                {sponsor.status === 'Active' && sponsorInvoice && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleGenerateInvoice(sponsor)} // This generates a receipt/tax invoice
                    className="text-amber-600 hover:text-amber-700 bg-amber-50 border-amber-200"
                  >
                    <Receipt className="w-3 h-3 mr-1" />
                    Tax Receipt
                  </Button>
                )}
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}