import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Star } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function TierList({ tiers, loading, onEdit, onDelete }) {
  if (loading) return <Skeleton className="h-64" />;

  // Sort tiers by minimum_amount (descending) first, then by sort_order (descending) as secondary
  const sortedTiers = [...tiers].sort((a, b) => {
    // Primary sort: by minimum amount (highest first)
    const amountDiff = (b.minimum_amount || 0) - (a.minimum_amount || 0);
    if (amountDiff !== 0) {
      return amountDiff;
    }
    
    // Secondary sort: by sort_order (highest first)
    const sortOrderA = a.sort_order ?? 0;
    const sortOrderB = b.sort_order ?? 0;
    return sortOrderB - sortOrderA;
  });

  return (
    <Card>
      <CardHeader><CardTitle>Sponsorship Tiers ({tiers.length})</CardTitle></CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sortedTiers.map(tier => (
            <div key={tier.id} className="p-6 border rounded-lg bg-white">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-4 h-4 rounded-full" 
                    style={{backgroundColor: tier.color || '#6b7280'}}
                  ></div>
                  <div>
                    <h3 className="font-bold text-xl">{tier.name}</h3>
                    <p className="text-slate-600">{tier.description}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => onEdit(tier)}>
                    <Edit className="w-3 h-3 mr-1"/> Edit
                  </Button>
                  <Button variant="outline" size="sm" className="text-red-600" onClick={() => onDelete(tier.id)}>
                    <Trash2 className="w-3 h-3 mr-1"/> Delete
                  </Button>
                </div>
              </div>

              <div className="flex items-center gap-4 mb-4">
                <div>
                  <p className="text-sm text-slate-500">Sponsorship Range</p>
                  <p className="font-semibold">
                    ${tier.minimum_amount.toLocaleString()}
                    {tier.maximum_amount && ` - $${tier.maximum_amount.toLocaleString()}`}
                  </p>
                </div>
                <Badge variant={tier.is_active ? "default" : "secondary"}>
                  {tier.is_active ? "Active" : "Inactive"}
                </Badge>
              </div>

              {tier.benefits && tier.benefits.length > 0 && (
                <div>
                  <h4 className="font-medium text-slate-900 mb-2 flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    Benefits:
                  </h4>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {tier.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm text-slate-600">
                        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}