import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, Plus, Minus, Zap } from "lucide-react";
import { upsertSponsorshipTier } from "@/api/functions";

export default function TierForm({ tier, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(tier || {
    name: "",
    description: "",
    minimum_amount: "",
    maximum_amount: "",
    benefits: [""],
    color: "#3b82f6",
    is_active: true,
    sort_order: 1
  });
  const [saving, setSaving] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addBenefit = () => {
    setFormData(prev => ({
      ...prev,
      benefits: [...prev.benefits, ""]
    }));
  };

  const removeBenefit = (index) => {
    setFormData(prev => ({
      ...prev,
      benefits: prev.benefits.filter((_, i) => i !== index)
    }));
  };

  const handleBenefitChange = (index, value) => {
    const newBenefits = [...formData.benefits];
    newBenefits[index] = value;
    setFormData(prev => ({ ...prev, benefits: newBenefits }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const filteredBenefits = formData.benefits.filter(benefit => benefit.trim() !== "");
      
      const response = await upsertSponsorshipTier({
        tierIdToUpdate: tier?.id,
        ...formData, 
        minimum_amount: parseFloat(formData.minimum_amount),
        maximum_amount: formData.maximum_amount ? parseFloat(formData.maximum_amount) : null,
        benefits: filteredBenefits
      });

      console.log('Sponsorship tier saved with Stripe integration:', response.data);
      onSubmit(response.data.tier);
      
    } catch (error) {
      console.error('Error saving sponsorship tier:', error);
      if (error.response?.data?.error) {
        alert(`Error: ${error.response.data.error}`);
      } else {
        alert('Failed to save sponsorship tier. Please try again.');
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-yellow-500" />
          {tier ? "Edit Sponsorship Tier" : "Add New Sponsorship Tier"}
        </CardTitle>
        <p className="text-sm text-slate-600">Stripe Product and Price will be created automatically</p>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="name">Tier Name</Label>
              <Input id="name" value={formData.name} onChange={e => handleChange("name", e.target.value)} placeholder="e.g., Platinum, Gold, Silver" required />
            </div>
            <div className="space-y-1">
              <Label htmlFor="color">Tier Color</Label>
              <div className="flex gap-2">
                <Input 
                  id="color" 
                  type="color" 
                  value={formData.color} 
                  onChange={e => handleChange("color", e.target.value)}
                  className="w-16 h-10"
                />
                <Input 
                  value={formData.color} 
                  onChange={e => handleChange("color", e.target.value)}
                  placeholder="#3b82f6"
                  className="flex-1"
                />
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description" 
              value={formData.description} 
              onChange={e => handleChange("description", e.target.value)} 
              placeholder="Description of this sponsorship tier"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="minimum_amount">Minimum Amount ($)</Label>
              <Input 
                id="minimum_amount" 
                type="number" 
                step="0.01" 
                value={formData.minimum_amount} 
                onChange={e => handleChange("minimum_amount", e.target.value)} 
                required 
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="maximum_amount">Maximum Amount ($)</Label>
              <Input 
                id="maximum_amount" 
                type="number" 
                step="0.01" 
                value={formData.maximum_amount} 
                onChange={e => handleChange("maximum_amount", e.target.value)} 
                placeholder="Optional"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="sort_order">Sort Order</Label>
              <Input 
                id="sort_order" 
                type="number" 
                value={formData.sort_order} 
                onChange={e => handleChange("sort_order", parseInt(e.target.value))} 
                placeholder="1"
              />
            </div>
          </div>

          <div className="space-y-3">
            <Label>Benefits</Label>
            {formData.benefits.map((benefit, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  value={benefit}
                  onChange={(e) => handleBenefitChange(index, e.target.value)}
                  placeholder="e.g., Logo on team jersey, Website listing"
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeBenefit(index)}
                  className="text-red-600"
                >
                  <Minus className="w-4 h-4" />
                </Button>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              onClick={addBenefit}
              className="w-full"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Benefit
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => handleChange("is_active", checked)}
            />
            <Label htmlFor="is_active">Tier is active and available for new sponsors</Label>
          </div>

          {tier && tier.stripe_price_id && (
            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800">
                ✅ Connected to Stripe: <code className="font-mono">{tier.stripe_price_id}</code>
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel} disabled={saving}>
            <X className="w-4 h-4 mr-2" />Cancel
          </Button>
          <Button type="submit" disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Creating in Stripe...' : (tier ? "Update" : "Create")}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}