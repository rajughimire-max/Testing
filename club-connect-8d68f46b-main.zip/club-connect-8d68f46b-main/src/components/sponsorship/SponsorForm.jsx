import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Upload, Facebook, Instagram, Twitter, Linkedin } from "lucide-react";
import { UploadFile } from "@/api/integrations";
import { add, formatISO } from "date-fns";

export default function SponsorForm({ sponsor, tiers, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(() => {
    if (sponsor) return sponsor;
    
    // For new sponsors, set default dates based on general sponsorship (1 year)
    const now = new Date();
    const oneYearLater = add(now, { years: 1 });
    
    return {
      name: "",
      logo_url: "",
      sponsor_type: "general",
      sponsorship_tier_id: "",
      amount: "",
      contact_person: "",
      email: "",
      phone: "",
      website: "",
      facebook_url: "",
      instagram_url: "",
      twitter_url: "",
      linkedin_url: "",
      start_date: formatISO(now, { representation: 'date' }),
      end_date: formatISO(oneYearLater, { representation: 'date' }),
      notes: "",
      status: "Pending"
    };
  });

  const [uploading, setUploading] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSponsorTypeChange = (type) => {
    const now = new Date();
    let newFormData = { ...formData, sponsor_type: type };
    
    if (type === "general" && !sponsor) {
      // Set 1-year period for general sponsors
      const oneYearLater = add(now, { years: 1 });
      newFormData.start_date = formatISO(now, { representation: 'date' });
      newFormData.end_date = formatISO(oneYearLater, { representation: 'date' });
    } else if (type === "event" && !sponsor) {
      // Clear dates for event sponsors to be manually set
      newFormData.start_date = "";
      newFormData.end_date = "";
    }
    
    setFormData(newFormData);
  };

  const handleTierChange = (tierId) => {
    const selectedTier = tiers.find(t => t.id === tierId);
    if (selectedTier && !sponsor) {
      // Auto-fill minimum amount for new sponsors
      setFormData(prev => ({ 
        ...prev, 
        sponsorship_tier_id: tierId,
        amount: selectedTier.minimum_amount
      }));
    } else {
      setFormData(prev => ({ ...prev, sponsorship_tier_id: tierId }));
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({ ...prev, logo_url: file_url }));
    } catch (error) {
      console.error("Error uploading file:", error);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({...formData, amount: parseFloat(formData.amount)});
  };

  const selectedTier = tiers.find(t => t.id === formData.sponsorship_tier_id);

  return (
    <Card className="mb-6">
      <CardHeader><CardTitle>{sponsor ? "Edit Sponsor" : "Add New Sponsor"}</CardTitle></CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="name">Sponsor Name</Label>
              <Input id="name" value={formData.name} onChange={e => handleChange("name", e.target.value)} required />
            </div>
            <div className="space-y-1">
              <Label htmlFor="sponsor_type">Sponsor Type</Label>
              <Select value={formData.sponsor_type} onValueChange={handleSponsorTypeChange} required>
                <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Sponsor</SelectItem>
                  <SelectItem value="event">Event Sponsor</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="contact_person">Contact Person</Label>
              <Input id="contact_person" value={formData.contact_person} onChange={e => handleChange("contact_person", e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={formData.email} onChange={e => handleChange("email", e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" value={formData.phone} onChange={e => handleChange("phone", e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="website">Website</Label>
              <Input id="website" type="url" value={formData.website} onChange={e => handleChange("website", e.target.value)} placeholder="https://" />
            </div>
          </div>

          {/* Social Media Links */}
          <div className="space-y-3">
            <Label>Social Media Links</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label htmlFor="facebook_url" className="flex items-center gap-2">
                  <Facebook className="w-4 h-4 text-blue-600" />
                  Facebook
                </Label>
                <Input id="facebook_url" type="url" value={formData.facebook_url} onChange={e => handleChange("facebook_url", e.target.value)} placeholder="https://facebook.com/..." />
              </div>
              <div className="space-y-1">
                <Label htmlFor="instagram_url" className="flex items-center gap-2">
                  <Instagram className="w-4 h-4 text-pink-600" />
                  Instagram
                </Label>
                <Input id="instagram_url" type="url" value={formData.instagram_url} onChange={e => handleChange("instagram_url", e.target.value)} placeholder="https://instagram.com/..." />
              </div>
              <div className="space-y-1">
                <Label htmlFor="twitter_url" className="flex items-center gap-2">
                  <Twitter className="w-4 h-4 text-blue-400" />
                  Twitter/X
                </Label>
                <Input id="twitter_url" type="url" value={formData.twitter_url} onChange={e => handleChange("twitter_url", e.target.value)} placeholder="https://twitter.com/..." />
              </div>
              <div className="space-y-1">
                <Label htmlFor="linkedin_url" className="flex items-center gap-2">
                  <Linkedin className="w-4 h-4 text-blue-700" />
                  LinkedIn
                </Label>
                <Input id="linkedin_url" type="url" value={formData.linkedin_url} onChange={e => handleChange("linkedin_url", e.target.value)} placeholder="https://linkedin.com/..." />
              </div>
            </div>
          </div>

          {/* Logo Upload */}
          <div className="space-y-3">
            <Label>Logo Upload</Label>
            <div className="flex items-center gap-4">
              {formData.logo_url && (
                <img src={formData.logo_url} alt="Sponsor logo" className="w-16 h-16 object-contain border rounded-lg" />
              )}
              <div className="flex-1">
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  disabled={uploading}
                />
                {uploading && <p className="text-sm text-slate-500 mt-1">Uploading...</p>}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="sponsorship_tier_id">Sponsorship Tier</Label>
              <Select value={formData.sponsorship_tier_id} onValueChange={handleTierChange} required>
                <SelectTrigger><SelectValue placeholder="Select tier" /></SelectTrigger>
                <SelectContent>
                  {tiers.filter(t => t.is_active).map(tier => (
                    <SelectItem key={tier.id} value={tier.id}>
                      {tier.name} (${tier.minimum_amount.toLocaleString()}+)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="amount">Amount ($)</Label>
              <Input 
                id="amount" 
                type="number" 
                step="0.01" 
                value={formData.amount} 
                onChange={e => handleChange("amount", e.target.value)} 
                min={selectedTier?.minimum_amount || 0}
                required 
              />
              {selectedTier && (
                <p className="text-xs text-slate-500">
                  Minimum: ${selectedTier.minimum_amount.toLocaleString()}
                  {selectedTier.maximum_amount && ` - Maximum: $${selectedTier.maximum_amount.toLocaleString()}`}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="start_date">Start Date</Label>
              <Input 
                id="start_date" 
                type="date" 
                value={formData.start_date} 
                onChange={e => handleChange("start_date", e.target.value)} 
                required={formData.sponsor_type === "event"}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="end_date">End Date</Label>
              <Input 
                id="end_date" 
                type="date" 
                value={formData.end_date} 
                onChange={e => handleChange("end_date", e.target.value)} 
                required={formData.sponsor_type === "event"}
              />
            </div>
          </div>

          {formData.sponsor_type === "general" && (
            <p className="text-sm text-slate-500 bg-blue-50 p-3 rounded-lg">
              💡 General sponsors automatically get a 1-year sponsorship period. You can adjust the dates above if needed.
            </p>
          )}

          {formData.sponsor_type === "event" && (
            <p className="text-sm text-slate-500 bg-amber-50 p-3 rounded-lg">
              📅 Event sponsors require specific start and end dates for the sponsored event.
            </p>
          )}

          <div className="space-y-1">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" value={formData.notes} onChange={e => handleChange("notes", e.target.value)} placeholder="Additional notes about the sponsorship" />
          </div>

          {/* Show tier benefits if a tier is selected */}
          {selectedTier && selectedTier.benefits && selectedTier.benefits.length > 0 && (
            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="font-medium text-slate-900 mb-2">{selectedTier.name} Tier Benefits:</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                {selectedTier.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" />Cancel</Button>
          <Button type="submit" disabled={uploading}><Save className="w-4 h-4 mr-2" />{sponsor ? "Update" : "Create"}</Button>
        </CardFooter>
      </form>
    </Card>
  );
}