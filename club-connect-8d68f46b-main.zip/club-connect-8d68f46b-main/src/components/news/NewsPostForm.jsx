
import React, { useState, useEffect, useCallback } from 'react';
import { NewsPost } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { UploadFile } from '@/api/integrations';
import { toast } from 'sonner';
import { X, UploadCloud } from 'lucide-react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

function slugify(text) {
  return text.toString().toLowerCase()
    .replace(/\s+/g, '-')           // Replace spaces with -
    .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
    .replace(/\-\-+/g, '-')         // Replace multiple - with single -
    .replace(/^-+/, '')             // Trim - from start of text
    .replace(/-+$/, '');            // Trim - from end of text
}

export default function NewsPostForm({ post, onSuccess, onCancel }) {
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    summary: '',
    content: '',
    hero_media_type: 'image',
    hero_image_url: '',
    hero_video_url: '',
    gallery: [],
    action_button_label: '',
    action_button_url: '',
    action_button_target: '_self',
    tags: [],
    publish_status: 'draft',
    publish_at: '',
    author: '',
    seo_meta_title: '',
    seo_meta_description: ''
  });
  const [isSlugManuallyEdited, setIsSlugManuallyEdited] = useState(false);
  const [currentTag, setCurrentTag] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (post) {
      setFormData({
        ...post,
        tags: post.tags || [],
        gallery: post.gallery || [],
        publish_at: post.publish_at ? post.publish_at.slice(0, 16) : ''
      });
      setIsSlugManuallyEdited(true);
    }
  }, [post]);

  const handleTitleChange = (e) => {
    const newTitle = e.target.value;
    setFormData(prev => ({...prev, title: newTitle}));
    if (!isSlugManuallyEdited) {
      setFormData(prev => ({...prev, slug: slugify(newTitle)}));
    }
  };

  const handleSlugChange = (e) => {
    setIsSlugManuallyEdited(true);
    setFormData(prev => ({...prev, slug: e.target.value}));
  };
  
  const handleFileUpload = async (file, field) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({...prev, [field]: file_url}));
      toast.success('File uploaded successfully!');
    } catch(err) {
      toast.error('File upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const handleTagAdd = () => {
    if (currentTag && !formData.tags.includes(currentTag)) {
      setFormData(prev => ({...prev, tags: [...prev.tags, currentTag]}));
      setCurrentTag('');
    }
  };
  
  const handleTagRemove = (tagToRemove) => {
    setFormData(prev => ({...prev, tags: prev.tags.filter(tag => tag !== tagToRemove)}));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const dataToSave = { ...formData };
    if (!dataToSave.publish_at) {
        delete dataToSave.publish_at;
    }
    
    try {
      if (post?.id) {
        await NewsPost.update(post.id, dataToSave);
        toast.success('Post updated successfully.');
      } else {
        await NewsPost.create(dataToSave);
        toast.success('Post created successfully.');
      }
      onSuccess();
    } catch (error) {
      console.error('Failed to save post:', error);
      toast.error('Failed to save post.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" value={formData.title} onChange={handleTitleChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="slug">URL Slug</Label>
          <Input id="slug" value={formData.slug} onChange={handleSlugChange} required />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="summary">Summary</Label>
        <Textarea id="summary" value={formData.summary} onChange={(e) => setFormData(p => ({...p, summary: e.target.value}))} required />
      </div>

      <div className="space-y-2">
        <Label>Content</Label>
        <ReactQuill theme="snow" value={formData.content} onChange={(value) => setFormData(p => ({...p, content: value}))} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Hero Media</CardTitle>
          <CardDescription>Choose an image or video for the top of the article.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
           <Select value={formData.hero_media_type} onValueChange={(v) => setFormData(p => ({...p, hero_media_type: v}))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="image">Image</SelectItem>
              <SelectItem value="video">Video</SelectItem>
            </SelectContent>
          </Select>
          {formData.hero_media_type === 'image' ? (
            <div>
              <Label>Hero Image</Label>
              <Input type="file" onChange={(e) => handleFileUpload(e.target.files[0], 'hero_image_url')} disabled={uploading} />
              {formData.hero_image_url && <img src={formData.hero_image_url} alt="Hero preview" className="mt-2 h-32 object-cover" />}
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Hero Video</Label>
              <div className="flex items-center gap-4">
                <Input 
                    value={formData.hero_video_url} 
                    onChange={(e) => setFormData(p => ({...p, hero_video_url: e.target.value}))} 
                    placeholder="Upload a video or paste a URL"
                    className="flex-1"
                />
                <Button asChild variant="outline" disabled={uploading} type="button">
                  <label htmlFor="video-upload" className="cursor-pointer">
                    <UploadCloud className="w-4 h-4 mr-2" />
                    {uploading ? "Uploading..." : "Upload"}
                  </label>
                </Button>
                <input 
                  id="video-upload" 
                  type="file" 
                  className="hidden" 
                  onChange={(e) => handleFileUpload(e.target.files[0], 'hero_video_url')} 
                  accept="video/mp4,video/webm,video/ogg" 
                />
              </div>
              {formData.hero_video_url && (
                <div className="mt-2 text-sm text-slate-500">
                  Current video source: <span className="font-mono break-all">{formData.hero_video_url}</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Publish Settings</CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={formData.publish_status} onValueChange={(v) => setFormData(p => ({...p, publish_status: v}))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="published">Published</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Publish At (optional)</Label>
            <Input type="datetime-local" value={formData.publish_at} onChange={(e) => setFormData(p => ({...p, publish_at: e.target.value}))} />
          </div>
          <div className="space-y-2">
            <Label>Author</Label>
            <Input value={formData.author} onChange={(e) => setFormData(p => ({...p, author: e.target.value}))} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Tags</CardTitle></CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-2">
            {formData.tags.map(tag => (
              <span key={tag} className="flex items-center gap-1 bg-gray-200 px-2 py-1 rounded">
                {tag} <X className="w-4 h-4 cursor-pointer" onClick={() => handleTagRemove(tag)} />
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <Input value={currentTag} onChange={(e) => setCurrentTag(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleTagAdd())} />
            <Button type="button" onClick={handleTagAdd}>Add Tag</Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit">Save Post</Button>
      </div>
    </form>
  );
}
