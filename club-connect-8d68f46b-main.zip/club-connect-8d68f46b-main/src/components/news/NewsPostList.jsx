import React, { useState, useEffect } from 'react';
import { NewsPost } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { toast } from 'sonner';
import NewsPostForm from './NewsPostForm';

export default function NewsPostList() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPost, setEditingPost] = useState(null);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    setLoading(true);
    try {
      const data = await NewsPost.list('-created_date');
      setPosts(data);
    } catch (error) {
      console.error("Failed to load news posts:", error);
      toast.error("Could not load news posts.");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (post) => {
    setEditingPost(post);
    setShowForm(true);
  };

  const handleDelete = async (postId) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      try {
        await NewsPost.delete(postId);
        toast.success('Post deleted successfully.');
        loadPosts();
      } catch (error) {
        console.error('Failed to delete post:', error);
        toast.error('Failed to delete post.');
      }
    }
  };

  const handleFormSuccess = () => {
    setShowForm(false);
    setEditingPost(null);
    loadPosts();
  };

  const statusColors = {
    draft: 'bg-yellow-100 text-yellow-800',
    published: 'bg-green-100 text-green-800',
  };

  if (loading) return <div>Loading news posts...</div>;

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>News Posts</CardTitle>
            <CardDescription>Create and manage news articles for your public website.</CardDescription>
          </div>
          <Button onClick={() => { setEditingPost(null); setShowForm(true); }}>
            <Plus className="w-4 h-4 mr-2" /> Add News Post
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {showForm ? (
          <NewsPostForm post={editingPost} onSuccess={handleFormSuccess} onCancel={() => setShowForm(false)} />
        ) : (
          <div className="space-y-4">
            {posts.map(post => (
              <Card key={post.id}>
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <h4 className="font-semibold">{post.title}</h4>
                    <p className="text-sm text-gray-500">
                      Last updated: {format(parseISO(post.updated_date), 'dd MMM yyyy')}
                    </p>
                    <div className="mt-2 flex gap-2">
                       <Badge className={statusColors[post.publish_status]}>{post.publish_status}</Badge>
                       {post.tags?.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleEdit(post)}>
                      <Edit className="w-4 h-4 mr-2" /> Edit
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDelete(post.id)}>
                      <Trash2 className="w-4 h-4 mr-2" /> Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            {posts.length === 0 && <p className="text-center text-gray-500 py-8">No news posts found.</p>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}